(globalThis["webpackChunkaluga_ufc"]=globalThis["webpackChunkaluga_ufc"]||[]).push([[736],{5505:(e,t,n)=>{"use strict";n.d(t,{BH:()=>b,L:()=>l,LL:()=>O,P0:()=>m,Pz:()=>y,Sg:()=>w,UG:()=>E,ZR:()=>R,aH:()=>v,b$:()=>T,eu:()=>x,hl:()=>I,m9:()=>z,ne:()=>U,pd:()=>V,q4:()=>g,ru:()=>k,tV:()=>u,uI:()=>S,vZ:()=>L,w1:()=>C,xO:()=>M,xb:()=>F,z$:()=>_,zd:()=>q});
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r=function(e){const t=[];let n=0;for(let r=0;r<e.length;r++){let i=e.charCodeAt(r);i<128?t[n++]=i:i<2048?(t[n++]=i>>6|192,t[n++]=63&i|128):55296===(64512&i)&&r+1<e.length&&56320===(64512&e.charCodeAt(r+1))?(i=65536+((1023&i)<<10)+(1023&e.charCodeAt(++r)),t[n++]=i>>18|240,t[n++]=i>>12&63|128,t[n++]=i>>6&63|128,t[n++]=63&i|128):(t[n++]=i>>12|224,t[n++]=i>>6&63|128,t[n++]=63&i|128)}return t},i=function(e){const t=[];let n=0,r=0;while(n<e.length){const i=e[n++];if(i<128)t[r++]=String.fromCharCode(i);else if(i>191&&i<224){const o=e[n++];t[r++]=String.fromCharCode((31&i)<<6|63&o)}else if(i>239&&i<365){const o=e[n++],s=e[n++],a=e[n++],l=((7&i)<<18|(63&o)<<12|(63&s)<<6|63&a)-65536;t[r++]=String.fromCharCode(55296+(l>>10)),t[r++]=String.fromCharCode(56320+(1023&l))}else{const o=e[n++],s=e[n++];t[r++]=String.fromCharCode((15&i)<<12|(63&o)<<6|63&s)}}return t.join("")},o={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:"function"===typeof atob,encodeByteArray(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let i=0;i<e.length;i+=3){const t=e[i],o=i+1<e.length,s=o?e[i+1]:0,a=i+2<e.length,l=a?e[i+2]:0,u=t>>2,c=(3&t)<<4|s>>4;let d=(15&s)<<2|l>>6,h=63&l;a||(h=64,o||(d=64)),r.push(n[u],n[c],n[d],n[h])}return r.join("")},encodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(r(e),t)},decodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):i(this.decodeStringToByteArray(e,t))},decodeStringToByteArray(e,t){this.init_();const n=t?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let i=0;i<e.length;){const t=n[e.charAt(i++)],o=i<e.length,a=o?n[e.charAt(i)]:0;++i;const l=i<e.length,u=l?n[e.charAt(i)]:64;++i;const c=i<e.length,d=c?n[e.charAt(i)]:64;if(++i,null==t||null==a||null==u||null==d)throw new s;const h=t<<2|a>>4;if(r.push(h),64!==u){const e=a<<4&240|u>>2;if(r.push(e),64!==d){const e=u<<6&192|d;r.push(e)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class s extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const a=function(e){const t=r(e);return o.encodeByteArray(t,!0)},l=function(e){return a(e).replace(/\./g,"")},u=function(e){try{return o.decodeString(e,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function c(){if("undefined"!==typeof self)return self;if("undefined"!==typeof window)return window;if("undefined"!==typeof n.g)return n.g;throw new Error("Unable to locate global object.")}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const d=()=>c().__FIREBASE_DEFAULTS__,h=()=>{if("undefined"===typeof process||"undefined"===typeof process.env)return;const e=process.env.__FIREBASE_DEFAULTS__;return e?JSON.parse(e):void 0},f=()=>{if("undefined"===typeof document)return;let e;try{e=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch(n){return}const t=e&&u(e[1]);return t&&JSON.parse(t)},p=()=>{try{return d()||h()||f()}catch(e){return void console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`)}},g=e=>{var t,n;return null===(n=null===(t=p())||void 0===t?void 0:t.emulatorHosts)||void 0===n?void 0:n[e]},m=e=>{const t=g(e);if(!t)return;const n=t.lastIndexOf(":");if(n<=0||n+1===t.length)throw new Error(`Invalid host ${t} with no separate hostname and port!`);const r=parseInt(t.substring(n+1),10);return"["===t[0]?[t.substring(1,n-1),r]:[t.substring(0,n),r]},v=()=>{var e;return null===(e=p())||void 0===e?void 0:e.config},y=e=>{var t;return null===(t=p())||void 0===t?void 0:t[`_${e}`]};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class b{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise(((e,t)=>{this.resolve=e,this.reject=t}))}wrapCallback(e){return(t,n)=>{t?this.reject(t):this.resolve(n),"function"===typeof e&&(this.promise.catch((()=>{})),1===e.length?e(t):e(t,n))}}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function w(e,t){if(e.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const n={alg:"none",type:"JWT"},r=t||"demo-project",i=e.iat||0,o=e.sub||e.user_id;if(!o)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const s=Object.assign({iss:`https://securetoken.google.com/${r}`,aud:r,iat:i,exp:i+3600,auth_time:i,sub:o,user_id:o,firebase:{sign_in_provider:"custom",identities:{}}},e),a="";return[l(JSON.stringify(n)),l(JSON.stringify(s)),a].join(".")}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _(){return"undefined"!==typeof navigator&&"string"===typeof navigator["userAgent"]?navigator["userAgent"]:""}function S(){return"undefined"!==typeof window&&!!(window["cordova"]||window["phonegap"]||window["PhoneGap"])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(_())}function E(){var e;const t=null===(e=p())||void 0===e?void 0:e.forceEnvironment;if("node"===t)return!0;if("browser"===t)return!1;try{return"[object process]"===Object.prototype.toString.call(n.g.process)}catch(r){return!1}}function k(){const e="object"===typeof chrome?chrome.runtime:"object"===typeof browser?browser.runtime:void 0;return"object"===typeof e&&void 0!==e.id}function T(){return"object"===typeof navigator&&"ReactNative"===navigator["product"]}function C(){const e=_();return e.indexOf("MSIE ")>=0||e.indexOf("Trident/")>=0}function I(){try{return"object"===typeof indexedDB}catch(e){return!1}}function x(){return new Promise(((e,t)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(r);i.onsuccess=()=>{i.result.close(),n||self.indexedDB.deleteDatabase(r),e(!0)},i.onupgradeneeded=()=>{n=!1},i.onerror=()=>{var e;t((null===(e=i.error)||void 0===e?void 0:e.message)||"")}}catch(n){t(n)}}))}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const A="FirebaseError";class R extends Error{constructor(e,t,n){super(t),this.code=e,this.customData=n,this.name=A,Object.setPrototypeOf(this,R.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,O.prototype.create)}}class O{constructor(e,t,n){this.service=e,this.serviceName=t,this.errors=n}create(e,...t){const n=t[0]||{},r=`${this.service}/${e}`,i=this.errors[e],o=i?N(i,n):"Error",s=`${this.serviceName}: ${o} (${r}).`,a=new R(r,s,n);return a}}function N(e,t){return e.replace(P,((e,n)=>{const r=t[n];return null!=r?String(r):`<${n}?>`}))}const P=/\{\$([^}]+)}/g;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function F(e){for(const t in e)if(Object.prototype.hasOwnProperty.call(e,t))return!1;return!0}function L(e,t){if(e===t)return!0;const n=Object.keys(e),r=Object.keys(t);for(const i of n){if(!r.includes(i))return!1;const n=e[i],o=t[i];if(D(n)&&D(o)){if(!L(n,o))return!1}else if(n!==o)return!1}for(const i of r)if(!n.includes(i))return!1;return!0}function D(e){return null!==e&&"object"===typeof e}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function M(e){const t=[];for(const[n,r]of Object.entries(e))Array.isArray(r)?r.forEach((e=>{t.push(encodeURIComponent(n)+"="+encodeURIComponent(e))})):t.push(encodeURIComponent(n)+"="+encodeURIComponent(r));return t.length?"&"+t.join("&"):""}function q(e){const t={},n=e.replace(/^\?/,"").split("&");return n.forEach((e=>{if(e){const[n,r]=e.split("=");t[decodeURIComponent(n)]=decodeURIComponent(r)}})),t}function V(e){const t=e.indexOf("?");if(!t)return"";const n=e.indexOf("#",t);return e.substring(t,n>0?n:void 0)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function U(e,t){const n=new B(e,t);return n.subscribe.bind(n)}class B{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then((()=>{e(this)})).catch((e=>{this.error(e)}))}next(e){this.forEachObserver((t=>{t.next(e)}))}error(e){this.forEachObserver((t=>{t.error(e)})),this.close(e)}complete(){this.forEachObserver((e=>{e.complete()})),this.close()}subscribe(e,t,n){let r;if(void 0===e&&void 0===t&&void 0===n)throw new Error("Missing Observer.");r=$(e,["next","error","complete"])?e:{next:e,error:t,complete:n},void 0===r.next&&(r.next=j),void 0===r.error&&(r.error=j),void 0===r.complete&&(r.complete=j);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then((()=>{try{this.finalError?r.error(this.finalError):r.complete()}catch(e){}})),this.observers.push(r),i}unsubscribeOne(e){void 0!==this.observers&&void 0!==this.observers[e]&&(delete this.observers[e],this.observerCount-=1,0===this.observerCount&&void 0!==this.onNoObservers&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then((()=>{if(void 0!==this.observers&&void 0!==this.observers[e])try{t(this.observers[e])}catch(n){"undefined"!==typeof console&&console.error&&console.error(n)}}))}close(e){this.finalized||(this.finalized=!0,void 0!==e&&(this.finalError=e),this.task.then((()=>{this.observers=void 0,this.onNoObservers=void 0})))}}function $(e,t){if("object"!==typeof e||null===e)return!1;for(const n of t)if(n in e&&"function"===typeof e[n])return!0;return!1}function j(){}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function z(e){return e&&e._delegate?e._delegate:e}},9984:e=>{e.exports=function(e,t,n){const r=void 0!==e.__vccOpts?e.__vccOpts:e,i=r[t];if(void 0===i)r[t]=n;else for(const o in n)void 0===i[o]&&(i[o]=n[o])}},499:(e,t,n)=>{"use strict";n.d(t,{Bj:()=>o,Fl:()=>He,IU:()=>Re,Jd:()=>k,PG:()=>Ce,SU:()=>Be,Um:()=>Ee,WL:()=>je,X$:()=>x,X3:()=>Ae,XI:()=>qe,Xl:()=>Oe,dq:()=>De,iH:()=>Me,j:()=>C,lk:()=>T,nZ:()=>a,qj:()=>Se,qq:()=>w,yT:()=>xe});var r=n(6970);let i;class o{constructor(e=!1){this.detached=e,this._active=!0,this.effects=[],this.cleanups=[],this.parent=i,!e&&i&&(this.index=(i.scopes||(i.scopes=[])).push(this)-1)}get active(){return this._active}run(e){if(this._active){const t=i;try{return i=this,e()}finally{i=t}}else 0}on(){i=this}off(){i=this.parent}stop(e){if(this._active){let t,n;for(t=0,n=this.effects.length;t<n;t++)this.effects[t].stop();for(t=0,n=this.cleanups.length;t<n;t++)this.cleanups[t]();if(this.scopes)for(t=0,n=this.scopes.length;t<n;t++)this.scopes[t].stop(!0);if(!this.detached&&this.parent&&!e){const e=this.parent.scopes.pop();e&&e!==this&&(this.parent.scopes[this.index]=e,e.index=this.index)}this.parent=void 0,this._active=!1}}}function s(e,t=i){t&&t.active&&t.effects.push(e)}function a(){return i}const l=e=>{const t=new Set(e);return t.w=0,t.n=0,t},u=e=>(e.w&g)>0,c=e=>(e.n&g)>0,d=({deps:e})=>{if(e.length)for(let t=0;t<e.length;t++)e[t].w|=g},h=e=>{const{deps:t}=e;if(t.length){let n=0;for(let r=0;r<t.length;r++){const i=t[r];u(i)&&!c(i)?i.delete(e):t[n++]=i,i.w&=~g,i.n&=~g}t.length=n}},f=new WeakMap;let p=0,g=1;const m=30;let v;const y=Symbol(""),b=Symbol("");class w{constructor(e,t=null,n){this.fn=e,this.scheduler=t,this.active=!0,this.deps=[],this.parent=void 0,s(this,n)}run(){if(!this.active)return this.fn();let e=v,t=S;while(e){if(e===this)return;e=e.parent}try{return this.parent=v,v=this,S=!0,g=1<<++p,p<=m?d(this):_(this),this.fn()}finally{p<=m&&h(this),g=1<<--p,v=this.parent,S=t,this.parent=void 0,this.deferStop&&this.stop()}}stop(){v===this?this.deferStop=!0:this.active&&(_(this),this.onStop&&this.onStop(),this.active=!1)}}function _(e){const{deps:t}=e;if(t.length){for(let n=0;n<t.length;n++)t[n].delete(e);t.length=0}}let S=!0;const E=[];function k(){E.push(S),S=!1}function T(){const e=E.pop();S=void 0===e||e}function C(e,t,n){if(S&&v){let t=f.get(e);t||f.set(e,t=new Map);let r=t.get(n);r||t.set(n,r=l());const i=void 0;I(r,i)}}function I(e,t){let n=!1;p<=m?c(e)||(e.n|=g,n=!u(e)):n=!e.has(v),n&&(e.add(v),v.deps.push(e))}function x(e,t,n,i,o,s){const a=f.get(e);if(!a)return;let u=[];if("clear"===t)u=[...a.values()];else if("length"===n&&(0,r.kJ)(e)){const e=Number(i);a.forEach(((t,n)=>{("length"===n||n>=e)&&u.push(t)}))}else switch(void 0!==n&&u.push(a.get(n)),t){case"add":(0,r.kJ)(e)?(0,r.S0)(n)&&u.push(a.get("length")):(u.push(a.get(y)),(0,r._N)(e)&&u.push(a.get(b)));break;case"delete":(0,r.kJ)(e)||(u.push(a.get(y)),(0,r._N)(e)&&u.push(a.get(b)));break;case"set":(0,r._N)(e)&&u.push(a.get(y));break}if(1===u.length)u[0]&&A(u[0]);else{const e=[];for(const t of u)t&&e.push(...t);A(l(e))}}function A(e,t){const n=(0,r.kJ)(e)?e:[...e];for(const r of n)r.computed&&R(r,t);for(const r of n)r.computed||R(r,t)}function R(e,t){(e!==v||e.allowRecurse)&&(e.scheduler?e.scheduler():e.run())}const O=(0,r.fY)("__proto__,__v_isRef,__isVue"),N=new Set(Object.getOwnPropertyNames(Symbol).filter((e=>"arguments"!==e&&"caller"!==e)).map((e=>Symbol[e])).filter(r.yk)),P=V(),F=V(!1,!0),L=V(!0),D=M();function M(){const e={};return["includes","indexOf","lastIndexOf"].forEach((t=>{e[t]=function(...e){const n=Re(this);for(let t=0,i=this.length;t<i;t++)C(n,"get",t+"");const r=n[t](...e);return-1===r||!1===r?n[t](...e.map(Re)):r}})),["push","pop","shift","unshift","splice"].forEach((t=>{e[t]=function(...e){k();const n=Re(this)[t].apply(this,e);return T(),n}})),e}function q(e){const t=Re(this);return C(t,"has",e),t.hasOwnProperty(e)}function V(e=!1,t=!1){return function(n,i,o){if("__v_isReactive"===i)return!e;if("__v_isReadonly"===i)return e;if("__v_isShallow"===i)return t;if("__v_raw"===i&&o===(e?t?be:ye:t?ve:me).get(n))return n;const s=(0,r.kJ)(n);if(!e){if(s&&(0,r.RI)(D,i))return Reflect.get(D,i,o);if("hasOwnProperty"===i)return q}const a=Reflect.get(n,i,o);return((0,r.yk)(i)?N.has(i):O(i))?a:(e||C(n,"get",i),t?a:De(a)?s&&(0,r.S0)(i)?a:a.value:(0,r.Kn)(a)?e?ke(a):Se(a):a)}}const U=$(),B=$(!0);function $(e=!1){return function(t,n,i,o){let s=t[n];if(Ie(s)&&De(s)&&!De(i))return!1;if(!e&&(xe(i)||Ie(i)||(s=Re(s),i=Re(i)),!(0,r.kJ)(t)&&De(s)&&!De(i)))return s.value=i,!0;const a=(0,r.kJ)(t)&&(0,r.S0)(n)?Number(n)<t.length:(0,r.RI)(t,n),l=Reflect.set(t,n,i,o);return t===Re(o)&&(a?(0,r.aU)(i,s)&&x(t,"set",n,i,s):x(t,"add",n,i)),l}}function j(e,t){const n=(0,r.RI)(e,t),i=e[t],o=Reflect.deleteProperty(e,t);return o&&n&&x(e,"delete",t,void 0,i),o}function z(e,t){const n=Reflect.has(e,t);return(0,r.yk)(t)&&N.has(t)||C(e,"has",t),n}function H(e){return C(e,"iterate",(0,r.kJ)(e)?"length":y),Reflect.ownKeys(e)}const K={get:P,set:U,deleteProperty:j,has:z,ownKeys:H},W={get:L,set(e,t){return!0},deleteProperty(e,t){return!0}},Z=(0,r.l7)({},K,{get:F,set:B}),G=e=>e,J=e=>Reflect.getPrototypeOf(e);function Q(e,t,n=!1,r=!1){e=e["__v_raw"];const i=Re(e),o=Re(t);n||(t!==o&&C(i,"get",t),C(i,"get",o));const{has:s}=J(i),a=r?G:n?Pe:Ne;return s.call(i,t)?a(e.get(t)):s.call(i,o)?a(e.get(o)):void(e!==i&&e.get(t))}function Y(e,t=!1){const n=this["__v_raw"],r=Re(n),i=Re(e);return t||(e!==i&&C(r,"has",e),C(r,"has",i)),e===i?n.has(e):n.has(e)||n.has(i)}function X(e,t=!1){return e=e["__v_raw"],!t&&C(Re(e),"iterate",y),Reflect.get(e,"size",e)}function ee(e){e=Re(e);const t=Re(this),n=J(t),r=n.has.call(t,e);return r||(t.add(e),x(t,"add",e,e)),this}function te(e,t){t=Re(t);const n=Re(this),{has:i,get:o}=J(n);let s=i.call(n,e);s||(e=Re(e),s=i.call(n,e));const a=o.call(n,e);return n.set(e,t),s?(0,r.aU)(t,a)&&x(n,"set",e,t,a):x(n,"add",e,t),this}function ne(e){const t=Re(this),{has:n,get:r}=J(t);let i=n.call(t,e);i||(e=Re(e),i=n.call(t,e));const o=r?r.call(t,e):void 0,s=t.delete(e);return i&&x(t,"delete",e,void 0,o),s}function re(){const e=Re(this),t=0!==e.size,n=void 0,r=e.clear();return t&&x(e,"clear",void 0,void 0,n),r}function ie(e,t){return function(n,r){const i=this,o=i["__v_raw"],s=Re(o),a=t?G:e?Pe:Ne;return!e&&C(s,"iterate",y),o.forEach(((e,t)=>n.call(r,a(e),a(t),i)))}}function oe(e,t,n){return function(...i){const o=this["__v_raw"],s=Re(o),a=(0,r._N)(s),l="entries"===e||e===Symbol.iterator&&a,u="keys"===e&&a,c=o[e](...i),d=n?G:t?Pe:Ne;return!t&&C(s,"iterate",u?b:y),{next(){const{value:e,done:t}=c.next();return t?{value:e,done:t}:{value:l?[d(e[0]),d(e[1])]:d(e),done:t}},[Symbol.iterator](){return this}}}}function se(e){return function(...t){return"delete"!==e&&this}}function ae(){const e={get(e){return Q(this,e)},get size(){return X(this)},has:Y,add:ee,set:te,delete:ne,clear:re,forEach:ie(!1,!1)},t={get(e){return Q(this,e,!1,!0)},get size(){return X(this)},has:Y,add:ee,set:te,delete:ne,clear:re,forEach:ie(!1,!0)},n={get(e){return Q(this,e,!0)},get size(){return X(this,!0)},has(e){return Y.call(this,e,!0)},add:se("add"),set:se("set"),delete:se("delete"),clear:se("clear"),forEach:ie(!0,!1)},r={get(e){return Q(this,e,!0,!0)},get size(){return X(this,!0)},has(e){return Y.call(this,e,!0)},add:se("add"),set:se("set"),delete:se("delete"),clear:se("clear"),forEach:ie(!0,!0)},i=["keys","values","entries",Symbol.iterator];return i.forEach((i=>{e[i]=oe(i,!1,!1),n[i]=oe(i,!0,!1),t[i]=oe(i,!1,!0),r[i]=oe(i,!0,!0)})),[e,n,t,r]}const[le,ue,ce,de]=ae();function he(e,t){const n=t?e?de:ce:e?ue:le;return(t,i,o)=>"__v_isReactive"===i?!e:"__v_isReadonly"===i?e:"__v_raw"===i?t:Reflect.get((0,r.RI)(n,i)&&i in t?n:t,i,o)}const fe={get:he(!1,!1)},pe={get:he(!1,!0)},ge={get:he(!0,!1)};const me=new WeakMap,ve=new WeakMap,ye=new WeakMap,be=new WeakMap;function we(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function _e(e){return e["__v_skip"]||!Object.isExtensible(e)?0:we((0,r.W7)(e))}function Se(e){return Ie(e)?e:Te(e,!1,K,fe,me)}function Ee(e){return Te(e,!1,Z,pe,ve)}function ke(e){return Te(e,!0,W,ge,ye)}function Te(e,t,n,i,o){if(!(0,r.Kn)(e))return e;if(e["__v_raw"]&&(!t||!e["__v_isReactive"]))return e;const s=o.get(e);if(s)return s;const a=_e(e);if(0===a)return e;const l=new Proxy(e,2===a?i:n);return o.set(e,l),l}function Ce(e){return Ie(e)?Ce(e["__v_raw"]):!(!e||!e["__v_isReactive"])}function Ie(e){return!(!e||!e["__v_isReadonly"])}function xe(e){return!(!e||!e["__v_isShallow"])}function Ae(e){return Ce(e)||Ie(e)}function Re(e){const t=e&&e["__v_raw"];return t?Re(t):e}function Oe(e){return(0,r.Nj)(e,"__v_skip",!0),e}const Ne=e=>(0,r.Kn)(e)?Se(e):e,Pe=e=>(0,r.Kn)(e)?ke(e):e;function Fe(e){S&&v&&(e=Re(e),I(e.dep||(e.dep=l())))}function Le(e,t){e=Re(e);const n=e.dep;n&&A(n)}function De(e){return!(!e||!0!==e.__v_isRef)}function Me(e){return Ve(e,!1)}function qe(e){return Ve(e,!0)}function Ve(e,t){return De(e)?e:new Ue(e,t)}class Ue{constructor(e,t){this.__v_isShallow=t,this.dep=void 0,this.__v_isRef=!0,this._rawValue=t?e:Re(e),this._value=t?e:Ne(e)}get value(){return Fe(this),this._value}set value(e){const t=this.__v_isShallow||xe(e)||Ie(e);e=t?e:Re(e),(0,r.aU)(e,this._rawValue)&&(this._rawValue=e,this._value=t?e:Ne(e),Le(this,e))}}function Be(e){return De(e)?e.value:e}const $e={get:(e,t,n)=>Be(Reflect.get(e,t,n)),set:(e,t,n,r)=>{const i=e[t];return De(i)&&!De(n)?(i.value=n,!0):Reflect.set(e,t,n,r)}};function je(e){return Ce(e)?e:new Proxy(e,$e)}class ze{constructor(e,t,n,r){this._setter=t,this.dep=void 0,this.__v_isRef=!0,this["__v_isReadonly"]=!1,this._dirty=!0,this.effect=new w(e,(()=>{this._dirty||(this._dirty=!0,Le(this))})),this.effect.computed=this,this.effect.active=this._cacheable=!r,this["__v_isReadonly"]=n}get value(){const e=Re(this);return Fe(e),!e._dirty&&e._cacheable||(e._dirty=!1,e._value=e.effect.run()),e._value}set value(e){this._setter(e)}}function He(e,t,n=!1){let i,o;const s=(0,r.mf)(e);s?(i=e,o=r.dG):(i=e.get,o=e.set);const a=new ze(i,o,s||!o,n);return a}},9835:(e,t,n)=>{"use strict";n.d(t,{$d:()=>s,Ah:()=>Re,Cn:()=>D,FN:()=>An,Fl:()=>Zn,HY:()=>Zt,JJ:()=>ft,Jd:()=>Ae,Ko:()=>$e,Ob:()=>ge,P$:()=>ie,Q2:()=>Ve,Q6:()=>ce,U2:()=>se,Uk:()=>yn,Us:()=>Ft,Wm:()=>pn,Xn:()=>Ie,Y3:()=>y,Y8:()=>ee,YP:()=>W,_:()=>fn,aZ:()=>de,bv:()=>Ce,dD:()=>L,dl:()=>ve,f3:()=>pt,h:()=>Gn,iD:()=>sn,ic:()=>xe,j4:()=>an,kq:()=>bn,lR:()=>Kt,nJ:()=>ne,nK:()=>ue,se:()=>ye,up:()=>Me,w5:()=>M,wF:()=>Te,wg:()=>en,wy:()=>Y});var r=n(499),i=n(6970);function o(e,t,n,r){let i;try{i=r?e(...r):e()}catch(o){a(o,t,n)}return i}function s(e,t,n,r){if((0,i.mf)(e)){const s=o(e,t,n,r);return s&&(0,i.tI)(s)&&s.catch((e=>{a(e,t,n)})),s}const l=[];for(let i=0;i<e.length;i++)l.push(s(e[i],t,n,r));return l}function a(e,t,n,r=!0){const i=t?t.vnode:null;if(t){let r=t.parent;const i=t.proxy,s=n;while(r){const t=r.ec;if(t)for(let n=0;n<t.length;n++)if(!1===t[n](e,i,s))return;r=r.parent}const a=t.appContext.config.errorHandler;if(a)return void o(a,null,10,[e,i,s])}l(e,n,i,r)}function l(e,t,n,r=!0){console.error(e)}let u=!1,c=!1;const d=[];let h=0;const f=[];let p=null,g=0;const m=Promise.resolve();let v=null;function y(e){const t=v||m;return e?t.then(this?e.bind(this):e):t}function b(e){let t=h+1,n=d.length;while(t<n){const r=t+n>>>1,i=C(d[r]);i<e?t=r+1:n=r}return t}function w(e){d.length&&d.includes(e,u&&e.allowRecurse?h+1:h)||(null==e.id?d.push(e):d.splice(b(e.id),0,e),_())}function _(){u||c||(c=!0,v=m.then(x))}function S(e){const t=d.indexOf(e);t>h&&d.splice(t,1)}function E(e){(0,i.kJ)(e)?f.push(...e):p&&p.includes(e,e.allowRecurse?g+1:g)||f.push(e),_()}function k(e,t=(u?h+1:0)){for(0;t<d.length;t++){const e=d[t];e&&e.pre&&(d.splice(t,1),t--,e())}}function T(e){if(f.length){const e=[...new Set(f)];if(f.length=0,p)return void p.push(...e);for(p=e,p.sort(((e,t)=>C(e)-C(t))),g=0;g<p.length;g++)p[g]();p=null,g=0}}const C=e=>null==e.id?1/0:e.id,I=(e,t)=>{const n=C(e)-C(t);if(0===n){if(e.pre&&!t.pre)return-1;if(t.pre&&!e.pre)return 1}return n};function x(e){c=!1,u=!0,d.sort(I);i.dG;try{for(h=0;h<d.length;h++){const e=d[h];e&&!1!==e.active&&o(e,null,14)}}finally{h=0,d.length=0,T(e),u=!1,v=null,(d.length||f.length)&&x(e)}}function A(e,t,...n){if(e.isUnmounted)return;const r=e.vnode.props||i.kT;let o=n;const a=t.startsWith("update:"),l=a&&t.slice(7);if(l&&l in r){const e=`${"modelValue"===l?"model":l}Modifiers`,{number:t,trim:s}=r[e]||i.kT;s&&(o=n.map((e=>(0,i.HD)(e)?e.trim():e))),t&&(o=n.map(i.h5))}let u;let c=r[u=(0,i.hR)(t)]||r[u=(0,i.hR)((0,i._A)(t))];!c&&a&&(c=r[u=(0,i.hR)((0,i.rs)(t))]),c&&s(c,e,6,o);const d=r[u+"Once"];if(d){if(e.emitted){if(e.emitted[u])return}else e.emitted={};e.emitted[u]=!0,s(d,e,6,o)}}function R(e,t,n=!1){const r=t.emitsCache,o=r.get(e);if(void 0!==o)return o;const s=e.emits;let a={},l=!1;if(!(0,i.mf)(e)){const r=e=>{const n=R(e,t,!0);n&&(l=!0,(0,i.l7)(a,n))};!n&&t.mixins.length&&t.mixins.forEach(r),e.extends&&r(e.extends),e.mixins&&e.mixins.forEach(r)}return s||l?((0,i.kJ)(s)?s.forEach((e=>a[e]=null)):(0,i.l7)(a,s),(0,i.Kn)(e)&&r.set(e,a),a):((0,i.Kn)(e)&&r.set(e,null),null)}function O(e,t){return!(!e||!(0,i.F7)(t))&&(t=t.slice(2).replace(/Once$/,""),(0,i.RI)(e,t[0].toLowerCase()+t.slice(1))||(0,i.RI)(e,(0,i.rs)(t))||(0,i.RI)(e,t))}let N=null,P=null;function F(e){const t=N;return N=e,P=e&&e.type.__scopeId||null,t}function L(e){P=e}function D(){P=null}function M(e,t=N,n){if(!t)return e;if(e._n)return e;const r=(...n)=>{r._d&&rn(-1);const i=F(t);let o;try{o=e(...n)}finally{F(i),r._d&&rn(1)}return o};return r._n=!0,r._c=!0,r._d=!0,r}function q(e){const{type:t,vnode:n,proxy:r,withProxy:o,props:s,propsOptions:[l],slots:u,attrs:c,emit:d,render:h,renderCache:f,data:p,setupState:g,ctx:m,inheritAttrs:v}=e;let y,b;const w=F(e);try{if(4&n.shapeFlag){const e=o||r;y=wn(h.call(e,e,f,s,g,p,m)),b=c}else{const e=t;0,y=wn(e.length>1?e(s,{attrs:c,slots:u,emit:d}):e(s,null)),b=t.props?c:V(c)}}catch(S){Yt.length=0,a(S,e,1),y=pn(Jt)}let _=y;if(b&&!1!==v){const e=Object.keys(b),{shapeFlag:t}=_;e.length&&7&t&&(l&&e.some(i.tR)&&(b=U(b,l)),_=vn(_,b))}return n.dirs&&(_=vn(_),_.dirs=_.dirs?_.dirs.concat(n.dirs):n.dirs),n.transition&&(_.transition=n.transition),y=_,F(w),y}const V=e=>{let t;for(const n in e)("class"===n||"style"===n||(0,i.F7)(n))&&((t||(t={}))[n]=e[n]);return t},U=(e,t)=>{const n={};for(const r in e)(0,i.tR)(r)&&r.slice(9)in t||(n[r]=e[r]);return n};function B(e,t,n){const{props:r,children:i,component:o}=e,{props:s,children:a,patchFlag:l}=t,u=o.emitsOptions;if(t.dirs||t.transition)return!0;if(!(n&&l>=0))return!(!i&&!a||a&&a.$stable)||r!==s&&(r?!s||$(r,s,u):!!s);if(1024&l)return!0;if(16&l)return r?$(r,s,u):!!s;if(8&l){const e=t.dynamicProps;for(let t=0;t<e.length;t++){const n=e[t];if(s[n]!==r[n]&&!O(u,n))return!0}}return!1}function $(e,t,n){const r=Object.keys(t);if(r.length!==Object.keys(e).length)return!0;for(let i=0;i<r.length;i++){const o=r[i];if(t[o]!==e[o]&&!O(n,o))return!0}return!1}function j({vnode:e,parent:t},n){while(t&&t.subTree===e)(e=t.vnode).el=n,t=t.parent}const z=e=>e.__isSuspense;function H(e,t){t&&t.pendingBranch?(0,i.kJ)(e)?t.effects.push(...e):t.effects.push(e):E(e)}const K={};function W(e,t,n){return Z(e,t,n)}function Z(e,t,{immediate:n,deep:a,flush:l,onTrack:u,onTrigger:c}=i.kT){var d;const h=(0,r.nZ)()===(null==(d=xn)?void 0:d.scope)?xn:null;let f,p,g=!1,m=!1;if((0,r.dq)(e)?(f=()=>e.value,g=(0,r.yT)(e)):(0,r.PG)(e)?(f=()=>e,a=!0):(0,i.kJ)(e)?(m=!0,g=e.some((e=>(0,r.PG)(e)||(0,r.yT)(e))),f=()=>e.map((e=>(0,r.dq)(e)?e.value:(0,r.PG)(e)?Q(e):(0,i.mf)(e)?o(e,h,2):void 0))):f=(0,i.mf)(e)?t?()=>o(e,h,2):()=>{if(!h||!h.isUnmounted)return p&&p(),s(e,h,3,[y])}:i.dG,t&&a){const e=f;f=()=>Q(e())}let v,y=e=>{p=E.onStop=()=>{o(e,h,4)}};if(qn){if(y=i.dG,t?n&&s(t,h,3,[f(),m?[]:void 0,y]):f(),"sync"!==l)return i.dG;{const e=Qn();v=e.__watcherHandles||(e.__watcherHandles=[])}}let b=m?new Array(e.length).fill(K):K;const _=()=>{if(E.active)if(t){const e=E.run();(a||g||(m?e.some(((e,t)=>(0,i.aU)(e,b[t]))):(0,i.aU)(e,b)))&&(p&&p(),s(t,h,3,[e,b===K?void 0:m&&b[0]===K?[]:b,y]),b=e)}else E.run()};let S;_.allowRecurse=!!t,"sync"===l?S=_:"post"===l?S=()=>Pt(_,h&&h.suspense):(_.pre=!0,h&&(_.id=h.uid),S=()=>w(_));const E=new r.qq(f,S);t?n?_():b=E.run():"post"===l?Pt(E.run.bind(E),h&&h.suspense):E.run();const k=()=>{E.stop(),h&&h.scope&&(0,i.Od)(h.scope.effects,E)};return v&&v.push(k),k}function G(e,t,n){const r=this.proxy,o=(0,i.HD)(e)?e.includes(".")?J(r,e):()=>r[e]:e.bind(r,r);let s;(0,i.mf)(t)?s=t:(s=t.handler,n=t);const a=xn;Pn(this);const l=Z(o,s.bind(r),n);return a?Pn(a):Fn(),l}function J(e,t){const n=t.split(".");return()=>{let t=e;for(let e=0;e<n.length&&t;e++)t=t[n[e]];return t}}function Q(e,t){if(!(0,i.Kn)(e)||e["__v_skip"])return e;if(t=t||new Set,t.has(e))return e;if(t.add(e),(0,r.dq)(e))Q(e.value,t);else if((0,i.kJ)(e))for(let n=0;n<e.length;n++)Q(e[n],t);else if((0,i.DM)(e)||(0,i._N)(e))e.forEach((e=>{Q(e,t)}));else if((0,i.PO)(e))for(const n in e)Q(e[n],t);return e}function Y(e,t){const n=N;if(null===n)return e;const r=Hn(n)||n.proxy,o=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[e,n,a,l=i.kT]=t[s];e&&((0,i.mf)(e)&&(e={mounted:e,updated:e}),e.deep&&Q(n),o.push({dir:e,instance:r,value:n,oldValue:void 0,arg:a,modifiers:l}))}return e}function X(e,t,n,i){const o=e.dirs,a=t&&t.dirs;for(let l=0;l<o.length;l++){const u=o[l];a&&(u.oldValue=a[l].value);let c=u.dir[i];c&&((0,r.Jd)(),s(c,n,8,[e.el,u,e,t]),(0,r.lk)())}}function ee(){const e={isMounted:!1,isLeaving:!1,isUnmounting:!1,leavingVNodes:new Map};return Ce((()=>{e.isMounted=!0})),Ae((()=>{e.isUnmounting=!0})),e}const te=[Function,Array],ne={mode:String,appear:Boolean,persisted:Boolean,onBeforeEnter:te,onEnter:te,onAfterEnter:te,onEnterCancelled:te,onBeforeLeave:te,onLeave:te,onAfterLeave:te,onLeaveCancelled:te,onBeforeAppear:te,onAppear:te,onAfterAppear:te,onAppearCancelled:te},re={name:"BaseTransition",props:ne,setup(e,{slots:t}){const n=An(),i=ee();let o;return()=>{const s=t.default&&ce(t.default(),!0);if(!s||!s.length)return;let a=s[0];if(s.length>1){let e=!1;for(const t of s)if(t.type!==Jt){0,a=t,e=!0;break}}const l=(0,r.IU)(e),{mode:u}=l;if(i.isLeaving)return ae(a);const c=le(a);if(!c)return ae(a);const d=se(c,l,i,n);ue(c,d);const h=n.subTree,f=h&&le(h);let p=!1;const{getTransitionKey:g}=c.type;if(g){const e=g();void 0===o?o=e:e!==o&&(o=e,p=!0)}if(f&&f.type!==Jt&&(!un(c,f)||p)){const e=se(f,l,i,n);if(ue(f,e),"out-in"===u)return i.isLeaving=!0,e.afterLeave=()=>{i.isLeaving=!1,!1!==n.update.active&&n.update()},ae(a);"in-out"===u&&c.type!==Jt&&(e.delayLeave=(e,t,n)=>{const r=oe(i,f);r[String(f.key)]=f,e._leaveCb=()=>{t(),e._leaveCb=void 0,delete d.delayedLeave},d.delayedLeave=n})}return a}}},ie=re;function oe(e,t){const{leavingVNodes:n}=e;let r=n.get(t.type);return r||(r=Object.create(null),n.set(t.type,r)),r}function se(e,t,n,r){const{appear:o,mode:a,persisted:l=!1,onBeforeEnter:u,onEnter:c,onAfterEnter:d,onEnterCancelled:h,onBeforeLeave:f,onLeave:p,onAfterLeave:g,onLeaveCancelled:m,onBeforeAppear:v,onAppear:y,onAfterAppear:b,onAppearCancelled:w}=t,_=String(e.key),S=oe(n,e),E=(e,t)=>{e&&s(e,r,9,t)},k=(e,t)=>{const n=t[1];E(e,t),(0,i.kJ)(e)?e.every((e=>e.length<=1))&&n():e.length<=1&&n()},T={mode:a,persisted:l,beforeEnter(t){let r=u;if(!n.isMounted){if(!o)return;r=v||u}t._leaveCb&&t._leaveCb(!0);const i=S[_];i&&un(e,i)&&i.el._leaveCb&&i.el._leaveCb(),E(r,[t])},enter(e){let t=c,r=d,i=h;if(!n.isMounted){if(!o)return;t=y||c,r=b||d,i=w||h}let s=!1;const a=e._enterCb=t=>{s||(s=!0,E(t?i:r,[e]),T.delayedLeave&&T.delayedLeave(),e._enterCb=void 0)};t?k(t,[e,a]):a()},leave(t,r){const i=String(e.key);if(t._enterCb&&t._enterCb(!0),n.isUnmounting)return r();E(f,[t]);let o=!1;const s=t._leaveCb=n=>{o||(o=!0,r(),E(n?m:g,[t]),t._leaveCb=void 0,S[i]===e&&delete S[i])};S[i]=e,p?k(p,[t,s]):s()},clone(e){return se(e,t,n,r)}};return T}function ae(e){if(fe(e))return e=vn(e),e.children=null,e}function le(e){return fe(e)?e.children?e.children[0]:void 0:e}function ue(e,t){6&e.shapeFlag&&e.component?ue(e.component.subTree,t):128&e.shapeFlag?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function ce(e,t=!1,n){let r=[],i=0;for(let o=0;o<e.length;o++){let s=e[o];const a=null==n?s.key:String(n)+String(null!=s.key?s.key:o);s.type===Zt?(128&s.patchFlag&&i++,r=r.concat(ce(s.children,t,a))):(t||s.type!==Jt)&&r.push(null!=a?vn(s,{key:a}):s)}if(i>1)for(let o=0;o<r.length;o++)r[o].patchFlag=-2;return r}function de(e,t){return(0,i.mf)(e)?(()=>(0,i.l7)({name:e.name},t,{setup:e}))():e}const he=e=>!!e.type.__asyncLoader;const fe=e=>e.type.__isKeepAlive,pe={name:"KeepAlive",__isKeepAlive:!0,props:{include:[String,RegExp,Array],exclude:[String,RegExp,Array],max:[String,Number]},setup(e,{slots:t}){const n=An(),r=n.ctx;if(!r.renderer)return()=>{const e=t.default&&t.default();return e&&1===e.length?e[0]:e};const o=new Map,s=new Set;let a=null;const l=n.suspense,{renderer:{p:u,m:c,um:d,o:{createElement:h}}}=r,f=h("div");function p(e){_e(e),d(e,n,l,!0)}function g(e){o.forEach(((t,n)=>{const r=Kn(t.type);!r||e&&e(r)||m(n)}))}function m(e){const t=o.get(e);a&&un(t,a)?a&&_e(a):p(t),o.delete(e),s.delete(e)}r.activate=(e,t,n,r,o)=>{const s=e.component;c(e,t,n,0,l),u(s.vnode,e,t,n,s,l,r,e.slotScopeIds,o),Pt((()=>{s.isDeactivated=!1,s.a&&(0,i.ir)(s.a);const t=e.props&&e.props.onVnodeMounted;t&&kn(t,s.parent,e)}),l)},r.deactivate=e=>{const t=e.component;c(e,f,null,1,l),Pt((()=>{t.da&&(0,i.ir)(t.da);const n=e.props&&e.props.onVnodeUnmounted;n&&kn(n,t.parent,e),t.isDeactivated=!0}),l)},W((()=>[e.include,e.exclude]),(([e,t])=>{e&&g((t=>me(e,t))),t&&g((e=>!me(t,e)))}),{flush:"post",deep:!0});let v=null;const y=()=>{null!=v&&o.set(v,Se(n.subTree))};return Ce(y),xe(y),Ae((()=>{o.forEach((e=>{const{subTree:t,suspense:r}=n,i=Se(t);if(e.type!==i.type||e.key!==i.key)p(e);else{_e(i);const e=i.component.da;e&&Pt(e,r)}}))})),()=>{if(v=null,!t.default)return null;const n=t.default(),r=n[0];if(n.length>1)return a=null,n;if(!ln(r)||!(4&r.shapeFlag)&&!(128&r.shapeFlag))return a=null,r;let i=Se(r);const l=i.type,u=Kn(he(i)?i.type.__asyncResolved||{}:l),{include:c,exclude:d,max:h}=e;if(c&&(!u||!me(c,u))||d&&u&&me(d,u))return a=i,r;const f=null==i.key?l:i.key,p=o.get(f);return i.el&&(i=vn(i),128&r.shapeFlag&&(r.ssContent=i)),v=f,p?(i.el=p.el,i.component=p.component,i.transition&&ue(i,i.transition),i.shapeFlag|=512,s.delete(f),s.add(f)):(s.add(f),h&&s.size>parseInt(h,10)&&m(s.values().next().value)),i.shapeFlag|=256,a=i,z(r.type)?r:i}}},ge=pe;function me(e,t){return(0,i.kJ)(e)?e.some((e=>me(e,t))):(0,i.HD)(e)?e.split(",").includes(t):!!(0,i.Kj)(e)&&e.test(t)}function ve(e,t){be(e,"a",t)}function ye(e,t){be(e,"da",t)}function be(e,t,n=xn){const r=e.__wdc||(e.__wdc=()=>{let t=n;while(t){if(t.isDeactivated)return;t=t.parent}return e()});if(Ee(t,r,n),n){let e=n.parent;while(e&&e.parent)fe(e.parent.vnode)&&we(r,t,n,e),e=e.parent}}function we(e,t,n,r){const o=Ee(t,e,r,!0);Re((()=>{(0,i.Od)(r[t],o)}),n)}function _e(e){e.shapeFlag&=-257,e.shapeFlag&=-513}function Se(e){return 128&e.shapeFlag?e.ssContent:e}function Ee(e,t,n=xn,i=!1){if(n){const o=n[e]||(n[e]=[]),a=t.__weh||(t.__weh=(...i)=>{if(n.isUnmounted)return;(0,r.Jd)(),Pn(n);const o=s(t,n,e,i);return Fn(),(0,r.lk)(),o});return i?o.unshift(a):o.push(a),a}}const ke=e=>(t,n=xn)=>(!qn||"sp"===e)&&Ee(e,((...e)=>t(...e)),n),Te=ke("bm"),Ce=ke("m"),Ie=ke("bu"),xe=ke("u"),Ae=ke("bum"),Re=ke("um"),Oe=ke("sp"),Ne=ke("rtg"),Pe=ke("rtc");function Fe(e,t=xn){Ee("ec",e,t)}const Le="components",De="directives";function Me(e,t){return Ue(Le,e,!0,t)||e}const qe=Symbol.for("v-ndc");function Ve(e){return Ue(De,e)}function Ue(e,t,n=!0,r=!1){const o=N||xn;if(o){const n=o.type;if(e===Le){const e=Kn(n,!1);if(e&&(e===t||e===(0,i._A)(t)||e===(0,i.kC)((0,i._A)(t))))return n}const s=Be(o[e]||n[e],t)||Be(o.appContext[e],t);return!s&&r?n:s}}function Be(e,t){return e&&(e[t]||e[(0,i._A)(t)]||e[(0,i.kC)((0,i._A)(t))])}function $e(e,t,n,r){let o;const s=n&&n[r];if((0,i.kJ)(e)||(0,i.HD)(e)){o=new Array(e.length);for(let n=0,r=e.length;n<r;n++)o[n]=t(e[n],n,void 0,s&&s[n])}else if("number"===typeof e){0,o=new Array(e);for(let n=0;n<e;n++)o[n]=t(n+1,n,void 0,s&&s[n])}else if((0,i.Kn)(e))if(e[Symbol.iterator])o=Array.from(e,((e,n)=>t(e,n,void 0,s&&s[n])));else{const n=Object.keys(e);o=new Array(n.length);for(let r=0,i=n.length;r<i;r++){const i=n[r];o[r]=t(e[i],i,r,s&&s[r])}}else o=[];return n&&(n[r]=o),o}const je=e=>e?Ln(e)?Hn(e)||e.proxy:je(e.parent):null,ze=(0,i.l7)(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>je(e.parent),$root:e=>je(e.root),$emit:e=>e.emit,$options:e=>Xe(e),$forceUpdate:e=>e.f||(e.f=()=>w(e.update)),$nextTick:e=>e.n||(e.n=y.bind(e.proxy)),$watch:e=>G.bind(e)}),He=(e,t)=>e!==i.kT&&!e.__isScriptSetup&&(0,i.RI)(e,t),Ke={get({_:e},t){const{ctx:n,setupState:o,data:s,props:a,accessCache:l,type:u,appContext:c}=e;let d;if("$"!==t[0]){const r=l[t];if(void 0!==r)switch(r){case 1:return o[t];case 2:return s[t];case 4:return n[t];case 3:return a[t]}else{if(He(o,t))return l[t]=1,o[t];if(s!==i.kT&&(0,i.RI)(s,t))return l[t]=2,s[t];if((d=e.propsOptions[0])&&(0,i.RI)(d,t))return l[t]=3,a[t];if(n!==i.kT&&(0,i.RI)(n,t))return l[t]=4,n[t];Ze&&(l[t]=0)}}const h=ze[t];let f,p;return h?("$attrs"===t&&(0,r.j)(e,"get",t),h(e)):(f=u.__cssModules)&&(f=f[t])?f:n!==i.kT&&(0,i.RI)(n,t)?(l[t]=4,n[t]):(p=c.config.globalProperties,(0,i.RI)(p,t)?p[t]:void 0)},set({_:e},t,n){const{data:r,setupState:o,ctx:s}=e;return He(o,t)?(o[t]=n,!0):r!==i.kT&&(0,i.RI)(r,t)?(r[t]=n,!0):!(0,i.RI)(e.props,t)&&(("$"!==t[0]||!(t.slice(1)in e))&&(s[t]=n,!0))},has({_:{data:e,setupState:t,accessCache:n,ctx:r,appContext:o,propsOptions:s}},a){let l;return!!n[a]||e!==i.kT&&(0,i.RI)(e,a)||He(t,a)||(l=s[0])&&(0,i.RI)(l,a)||(0,i.RI)(r,a)||(0,i.RI)(ze,a)||(0,i.RI)(o.config.globalProperties,a)},defineProperty(e,t,n){return null!=n.get?e._.accessCache[t]=0:(0,i.RI)(n,"value")&&this.set(e,t,n.value,null),Reflect.defineProperty(e,t,n)}};function We(e){return(0,i.kJ)(e)?e.reduce(((e,t)=>(e[t]=null,e)),{}):e}let Ze=!0;function Ge(e){const t=Xe(e),n=e.proxy,o=e.ctx;Ze=!1,t.beforeCreate&&Qe(t.beforeCreate,e,"bc");const{data:s,computed:a,methods:l,watch:u,provide:c,inject:d,created:h,beforeMount:f,mounted:p,beforeUpdate:g,updated:m,activated:v,deactivated:y,beforeDestroy:b,beforeUnmount:w,destroyed:_,unmounted:S,render:E,renderTracked:k,renderTriggered:T,errorCaptured:C,serverPrefetch:I,expose:x,inheritAttrs:A,components:R,directives:O,filters:N}=t,P=null;if(d&&Je(d,o,P),l)for(const r in l){const e=l[r];(0,i.mf)(e)&&(o[r]=e.bind(n))}if(s){0;const t=s.call(n,n);0,(0,i.Kn)(t)&&(e.data=(0,r.qj)(t))}if(Ze=!0,a)for(const r in a){const e=a[r],t=(0,i.mf)(e)?e.bind(n,n):(0,i.mf)(e.get)?e.get.bind(n,n):i.dG;0;const s=!(0,i.mf)(e)&&(0,i.mf)(e.set)?e.set.bind(n):i.dG,l=Zn({get:t,set:s});Object.defineProperty(o,r,{enumerable:!0,configurable:!0,get:()=>l.value,set:e=>l.value=e})}if(u)for(const r in u)Ye(u[r],o,n,r);if(c){const e=(0,i.mf)(c)?c.call(n):c;Reflect.ownKeys(e).forEach((t=>{ft(t,e[t])}))}function F(e,t){(0,i.kJ)(t)?t.forEach((t=>e(t.bind(n)))):t&&e(t.bind(n))}if(h&&Qe(h,e,"c"),F(Te,f),F(Ce,p),F(Ie,g),F(xe,m),F(ve,v),F(ye,y),F(Fe,C),F(Pe,k),F(Ne,T),F(Ae,w),F(Re,S),F(Oe,I),(0,i.kJ)(x))if(x.length){const t=e.exposed||(e.exposed={});x.forEach((e=>{Object.defineProperty(t,e,{get:()=>n[e],set:t=>n[e]=t})}))}else e.exposed||(e.exposed={});E&&e.render===i.dG&&(e.render=E),null!=A&&(e.inheritAttrs=A),R&&(e.components=R),O&&(e.directives=O)}function Je(e,t,n=i.dG){(0,i.kJ)(e)&&(e=it(e));for(const o in e){const n=e[o];let s;s=(0,i.Kn)(n)?"default"in n?pt(n.from||o,n.default,!0):pt(n.from||o):pt(n),(0,r.dq)(s)?Object.defineProperty(t,o,{enumerable:!0,configurable:!0,get:()=>s.value,set:e=>s.value=e}):t[o]=s}}function Qe(e,t,n){s((0,i.kJ)(e)?e.map((e=>e.bind(t.proxy))):e.bind(t.proxy),t,n)}function Ye(e,t,n,r){const o=r.includes(".")?J(n,r):()=>n[r];if((0,i.HD)(e)){const n=t[e];(0,i.mf)(n)&&W(o,n)}else if((0,i.mf)(e))W(o,e.bind(n));else if((0,i.Kn)(e))if((0,i.kJ)(e))e.forEach((e=>Ye(e,t,n,r)));else{const r=(0,i.mf)(e.handler)?e.handler.bind(n):t[e.handler];(0,i.mf)(r)&&W(o,r,e)}else 0}function Xe(e){const t=e.type,{mixins:n,extends:r}=t,{mixins:o,optionsCache:s,config:{optionMergeStrategies:a}}=e.appContext,l=s.get(t);let u;return l?u=l:o.length||n||r?(u={},o.length&&o.forEach((e=>et(u,e,a,!0))),et(u,t,a)):u=t,(0,i.Kn)(t)&&s.set(t,u),u}function et(e,t,n,r=!1){const{mixins:i,extends:o}=t;o&&et(e,o,n,!0),i&&i.forEach((t=>et(e,t,n,!0)));for(const s in t)if(r&&"expose"===s);else{const r=tt[s]||n&&n[s];e[s]=r?r(e[s],t[s]):t[s]}return e}const tt={data:nt,props:at,emits:at,methods:st,computed:st,beforeCreate:ot,created:ot,beforeMount:ot,mounted:ot,beforeUpdate:ot,updated:ot,beforeDestroy:ot,beforeUnmount:ot,destroyed:ot,unmounted:ot,activated:ot,deactivated:ot,errorCaptured:ot,serverPrefetch:ot,components:st,directives:st,watch:lt,provide:nt,inject:rt};function nt(e,t){return t?e?function(){return(0,i.l7)((0,i.mf)(e)?e.call(this,this):e,(0,i.mf)(t)?t.call(this,this):t)}:t:e}function rt(e,t){return st(it(e),it(t))}function it(e){if((0,i.kJ)(e)){const t={};for(let n=0;n<e.length;n++)t[e[n]]=e[n];return t}return e}function ot(e,t){return e?[...new Set([].concat(e,t))]:t}function st(e,t){return e?(0,i.l7)(Object.create(null),e,t):t}function at(e,t){return e?(0,i.kJ)(e)&&(0,i.kJ)(t)?[...new Set([...e,...t])]:(0,i.l7)(Object.create(null),We(e),We(null!=t?t:{})):t}function lt(e,t){if(!e)return t;if(!t)return e;const n=(0,i.l7)(Object.create(null),e);for(const r in t)n[r]=ot(e[r],t[r]);return n}function ut(){return{app:null,config:{isNativeTag:i.NO,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let ct=0;function dt(e,t){return function(n,r=null){(0,i.mf)(n)||(n=(0,i.l7)({},n)),null==r||(0,i.Kn)(r)||(r=null);const o=ut();const s=new Set;let a=!1;const l=o.app={_uid:ct++,_component:n,_props:r,_container:null,_context:o,_instance:null,version:Yn,get config(){return o.config},set config(e){0},use(e,...t){return s.has(e)||(e&&(0,i.mf)(e.install)?(s.add(e),e.install(l,...t)):(0,i.mf)(e)&&(s.add(e),e(l,...t))),l},mixin(e){return o.mixins.includes(e)||o.mixins.push(e),l},component(e,t){return t?(o.components[e]=t,l):o.components[e]},directive(e,t){return t?(o.directives[e]=t,l):o.directives[e]},mount(i,s,u){if(!a){0;const c=pn(n,r);return c.appContext=o,s&&t?t(c,i):e(c,i,u),a=!0,l._container=i,i.__vue_app__=l,Hn(c.component)||c.component.proxy}},unmount(){a&&(e(null,l._container),delete l._container.__vue_app__)},provide(e,t){return o.provides[e]=t,l},runWithContext(e){ht=l;try{return e()}finally{ht=null}}};return l}}let ht=null;function ft(e,t){if(xn){let n=xn.provides;const r=xn.parent&&xn.parent.provides;r===n&&(n=xn.provides=Object.create(r)),n[e]=t}else 0}function pt(e,t,n=!1){const r=xn||N;if(r||ht){const o=r?null==r.parent?r.vnode.appContext&&r.vnode.appContext.provides:r.parent.provides:ht._context.provides;if(o&&e in o)return o[e];if(arguments.length>1)return n&&(0,i.mf)(t)?t.call(r&&r.proxy):t}else 0}function gt(e,t,n,o=!1){const s={},a={};(0,i.Nj)(a,cn,1),e.propsDefaults=Object.create(null),vt(e,t,s,a);for(const r in e.propsOptions[0])r in s||(s[r]=void 0);n?e.props=o?s:(0,r.Um)(s):e.type.props?e.props=s:e.props=a,e.attrs=a}function mt(e,t,n,o){const{props:s,attrs:a,vnode:{patchFlag:l}}=e,u=(0,r.IU)(s),[c]=e.propsOptions;let d=!1;if(!(o||l>0)||16&l){let r;vt(e,t,s,a)&&(d=!0);for(const o in u)t&&((0,i.RI)(t,o)||(r=(0,i.rs)(o))!==o&&(0,i.RI)(t,r))||(c?!n||void 0===n[o]&&void 0===n[r]||(s[o]=yt(c,u,o,void 0,e,!0)):delete s[o]);if(a!==u)for(const e in a)t&&(0,i.RI)(t,e)||(delete a[e],d=!0)}else if(8&l){const n=e.vnode.dynamicProps;for(let r=0;r<n.length;r++){let o=n[r];if(O(e.emitsOptions,o))continue;const l=t[o];if(c)if((0,i.RI)(a,o))l!==a[o]&&(a[o]=l,d=!0);else{const t=(0,i._A)(o);s[t]=yt(c,u,t,l,e,!1)}else l!==a[o]&&(a[o]=l,d=!0)}}d&&(0,r.X$)(e,"set","$attrs")}function vt(e,t,n,o){const[s,a]=e.propsOptions;let l,u=!1;if(t)for(let r in t){if((0,i.Gg)(r))continue;const c=t[r];let d;s&&(0,i.RI)(s,d=(0,i._A)(r))?a&&a.includes(d)?(l||(l={}))[d]=c:n[d]=c:O(e.emitsOptions,r)||r in o&&c===o[r]||(o[r]=c,u=!0)}if(a){const t=(0,r.IU)(n),o=l||i.kT;for(let r=0;r<a.length;r++){const l=a[r];n[l]=yt(s,t,l,o[l],e,!(0,i.RI)(o,l))}}return u}function yt(e,t,n,r,o,s){const a=e[n];if(null!=a){const e=(0,i.RI)(a,"default");if(e&&void 0===r){const e=a.default;if(a.type!==Function&&!a.skipFactory&&(0,i.mf)(e)){const{propsDefaults:i}=o;n in i?r=i[n]:(Pn(o),r=i[n]=e.call(null,t),Fn())}else r=e}a[0]&&(s&&!e?r=!1:!a[1]||""!==r&&r!==(0,i.rs)(n)||(r=!0))}return r}function bt(e,t,n=!1){const r=t.propsCache,o=r.get(e);if(o)return o;const s=e.props,a={},l=[];let u=!1;if(!(0,i.mf)(e)){const r=e=>{u=!0;const[n,r]=bt(e,t,!0);(0,i.l7)(a,n),r&&l.push(...r)};!n&&t.mixins.length&&t.mixins.forEach(r),e.extends&&r(e.extends),e.mixins&&e.mixins.forEach(r)}if(!s&&!u)return(0,i.Kn)(e)&&r.set(e,i.Z6),i.Z6;if((0,i.kJ)(s))for(let d=0;d<s.length;d++){0;const e=(0,i._A)(s[d]);wt(e)&&(a[e]=i.kT)}else if(s){0;for(const e in s){const t=(0,i._A)(e);if(wt(t)){const n=s[e],r=a[t]=(0,i.kJ)(n)||(0,i.mf)(n)?{type:n}:(0,i.l7)({},n);if(r){const e=Et(Boolean,r.type),n=Et(String,r.type);r[0]=e>-1,r[1]=n<0||e<n,(e>-1||(0,i.RI)(r,"default"))&&l.push(t)}}}}const c=[a,l];return(0,i.Kn)(e)&&r.set(e,c),c}function wt(e){return"$"!==e[0]}function _t(e){const t=e&&e.toString().match(/^\s*(function|class) (\w+)/);return t?t[2]:null===e?"null":""}function St(e,t){return _t(e)===_t(t)}function Et(e,t){return(0,i.kJ)(t)?t.findIndex((t=>St(t,e))):(0,i.mf)(t)&&St(t,e)?0:-1}const kt=e=>"_"===e[0]||"$stable"===e,Tt=e=>(0,i.kJ)(e)?e.map(wn):[wn(e)],Ct=(e,t,n)=>{if(t._n)return t;const r=M(((...e)=>Tt(t(...e))),n);return r._c=!1,r},It=(e,t,n)=>{const r=e._ctx;for(const o in e){if(kt(o))continue;const n=e[o];if((0,i.mf)(n))t[o]=Ct(o,n,r);else if(null!=n){0;const e=Tt(n);t[o]=()=>e}}},xt=(e,t)=>{const n=Tt(t);e.slots.default=()=>n},At=(e,t)=>{if(32&e.vnode.shapeFlag){const n=t._;n?(e.slots=(0,r.IU)(t),(0,i.Nj)(t,"_",n)):It(t,e.slots={})}else e.slots={},t&&xt(e,t);(0,i.Nj)(e.slots,cn,1)},Rt=(e,t,n)=>{const{vnode:r,slots:o}=e;let s=!0,a=i.kT;if(32&r.shapeFlag){const e=t._;e?n&&1===e?s=!1:((0,i.l7)(o,t),n||1!==e||delete o._):(s=!t.$stable,It(t,o)),a=t}else t&&(xt(e,t),a={default:1});if(s)for(const i in o)kt(i)||i in a||delete o[i]};function Ot(e,t,n,s,a=!1){if((0,i.kJ)(e))return void e.forEach(((e,r)=>Ot(e,t&&((0,i.kJ)(t)?t[r]:t),n,s,a)));if(he(s)&&!a)return;const l=4&s.shapeFlag?Hn(s.component)||s.component.proxy:s.el,u=a?null:l,{i:c,r:d}=e;const h=t&&t.r,f=c.refs===i.kT?c.refs={}:c.refs,p=c.setupState;if(null!=h&&h!==d&&((0,i.HD)(h)?(f[h]=null,(0,i.RI)(p,h)&&(p[h]=null)):(0,r.dq)(h)&&(h.value=null)),(0,i.mf)(d))o(d,c,12,[u,f]);else{const t=(0,i.HD)(d),o=(0,r.dq)(d);if(t||o){const r=()=>{if(e.f){const n=t?(0,i.RI)(p,d)?p[d]:f[d]:d.value;a?(0,i.kJ)(n)&&(0,i.Od)(n,l):(0,i.kJ)(n)?n.includes(l)||n.push(l):t?(f[d]=[l],(0,i.RI)(p,d)&&(p[d]=f[d])):(d.value=[l],e.k&&(f[e.k]=d.value))}else t?(f[d]=u,(0,i.RI)(p,d)&&(p[d]=u)):o&&(d.value=u,e.k&&(f[e.k]=u))};u?(r.id=-1,Pt(r,n)):r()}else 0}}function Nt(){}const Pt=H;function Ft(e){return Lt(e)}function Lt(e,t){Nt();const n=(0,i.E9)();n.__VUE__=!0;const{insert:o,remove:s,patchProp:a,createElement:l,createText:u,createComment:c,setText:d,setElementText:h,parentNode:f,nextSibling:p,setScopeId:g=i.dG,insertStaticContent:m}=e,v=(e,t,n,r=null,i=null,o=null,s=!1,a=null,l=!!t.dynamicChildren)=>{if(e===t)return;e&&!un(e,t)&&(r=Y(e),W(e,i,o,!0),e=null),-2===t.patchFlag&&(l=!1,t.dynamicChildren=null);const{type:u,ref:c,shapeFlag:d}=t;switch(u){case Gt:y(e,t,n,r);break;case Jt:b(e,t,n,r);break;case Qt:null==e&&_(t,n,r,s);break;case Zt:F(e,t,n,r,i,o,s,a,l);break;default:1&d?I(e,t,n,r,i,o,s,a,l):6&d?L(e,t,n,r,i,o,s,a,l):(64&d||128&d)&&u.process(e,t,n,r,i,o,s,a,l,te)}null!=c&&i&&Ot(c,e&&e.ref,o,t||e,!t)},y=(e,t,n,r)=>{if(null==e)o(t.el=u(t.children),n,r);else{const n=t.el=e.el;t.children!==e.children&&d(n,t.children)}},b=(e,t,n,r)=>{null==e?o(t.el=c(t.children||""),n,r):t.el=e.el},_=(e,t,n,r)=>{[e.el,e.anchor]=m(e.children,t,n,r,e.el,e.anchor)},E=({el:e,anchor:t},n,r)=>{let i;while(e&&e!==t)i=p(e),o(e,n,r),e=i;o(t,n,r)},C=({el:e,anchor:t})=>{let n;while(e&&e!==t)n=p(e),s(e),e=n;s(t)},I=(e,t,n,r,i,o,s,a,l)=>{s=s||"svg"===t.type,null==e?x(t,n,r,i,o,s,a,l):O(e,t,i,o,s,a,l)},x=(e,t,n,r,s,u,c,d)=>{let f,p;const{type:g,props:m,shapeFlag:v,transition:y,dirs:b}=e;if(f=e.el=l(e.type,u,m&&m.is,m),8&v?h(f,e.children):16&v&&R(e.children,f,null,r,s,u&&"foreignObject"!==g,c,d),b&&X(e,null,r,"created"),A(f,e,e.scopeId,c,r),m){for(const t in m)"value"===t||(0,i.Gg)(t)||a(f,t,null,m[t],u,e.children,r,s,Q);"value"in m&&a(f,"value",null,m.value),(p=m.onVnodeBeforeMount)&&kn(p,r,e)}b&&X(e,null,r,"beforeMount");const w=(!s||s&&!s.pendingBranch)&&y&&!y.persisted;w&&y.beforeEnter(f),o(f,t,n),((p=m&&m.onVnodeMounted)||w||b)&&Pt((()=>{p&&kn(p,r,e),w&&y.enter(f),b&&X(e,null,r,"mounted")}),s)},A=(e,t,n,r,i)=>{if(n&&g(e,n),r)for(let o=0;o<r.length;o++)g(e,r[o]);if(i){let n=i.subTree;if(t===n){const t=i.vnode;A(e,t,t.scopeId,t.slotScopeIds,i.parent)}}},R=(e,t,n,r,i,o,s,a,l=0)=>{for(let u=l;u<e.length;u++){const l=e[u]=a?_n(e[u]):wn(e[u]);v(null,l,t,n,r,i,o,s,a)}},O=(e,t,n,r,o,s,l)=>{const u=t.el=e.el;let{patchFlag:c,dynamicChildren:d,dirs:f}=t;c|=16&e.patchFlag;const p=e.props||i.kT,g=t.props||i.kT;let m;n&&Dt(n,!1),(m=g.onVnodeBeforeUpdate)&&kn(m,n,t,e),f&&X(t,e,n,"beforeUpdate"),n&&Dt(n,!0);const v=o&&"foreignObject"!==t.type;if(d?N(e.dynamicChildren,d,u,n,r,v,s):l||$(e,t,u,null,n,r,v,s,!1),c>0){if(16&c)P(u,t,p,g,n,r,o);else if(2&c&&p.class!==g.class&&a(u,"class",null,g.class,o),4&c&&a(u,"style",p.style,g.style,o),8&c){const i=t.dynamicProps;for(let t=0;t<i.length;t++){const s=i[t],l=p[s],c=g[s];c===l&&"value"!==s||a(u,s,l,c,o,e.children,n,r,Q)}}1&c&&e.children!==t.children&&h(u,t.children)}else l||null!=d||P(u,t,p,g,n,r,o);((m=g.onVnodeUpdated)||f)&&Pt((()=>{m&&kn(m,n,t,e),f&&X(t,e,n,"updated")}),r)},N=(e,t,n,r,i,o,s)=>{for(let a=0;a<t.length;a++){const l=e[a],u=t[a],c=l.el&&(l.type===Zt||!un(l,u)||70&l.shapeFlag)?f(l.el):n;v(l,u,c,null,r,i,o,s,!0)}},P=(e,t,n,r,o,s,l)=>{if(n!==r){if(n!==i.kT)for(const u in n)(0,i.Gg)(u)||u in r||a(e,u,n[u],null,l,t.children,o,s,Q);for(const u in r){if((0,i.Gg)(u))continue;const c=r[u],d=n[u];c!==d&&"value"!==u&&a(e,u,d,c,l,t.children,o,s,Q)}"value"in r&&a(e,"value",n.value,r.value)}},F=(e,t,n,r,i,s,a,l,c)=>{const d=t.el=e?e.el:u(""),h=t.anchor=e?e.anchor:u("");let{patchFlag:f,dynamicChildren:p,slotScopeIds:g}=t;g&&(l=l?l.concat(g):g),null==e?(o(d,n,r),o(h,n,r),R(t.children,n,h,i,s,a,l,c)):f>0&&64&f&&p&&e.dynamicChildren?(N(e.dynamicChildren,p,n,i,s,a,l),(null!=t.key||i&&t===i.subTree)&&Mt(e,t,!0)):$(e,t,n,h,i,s,a,l,c)},L=(e,t,n,r,i,o,s,a,l)=>{t.slotScopeIds=a,null==e?512&t.shapeFlag?i.ctx.activate(t,n,r,s,l):D(t,n,r,i,o,s,l):M(e,t,l)},D=(e,t,n,r,i,o,s)=>{const a=e.component=In(e,r,i);if(fe(e)&&(a.ctx.renderer=te),Vn(a),a.asyncDep){if(i&&i.registerDep(a,V),!e.el){const e=a.subTree=pn(Jt);b(null,e,t,n)}}else V(a,e,t,n,i,o,s)},M=(e,t,n)=>{const r=t.component=e.component;if(B(e,t,n)){if(r.asyncDep&&!r.asyncResolved)return void U(r,t,n);r.next=t,S(r.update),r.update()}else t.el=e.el,r.vnode=t},V=(e,t,n,o,s,a,l)=>{const u=()=>{if(e.isMounted){let t,{next:n,bu:r,u:o,parent:u,vnode:c}=e,d=n;0,Dt(e,!1),n?(n.el=c.el,U(e,n,l)):n=c,r&&(0,i.ir)(r),(t=n.props&&n.props.onVnodeBeforeUpdate)&&kn(t,u,n,c),Dt(e,!0);const h=q(e);0;const p=e.subTree;e.subTree=h,v(p,h,f(p.el),Y(p),e,s,a),n.el=h.el,null===d&&j(e,h.el),o&&Pt(o,s),(t=n.props&&n.props.onVnodeUpdated)&&Pt((()=>kn(t,u,n,c)),s)}else{let r;const{el:l,props:u}=t,{bm:c,m:d,parent:h}=e,f=he(t);if(Dt(e,!1),c&&(0,i.ir)(c),!f&&(r=u&&u.onVnodeBeforeMount)&&kn(r,h,t),Dt(e,!0),l&&re){const n=()=>{e.subTree=q(e),re(l,e.subTree,e,s,null)};f?t.type.__asyncLoader().then((()=>!e.isUnmounted&&n())):n()}else{0;const r=e.subTree=q(e);0,v(null,r,n,o,e,s,a),t.el=r.el}if(d&&Pt(d,s),!f&&(r=u&&u.onVnodeMounted)){const e=t;Pt((()=>kn(r,h,e)),s)}(256&t.shapeFlag||h&&he(h.vnode)&&256&h.vnode.shapeFlag)&&e.a&&Pt(e.a,s),e.isMounted=!0,t=n=o=null}},c=e.effect=new r.qq(u,(()=>w(d)),e.scope),d=e.update=()=>c.run();d.id=e.uid,Dt(e,!0),d()},U=(e,t,n)=>{t.component=e;const i=e.vnode.props;e.vnode=t,e.next=null,mt(e,t.props,i,n),Rt(e,t.children,n),(0,r.Jd)(),k(),(0,r.lk)()},$=(e,t,n,r,i,o,s,a,l=!1)=>{const u=e&&e.children,c=e?e.shapeFlag:0,d=t.children,{patchFlag:f,shapeFlag:p}=t;if(f>0){if(128&f)return void H(u,d,n,r,i,o,s,a,l);if(256&f)return void z(u,d,n,r,i,o,s,a,l)}8&p?(16&c&&Q(u,i,o),d!==u&&h(n,d)):16&c?16&p?H(u,d,n,r,i,o,s,a,l):Q(u,i,o,!0):(8&c&&h(n,""),16&p&&R(d,n,r,i,o,s,a,l))},z=(e,t,n,r,o,s,a,l,u)=>{e=e||i.Z6,t=t||i.Z6;const c=e.length,d=t.length,h=Math.min(c,d);let f;for(f=0;f<h;f++){const r=t[f]=u?_n(t[f]):wn(t[f]);v(e[f],r,n,null,o,s,a,l,u)}c>d?Q(e,o,s,!0,!1,h):R(t,n,r,o,s,a,l,u,h)},H=(e,t,n,r,o,s,a,l,u)=>{let c=0;const d=t.length;let h=e.length-1,f=d-1;while(c<=h&&c<=f){const r=e[c],i=t[c]=u?_n(t[c]):wn(t[c]);if(!un(r,i))break;v(r,i,n,null,o,s,a,l,u),c++}while(c<=h&&c<=f){const r=e[h],i=t[f]=u?_n(t[f]):wn(t[f]);if(!un(r,i))break;v(r,i,n,null,o,s,a,l,u),h--,f--}if(c>h){if(c<=f){const e=f+1,i=e<d?t[e].el:r;while(c<=f)v(null,t[c]=u?_n(t[c]):wn(t[c]),n,i,o,s,a,l,u),c++}}else if(c>f)while(c<=h)W(e[c],o,s,!0),c++;else{const p=c,g=c,m=new Map;for(c=g;c<=f;c++){const e=t[c]=u?_n(t[c]):wn(t[c]);null!=e.key&&m.set(e.key,c)}let y,b=0;const w=f-g+1;let _=!1,S=0;const E=new Array(w);for(c=0;c<w;c++)E[c]=0;for(c=p;c<=h;c++){const r=e[c];if(b>=w){W(r,o,s,!0);continue}let i;if(null!=r.key)i=m.get(r.key);else for(y=g;y<=f;y++)if(0===E[y-g]&&un(r,t[y])){i=y;break}void 0===i?W(r,o,s,!0):(E[i-g]=c+1,i>=S?S=i:_=!0,v(r,t[i],n,null,o,s,a,l,u),b++)}const k=_?qt(E):i.Z6;for(y=k.length-1,c=w-1;c>=0;c--){const e=g+c,i=t[e],h=e+1<d?t[e+1].el:r;0===E[c]?v(null,i,n,h,o,s,a,l,u):_&&(y<0||c!==k[y]?K(i,n,h,2):y--)}}},K=(e,t,n,r,i=null)=>{const{el:s,type:a,transition:l,children:u,shapeFlag:c}=e;if(6&c)return void K(e.component.subTree,t,n,r);if(128&c)return void e.suspense.move(t,n,r);if(64&c)return void a.move(e,t,n,te);if(a===Zt){o(s,t,n);for(let e=0;e<u.length;e++)K(u[e],t,n,r);return void o(e.anchor,t,n)}if(a===Qt)return void E(e,t,n);const d=2!==r&&1&c&&l;if(d)if(0===r)l.beforeEnter(s),o(s,t,n),Pt((()=>l.enter(s)),i);else{const{leave:e,delayLeave:r,afterLeave:i}=l,a=()=>o(s,t,n),u=()=>{e(s,(()=>{a(),i&&i()}))};r?r(s,a,u):u()}else o(s,t,n)},W=(e,t,n,r=!1,i=!1)=>{const{type:o,props:s,ref:a,children:l,dynamicChildren:u,shapeFlag:c,patchFlag:d,dirs:h}=e;if(null!=a&&Ot(a,null,n,e,!0),256&c)return void t.ctx.deactivate(e);const f=1&c&&h,p=!he(e);let g;if(p&&(g=s&&s.onVnodeBeforeUnmount)&&kn(g,t,e),6&c)J(e.component,n,r);else{if(128&c)return void e.suspense.unmount(n,r);f&&X(e,null,t,"beforeUnmount"),64&c?e.type.remove(e,t,n,i,te,r):u&&(o!==Zt||d>0&&64&d)?Q(u,t,n,!1,!0):(o===Zt&&384&d||!i&&16&c)&&Q(l,t,n),r&&Z(e)}(p&&(g=s&&s.onVnodeUnmounted)||f)&&Pt((()=>{g&&kn(g,t,e),f&&X(e,null,t,"unmounted")}),n)},Z=e=>{const{type:t,el:n,anchor:r,transition:i}=e;if(t===Zt)return void G(n,r);if(t===Qt)return void C(e);const o=()=>{s(n),i&&!i.persisted&&i.afterLeave&&i.afterLeave()};if(1&e.shapeFlag&&i&&!i.persisted){const{leave:t,delayLeave:r}=i,s=()=>t(n,o);r?r(e.el,o,s):s()}else o()},G=(e,t)=>{let n;while(e!==t)n=p(e),s(e),e=n;s(t)},J=(e,t,n)=>{const{bum:r,scope:o,update:s,subTree:a,um:l}=e;r&&(0,i.ir)(r),o.stop(),s&&(s.active=!1,W(a,e,t,n)),l&&Pt(l,t),Pt((()=>{e.isUnmounted=!0}),t),t&&t.pendingBranch&&!t.isUnmounted&&e.asyncDep&&!e.asyncResolved&&e.suspenseId===t.pendingId&&(t.deps--,0===t.deps&&t.resolve())},Q=(e,t,n,r=!1,i=!1,o=0)=>{for(let s=o;s<e.length;s++)W(e[s],t,n,r,i)},Y=e=>6&e.shapeFlag?Y(e.component.subTree):128&e.shapeFlag?e.suspense.next():p(e.anchor||e.el),ee=(e,t,n)=>{null==e?t._vnode&&W(t._vnode,null,null,!0):v(t._vnode||null,e,t,null,null,null,n),k(),T(),t._vnode=e},te={p:v,um:W,m:K,r:Z,mt:D,mc:R,pc:$,pbc:N,n:Y,o:e};let ne,re;return t&&([ne,re]=t(te)),{render:ee,hydrate:ne,createApp:dt(ee,ne)}}function Dt({effect:e,update:t},n){e.allowRecurse=t.allowRecurse=n}function Mt(e,t,n=!1){const r=e.children,o=t.children;if((0,i.kJ)(r)&&(0,i.kJ)(o))for(let i=0;i<r.length;i++){const e=r[i];let t=o[i];1&t.shapeFlag&&!t.dynamicChildren&&((t.patchFlag<=0||32===t.patchFlag)&&(t=o[i]=_n(o[i]),t.el=e.el),n||Mt(e,t)),t.type===Gt&&(t.el=e.el)}}function qt(e){const t=e.slice(),n=[0];let r,i,o,s,a;const l=e.length;for(r=0;r<l;r++){const l=e[r];if(0!==l){if(i=n[n.length-1],e[i]<l){t[r]=i,n.push(r);continue}o=0,s=n.length-1;while(o<s)a=o+s>>1,e[n[a]]<l?o=a+1:s=a;l<e[n[o]]&&(o>0&&(t[r]=n[o-1]),n[o]=r)}}o=n.length,s=n[o-1];while(o-- >0)n[o]=s,s=t[s];return n}const Vt=e=>e.__isTeleport,Ut=e=>e&&(e.disabled||""===e.disabled),Bt=e=>"undefined"!==typeof SVGElement&&e instanceof SVGElement,$t=(e,t)=>{const n=e&&e.to;if((0,i.HD)(n)){if(t){const e=t(n);return e}return null}return n},jt={__isTeleport:!0,process(e,t,n,r,i,o,s,a,l,u){const{mc:c,pc:d,pbc:h,o:{insert:f,querySelector:p,createText:g,createComment:m}}=u,v=Ut(t.props);let{shapeFlag:y,children:b,dynamicChildren:w}=t;if(null==e){const e=t.el=g(""),u=t.anchor=g("");f(e,n,r),f(u,n,r);const d=t.target=$t(t.props,p),h=t.targetAnchor=g("");d&&(f(h,d),s=s||Bt(d));const m=(e,t)=>{16&y&&c(b,e,t,i,o,s,a,l)};v?m(n,u):d&&m(d,h)}else{t.el=e.el;const r=t.anchor=e.anchor,c=t.target=e.target,f=t.targetAnchor=e.targetAnchor,g=Ut(e.props),m=g?n:c,y=g?r:f;if(s=s||Bt(c),w?(h(e.dynamicChildren,w,m,i,o,s,a),Mt(e,t,!0)):l||d(e,t,m,y,i,o,s,a,!1),v)g||zt(t,n,r,u,1);else if((t.props&&t.props.to)!==(e.props&&e.props.to)){const e=t.target=$t(t.props,p);e&&zt(t,e,null,u,0)}else g&&zt(t,c,f,u,1)}Wt(t)},remove(e,t,n,r,{um:i,o:{remove:o}},s){const{shapeFlag:a,children:l,anchor:u,targetAnchor:c,target:d,props:h}=e;if(d&&o(c),(s||!Ut(h))&&(o(u),16&a))for(let f=0;f<l.length;f++){const e=l[f];i(e,t,n,!0,!!e.dynamicChildren)}},move:zt,hydrate:Ht};function zt(e,t,n,{o:{insert:r},m:i},o=2){0===o&&r(e.targetAnchor,t,n);const{el:s,anchor:a,shapeFlag:l,children:u,props:c}=e,d=2===o;if(d&&r(s,t,n),(!d||Ut(c))&&16&l)for(let h=0;h<u.length;h++)i(u[h],t,n,2);d&&r(a,t,n)}function Ht(e,t,n,r,i,o,{o:{nextSibling:s,parentNode:a,querySelector:l}},u){const c=t.target=$t(t.props,l);if(c){const l=c._lpa||c.firstChild;if(16&t.shapeFlag)if(Ut(t.props))t.anchor=u(s(e),t,a(e),n,r,i,o),t.targetAnchor=l;else{t.anchor=s(e);let a=l;while(a)if(a=s(a),a&&8===a.nodeType&&"teleport anchor"===a.data){t.targetAnchor=a,c._lpa=t.targetAnchor&&s(t.targetAnchor);break}u(l,t,c,n,r,i,o)}Wt(t)}return t.anchor&&s(t.anchor)}const Kt=jt;function Wt(e){const t=e.ctx;if(t&&t.ut){let n=e.children[0].el;while(n!==e.targetAnchor)1===n.nodeType&&n.setAttribute("data-v-owner",t.uid),n=n.nextSibling;t.ut()}}const Zt=Symbol.for("v-fgt"),Gt=Symbol.for("v-txt"),Jt=Symbol.for("v-cmt"),Qt=Symbol.for("v-stc"),Yt=[];let Xt=null;function en(e=!1){Yt.push(Xt=e?null:[])}function tn(){Yt.pop(),Xt=Yt[Yt.length-1]||null}let nn=1;function rn(e){nn+=e}function on(e){return e.dynamicChildren=nn>0?Xt||i.Z6:null,tn(),nn>0&&Xt&&Xt.push(e),e}function sn(e,t,n,r,i,o){return on(fn(e,t,n,r,i,o,!0))}function an(e,t,n,r,i){return on(pn(e,t,n,r,i,!0))}function ln(e){return!!e&&!0===e.__v_isVNode}function un(e,t){return e.type===t.type&&e.key===t.key}const cn="__vInternal",dn=({key:e})=>null!=e?e:null,hn=({ref:e,ref_key:t,ref_for:n})=>("number"===typeof e&&(e=""+e),null!=e?(0,i.HD)(e)||(0,r.dq)(e)||(0,i.mf)(e)?{i:N,r:e,k:t,f:!!n}:e:null);function fn(e,t=null,n=null,r=0,o=null,s=(e===Zt?0:1),a=!1,l=!1){const u={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&dn(t),ref:t&&hn(t),scopeId:P,slotScopeIds:null,children:n,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:r,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:N};return l?(Sn(u,n),128&s&&e.normalize(u)):n&&(u.shapeFlag|=(0,i.HD)(n)?8:16),nn>0&&!a&&Xt&&(u.patchFlag>0||6&s)&&32!==u.patchFlag&&Xt.push(u),u}const pn=gn;function gn(e,t=null,n=null,o=0,s=null,a=!1){if(e&&e!==qe||(e=Jt),ln(e)){const r=vn(e,t,!0);return n&&Sn(r,n),nn>0&&!a&&Xt&&(6&r.shapeFlag?Xt[Xt.indexOf(e)]=r:Xt.push(r)),r.patchFlag|=-2,r}if(Wn(e)&&(e=e.__vccOpts),t){t=mn(t);let{class:e,style:n}=t;e&&!(0,i.HD)(e)&&(t.class=(0,i.C_)(e)),(0,i.Kn)(n)&&((0,r.X3)(n)&&!(0,i.kJ)(n)&&(n=(0,i.l7)({},n)),t.style=(0,i.j5)(n))}const l=(0,i.HD)(e)?1:z(e)?128:Vt(e)?64:(0,i.Kn)(e)?4:(0,i.mf)(e)?2:0;return fn(e,t,n,o,s,l,a,!0)}function mn(e){return e?(0,r.X3)(e)||cn in e?(0,i.l7)({},e):e:null}function vn(e,t,n=!1){const{props:r,ref:o,patchFlag:s,children:a}=e,l=t?En(r||{},t):r,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:l,key:l&&dn(l),ref:t&&t.ref?n&&o?(0,i.kJ)(o)?o.concat(hn(t)):[o,hn(t)]:hn(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:a,target:e.target,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Zt?-1===s?16:16|s:s,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:e.transition,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&vn(e.ssContent),ssFallback:e.ssFallback&&vn(e.ssFallback),el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return u}function yn(e=" ",t=0){return pn(Gt,null,e,t)}function bn(e="",t=!1){return t?(en(),an(Jt,null,e)):pn(Jt,null,e)}function wn(e){return null==e||"boolean"===typeof e?pn(Jt):(0,i.kJ)(e)?pn(Zt,null,e.slice()):"object"===typeof e?_n(e):pn(Gt,null,String(e))}function _n(e){return null===e.el&&-1!==e.patchFlag||e.memo?e:vn(e)}function Sn(e,t){let n=0;const{shapeFlag:r}=e;if(null==t)t=null;else if((0,i.kJ)(t))n=16;else if("object"===typeof t){if(65&r){const n=t.default;return void(n&&(n._c&&(n._d=!1),Sn(e,n()),n._c&&(n._d=!0)))}{n=32;const r=t._;r||cn in t?3===r&&N&&(1===N.slots._?t._=1:(t._=2,e.patchFlag|=1024)):t._ctx=N}}else(0,i.mf)(t)?(t={default:t,_ctx:N},n=32):(t=String(t),64&r?(n=16,t=[yn(t)]):n=8);e.children=t,e.shapeFlag|=n}function En(...e){const t={};for(let n=0;n<e.length;n++){const r=e[n];for(const e in r)if("class"===e)t.class!==r.class&&(t.class=(0,i.C_)([t.class,r.class]));else if("style"===e)t.style=(0,i.j5)([t.style,r.style]);else if((0,i.F7)(e)){const n=t[e],o=r[e];!o||n===o||(0,i.kJ)(n)&&n.includes(o)||(t[e]=n?[].concat(n,o):o)}else""!==e&&(t[e]=r[e])}return t}function kn(e,t,n,r=null){s(e,t,7,[n,r])}const Tn=ut();let Cn=0;function In(e,t,n){const o=e.type,s=(t?t.appContext:e.appContext)||Tn,a={uid:Cn++,vnode:e,type:o,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,scope:new r.Bj(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),accessCache:null,renderCache:[],components:null,directives:null,propsOptions:bt(o,s),emitsOptions:R(o,s),emit:null,emitted:null,propsDefaults:i.kT,inheritAttrs:o.inheritAttrs,ctx:i.kT,data:i.kT,props:i.kT,attrs:i.kT,slots:i.kT,refs:i.kT,setupState:i.kT,setupContext:null,attrsProxy:null,slotsProxy:null,suspense:n,suspenseId:n?n.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return a.ctx={_:a},a.root=t?t.root:a,a.emit=A.bind(null,a),e.ce&&e.ce(a),a}let xn=null;const An=()=>xn||N;let Rn,On,Nn="__VUE_INSTANCE_SETTERS__";(On=(0,i.E9)()[Nn])||(On=(0,i.E9)()[Nn]=[]),On.push((e=>xn=e)),Rn=e=>{On.length>1?On.forEach((t=>t(e))):On[0](e)};const Pn=e=>{Rn(e),e.scope.on()},Fn=()=>{xn&&xn.scope.off(),Rn(null)};function Ln(e){return 4&e.vnode.shapeFlag}let Dn,Mn,qn=!1;function Vn(e,t=!1){qn=t;const{props:n,children:r}=e.vnode,i=Ln(e);gt(e,n,i,t),At(e,r);const o=i?Un(e,t):void 0;return qn=!1,o}function Un(e,t){const n=e.type;e.accessCache=Object.create(null),e.proxy=(0,r.Xl)(new Proxy(e.ctx,Ke));const{setup:s}=n;if(s){const n=e.setupContext=s.length>1?zn(e):null;Pn(e),(0,r.Jd)();const l=o(s,e,0,[e.props,n]);if((0,r.lk)(),Fn(),(0,i.tI)(l)){if(l.then(Fn,Fn),t)return l.then((n=>{Bn(e,n,t)})).catch((t=>{a(t,e,0)}));e.asyncDep=l}else Bn(e,l,t)}else $n(e,t)}function Bn(e,t,n){(0,i.mf)(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:(0,i.Kn)(t)&&(e.setupState=(0,r.WL)(t)),$n(e,n)}function $n(e,t,n){const o=e.type;if(!e.render){if(!t&&Dn&&!o.render){const t=o.template||Xe(e).template;if(t){0;const{isCustomElement:n,compilerOptions:r}=e.appContext.config,{delimiters:s,compilerOptions:a}=o,l=(0,i.l7)((0,i.l7)({isCustomElement:n,delimiters:s},r),a);o.render=Dn(t,l)}}e.render=o.render||i.dG,Mn&&Mn(e)}Pn(e),(0,r.Jd)(),Ge(e),(0,r.lk)(),Fn()}function jn(e){return e.attrsProxy||(e.attrsProxy=new Proxy(e.attrs,{get(t,n){return(0,r.j)(e,"get","$attrs"),t[n]}}))}function zn(e){const t=t=>{e.exposed=t||{}};return{get attrs(){return jn(e)},slots:e.slots,emit:e.emit,expose:t}}function Hn(e){if(e.exposed)return e.exposeProxy||(e.exposeProxy=new Proxy((0,r.WL)((0,r.Xl)(e.exposed)),{get(t,n){return n in t?t[n]:n in ze?ze[n](e):void 0},has(e,t){return t in e||t in ze}}))}function Kn(e,t=!0){return(0,i.mf)(e)?e.displayName||e.name:e.name||t&&e.__name}function Wn(e){return(0,i.mf)(e)&&"__vccOpts"in e}const Zn=(e,t)=>(0,r.Fl)(e,t,qn);function Gn(e,t,n){const r=arguments.length;return 2===r?(0,i.Kn)(t)&&!(0,i.kJ)(t)?ln(t)?pn(e,null,[t]):pn(e,t):pn(e,null,t):(r>3?n=Array.prototype.slice.call(arguments,2):3===r&&ln(n)&&(n=[n]),pn(e,t,n))}const Jn=Symbol.for("v-scx"),Qn=()=>{{const e=pt(Jn);return e}};const Yn="3.3.4"},1957:(e,t,n)=>{"use strict";n.d(t,{D2:()=>ae,W3:()=>te,ri:()=>de,uT:()=>L});var r=n(6970),i=n(9835),o=n(499);const s="http://www.w3.org/2000/svg",a="undefined"!==typeof document?document:null,l=a&&a.createElement("template"),u={insert:(e,t,n)=>{t.insertBefore(e,n||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,n,r)=>{const i=t?a.createElementNS(s,e):a.createElement(e,n?{is:n}:void 0);return"select"===e&&r&&null!=r.multiple&&i.setAttribute("multiple",r.multiple),i},createText:e=>a.createTextNode(e),createComment:e=>a.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>a.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,n,r,i,o){const s=n?n.previousSibling:t.lastChild;if(i&&(i===o||i.nextSibling)){while(1)if(t.insertBefore(i.cloneNode(!0),n),i===o||!(i=i.nextSibling))break}else{l.innerHTML=r?`<svg>${e}</svg>`:e;const i=l.content;if(r){const e=i.firstChild;while(e.firstChild)i.appendChild(e.firstChild);i.removeChild(e)}t.insertBefore(i,n)}return[s?s.nextSibling:t.firstChild,n?n.previousSibling:t.lastChild]}};function c(e,t,n){const r=e._vtc;r&&(t=(t?[t,...r]:[...r]).join(" ")),null==t?e.removeAttribute("class"):n?e.setAttribute("class",t):e.className=t}function d(e,t,n){const i=e.style,o=(0,r.HD)(n);if(n&&!o){if(t&&!(0,r.HD)(t))for(const e in t)null==n[e]&&f(i,e,"");for(const e in n)f(i,e,n[e])}else{const r=i.display;o?t!==n&&(i.cssText=n):t&&e.removeAttribute("style"),"_vod"in e&&(i.display=r)}}const h=/\s*!important$/;function f(e,t,n){if((0,r.kJ)(n))n.forEach((n=>f(e,t,n)));else if(null==n&&(n=""),t.startsWith("--"))e.setProperty(t,n);else{const i=m(e,t);h.test(n)?e.setProperty((0,r.rs)(i),n.replace(h,""),"important"):e[i]=n}}const p=["Webkit","Moz","ms"],g={};function m(e,t){const n=g[t];if(n)return n;let i=(0,r._A)(t);if("filter"!==i&&i in e)return g[t]=i;i=(0,r.kC)(i);for(let r=0;r<p.length;r++){const n=p[r]+i;if(n in e)return g[t]=n}return t}const v="http://www.w3.org/1999/xlink";function y(e,t,n,i,o){if(i&&t.startsWith("xlink:"))null==n?e.removeAttributeNS(v,t.slice(6,t.length)):e.setAttributeNS(v,t,n);else{const i=(0,r.Pq)(t);null==n||i&&!(0,r.yA)(n)?e.removeAttribute(t):e.setAttribute(t,i?"":n)}}function b(e,t,n,i,o,s,a){if("innerHTML"===t||"textContent"===t)return i&&a(i,o,s),void(e[t]=null==n?"":n);const l=e.tagName;if("value"===t&&"PROGRESS"!==l&&!l.includes("-")){e._value=n;const r="OPTION"===l?e.getAttribute("value"):e.value,i=null==n?"":n;return r!==i&&(e.value=i),void(null==n&&e.removeAttribute(t))}let u=!1;if(""===n||null==n){const i=typeof e[t];"boolean"===i?n=(0,r.yA)(n):null==n&&"string"===i?(n="",u=!0):"number"===i&&(n=0,u=!0)}try{e[t]=n}catch(c){0}u&&e.removeAttribute(t)}function w(e,t,n,r){e.addEventListener(t,n,r)}function _(e,t,n,r){e.removeEventListener(t,n,r)}function S(e,t,n,r,i=null){const o=e._vei||(e._vei={}),s=o[t];if(r&&s)s.value=r;else{const[n,a]=k(t);if(r){const s=o[t]=x(r,i);w(e,n,s,a)}else s&&(_(e,n,s,a),o[t]=void 0)}}const E=/(?:Once|Passive|Capture)$/;function k(e){let t;if(E.test(e)){let n;t={};while(n=e.match(E))e=e.slice(0,e.length-n[0].length),t[n[0].toLowerCase()]=!0}const n=":"===e[2]?e.slice(3):(0,r.rs)(e.slice(2));return[n,t]}let T=0;const C=Promise.resolve(),I=()=>T||(C.then((()=>T=0)),T=Date.now());function x(e,t){const n=e=>{if(e._vts){if(e._vts<=n.attached)return}else e._vts=Date.now();(0,i.$d)(A(e,n.value),t,5,[e])};return n.value=e,n.attached=I(),n}function A(e,t){if((0,r.kJ)(t)){const n=e.stopImmediatePropagation;return e.stopImmediatePropagation=()=>{n.call(e),e._stopped=!0},t.map((e=>t=>!t._stopped&&e&&e(t)))}return t}const R=/^on[a-z]/,O=(e,t,n,i,o=!1,s,a,l,u)=>{"class"===t?c(e,i,o):"style"===t?d(e,n,i):(0,r.F7)(t)?(0,r.tR)(t)||S(e,t,n,i,a):("."===t[0]?(t=t.slice(1),1):"^"===t[0]?(t=t.slice(1),0):N(e,t,i,o))?b(e,t,i,s,a,l,u):("true-value"===t?e._trueValue=i:"false-value"===t&&(e._falseValue=i),y(e,t,i,o))};function N(e,t,n,i){return i?"innerHTML"===t||"textContent"===t||!!(t in e&&R.test(t)&&(0,r.mf)(n)):"spellcheck"!==t&&"draggable"!==t&&"translate"!==t&&("form"!==t&&(("list"!==t||"INPUT"!==e.tagName)&&(("type"!==t||"TEXTAREA"!==e.tagName)&&((!R.test(t)||!(0,r.HD)(n))&&t in e))))}"undefined"!==typeof HTMLElement&&HTMLElement;const P="transition",F="animation",L=(e,{slots:t})=>(0,i.h)(i.P$,U(e),t);L.displayName="Transition";const D={name:String,type:String,css:{type:Boolean,default:!0},duration:[String,Number,Object],enterFromClass:String,enterActiveClass:String,enterToClass:String,appearFromClass:String,appearActiveClass:String,appearToClass:String,leaveFromClass:String,leaveActiveClass:String,leaveToClass:String},M=L.props=(0,r.l7)({},i.nJ,D),q=(e,t=[])=>{(0,r.kJ)(e)?e.forEach((e=>e(...t))):e&&e(...t)},V=e=>!!e&&((0,r.kJ)(e)?e.some((e=>e.length>1)):e.length>1);function U(e){const t={};for(const r in e)r in D||(t[r]=e[r]);if(!1===e.css)return t;const{name:n="v",type:i,duration:o,enterFromClass:s=`${n}-enter-from`,enterActiveClass:a=`${n}-enter-active`,enterToClass:l=`${n}-enter-to`,appearFromClass:u=s,appearActiveClass:c=a,appearToClass:d=l,leaveFromClass:h=`${n}-leave-from`,leaveActiveClass:f=`${n}-leave-active`,leaveToClass:p=`${n}-leave-to`}=e,g=B(o),m=g&&g[0],v=g&&g[1],{onBeforeEnter:y,onEnter:b,onEnterCancelled:w,onLeave:_,onLeaveCancelled:S,onBeforeAppear:E=y,onAppear:k=b,onAppearCancelled:T=w}=t,C=(e,t,n)=>{z(e,t?d:l),z(e,t?c:a),n&&n()},I=(e,t)=>{e._isLeaving=!1,z(e,h),z(e,p),z(e,f),t&&t()},x=e=>(t,n)=>{const r=e?k:b,o=()=>C(t,e,n);q(r,[t,o]),H((()=>{z(t,e?u:s),j(t,e?d:l),V(r)||W(t,i,m,o)}))};return(0,r.l7)(t,{onBeforeEnter(e){q(y,[e]),j(e,s),j(e,a)},onBeforeAppear(e){q(E,[e]),j(e,u),j(e,c)},onEnter:x(!1),onAppear:x(!0),onLeave(e,t){e._isLeaving=!0;const n=()=>I(e,t);j(e,h),Q(),j(e,f),H((()=>{e._isLeaving&&(z(e,h),j(e,p),V(_)||W(e,i,v,n))})),q(_,[e,n])},onEnterCancelled(e){C(e,!1),q(w,[e])},onAppearCancelled(e){C(e,!0),q(T,[e])},onLeaveCancelled(e){I(e),q(S,[e])}})}function B(e){if(null==e)return null;if((0,r.Kn)(e))return[$(e.enter),$(e.leave)];{const t=$(e);return[t,t]}}function $(e){const t=(0,r.He)(e);return t}function j(e,t){t.split(/\s+/).forEach((t=>t&&e.classList.add(t))),(e._vtc||(e._vtc=new Set)).add(t)}function z(e,t){t.split(/\s+/).forEach((t=>t&&e.classList.remove(t)));const{_vtc:n}=e;n&&(n.delete(t),n.size||(e._vtc=void 0))}function H(e){requestAnimationFrame((()=>{requestAnimationFrame(e)}))}let K=0;function W(e,t,n,r){const i=e._endId=++K,o=()=>{i===e._endId&&r()};if(n)return setTimeout(o,n);const{type:s,timeout:a,propCount:l}=Z(e,t);if(!s)return r();const u=s+"end";let c=0;const d=()=>{e.removeEventListener(u,h),o()},h=t=>{t.target===e&&++c>=l&&d()};setTimeout((()=>{c<l&&d()}),a+1),e.addEventListener(u,h)}function Z(e,t){const n=window.getComputedStyle(e),r=e=>(n[e]||"").split(", "),i=r(`${P}Delay`),o=r(`${P}Duration`),s=G(i,o),a=r(`${F}Delay`),l=r(`${F}Duration`),u=G(a,l);let c=null,d=0,h=0;t===P?s>0&&(c=P,d=s,h=o.length):t===F?u>0&&(c=F,d=u,h=l.length):(d=Math.max(s,u),c=d>0?s>u?P:F:null,h=c?c===P?o.length:l.length:0);const f=c===P&&/\b(transform|all)(,|$)/.test(r(`${P}Property`).toString());return{type:c,timeout:d,propCount:h,hasTransform:f}}function G(e,t){while(e.length<t.length)e=e.concat(e);return Math.max(...t.map(((t,n)=>J(t)+J(e[n]))))}function J(e){return 1e3*Number(e.slice(0,-1).replace(",","."))}function Q(){return document.body.offsetHeight}const Y=new WeakMap,X=new WeakMap,ee={name:"TransitionGroup",props:(0,r.l7)({},M,{tag:String,moveClass:String}),setup(e,{slots:t}){const n=(0,i.FN)(),r=(0,i.Y8)();let s,a;return(0,i.ic)((()=>{if(!s.length)return;const t=e.moveClass||`${e.name||"v"}-move`;if(!oe(s[0].el,n.vnode.el,t))return;s.forEach(ne),s.forEach(re);const r=s.filter(ie);Q(),r.forEach((e=>{const n=e.el,r=n.style;j(n,t),r.transform=r.webkitTransform=r.transitionDuration="";const i=n._moveCb=e=>{e&&e.target!==n||e&&!/transform$/.test(e.propertyName)||(n.removeEventListener("transitionend",i),n._moveCb=null,z(n,t))};n.addEventListener("transitionend",i)}))})),()=>{const l=(0,o.IU)(e),u=U(l);let c=l.tag||i.HY;s=a,a=t.default?(0,i.Q6)(t.default()):[];for(let e=0;e<a.length;e++){const t=a[e];null!=t.key&&(0,i.nK)(t,(0,i.U2)(t,u,r,n))}if(s)for(let e=0;e<s.length;e++){const t=s[e];(0,i.nK)(t,(0,i.U2)(t,u,r,n)),Y.set(t,t.el.getBoundingClientRect())}return(0,i.Wm)(c,null,a)}}};ee.props;const te=ee;function ne(e){const t=e.el;t._moveCb&&t._moveCb(),t._enterCb&&t._enterCb()}function re(e){X.set(e,e.el.getBoundingClientRect())}function ie(e){const t=Y.get(e),n=X.get(e),r=t.left-n.left,i=t.top-n.top;if(r||i){const t=e.el.style;return t.transform=t.webkitTransform=`translate(${r}px,${i}px)`,t.transitionDuration="0s",e}}function oe(e,t,n){const r=e.cloneNode();e._vtc&&e._vtc.forEach((e=>{e.split(/\s+/).forEach((e=>e&&r.classList.remove(e)))})),n.split(/\s+/).forEach((e=>e&&r.classList.add(e))),r.style.display="none";const i=1===t.nodeType?t:t.parentNode;i.appendChild(r);const{hasTransform:o}=Z(r);return i.removeChild(r),o}const se={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},ae=(e,t)=>n=>{if(!("key"in n))return;const i=(0,r.rs)(n.key);return t.some((e=>e===i||se[e]===i))?e(n):void 0};const le=(0,r.l7)({patchProp:O},u);let ue;function ce(){return ue||(ue=(0,i.Us)(le))}const de=(...e)=>{const t=ce().createApp(...e);const{mount:n}=t;return t.mount=e=>{const i=he(e);if(!i)return;const o=t._component;(0,r.mf)(o)||o.render||o.template||(o.template=i.innerHTML),i.innerHTML="";const s=n(i,!1,i instanceof SVGElement);return i instanceof Element&&(i.removeAttribute("v-cloak"),i.setAttribute("data-v-app","")),s},t};function he(e){if((0,r.HD)(e)){const t=document.querySelector(e);return t}return e}},6970:(e,t,n)=>{"use strict";function r(e,t){const n=Object.create(null),r=e.split(",");for(let i=0;i<r.length;i++)n[r[i]]=!0;return t?e=>!!n[e.toLowerCase()]:e=>!!n[e]}n.d(t,{C_:()=>Y,DM:()=>v,E9:()=>z,F7:()=>u,Gg:()=>R,HD:()=>_,He:()=>$,Kj:()=>b,Kn:()=>E,NO:()=>a,Nj:()=>U,Od:()=>h,PO:()=>x,Pq:()=>ee,RI:()=>p,S0:()=>A,W7:()=>I,WV:()=>re,Z6:()=>o,_A:()=>P,_N:()=>m,aU:()=>q,dG:()=>s,e1:()=>K,fY:()=>r,h5:()=>B,hR:()=>M,hq:()=>ie,ir:()=>V,j5:()=>W,kC:()=>D,kJ:()=>g,kT:()=>i,l7:()=>d,mf:()=>w,rs:()=>L,tI:()=>k,tR:()=>c,yA:()=>te,yk:()=>S,zw:()=>oe});const i={},o=[],s=()=>{},a=()=>!1,l=/^on[^a-z]/,u=e=>l.test(e),c=e=>e.startsWith("onUpdate:"),d=Object.assign,h=(e,t)=>{const n=e.indexOf(t);n>-1&&e.splice(n,1)},f=Object.prototype.hasOwnProperty,p=(e,t)=>f.call(e,t),g=Array.isArray,m=e=>"[object Map]"===C(e),v=e=>"[object Set]"===C(e),y=e=>"[object Date]"===C(e),b=e=>"[object RegExp]"===C(e),w=e=>"function"===typeof e,_=e=>"string"===typeof e,S=e=>"symbol"===typeof e,E=e=>null!==e&&"object"===typeof e,k=e=>E(e)&&w(e.then)&&w(e.catch),T=Object.prototype.toString,C=e=>T.call(e),I=e=>C(e).slice(8,-1),x=e=>"[object Object]"===C(e),A=e=>_(e)&&"NaN"!==e&&"-"!==e[0]&&""+parseInt(e,10)===e,R=r(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),O=e=>{const t=Object.create(null);return n=>{const r=t[n];return r||(t[n]=e(n))}},N=/-(\w)/g,P=O((e=>e.replace(N,((e,t)=>t?t.toUpperCase():"")))),F=/\B([A-Z])/g,L=O((e=>e.replace(F,"-$1").toLowerCase())),D=O((e=>e.charAt(0).toUpperCase()+e.slice(1))),M=O((e=>e?`on${D(e)}`:"")),q=(e,t)=>!Object.is(e,t),V=(e,t)=>{for(let n=0;n<e.length;n++)e[n](t)},U=(e,t,n)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,value:n})},B=e=>{const t=parseFloat(e);return isNaN(t)?e:t},$=e=>{const t=_(e)?Number(e):NaN;return isNaN(t)?e:t};let j;const z=()=>j||(j="undefined"!==typeof globalThis?globalThis:"undefined"!==typeof self?self:"undefined"!==typeof window?window:"undefined"!==typeof n.g?n.g:{});const H="Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt,console",K=r(H);function W(e){if(g(e)){const t={};for(let n=0;n<e.length;n++){const r=e[n],i=_(r)?Q(r):W(r);if(i)for(const e in i)t[e]=i[e]}return t}return _(e)||E(e)?e:void 0}const Z=/;(?![^(]*\))/g,G=/:([^]+)/,J=/\/\*[^]*?\*\//g;function Q(e){const t={};return e.replace(J,"").split(Z).forEach((e=>{if(e){const n=e.split(G);n.length>1&&(t[n[0].trim()]=n[1].trim())}})),t}function Y(e){let t="";if(_(e))t=e;else if(g(e))for(let n=0;n<e.length;n++){const r=Y(e[n]);r&&(t+=r+" ")}else if(E(e))for(const n in e)e[n]&&(t+=n+" ");return t.trim()}const X="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",ee=r(X);function te(e){return!!e||""===e}function ne(e,t){if(e.length!==t.length)return!1;let n=!0;for(let r=0;n&&r<e.length;r++)n=re(e[r],t[r]);return n}function re(e,t){if(e===t)return!0;let n=y(e),r=y(t);if(n||r)return!(!n||!r)&&e.getTime()===t.getTime();if(n=S(e),r=S(t),n||r)return e===t;if(n=g(e),r=g(t),n||r)return!(!n||!r)&&ne(e,t);if(n=E(e),r=E(t),n||r){if(!n||!r)return!1;const i=Object.keys(e).length,o=Object.keys(t).length;if(i!==o)return!1;for(const n in e){const r=e.hasOwnProperty(n),i=t.hasOwnProperty(n);if(r&&!i||!r&&i||!re(e[n],t[n]))return!1}}return String(e)===String(t)}function ie(e,t){return e.findIndex((e=>re(e,t)))}const oe=e=>_(e)?e:null==e?"":g(e)||E(e)&&(e.toString===T||!w(e.toString))?JSON.stringify(e,se,2):String(e),se=(e,t)=>t&&t.__v_isRef?se(e,t.value):m(t)?{[`Map(${t.size})`]:[...t.entries()].reduce(((e,[t,n])=>(e[`${t} =>`]=n,e)),{})}:v(t)?{[`Set(${t.size})`]:[...t.values()]}:!E(t)||g(t)||x(t)?t:String(t)},1357:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l});var r=n(9835),i=n(2857),o=n(244),s=n(5987),a=n(2026);const l=(0,s.L)({name:"QAvatar",props:{...o.LU,fontSize:String,color:String,textColor:String,icon:String,square:Boolean,rounded:Boolean},setup(e,{slots:t}){const n=(0,o.ZP)(e),s=(0,r.Fl)((()=>"q-avatar"+(e.color?` bg-${e.color}`:"")+(e.textColor?` text-${e.textColor} q-chip--colored`:"")+(!0===e.square?" q-avatar--square":!0===e.rounded?" rounded-borders":""))),l=(0,r.Fl)((()=>e.fontSize?{fontSize:e.fontSize}:null));return()=>{const o=void 0!==e.icon?[(0,r.h)(i.Z,{name:e.icon})]:void 0;return(0,r.h)("div",{class:s.value,style:n.value},[(0,r.h)("div",{class:"q-avatar__content row flex-center overflow-hidden",style:l.value},(0,a.pf)(t.default,o))])}}})},8983:(e,t,n)=>{"use strict";n.d(t,{Z:()=>c});var r=n(9835),i=n(8879),o=n(5987),s=n(2026);const a=(0,o.L)({name:"QBtnGroup",props:{unelevated:Boolean,outline:Boolean,flat:Boolean,rounded:Boolean,square:Boolean,push:Boolean,stretch:Boolean,glossy:Boolean,spread:Boolean},setup(e,{slots:t}){const n=(0,r.Fl)((()=>{const t=["unelevated","outline","flat","rounded","square","push","stretch","glossy"].filter((t=>!0===e[t])).map((e=>`q-btn-group--${e}`)).join(" ");return"q-btn-group row no-wrap"+(0!==t.length?" "+t:"")+(!0===e.spread?" q-btn-group--spread":" inline")}));return()=>(0,r.h)("div",{class:n.value},(0,s.KR)(t.default))}});var l=n(9256),u=n(6073);const c=(0,o.L)({name:"QBtnToggle",props:{...l.Fz,modelValue:{required:!0},options:{type:Array,required:!0,validator:e=>e.every((e=>("label"in e||"icon"in e||"slot"in e)&&"value"in e))},color:String,textColor:String,toggleColor:{type:String,default:"primary"},toggleTextColor:String,outline:Boolean,flat:Boolean,unelevated:Boolean,rounded:Boolean,push:Boolean,glossy:Boolean,size:String,padding:String,noCaps:Boolean,noWrap:Boolean,dense:Boolean,readonly:Boolean,disable:Boolean,stack:Boolean,stretch:Boolean,spread:Boolean,clearable:Boolean,ripple:{type:[Boolean,Object],default:!0}},emits:["update:modelValue","clear","click"],setup(e,{slots:t,emit:n}){const o=(0,r.Fl)((()=>void 0!==e.options.find((t=>t.value===e.modelValue)))),c=(0,r.Fl)((()=>({type:"hidden",name:e.name,value:e.modelValue}))),d=(0,l.eX)(c),h=(0,r.Fl)((()=>(0,u._V)(e))),f=(0,r.Fl)((()=>({rounded:e.rounded,dense:e.dense,...h.value}))),p=(0,r.Fl)((()=>e.options.map(((t,n)=>{const{attrs:r,value:i,slot:o,...s}=t;return{slot:o,props:{key:n,"aria-pressed":i===e.modelValue?"true":"false",...r,...s,...f.value,disable:!0===e.disable||!0===s.disable,color:i===e.modelValue?m(s,"toggleColor"):m(s,"color"),textColor:i===e.modelValue?m(s,"toggleTextColor"):m(s,"textColor"),noCaps:!0===m(s,"noCaps"),noWrap:!0===m(s,"noWrap"),size:m(s,"size"),padding:m(s,"padding"),ripple:m(s,"ripple"),stack:!0===m(s,"stack"),stretch:!0===m(s,"stretch"),onClick(e){g(i,t,e)}}}}))));function g(t,r,i){!0!==e.readonly&&(e.modelValue===t?!0===e.clearable&&(n("update:modelValue",null,null),n("clear")):n("update:modelValue",t,r),n("click",i))}function m(t,n){return void 0===t[n]?e[n]:t[n]}function v(){const n=p.value.map((e=>(0,r.h)(i.Z,e.props,void 0!==e.slot?t[e.slot]:void 0)));return void 0!==e.name&&!0!==e.disable&&!0===o.value&&d(n,"push"),(0,s.vs)(t.default,n)}return()=>(0,r.h)(a,{class:"q-btn-toggle",...h.value,rounded:e.rounded,stretch:e.stretch,glossy:e.glossy,spread:e.spread},v)}})},8879:(e,t,n)=>{"use strict";n.d(t,{Z:()=>y});n(9665);var r=n(9835),i=n(499),o=n(1957),s=n(2857),a=n(3940),l=n(1136),u=n(6073),c=n(5987),d=n(2026),h=n(1384),f=n(1705);const{passiveCapture:p}=h.listenOpts;let g=null,m=null,v=null;const y=(0,c.L)({name:"QBtn",props:{...u.b7,percentage:Number,darkPercentage:Boolean,onTouchstart:[Function,Array]},emits:["click","keydown","mousedown","keyup"],setup(e,{slots:t,emit:n}){const{proxy:c}=(0,r.FN)(),{classes:y,style:b,innerClasses:w,attributes:_,hasLink:S,linkTag:E,navigateOnClick:k,isActionable:T}=(0,u.ZP)(e),C=(0,i.iH)(null),I=(0,i.iH)(null);let x,A=null,R=null;const O=(0,r.Fl)((()=>void 0!==e.label&&null!==e.label&&""!==e.label)),N=(0,r.Fl)((()=>!0!==e.disable&&!1!==e.ripple&&{keyCodes:!0===S.value?[13,32]:[13],...!0===e.ripple?{}:e.ripple})),P=(0,r.Fl)((()=>({center:e.round}))),F=(0,r.Fl)((()=>{const t=Math.max(0,Math.min(100,e.percentage));return t>0?{transition:"transform 0.6s",transform:`translateX(${t-100}%)`}:{}})),L=(0,r.Fl)((()=>{if(!0===e.loading)return{onMousedown:j,onTouchstart:j,onClick:j,onKeydown:j,onKeyup:j};if(!0===T.value){const t={onClick:M,onKeydown:q,onMousedown:U};if(!0===c.$q.platform.has.touch){const n=void 0!==e.onTouchstart?"":"Passive";t[`onTouchstart${n}`]=V}return t}return{onClick:h.NS}})),D=(0,r.Fl)((()=>({ref:C,class:"q-btn q-btn-item non-selectable no-outline "+y.value,style:b.value,..._.value,...L.value})));function M(t){if(null!==C.value){if(void 0!==t){if(!0===t.defaultPrevented)return;const n=document.activeElement;if("submit"===e.type&&n!==document.body&&!1===C.value.contains(n)&&!1===n.contains(C.value)){C.value.focus();const e=()=>{document.removeEventListener("keydown",h.NS,!0),document.removeEventListener("keyup",e,p),null!==C.value&&C.value.removeEventListener("blur",e,p)};document.addEventListener("keydown",h.NS,!0),document.addEventListener("keyup",e,p),C.value.addEventListener("blur",e,p)}}k(t)}}function q(e){null!==C.value&&(n("keydown",e),!0===(0,f.So)(e,[13,32])&&m!==C.value&&(null!==m&&$(),!0!==e.defaultPrevented&&(C.value.focus(),m=C.value,C.value.classList.add("q-btn--active"),document.addEventListener("keyup",B,!0),C.value.addEventListener("blur",B,p)),(0,h.NS)(e)))}function V(e){null!==C.value&&(n("touchstart",e),!0!==e.defaultPrevented&&(g!==C.value&&(null!==g&&$(),g=C.value,A=e.target,A.addEventListener("touchcancel",B,p),A.addEventListener("touchend",B,p)),x=!0,null!==R&&clearTimeout(R),R=setTimeout((()=>{R=null,x=!1}),200)))}function U(e){null!==C.value&&(e.qSkipRipple=!0===x,n("mousedown",e),!0!==e.defaultPrevented&&v!==C.value&&(null!==v&&$(),v=C.value,C.value.classList.add("q-btn--active"),document.addEventListener("mouseup",B,p)))}function B(e){if(null!==C.value&&(void 0===e||"blur"!==e.type||document.activeElement!==C.value)){if(void 0!==e&&"keyup"===e.type){if(m===C.value&&!0===(0,f.So)(e,[13,32])){const t=new MouseEvent("click",e);t.qKeyEvent=!0,!0===e.defaultPrevented&&(0,h.X$)(t),!0===e.cancelBubble&&(0,h.sT)(t),C.value.dispatchEvent(t),(0,h.NS)(e),e.qKeyEvent=!0}n("keyup",e)}$()}}function $(e){const t=I.value;!0===e||g!==C.value&&v!==C.value||null===t||t===document.activeElement||(t.setAttribute("tabindex",-1),t.focus()),g===C.value&&(null!==A&&(A.removeEventListener("touchcancel",B,p),A.removeEventListener("touchend",B,p)),g=A=null),v===C.value&&(document.removeEventListener("mouseup",B,p),v=null),m===C.value&&(document.removeEventListener("keyup",B,!0),null!==C.value&&C.value.removeEventListener("blur",B,p),m=null),null!==C.value&&C.value.classList.remove("q-btn--active")}function j(e){(0,h.NS)(e),e.qSkipRipple=!0}return(0,r.Jd)((()=>{$(!0)})),Object.assign(c,{click:M}),()=>{let n=[];void 0!==e.icon&&n.push((0,r.h)(s.Z,{name:e.icon,left:!1===e.stack&&!0===O.value,role:"img","aria-hidden":"true"})),!0===O.value&&n.push((0,r.h)("span",{class:"block"},[e.label])),n=(0,d.vs)(t.default,n),void 0!==e.iconRight&&!1===e.round&&n.push((0,r.h)(s.Z,{name:e.iconRight,right:!1===e.stack&&!0===O.value,role:"img","aria-hidden":"true"}));const i=[(0,r.h)("span",{class:"q-focus-helper",ref:I})];return!0===e.loading&&void 0!==e.percentage&&i.push((0,r.h)("span",{class:"q-btn__progress absolute-full overflow-hidden"+(!0===e.darkPercentage?" q-btn__progress--dark":"")},[(0,r.h)("span",{class:"q-btn__progress-indicator fit block",style:F.value})])),i.push((0,r.h)("span",{class:"q-btn__content text-center col items-center q-anchor--skip "+w.value},n)),null!==e.loading&&i.push((0,r.h)(o.uT,{name:"q-transition--fade"},(()=>!0===e.loading?[(0,r.h)("span",{key:"loading",class:"absolute-full flex flex-center"},void 0!==t.loading?t.loading():[(0,r.h)(a.Z)])]:null))),(0,r.wy)((0,r.h)(E.value,D.value,i),[[l.Z,N.value,void 0,P.value]])}}})},6073:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>g,_V:()=>f,b7:()=>p});n(9665);var r=n(9835),i=n(5065),o=n(244),s=n(945);const a={none:0,xs:4,sm:8,md:16,lg:24,xl:32},l={xs:8,sm:10,md:14,lg:20,xl:24},u=["button","submit","reset"],c=/[^\s]\/[^\s]/,d=["flat","outline","push","unelevated"],h=(e,t)=>!0===e.flat?"flat":!0===e.outline?"outline":!0===e.push?"push":!0===e.unelevated?"unelevated":t,f=e=>{const t=h(e);return void 0!==t?{[t]:!0}:{}},p={...o.LU,...s.$,type:{type:String,default:"button"},label:[Number,String],icon:String,iconRight:String,...d.reduce(((e,t)=>(e[t]=Boolean)&&e),{}),square:Boolean,round:Boolean,rounded:Boolean,glossy:Boolean,size:String,fab:Boolean,fabMini:Boolean,padding:String,color:String,textColor:String,noCaps:Boolean,noWrap:Boolean,dense:Boolean,tabindex:[Number,String],ripple:{type:[Boolean,Object],default:!0},align:{...i.jO.align,default:"center"},stack:Boolean,stretch:Boolean,loading:{type:Boolean,default:null},disable:Boolean};function g(e){const t=(0,o.ZP)(e,l),n=(0,i.ZP)(e),{hasRouterLink:d,hasLink:f,linkTag:p,linkAttrs:g,navigateOnClick:m}=(0,s.Z)({fallbackTag:"button"}),v=(0,r.Fl)((()=>{const n=!1===e.fab&&!1===e.fabMini?t.value:{};return void 0!==e.padding?Object.assign({},n,{padding:e.padding.split(/\s+/).map((e=>e in a?a[e]+"px":e)).join(" "),minWidth:"0",minHeight:"0"}):n})),y=(0,r.Fl)((()=>!0===e.rounded||!0===e.fab||!0===e.fabMini)),b=(0,r.Fl)((()=>!0!==e.disable&&!0!==e.loading)),w=(0,r.Fl)((()=>!0===b.value?e.tabindex||0:-1)),_=(0,r.Fl)((()=>h(e,"standard"))),S=(0,r.Fl)((()=>{const t={tabindex:w.value};return!0===f.value?Object.assign(t,g.value):!0===u.includes(e.type)&&(t.type=e.type),"a"===p.value?(!0===e.disable?t["aria-disabled"]="true":void 0===t.href&&(t.role="button"),!0!==d.value&&!0===c.test(e.type)&&(t.type=e.type)):!0===e.disable&&(t.disabled="",t["aria-disabled"]="true"),!0===e.loading&&void 0!==e.percentage&&Object.assign(t,{role:"progressbar","aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":e.percentage}),t})),E=(0,r.Fl)((()=>{let t;void 0!==e.color?t=!0===e.flat||!0===e.outline?`text-${e.textColor||e.color}`:`bg-${e.color} text-${e.textColor||"white"}`:e.textColor&&(t=`text-${e.textColor}`);const n=!0===e.round?"round":"rectangle"+(!0===y.value?" q-btn--rounded":!0===e.square?" q-btn--square":"");return`q-btn--${_.value} q-btn--${n}`+(void 0!==t?" "+t:"")+(!0===b.value?" q-btn--actionable q-focusable q-hoverable":!0===e.disable?" disabled":"")+(!0===e.fab?" q-btn--fab":!0===e.fabMini?" q-btn--fab-mini":"")+(!0===e.noCaps?" q-btn--no-uppercase":"")+(!0===e.dense?" q-btn--dense":"")+(!0===e.stretch?" no-border-radius self-stretch":"")+(!0===e.glossy?" glossy":"")+(e.square?" q-btn--square":"")})),k=(0,r.Fl)((()=>n.value+(!0===e.stack?" column":" row")+(!0===e.noWrap?" no-wrap text-no-wrap":"")+(!0===e.loading?" q-btn__content--hidden":"")));return{classes:E,style:v,innerClasses:k,attributes:S,hasLink:f,linkTag:p,navigateOnClick:m,isActionable:b}}},4458:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(9835),i=n(8234),o=n(5987),s=n(2026);const a=(0,o.L)({name:"QCard",props:{...i.S,tag:{type:String,default:"div"},square:Boolean,flat:Boolean,bordered:Boolean},setup(e,{slots:t}){const{proxy:{$q:n}}=(0,r.FN)(),o=(0,i.Z)(e,n),a=(0,r.Fl)((()=>"q-card"+(!0===o.value?" q-card--dark q-dark":"")+(!0===e.bordered?" q-card--bordered":"")+(!0===e.square?" q-card--square no-border-radius":"")+(!0===e.flat?" q-card--flat no-shadow":"")));return()=>(0,r.h)(e.tag,{class:a.value},(0,s.KR)(t.default))}})},1821:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(9835),i=n(5065),o=n(5987),s=n(2026);const a=(0,o.L)({name:"QCardActions",props:{...i.jO,vertical:Boolean},setup(e,{slots:t}){const n=(0,i.ZP)(e),o=(0,r.Fl)((()=>`q-card__actions ${n.value} q-card__actions--`+(!0===e.vertical?"vert column":"horiz row")));return()=>(0,r.h)("div",{class:o.value},(0,s.KR)(t.default))}})},3190:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(9835),i=n(5987),o=n(2026);const s=(0,i.L)({name:"QCardSection",props:{tag:{type:String,default:"div"},horizontal:Boolean},setup(e,{slots:t}){const n=(0,r.Fl)((()=>"q-card__section q-card__section--"+(!0===e.horizontal?"horiz row no-wrap":"vert")));return()=>(0,r.h)(e.tag,{class:n.value},(0,o.KR)(t.default))}})},7052:(e,t,n)=>{"use strict";n.d(t,{Z:()=>f});n(9665);var r=n(9835),i=n(8879),o=n(8234),s=n(3936),a=n(3929),l=n(5987),u=n(4680),c=n(2026);const d=["top","right","bottom","left"],h=["regular","flat","outline","push","unelevated"],f=(0,l.L)({name:"QCarousel",props:{...o.S,...s.t6,...a.kM,transitionPrev:{type:String,default:"fade"},transitionNext:{type:String,default:"fade"},height:String,padding:Boolean,controlColor:String,controlTextColor:String,controlType:{type:String,validator:e=>h.includes(e),default:"flat"},autoplay:[Number,Boolean],arrows:Boolean,prevIcon:String,nextIcon:String,navigation:Boolean,navigationPosition:{type:String,validator:e=>d.includes(e)},navigationIcon:String,navigationActiveIcon:String,thumbnails:Boolean},emits:[...a.fL,...s.K6],setup(e,{slots:t}){const{proxy:{$q:n}}=(0,r.FN)(),l=(0,o.Z)(e,n);let d,h=null;const{updatePanelsList:f,getPanelContent:p,panelDirectives:g,goToPanel:m,previousPanel:v,nextPanel:y,getEnabledPanels:b,panelIndex:w}=(0,s.ZP)(),{inFullscreen:_}=(0,a.ZP)(),S=(0,r.Fl)((()=>!0!==_.value&&void 0!==e.height?{height:e.height}:{})),E=(0,r.Fl)((()=>!0===e.vertical?"vertical":"horizontal")),k=(0,r.Fl)((()=>`q-carousel q-panel-parent q-carousel--with${!0===e.padding?"":"out"}-padding`+(!0===_.value?" fullscreen":"")+(!0===l.value?" q-carousel--dark q-dark":"")+(!0===e.arrows?` q-carousel--arrows-${E.value}`:"")+(!0===e.navigation?` q-carousel--navigation-${x.value}`:""))),T=(0,r.Fl)((()=>{const t=[e.prevIcon||n.iconSet.carousel[!0===e.vertical?"up":"left"],e.nextIcon||n.iconSet.carousel[!0===e.vertical?"down":"right"]];return!1===e.vertical&&!0===n.lang.rtl?t.reverse():t})),C=(0,r.Fl)((()=>e.navigationIcon||n.iconSet.carousel.navigationIcon)),I=(0,r.Fl)((()=>e.navigationActiveIcon||C.value)),x=(0,r.Fl)((()=>e.navigationPosition||(!0===e.vertical?"right":"bottom"))),A=(0,r.Fl)((()=>({color:e.controlColor,textColor:e.controlTextColor,round:!0,[e.controlType]:!0,dense:!0})));function R(){const t=!0===(0,u.hj)(e.autoplay)?Math.abs(e.autoplay):5e3;null!==h&&clearTimeout(h),h=setTimeout((()=>{h=null,t>=0?y():v()}),t)}function O(t,n){return(0,r.h)("div",{class:`q-carousel__control q-carousel__navigation no-wrap absolute flex q-carousel__navigation--${t} q-carousel__navigation--${x.value}`+(void 0!==e.controlColor?` text-${e.controlColor}`:"")},[(0,r.h)("div",{class:"q-carousel__navigation-inner flex flex-center no-wrap"},b().map(n))])}function N(){const n=[];if(!0===e.navigation){const e=void 0!==t["navigation-icon"]?t["navigation-icon"]:e=>(0,r.h)(i.Z,{key:"nav"+e.name,class:`q-carousel__navigation-icon q-carousel__navigation-icon--${!0===e.active?"":"in"}active`,...e.btnProps,onClick:e.onClick}),o=d-1;n.push(O("buttons",((t,n)=>{const r=t.props.name,i=w.value===n;return e({index:n,maxIndex:o,name:r,active:i,btnProps:{icon:!0===i?I.value:C.value,size:"sm",...A.value},onClick:()=>{m(r)}})})))}else if(!0===e.thumbnails){const t=void 0!==e.controlColor?` text-${e.controlColor}`:"";n.push(O("thumbnails",(n=>{const i=n.props;return(0,r.h)("img",{key:"tmb#"+i.name,class:`q-carousel__thumbnail q-carousel__thumbnail--${i.name===e.modelValue?"":"in"}active`+t,src:i.imgSrc||i["img-src"],onClick:()=>{m(i.name)}})})))}return!0===e.arrows&&w.value>=0&&((!0===e.infinite||w.value>0)&&n.push((0,r.h)("div",{key:"prev",class:`q-carousel__control q-carousel__arrow q-carousel__prev-arrow q-carousel__prev-arrow--${E.value} absolute flex flex-center`},[(0,r.h)(i.Z,{icon:T.value[0],...A.value,onClick:v})])),(!0===e.infinite||w.value<d-1)&&n.push((0,r.h)("div",{key:"next",class:`q-carousel__control q-carousel__arrow q-carousel__next-arrow q-carousel__next-arrow--${E.value} absolute flex flex-center`},[(0,r.h)(i.Z,{icon:T.value[1],...A.value,onClick:y})]))),(0,c.vs)(t.control,n)}return(0,r.YP)((()=>e.modelValue),(()=>{e.autoplay&&R()})),(0,r.YP)((()=>e.autoplay),(e=>{e?R():null!==h&&(clearTimeout(h),h=null)})),(0,r.bv)((()=>{e.autoplay&&R()})),(0,r.Jd)((()=>{null!==h&&clearTimeout(h)})),()=>(d=f(t),(0,r.h)("div",{class:k.value,style:S.value},[(0,c.Jl)("div",{class:"q-carousel__slides-container"},p(),"sl-cont",e.swipeable,(()=>g.value))].concat(N())))}})},33:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(9835),i=n(5987),o=n(2026);const s=(0,i.L)({name:"QCarouselControl",props:{position:{type:String,default:"bottom-right",validator:e=>["top-right","top-left","bottom-right","bottom-left","top","right","bottom","left"].includes(e)},offset:{type:Array,default:()=>[18,18],validator:e=>2===e.length}},setup(e,{slots:t}){const n=(0,r.Fl)((()=>`q-carousel__control absolute absolute-${e.position}`)),i=(0,r.Fl)((()=>({margin:`${e.offset[1]}px ${e.offset[0]}px`})));return()=>(0,r.h)("div",{class:n.value,style:i.value},(0,o.KR)(t.default))}})},1694:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(9835),i=n(5987),o=n(3936),s=n(2026);const a=(0,i.L)({name:"QCarouselSlide",props:{...o.vZ,imgSrc:String},setup(e,{slots:t}){const n=(0,r.Fl)((()=>e.imgSrc?{backgroundImage:`url("${e.imgSrc}")`}:{}));return()=>(0,r.h)("div",{class:"q-carousel__slide",style:n.value},(0,s.KR)(t.default))}})},5413:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>p,ZB:()=>f,Fz:()=>h});n(9665);var r=n(9835),i=n(499),o=n(8234),s=n(244);function a(e,t){const n=(0,i.iH)(null),o=(0,r.Fl)((()=>!0===e.disable?null:(0,r.h)("span",{ref:n,class:"no-outline",tabindex:-1})));function s(e){const r=t.value;void 0!==e&&0===e.type.indexOf("key")?null!==r&&document.activeElement!==r&&!0===r.contains(document.activeElement)&&r.focus():null!==n.value&&(void 0===e||null!==r&&!0===r.contains(e.target))&&n.value.focus()}return{refocusTargetEl:o,refocusTarget:s}}var l=n(9256);const u={xs:30,sm:35,md:40,lg:50,xl:60};var c=n(1384),d=n(2026);const h={...o.S,...s.LU,...l.Fz,modelValue:{required:!0,default:null},val:{},trueValue:{default:!0},falseValue:{default:!1},indeterminateValue:{default:null},checkedIcon:String,uncheckedIcon:String,indeterminateIcon:String,toggleOrder:{type:String,validator:e=>"tf"===e||"ft"===e},toggleIndeterminate:Boolean,label:String,leftLabel:Boolean,color:String,keepColor:Boolean,dense:Boolean,disable:Boolean,tabindex:[String,Number]},f=["update:modelValue"];function p(e,t){const{props:n,slots:h,emit:f,proxy:p}=(0,r.FN)(),{$q:g}=p,m=(0,o.Z)(n,g),v=(0,i.iH)(null),{refocusTargetEl:y,refocusTarget:b}=a(n,v),w=(0,s.ZP)(n,u),_=(0,r.Fl)((()=>void 0!==n.val&&Array.isArray(n.modelValue))),S=(0,r.Fl)((()=>{const e=(0,i.IU)(n.val);return!0===_.value?n.modelValue.findIndex((t=>(0,i.IU)(t)===e)):-1})),E=(0,r.Fl)((()=>!0===_.value?S.value>-1:(0,i.IU)(n.modelValue)===(0,i.IU)(n.trueValue))),k=(0,r.Fl)((()=>!0===_.value?-1===S.value:(0,i.IU)(n.modelValue)===(0,i.IU)(n.falseValue))),T=(0,r.Fl)((()=>!1===E.value&&!1===k.value)),C=(0,r.Fl)((()=>!0===n.disable?-1:n.tabindex||0)),I=(0,r.Fl)((()=>`q-${e} cursor-pointer no-outline row inline no-wrap items-center`+(!0===n.disable?" disabled":"")+(!0===m.value?` q-${e}--dark`:"")+(!0===n.dense?` q-${e}--dense`:"")+(!0===n.leftLabel?" reverse":""))),x=(0,r.Fl)((()=>{const t=!0===E.value?"truthy":!0===k.value?"falsy":"indet",r=void 0===n.color||!0!==n.keepColor&&("toggle"===e?!0!==E.value:!0===k.value)?"":` text-${n.color}`;return`q-${e}__inner relative-position non-selectable q-${e}__inner--${t}${r}`})),A=(0,r.Fl)((()=>{const e={type:"checkbox"};return void 0!==n.name&&Object.assign(e,{".checked":E.value,"^checked":!0===E.value?"checked":void 0,name:n.name,value:!0===_.value?n.val:n.trueValue}),e})),R=(0,l.eX)(A),O=(0,r.Fl)((()=>{const t={tabindex:C.value,role:"toggle"===e?"switch":"checkbox","aria-label":n.label,"aria-checked":!0===T.value?"mixed":!0===E.value?"true":"false"};return!0===n.disable&&(t["aria-disabled"]="true"),t}));function N(e){void 0!==e&&((0,c.NS)(e),b(e)),!0!==n.disable&&f("update:modelValue",P(),e)}function P(){if(!0===_.value){if(!0===E.value){const e=n.modelValue.slice();return e.splice(S.value,1),e}return n.modelValue.concat([n.val])}if(!0===E.value){if("ft"!==n.toggleOrder||!1===n.toggleIndeterminate)return n.falseValue}else{if(!0!==k.value)return"ft"!==n.toggleOrder?n.trueValue:n.falseValue;if("ft"===n.toggleOrder||!1===n.toggleIndeterminate)return n.trueValue}return n.indeterminateValue}function F(e){13!==e.keyCode&&32!==e.keyCode||(0,c.NS)(e)}function L(e){13!==e.keyCode&&32!==e.keyCode||N(e)}const D=t(E,T);return Object.assign(p,{toggle:N}),()=>{const t=D();!0!==n.disable&&R(t,"unshift",` q-${e}__native absolute q-ma-none q-pa-none`);const i=[(0,r.h)("div",{class:x.value,style:w.value,"aria-hidden":"true"},t)];null!==y.value&&i.push(y.value);const o=void 0!==n.label?(0,d.vs)(h.default,[n.label]):(0,d.KR)(h.default);return void 0!==o&&i.push((0,r.h)("div",{class:`q-${e}__label q-anchor--skip`},o)),(0,r.h)("div",{ref:v,class:I.value,...O.value,onClick:N,onKeydown:F,onKeyup:L},i)}}},7691:(e,t,n)=>{"use strict";n.d(t,{Z:()=>h});n(9665);var r=n(9835),i=n(2857),o=n(1136),s=n(8234),a=n(244),l=n(5987),u=n(1384),c=n(2026);const d={xs:8,sm:10,md:14,lg:20,xl:24},h=(0,l.L)({name:"QChip",props:{...s.S,...a.LU,dense:Boolean,icon:String,iconRight:String,iconRemove:String,iconSelected:String,label:[String,Number],color:String,textColor:String,modelValue:{type:Boolean,default:!0},selected:{type:Boolean,default:null},square:Boolean,outline:Boolean,clickable:Boolean,removable:Boolean,removeAriaLabel:String,tabindex:[String,Number],disable:Boolean,ripple:{type:[Boolean,Object],default:!0}},emits:["update:modelValue","update:selected","remove","click"],setup(e,{slots:t,emit:n}){const{proxy:{$q:l}}=(0,r.FN)(),h=(0,s.Z)(e,l),f=(0,a.ZP)(e,d),p=(0,r.Fl)((()=>!0===e.selected||void 0!==e.icon)),g=(0,r.Fl)((()=>!0===e.selected?e.iconSelected||l.iconSet.chip.selected:e.icon)),m=(0,r.Fl)((()=>e.iconRemove||l.iconSet.chip.remove)),v=(0,r.Fl)((()=>!1===e.disable&&(!0===e.clickable||null!==e.selected))),y=(0,r.Fl)((()=>{const t=!0===e.outline&&e.color||e.textColor;return"q-chip row inline no-wrap items-center"+(!1===e.outline&&void 0!==e.color?` bg-${e.color}`:"")+(t?` text-${t} q-chip--colored`:"")+(!0===e.disable?" disabled":"")+(!0===e.dense?" q-chip--dense":"")+(!0===e.outline?" q-chip--outline":"")+(!0===e.selected?" q-chip--selected":"")+(!0===v.value?" q-chip--clickable cursor-pointer non-selectable q-hoverable":"")+(!0===e.square?" q-chip--square":"")+(!0===h.value?" q-chip--dark q-dark":"")})),b=(0,r.Fl)((()=>{const t=!0===e.disable?{tabindex:-1,"aria-disabled":"true"}:{tabindex:e.tabindex||0},n={...t,role:"button","aria-hidden":"false","aria-label":e.removeAriaLabel||l.lang.label.remove};return{chip:t,remove:n}}));function w(e){13===e.keyCode&&_(e)}function _(t){e.disable||(n("update:selected",!e.selected),n("click",t))}function S(t){void 0!==t.keyCode&&13!==t.keyCode||((0,u.NS)(t),!1===e.disable&&(n("update:modelValue",!1),n("remove")))}function E(){const n=[];!0===v.value&&n.push((0,r.h)("div",{class:"q-focus-helper"})),!0===p.value&&n.push((0,r.h)(i.Z,{class:"q-chip__icon q-chip__icon--left",name:g.value}));const o=void 0!==e.label?[(0,r.h)("div",{class:"ellipsis"},[e.label])]:void 0;return n.push((0,r.h)("div",{class:"q-chip__content col row no-wrap items-center q-anchor--skip"},(0,c.pf)(t.default,o))),e.iconRight&&n.push((0,r.h)(i.Z,{class:"q-chip__icon q-chip__icon--right",name:e.iconRight})),!0===e.removable&&n.push((0,r.h)(i.Z,{class:"q-chip__icon q-chip__icon--remove cursor-pointer",name:m.value,...b.value.remove,onClick:S,onKeyup:S})),n}return()=>{if(!1===e.modelValue)return;const t={class:y.value,style:f.value};return!0===v.value&&Object.assign(t,b.value.chip,{onClick:_,onKeyup:w}),(0,c.Jl)("div",t,E(),"ripple",!1!==e.ripple&&!0!==e.disable,(()=>[[o.Z,e.ripple]]))}}})},7743:(e,t,n)=>{"use strict";n.d(t,{Z:()=>B});var r=n(9835),i=n(499),o=n(1957),s=n(5310);function a(e,t,n){let i;function o(){void 0!==i&&(s.Z.remove(i),i=void 0)}return(0,r.Jd)((()=>{!0===e.value&&o()})),{removeFromHistory:o,addToHistory(){i={condition:()=>!0===n.value,handler:t},s.Z.add(i)}}}var l=n(2695),u=n(6916),c=n(3842),d=n(431),h=n(1518),f=n(1384),p=n(3701),g=n(7506);let m,v,y,b,w,_,S=0,E=!1,k=null;function T(e){C(e)&&(0,f.NS)(e)}function C(e){if(e.target===document.body||e.target.classList.contains("q-layout__backdrop"))return!0;const t=(0,f.AZ)(e),n=e.shiftKey&&!e.deltaX,r=!n&&Math.abs(e.deltaX)<=Math.abs(e.deltaY),i=n||r?e.deltaY:e.deltaX;for(let o=0;o<t.length;o++){const e=t[o];if((0,p.QA)(e,r))return r?i<0&&0===e.scrollTop||i>0&&e.scrollTop+e.clientHeight===e.scrollHeight:i<0&&0===e.scrollLeft||i>0&&e.scrollLeft+e.clientWidth===e.scrollWidth}return!0}function I(e){e.target===document&&(document.scrollingElement.scrollTop=document.scrollingElement.scrollTop)}function x(e){!0!==E&&(E=!0,requestAnimationFrame((()=>{E=!1;const{height:t}=e.target,{clientHeight:n,scrollTop:r}=document.scrollingElement;void 0!==y&&t===window.innerHeight||(y=n-t,document.scrollingElement.scrollTop=r),r>y&&(document.scrollingElement.scrollTop-=Math.ceil((r-y)/8))})))}function A(e){const t=document.body,n=void 0!==window.visualViewport;if("add"===e){const{overflowY:e,overflowX:r}=window.getComputedStyle(t);m=(0,p.OI)(window),v=(0,p.u3)(window),b=t.style.left,w=t.style.top,_=window.location.href,t.style.left=`-${m}px`,t.style.top=`-${v}px`,"hidden"!==r&&("scroll"===r||t.scrollWidth>window.innerWidth)&&t.classList.add("q-body--force-scrollbar-x"),"hidden"!==e&&("scroll"===e||t.scrollHeight>window.innerHeight)&&t.classList.add("q-body--force-scrollbar-y"),t.classList.add("q-body--prevent-scroll"),document.qScrollPrevented=!0,!0===g.client.is.ios&&(!0===n?(window.scrollTo(0,0),window.visualViewport.addEventListener("resize",x,f.listenOpts.passiveCapture),window.visualViewport.addEventListener("scroll",x,f.listenOpts.passiveCapture),window.scrollTo(0,0)):window.addEventListener("scroll",I,f.listenOpts.passiveCapture))}!0===g.client.is.desktop&&!0===g.client.is.mac&&window[`${e}EventListener`]("wheel",T,f.listenOpts.notPassive),"remove"===e&&(!0===g.client.is.ios&&(!0===n?(window.visualViewport.removeEventListener("resize",x,f.listenOpts.passiveCapture),window.visualViewport.removeEventListener("scroll",x,f.listenOpts.passiveCapture)):window.removeEventListener("scroll",I,f.listenOpts.passiveCapture)),t.classList.remove("q-body--prevent-scroll"),t.classList.remove("q-body--force-scrollbar-x"),t.classList.remove("q-body--force-scrollbar-y"),document.qScrollPrevented=!1,t.style.left=b,t.style.top=w,window.location.href===_&&window.scrollTo(m,v),y=void 0)}function R(e){let t="add";if(!0===e){if(S++,null!==k)return clearTimeout(k),void(k=null);if(S>1)return}else{if(0===S)return;if(S--,S>0)return;if(t="remove",!0===g.client.is.ios&&!0===g.client.is.nativeMobile)return null!==k&&clearTimeout(k),void(k=setTimeout((()=>{A(t),k=null}),100))}A(t)}function O(){let e;return{preventBodyScroll(t){t===e||void 0===e&&!0!==t||(e=t,R(t))}}}var N=n(5987),P=n(223),F=n(2026),L=n(6532),D=n(4173),M=n(7026);let q=0;const V={standard:"fixed-full flex-center",top:"fixed-top justify-center",bottom:"fixed-bottom justify-center",right:"fixed-right items-center",left:"fixed-left items-center"},U={standard:["scale","scale"],top:["slide-down","slide-up"],bottom:["slide-up","slide-down"],right:["slide-left","slide-right"],left:["slide-right","slide-left"]},B=(0,N.L)({name:"QDialog",inheritAttrs:!1,props:{...c.vr,...d.D,transitionShow:String,transitionHide:String,persistent:Boolean,autoClose:Boolean,allowFocusOutside:Boolean,noEscDismiss:Boolean,noBackdropDismiss:Boolean,noRouteDismiss:Boolean,noRefocus:Boolean,noFocus:Boolean,noShake:Boolean,seamless:Boolean,maximized:Boolean,fullWidth:Boolean,fullHeight:Boolean,square:Boolean,position:{type:String,default:"standard",validator:e=>"standard"===e||["top","bottom","left","right"].includes(e)}},emits:[...c.gH,"shake","click","escapeKey"],setup(e,{slots:t,emit:n,attrs:s}){const f=(0,r.FN)(),p=(0,i.iH)(null),g=(0,i.iH)(!1),m=(0,i.iH)(!1);let v,y,b=null,w=null;const _=(0,r.Fl)((()=>!0!==e.persistent&&!0!==e.noRouteDismiss&&!0!==e.seamless)),{preventBodyScroll:S}=O(),{registerTimeout:E}=(0,l.Z)(),{registerTick:k,removeTick:T}=(0,u.Z)(),{transitionProps:C,transitionStyle:I}=(0,d.Z)(e,(()=>U[e.position][0]),(()=>U[e.position][1])),{showPortal:x,hidePortal:A,portalIsAccessible:R,renderPortal:N}=(0,h.Z)(f,p,ie,"dialog"),{hide:B}=(0,c.ZP)({showing:g,hideOnRouteChange:_,handleShow:Z,handleHide:G,processOnMount:!0}),{addToHistory:$,removeFromHistory:j}=a(g,B,_),z=(0,r.Fl)((()=>"q-dialog__inner flex no-pointer-events q-dialog__inner--"+(!0===e.maximized?"maximized":"minimized")+` q-dialog__inner--${e.position} ${V[e.position]}`+(!0===m.value?" q-dialog__inner--animating":"")+(!0===e.fullWidth?" q-dialog__inner--fullwidth":"")+(!0===e.fullHeight?" q-dialog__inner--fullheight":"")+(!0===e.square?" q-dialog__inner--square":""))),H=(0,r.Fl)((()=>!0===g.value&&!0!==e.seamless)),K=(0,r.Fl)((()=>!0===e.autoClose?{onClick:te}:{})),W=(0,r.Fl)((()=>["q-dialog fullscreen no-pointer-events q-dialog--"+(!0===H.value?"modal":"seamless"),s.class]));function Z(t){$(),w=!1===e.noRefocus&&null!==document.activeElement?document.activeElement:null,ee(e.maximized),x(),m.value=!0,!0!==e.noFocus?(null!==document.activeElement&&document.activeElement.blur(),k(J)):T(),E((()=>{if(!0===f.proxy.$q.platform.is.ios){if(!0!==e.seamless&&document.activeElement){const{top:e,bottom:t}=document.activeElement.getBoundingClientRect(),{innerHeight:n}=window,r=void 0!==window.visualViewport?window.visualViewport.height:n;e>0&&t>r/2&&(document.scrollingElement.scrollTop=Math.min(document.scrollingElement.scrollHeight-r,t>=n?1/0:Math.ceil(document.scrollingElement.scrollTop+t-r/2))),document.activeElement.scrollIntoView()}y=!0,p.value.click(),y=!1}x(!0),m.value=!1,n("show",t)}),e.transitionDuration)}function G(t){T(),j(),X(!0),m.value=!0,A(),null!==w&&(((t&&0===t.type.indexOf("key")?w.closest('[tabindex]:not([tabindex^="-"])'):void 0)||w).focus(),w=null),E((()=>{A(!0),m.value=!1,n("hide",t)}),e.transitionDuration)}function J(e){(0,M.jd)((()=>{let t=p.value;null!==t&&!0!==t.contains(document.activeElement)&&(t=(""!==e?t.querySelector(e):null)||t.querySelector("[autofocus][tabindex], [data-autofocus][tabindex]")||t.querySelector("[autofocus] [tabindex], [data-autofocus] [tabindex]")||t.querySelector("[autofocus], [data-autofocus]")||t,t.focus({preventScroll:!0}))}))}function Q(e){e&&"function"===typeof e.focus?e.focus({preventScroll:!0}):J(),n("shake");const t=p.value;null!==t&&(t.classList.remove("q-animate--scale"),t.classList.add("q-animate--scale"),null!==b&&clearTimeout(b),b=setTimeout((()=>{b=null,null!==p.value&&(t.classList.remove("q-animate--scale"),J())}),170))}function Y(){!0!==e.seamless&&(!0===e.persistent||!0===e.noEscDismiss?!0!==e.maximized&&!0!==e.noShake&&Q():(n("escapeKey"),B()))}function X(t){null!==b&&(clearTimeout(b),b=null),!0!==t&&!0!==g.value||(ee(!1),!0!==e.seamless&&(S(!1),(0,D.H)(re),(0,L.k)(Y))),!0!==t&&(w=null)}function ee(e){!0===e?!0!==v&&(q<1&&document.body.classList.add("q-body--dialog"),q++,v=!0):!0===v&&(q<2&&document.body.classList.remove("q-body--dialog"),q--,v=!1)}function te(e){!0!==y&&(B(e),n("click",e))}function ne(t){!0!==e.persistent&&!0!==e.noBackdropDismiss?B(t):!0!==e.noShake&&Q()}function re(t){!0!==e.allowFocusOutside&&!0===R.value&&!0!==(0,P.mY)(p.value,t.target)&&J('[tabindex]:not([tabindex="-1"])')}function ie(){return(0,r.h)("div",{role:"dialog","aria-modal":!0===H.value?"true":"false",...s,class:W.value},[(0,r.h)(o.uT,{name:"q-transition--fade",appear:!0},(()=>!0===H.value?(0,r.h)("div",{class:"q-dialog__backdrop fixed-full",style:I.value,"aria-hidden":"true",tabindex:-1,onClick:ne}):null)),(0,r.h)(o.uT,C.value,(()=>!0===g.value?(0,r.h)("div",{ref:p,class:z.value,style:I.value,tabindex:-1,...K.value},(0,F.KR)(t.default)):null))])}return(0,r.YP)((()=>e.maximized),(e=>{!0===g.value&&ee(e)})),(0,r.YP)(H,(e=>{S(e),!0===e?((0,D.i)(re),(0,L.c)(Y)):((0,D.H)(re),(0,L.k)(Y))})),Object.assign(f.proxy,{focus:J,shake:Q,__updateRefocusTarget(e){w=e||null}}),(0,r.Jd)(X),N}})},9420:(e,t,n)=>{"use strict";n.d(t,{Z:()=>b});var r=n(9835),i=n(499),o=n(7691),s=n(3167),a=n(9256),l=(n(9665),n(7506)),u=n(1384);function c(e,t,n,r){const i=[];return e.forEach((e=>{!0===r(e)?i.push(e):t.push({failedPropValidation:n,file:e})})),i}function d(e){e&&e.dataTransfer&&(e.dataTransfer.dropEffect="copy"),(0,u.NS)(e)}const h={multiple:Boolean,accept:String,capture:String,maxFileSize:[Number,String],maxTotalSize:[Number,String],maxFiles:[Number,String],filter:Function},f=["rejected"];function p({editable:e,dnd:t,getFileInput:n,addFilesToQueue:o}){const{props:s,emit:a,proxy:h}=(0,r.FN)(),f=(0,i.iH)(null),p=(0,r.Fl)((()=>void 0!==s.accept?s.accept.split(",").map((e=>(e=e.trim(),"*"===e?"*/":(e.endsWith("/*")&&(e=e.slice(0,e.length-1)),e.toUpperCase())))):null)),g=(0,r.Fl)((()=>parseInt(s.maxFiles,10))),m=(0,r.Fl)((()=>parseInt(s.maxTotalSize,10)));function v(t){if(e.value)if(t!==Object(t)&&(t={target:null}),null!==t.target&&!0===t.target.matches('input[type="file"]'))0===t.clientX&&0===t.clientY&&(0,u.sT)(t);else{const e=n();e&&e!==t.target&&e.click(t)}}function y(t){e.value&&t&&o(null,t)}function b(e,t,n,r){let i=Array.from(t||e.target.files);const o=[],l=()=>{0!==o.length&&a("rejected",o)};if(void 0!==s.accept&&-1===p.value.indexOf("*/")&&(i=c(i,o,"accept",(e=>p.value.some((t=>e.type.toUpperCase().startsWith(t)||e.name.toUpperCase().endsWith(t))))),0===i.length))return l();if(void 0!==s.maxFileSize){const e=parseInt(s.maxFileSize,10);if(i=c(i,o,"max-file-size",(t=>t.size<=e)),0===i.length)return l()}if(!0!==s.multiple&&0!==i.length&&(i=[i[0]]),i.forEach((e=>{e.__key=e.webkitRelativePath+e.lastModified+e.name+e.size})),!0===r){const e=n.map((e=>e.__key));i=c(i,o,"duplicate",(t=>!1===e.includes(t.__key)))}if(0===i.length)return l();if(void 0!==s.maxTotalSize){let e=!0===r?n.reduce(((e,t)=>e+t.size),0):0;if(i=c(i,o,"max-total-size",(t=>(e+=t.size,e<=m.value))),0===i.length)return l()}if("function"===typeof s.filter){const e=s.filter(i);i=c(i,o,"filter",(t=>e.includes(t)))}if(void 0!==s.maxFiles){let e=!0===r?n.length:0;if(i=c(i,o,"max-files",(()=>(e++,e<=g.value))),0===i.length)return l()}return l(),0!==i.length?i:void 0}function w(e){d(e),!0!==t.value&&(t.value=!0)}function _(e){(0,u.NS)(e);const n=null!==e.relatedTarget||!0!==l.client.is.safari?e.relatedTarget!==f.value:!1===document.elementsFromPoint(e.clientX,e.clientY).includes(f.value);!0===n&&(t.value=!1)}function S(e){d(e);const n=e.dataTransfer.files;0!==n.length&&o(null,n),t.value=!1}function E(e){if(!0===t.value)return(0,r.h)("div",{ref:f,class:`q-${e}__dnd absolute-full`,onDragenter:d,onDragover:d,onDragleave:_,onDrop:S})}return Object.assign(h,{pickFiles:v,addFiles:y}),{pickFiles:v,addFiles:y,onDragover:w,onDragleave:_,processFiles:b,getDndNode:E,maxFilesNumber:g,maxTotalSizeNumber:m}}var g=n(7915),m=n(5987),v=n(321),y=n(3251);const b=(0,m.L)({name:"QFile",inheritAttrs:!1,props:{...s.Cl,...a.Fz,...h,modelValue:[File,FileList,Array],append:Boolean,useChips:Boolean,displayValue:[String,Number],tabindex:{type:[String,Number],default:0},counterLabel:Function,inputClass:[Array,String,Object],inputStyle:[Array,String,Object]},emits:[...s.HJ,...f],setup(e,{slots:t,emit:n,attrs:l}){const{proxy:c}=(0,r.FN)(),d=(0,s.tL)(),h=(0,i.iH)(null),f=(0,i.iH)(!1),m=(0,a.Do)(e),{pickFiles:b,onDragover:w,onDragleave:_,processFiles:S,getDndNode:E}=p({editable:d.editable,dnd:f,getFileInput:q,addFilesToQueue:V}),k=(0,g.Z)(e),T=(0,r.Fl)((()=>Object(e.modelValue)===e.modelValue?"length"in e.modelValue?Array.from(e.modelValue):[e.modelValue]:[])),C=(0,r.Fl)((()=>(0,s.yV)(T.value))),I=(0,r.Fl)((()=>T.value.map((e=>e.name)).join(", "))),x=(0,r.Fl)((()=>(0,v.rB)(T.value.reduce(((e,t)=>e+t.size),0)))),A=(0,r.Fl)((()=>({totalSize:x.value,filesNumber:T.value.length,maxFiles:e.maxFiles}))),R=(0,r.Fl)((()=>({tabindex:-1,type:"file",title:"",accept:e.accept,capture:e.capture,name:m.value,...l,id:d.targetUid.value,disabled:!0!==d.editable.value}))),O=(0,r.Fl)((()=>"q-file q-field--auto-height"+(!0===f.value?" q-file--dnd":""))),N=(0,r.Fl)((()=>!0===e.multiple&&!0===e.append));function P(e){const t=T.value.slice();t.splice(e,1),L(t)}function F(e){const t=T.value.indexOf(e);t>-1&&P(t)}function L(t){n("update:modelValue",!0===e.multiple?t:t[0])}function D(e){13===e.keyCode&&(0,u.X$)(e)}function M(e){13!==e.keyCode&&32!==e.keyCode||b(e)}function q(){return h.value}function V(t,n){const r=S(t,n,T.value,N.value),i=q();void 0!==i&&null!==i&&(i.value=""),void 0!==r&&((!0===e.multiple?e.modelValue&&r.every((e=>T.value.includes(e))):e.modelValue===r[0])||L(!0===N.value?T.value.concat(r):r))}function U(){return[(0,r.h)("input",{class:[e.inputClass,"q-file__filler"],style:e.inputStyle})]}function B(){if(void 0!==t.file)return 0===T.value.length?U():T.value.map(((e,n)=>t.file({index:n,file:e,ref:this})));if(void 0!==t.selected)return 0===T.value.length?U():t.selected({files:T.value,ref:this});if(!0===e.useChips)return 0===T.value.length?U():T.value.map(((t,n)=>(0,r.h)(o.Z,{key:"file-"+n,removable:d.editable.value,dense:!0,textColor:e.color,tabindex:e.tabindex,onRemove:()=>{P(n)}},(()=>(0,r.h)("span",{class:"ellipsis",textContent:t.name})))));const n=void 0!==e.displayValue?e.displayValue:I.value;return 0!==n.length?[(0,r.h)("div",{class:e.inputClass,style:e.inputStyle,textContent:n})]:U()}function $(){const t={ref:h,...R.value,...k.value,class:"q-field__input fit absolute-full cursor-pointer",onChange:V};return!0===e.multiple&&(t.multiple=!0),(0,r.h)("input",t)}return Object.assign(d,{fieldClass:O,emitValue:L,hasValue:C,inputRef:h,innerValue:T,floatingLabel:(0,r.Fl)((()=>!0===C.value||(0,s.yV)(e.displayValue))),computedCounter:(0,r.Fl)((()=>{if(void 0!==e.counterLabel)return e.counterLabel(A.value);const t=e.maxFiles;return`${T.value.length}${void 0!==t?" / "+t:""} (${x.value})`})),getControlChild:()=>E("file"),getControl:()=>{const t={ref:d.targetRef,class:"q-field__native row items-center cursor-pointer",tabindex:e.tabindex};return!0===d.editable.value&&Object.assign(t,{onDragover:w,onDragleave:_,onKeydown:D,onKeyup:M}),(0,r.h)("div",t,[$()].concat(B()))}}),Object.assign(c,{removeAtIndex:P,removeFile:F,getNativeElement:()=>h.value}),(0,y.g)(c,"nativeEl",(()=>h.value)),(0,s.ZP)(d)}})},8326:(e,t,n)=>{"use strict";n.d(t,{Z:()=>d});n(9665);var r=n(9835),i=n(499),o=n(5987),s=n(1384),a=n(7026),l=n(2026),u=n(5439),c=n(2046);const d=(0,o.L)({name:"QForm",props:{autofocus:Boolean,noErrorFocus:Boolean,noResetFocus:Boolean,greedy:Boolean,onSubmit:Function},emits:["reset","validationSuccess","validationError"],setup(e,{slots:t,emit:n}){const o=(0,r.FN)(),d=(0,i.iH)(null);let h=0;const f=[];function p(t){const r="boolean"===typeof t?t:!0!==e.noErrorFocus,i=++h,o=(e,t)=>{n("validation"+(!0===e?"Success":"Error"),t)},s=e=>{const t=e.validate();return"function"===typeof t.then?t.then((t=>({valid:t,comp:e})),(t=>({valid:!1,comp:e,err:t}))):Promise.resolve({valid:t,comp:e})},a=!0===e.greedy?Promise.all(f.map(s)).then((e=>e.filter((e=>!0!==e.valid)))):f.reduce(((e,t)=>e.then((()=>s(t).then((e=>{if(!1===e.valid)return Promise.reject(e)}))))),Promise.resolve()).catch((e=>[e]));return a.then((e=>{if(void 0===e||0===e.length)return i===h&&o(!0),!0;if(i===h){const{comp:t,err:n}=e[0];if(void 0!==n&&console.error(n),o(!1,t),!0===r){const t=e.find((({comp:e})=>"function"===typeof e.focus&&!1===(0,c.$D)(e.$)));void 0!==t&&t.comp.focus()}}return!1}))}function g(){h++,f.forEach((e=>{"function"===typeof e.resetValidation&&e.resetValidation()}))}function m(t){void 0!==t&&(0,s.NS)(t);const r=h+1;p().then((i=>{r===h&&!0===i&&(void 0!==e.onSubmit?n("submit",t):void 0!==t&&void 0!==t.target&&"function"===typeof t.target.submit&&t.target.submit())}))}function v(t){void 0!==t&&(0,s.NS)(t),n("reset"),(0,r.Y3)((()=>{g(),!0===e.autofocus&&!0!==e.noResetFocus&&y()}))}function y(){(0,a.jd)((()=>{if(null===d.value)return;const e=d.value.querySelector("[autofocus][tabindex], [data-autofocus][tabindex]")||d.value.querySelector("[autofocus] [tabindex], [data-autofocus] [tabindex]")||d.value.querySelector("[autofocus], [data-autofocus]")||Array.prototype.find.call(d.value.querySelectorAll("[tabindex]"),(e=>e.tabIndex>-1));null!==e&&void 0!==e&&e.focus({preventScroll:!0})}))}(0,r.JJ)(u.vh,{bindComponent(e){f.push(e)},unbindComponent(e){const t=f.indexOf(e);t>-1&&f.splice(t,1)}});let b=!1;return(0,r.se)((()=>{b=!0})),(0,r.dl)((()=>{!0===b&&!0===e.autofocus&&y()})),(0,r.bv)((()=>{!0===e.autofocus&&y()})),Object.assign(o.proxy,{validate:p,resetValidation:g,submit:m,reset:v,focus:y,getValidationComponents:()=>f}),()=>(0,r.h)("form",{class:"q-form",ref:d,onSubmit:m,onReset:v},(0,l.KR)(t.default))}})},6602:(e,t,n)=>{"use strict";n.d(t,{Z:()=>u});n(9665);var r=n(9835),i=n(499),o=n(883),s=n(5987),a=n(2026),l=n(5439);const u=(0,s.L)({name:"QHeader",props:{modelValue:{type:Boolean,default:!0},reveal:Boolean,revealOffset:{type:Number,default:250},bordered:Boolean,elevated:Boolean,heightHint:{type:[String,Number],default:50}},emits:["reveal","focusin"],setup(e,{slots:t,emit:n}){const{proxy:{$q:s}}=(0,r.FN)(),u=(0,r.f3)(l.YE,l.qO);if(u===l.qO)return console.error("QHeader needs to be child of QLayout"),l.qO;const c=(0,i.iH)(parseInt(e.heightHint,10)),d=(0,i.iH)(!0),h=(0,r.Fl)((()=>!0===e.reveal||u.view.value.indexOf("H")>-1||s.platform.is.ios&&!0===u.isContainer.value)),f=(0,r.Fl)((()=>{if(!0!==e.modelValue)return 0;if(!0===h.value)return!0===d.value?c.value:0;const t=c.value-u.scroll.value.position;return t>0?t:0})),p=(0,r.Fl)((()=>!0!==e.modelValue||!0===h.value&&!0!==d.value)),g=(0,r.Fl)((()=>!0===e.modelValue&&!0===p.value&&!0===e.reveal)),m=(0,r.Fl)((()=>"q-header q-layout__section--marginal "+(!0===h.value?"fixed":"absolute")+"-top"+(!0===e.bordered?" q-header--bordered":"")+(!0===p.value?" q-header--hidden":"")+(!0!==e.modelValue?" q-layout--prevent-focus":""))),v=(0,r.Fl)((()=>{const e=u.rows.value.top,t={};return"l"===e[0]&&!0===u.left.space&&(t[!0===s.lang.rtl?"right":"left"]=`${u.left.size}px`),"r"===e[2]&&!0===u.right.space&&(t[!0===s.lang.rtl?"left":"right"]=`${u.right.size}px`),t}));function y(e,t){u.update("header",e,t)}function b(e,t){e.value!==t&&(e.value=t)}function w({height:e}){b(c,e),y("size",e)}function _(e){!0===g.value&&b(d,!0),n("focusin",e)}(0,r.YP)((()=>e.modelValue),(e=>{y("space",e),b(d,!0),u.animate()})),(0,r.YP)(f,(e=>{y("offset",e)})),(0,r.YP)((()=>e.reveal),(t=>{!1===t&&b(d,e.modelValue)})),(0,r.YP)(d,(e=>{u.animate(),n("reveal",e)})),(0,r.YP)(u.scroll,(t=>{!0===e.reveal&&b(d,"up"===t.direction||t.position<=e.revealOffset||t.position-t.inflectionPoint<100)}));const S={};return u.instances.header=S,!0===e.modelValue&&y("size",c.value),y("space",e.modelValue),y("offset",f.value),(0,r.Jd)((()=>{u.instances.header===S&&(u.instances.header=void 0,y("size",0),y("offset",0),y("space",!1))})),()=>{const n=(0,a.Bl)(t.default,[]);return!0===e.elevated&&n.push((0,r.h)("div",{class:"q-layout__shadow absolute-full overflow-hidden no-pointer-events"})),n.push((0,r.h)(o.Z,{debounce:0,onResize:w})),(0,r.h)("header",{class:m.value,style:v.value,onFocusin:_},n)}}})},2857:(e,t,n)=>{"use strict";n.d(t,{Z:()=>_});var r=n(9835),i=n(244),o=n(5987),s=n(2026);const a="0 0 24 24",l=e=>e,u=e=>`ionicons ${e}`,c={"mdi-":e=>`mdi ${e}`,"icon-":l,"bt-":e=>`bt ${e}`,"eva-":e=>`eva ${e}`,"ion-md":u,"ion-ios":u,"ion-logo":u,"iconfont ":l,"ti-":e=>`themify-icon ${e}`,"bi-":e=>`bootstrap-icons ${e}`},d={o_:"-outlined",r_:"-round",s_:"-sharp"},h={sym_o_:"-outlined",sym_r_:"-rounded",sym_s_:"-sharp"},f=new RegExp("^("+Object.keys(c).join("|")+")"),p=new RegExp("^("+Object.keys(d).join("|")+")"),g=new RegExp("^("+Object.keys(h).join("|")+")"),m=/^[Mm]\s?[-+]?\.?\d/,v=/^img:/,y=/^svguse:/,b=/^ion-/,w=/^(fa-(sharp|solid|regular|light|brands|duotone|thin)|[lf]a[srlbdk]?) /,_=(0,o.L)({name:"QIcon",props:{...i.LU,tag:{type:String,default:"i"},name:String,color:String,left:Boolean,right:Boolean},setup(e,{slots:t}){const{proxy:{$q:n}}=(0,r.FN)(),o=(0,i.ZP)(e),l=(0,r.Fl)((()=>"q-icon"+(!0===e.left?" on-left":"")+(!0===e.right?" on-right":"")+(void 0!==e.color?` text-${e.color}`:""))),u=(0,r.Fl)((()=>{let t,i=e.name;if("none"===i||!i)return{none:!0};if(null!==n.iconMapFn){const e=n.iconMapFn(i);if(void 0!==e){if(void 0===e.icon)return{cls:e.cls,content:void 0!==e.content?e.content:" "};if(i=e.icon,"none"===i||!i)return{none:!0}}}if(!0===m.test(i)){const[e,t=a]=i.split("|");return{svg:!0,viewBox:t,nodes:e.split("&&").map((e=>{const[t,n,i]=e.split("@@");return(0,r.h)("path",{style:n,d:t,transform:i})}))}}if(!0===v.test(i))return{img:!0,src:i.substring(4)};if(!0===y.test(i)){const[e,t=a]=i.split("|");return{svguse:!0,src:e.substring(7),viewBox:t}}let o=" ";const s=i.match(f);if(null!==s)t=c[s[1]](i);else if(!0===w.test(i))t=i;else if(!0===b.test(i))t=`ionicons ion-${!0===n.platform.is.ios?"ios":"md"}${i.substring(3)}`;else if(!0===g.test(i)){t="notranslate material-symbols";const e=i.match(g);null!==e&&(i=i.substring(6),t+=h[e[1]]),o=i}else{t="notranslate material-icons";const e=i.match(p);null!==e&&(i=i.substring(2),t+=d[e[1]]),o=i}return{cls:t,content:o}}));return()=>{const n={class:l.value,style:o.value,"aria-hidden":"true",role:"presentation"};return!0===u.value.none?(0,r.h)(e.tag,n,(0,s.KR)(t.default)):!0===u.value.img?(0,r.h)("span",n,(0,s.vs)(t.default,[(0,r.h)("img",{src:u.value.src})])):!0===u.value.svg?(0,r.h)("span",n,(0,s.vs)(t.default,[(0,r.h)("svg",{viewBox:u.value.viewBox||"0 0 24 24"},u.value.nodes)])):!0===u.value.svguse?(0,r.h)("span",n,(0,s.vs)(t.default,[(0,r.h)("svg",{viewBox:u.value.viewBox},[(0,r.h)("use",{"xlink:href":u.value.src})])])):(void 0!==u.value.cls&&(n.class+=" "+u.value.cls),(0,r.h)(e.tag,n,(0,s.vs)(t.default,[u.value.content])))}}})},335:(e,t,n)=>{"use strict";n.d(t,{Z:()=>h});n(9665);var r=n(499),i=n(9835),o=n(1957),s=n(3940);const a={ratio:[String,Number]};function l(e,t){return(0,i.Fl)((()=>{const n=Number(e.ratio||(void 0!==t?t.value:void 0));return!0!==isNaN(n)&&n>0?{paddingBottom:100/n+"%"}:null}))}var u=n(5987),c=n(2026);const d=16/9,h=(0,u.L)({name:"QImg",props:{...a,src:String,srcset:String,sizes:String,alt:String,crossorigin:String,decoding:String,referrerpolicy:String,draggable:Boolean,loading:{type:String,default:"lazy"},fetchpriority:{type:String,default:"auto"},width:String,height:String,initialRatio:{type:[Number,String],default:d},placeholderSrc:String,fit:{type:String,default:"cover"},position:{type:String,default:"50% 50%"},imgClass:String,imgStyle:Object,noSpinner:Boolean,noNativeMenu:Boolean,noTransition:Boolean,spinnerColor:String,spinnerSize:String},emits:["load","error"],setup(e,{slots:t,emit:n}){const a=(0,r.iH)(e.initialRatio),u=l(e,a);let d=null,h=!1;const f=[(0,r.iH)(null),(0,r.iH)(S())],p=(0,r.iH)(0),g=(0,r.iH)(!1),m=(0,r.iH)(!1),v=(0,i.Fl)((()=>`q-img q-img--${!0===e.noNativeMenu?"no-":""}menu`)),y=(0,i.Fl)((()=>({width:e.width,height:e.height}))),b=(0,i.Fl)((()=>"q-img__image "+(void 0!==e.imgClass?e.imgClass+" ":"")+`q-img__image--with${!0===e.noTransition?"out":""}-transition`)),w=(0,i.Fl)((()=>({...e.imgStyle,objectFit:e.fit,objectPosition:e.position})));function _(){return e.src||e.srcset||e.sizes?{src:e.src,srcset:e.srcset,sizes:e.sizes}:null}function S(){return void 0!==e.placeholderSrc?{src:e.placeholderSrc}:null}function E(e){null!==d&&(clearTimeout(d),d=null),m.value=!1,null===e?(g.value=!1,f[1^p.value].value=S()):g.value=!0,f[p.value].value=e}function k({target:e}){!0!==h&&(null!==d&&(clearTimeout(d),d=null),a.value=0===e.naturalHeight?.5:e.naturalWidth/e.naturalHeight,T(e,1))}function T(e,t){!0!==h&&1e3!==t&&(!0===e.complete?C(e):d=setTimeout((()=>{d=null,T(e,t+1)}),50))}function C(e){!0!==h&&(p.value=1^p.value,f[p.value].value=null,g.value=!1,m.value=!1,n("load",e.currentSrc||e.src))}function I(e){null!==d&&(clearTimeout(d),d=null),g.value=!1,m.value=!0,f[p.value].value=null,f[1^p.value].value=S(),n("error",e)}function x(t){const n=f[t].value,r={key:"img_"+t,class:b.value,style:w.value,crossorigin:e.crossorigin,decoding:e.decoding,referrerpolicy:e.referrerpolicy,height:e.height,width:e.width,loading:e.loading,fetchpriority:e.fetchpriority,"aria-hidden":"true",draggable:e.draggable,...n};return p.value===t?(r.class+=" q-img__image--waiting",Object.assign(r,{onLoad:k,onError:I})):r.class+=" q-img__image--loaded",(0,i.h)("div",{class:"q-img__container absolute-full",key:"img"+t},(0,i.h)("img",r))}function A(){return!0!==g.value?(0,i.h)("div",{key:"content",class:"q-img__content absolute-full q-anchor--skip"},(0,c.KR)(t[!0===m.value?"error":"default"])):(0,i.h)("div",{key:"loading",class:"q-img__loading absolute-full flex flex-center"},void 0!==t.loading?t.loading():!0===e.noSpinner?void 0:[(0,i.h)(s.Z,{color:e.spinnerColor,size:e.spinnerSize})])}return(0,i.YP)((()=>_()),E),E(_()),(0,i.Jd)((()=>{h=!0,null!==d&&(clearTimeout(d),d=null)})),()=>{const t=[];return null!==u.value&&t.push((0,i.h)("div",{key:"filler",style:u.value})),!0!==m.value&&(null!==f[0].value&&t.push(x(0)),null!==f[1].value&&t.push(x(1))),t.push((0,i.h)(o.uT,{name:"q-transition--fade"},A)),(0,i.h)("div",{class:v.value,style:y.value,role:"img","aria-label":e.alt},t)}}})},854:(e,t,n)=>{"use strict";n.d(t,{Z:()=>u});n(9665);var r=n(9835),i=n(1957),o=n(3940),s=n(5987),a=n(8234),l=n(431);const u=(0,s.L)({name:"QInnerLoading",props:{...a.S,...l.D,showing:Boolean,color:String,size:{type:[String,Number],default:42},label:String,labelClass:String,labelStyle:[String,Array,Object]},setup(e,{slots:t}){const n=(0,r.FN)(),s=(0,a.Z)(e,n.proxy.$q),{transitionProps:u,transitionStyle:c}=(0,l.Z)(e),d=(0,r.Fl)((()=>"q-inner-loading absolute-full column flex-center"+(!0===s.value?" q-inner-loading--dark":""))),h=(0,r.Fl)((()=>"q-inner-loading__label"+(void 0!==e.labelClass?` ${e.labelClass}`:"")));function f(){const t=[(0,r.h)(o.Z,{size:e.size,color:e.color})];return void 0!==e.label&&t.push((0,r.h)("div",{class:h.value,style:e.labelStyle},[e.label])),t}function p(){return!0===e.showing?(0,r.h)("div",{class:d.value,style:c.value},void 0!==t.default?t.default():f()):null}return()=>(0,r.h)(i.uT,u.value,p)}})},3119:(e,t,n)=>{"use strict";n.d(t,{Z:()=>S});var r=n(9835),i=n(499),o=n(3167),s=(n(9665),n(1705));const a={date:"####/##/##",datetime:"####/##/## ##:##",time:"##:##",fulltime:"##:##:##",phone:"(###) ### - ####",card:"#### #### #### ####"},l={"#":{pattern:"[\\d]",negate:"[^\\d]"},S:{pattern:"[a-zA-Z]",negate:"[^a-zA-Z]"},N:{pattern:"[0-9a-zA-Z]",negate:"[^0-9a-zA-Z]"},A:{pattern:"[a-zA-Z]",negate:"[^a-zA-Z]",transform:e=>e.toLocaleUpperCase()},a:{pattern:"[a-zA-Z]",negate:"[^a-zA-Z]",transform:e=>e.toLocaleLowerCase()},X:{pattern:"[0-9a-zA-Z]",negate:"[^0-9a-zA-Z]",transform:e=>e.toLocaleUpperCase()},x:{pattern:"[0-9a-zA-Z]",negate:"[^0-9a-zA-Z]",transform:e=>e.toLocaleLowerCase()}},u=Object.keys(l);u.forEach((e=>{l[e].regex=new RegExp(l[e].pattern)}));const c=new RegExp("\\\\([^.*+?^${}()|([\\]])|([.*+?^${}()|[\\]])|(["+u.join("")+"])|(.)","g"),d=/[.*+?^${}()|[\]\\]/g,h=String.fromCharCode(1),f={mask:String,reverseFillMask:Boolean,fillMask:[Boolean,String],unmaskedValue:Boolean};function p(e,t,n,o){let u,f,p,g,m,v;const y=(0,i.iH)(null),b=(0,i.iH)(_());function w(){return!0===e.autogrow||["textarea","text","search","url","tel","password"].includes(e.type)}function _(){if(E(),!0===y.value){const t=A(O(e.modelValue));return!1!==e.fillMask?N(t):t}return e.modelValue}function S(e){if(e<u.length)return u.slice(-e);let t="",n=u;const r=n.indexOf(h);if(r>-1){for(let r=e-n.length;r>0;r--)t+=h;n=n.slice(0,r)+t+n.slice(r)}return n}function E(){if(y.value=void 0!==e.mask&&0!==e.mask.length&&w(),!1===y.value)return g=void 0,u="",void(f="");const t=void 0===a[e.mask]?e.mask:a[e.mask],n="string"===typeof e.fillMask&&0!==e.fillMask.length?e.fillMask.slice(0,1):"_",r=n.replace(d,"\\$&"),i=[],o=[],s=[];let m=!0===e.reverseFillMask,v="",b="";t.replace(c,((e,t,n,r,a)=>{if(void 0!==r){const e=l[r];s.push(e),b=e.negate,!0===m&&(o.push("(?:"+b+"+)?("+e.pattern+"+)?(?:"+b+"+)?("+e.pattern+"+)?"),m=!1),o.push("(?:"+b+"+)?("+e.pattern+")?")}else if(void 0!==n)v="\\"+("\\"===n?"":n),s.push(n),i.push("([^"+v+"]+)?"+v+"?");else{const e=void 0!==t?t:a;v="\\"===e?"\\\\\\\\":e.replace(d,"\\\\$&"),s.push(e),i.push("([^"+v+"]+)?"+v+"?")}}));const _=new RegExp("^"+i.join("")+"("+(""===v?".":"[^"+v+"]")+"+)?"+(""===v?"":"["+v+"]*")+"$"),S=o.length-1,E=o.map(((t,n)=>0===n&&!0===e.reverseFillMask?new RegExp("^"+r+"*"+t):n===S?new RegExp("^"+t+"("+(""===b?".":b)+"+)?"+(!0===e.reverseFillMask?"$":r+"*")):new RegExp("^"+t)));p=s,g=t=>{const n=_.exec(!0===e.reverseFillMask?t:t.slice(0,s.length+1));null!==n&&(t=n.slice(1).join(""));const r=[],i=E.length;for(let e=0,o=t;e<i;e++){const t=E[e].exec(o);if(null===t)break;o=o.slice(t.shift().length),r.push(...t)}return 0!==r.length?r.join(""):t},u=s.map((e=>"string"===typeof e?e:h)).join(""),f=u.split(h).join(n)}function k(t,i,s){const a=o.value,l=a.selectionEnd,c=a.value.length-l,d=O(t);!0===i&&E();const p=A(d),g=!1!==e.fillMask?N(p):p,v=b.value!==g;a.value!==g&&(a.value=g),!0===v&&(b.value=g),document.activeElement===a&&(0,r.Y3)((()=>{if(g!==f)if("insertFromPaste"!==s||!0===e.reverseFillMask)if(["deleteContentBackward","deleteContentForward"].indexOf(s)>-1){const t=!0===e.reverseFillMask?0===l?g.length>p.length?1:0:Math.max(0,g.length-(g===f?0:Math.min(p.length,c)+1))+1:l;a.setSelectionRange(t,t,"forward")}else if(!0===e.reverseFillMask)if(!0===v){const e=Math.max(0,g.length-(g===f?0:Math.min(p.length,c+1)));1===e&&1===l?a.setSelectionRange(e,e,"forward"):C.rightReverse(a,e)}else{const e=g.length-c;a.setSelectionRange(e,e,"backward")}else if(!0===v){const e=Math.max(0,u.indexOf(h),Math.min(p.length,l)-1);C.right(a,e)}else{const e=l-1;C.right(a,e)}else{const e=a.selectionEnd;let t=l-1;for(let n=m;n<=t&&n<e;n++)u[n]!==h&&t++;C.right(a,t)}else{const t=!0===e.reverseFillMask?f.length:0;a.setSelectionRange(t,t,"forward")}}));const y=!0===e.unmaskedValue?O(g):g;String(e.modelValue)!==y&&n(y,!0)}function T(e,t,n){const r=A(O(e.value));t=Math.max(0,u.indexOf(h),Math.min(r.length,t)),m=t,e.setSelectionRange(t,n,"forward")}(0,r.YP)((()=>e.type+e.autogrow),E),(0,r.YP)((()=>e.mask),(n=>{if(void 0!==n)k(b.value,!0);else{const n=O(b.value);E(),e.modelValue!==n&&t("update:modelValue",n)}})),(0,r.YP)((()=>e.fillMask+e.reverseFillMask),(()=>{!0===y.value&&k(b.value,!0)})),(0,r.YP)((()=>e.unmaskedValue),(()=>{!0===y.value&&k(b.value)}));const C={left(e,t){const n=-1===u.slice(t-1).indexOf(h);let r=Math.max(0,t-1);for(;r>=0;r--)if(u[r]===h){t=r,!0===n&&t++;break}if(r<0&&void 0!==u[t]&&u[t]!==h)return C.right(e,0);t>=0&&e.setSelectionRange(t,t,"backward")},right(e,t){const n=e.value.length;let r=Math.min(n,t+1);for(;r<=n;r++){if(u[r]===h){t=r;break}u[r-1]===h&&(t=r)}if(r>n&&void 0!==u[t-1]&&u[t-1]!==h)return C.left(e,n);e.setSelectionRange(t,t,"forward")},leftReverse(e,t){const n=S(e.value.length);let r=Math.max(0,t-1);for(;r>=0;r--){if(n[r-1]===h){t=r;break}if(n[r]===h&&(t=r,0===r))break}if(r<0&&void 0!==n[t]&&n[t]!==h)return C.rightReverse(e,0);t>=0&&e.setSelectionRange(t,t,"backward")},rightReverse(e,t){const n=e.value.length,r=S(n),i=-1===r.slice(0,t+1).indexOf(h);let o=Math.min(n,t+1);for(;o<=n;o++)if(r[o-1]===h){t=o,t>0&&!0===i&&t--;break}if(o>n&&void 0!==r[t-1]&&r[t-1]!==h)return C.leftReverse(e,n);e.setSelectionRange(t,t,"forward")}};function I(e){t("click",e),v=void 0}function x(n){if(t("keydown",n),!0===(0,s.Wm)(n))return;const r=o.value,i=r.selectionStart,a=r.selectionEnd;if(n.shiftKey||(v=void 0),37===n.keyCode||39===n.keyCode){n.shiftKey&&void 0===v&&(v="forward"===r.selectionDirection?i:a);const t=C[(39===n.keyCode?"right":"left")+(!0===e.reverseFillMask?"Reverse":"")];if(n.preventDefault(),t(r,v===i?a:i),n.shiftKey){const e=r.selectionStart;r.setSelectionRange(Math.min(v,e),Math.max(v,e),"forward")}}else 8===n.keyCode&&!0!==e.reverseFillMask&&i===a?(C.left(r,i),r.setSelectionRange(r.selectionStart,a,"backward")):46===n.keyCode&&!0===e.reverseFillMask&&i===a&&(C.rightReverse(r,a),r.setSelectionRange(i,r.selectionEnd,"forward"))}function A(t){if(void 0===t||null===t||""===t)return"";if(!0===e.reverseFillMask)return R(t);const n=p;let r=0,i="";for(let e=0;e<n.length;e++){const o=t[r],s=n[e];if("string"===typeof s)i+=s,o===s&&r++;else{if(void 0===o||!s.regex.test(o))return i;i+=void 0!==s.transform?s.transform(o):o,r++}}return i}function R(e){const t=p,n=u.indexOf(h);let r=e.length-1,i="";for(let o=t.length-1;o>=0&&r>-1;o--){const s=t[o];let a=e[r];if("string"===typeof s)i=s+i,a===s&&r--;else{if(void 0===a||!s.regex.test(a))return i;do{i=(void 0!==s.transform?s.transform(a):a)+i,r--,a=e[r]}while(n===o&&void 0!==a&&s.regex.test(a))}}return i}function O(e){return"string"!==typeof e||void 0===g?"number"===typeof e?g(""+e):e:g(e)}function N(t){return f.length-t.length<=0?t:!0===e.reverseFillMask&&0!==t.length?f.slice(0,-t.length)+t:t+f.slice(t.length)}return{innerValue:b,hasMask:y,moveCursorForPaste:T,updateMaskValue:k,onMaskedKeydown:x,onMaskedClick:I}}var g=n(9256),m=n(7915),v=n(2802),y=n(5987),b=n(1384),w=n(7026),_=n(3251);const S=(0,y.L)({name:"QInput",inheritAttrs:!1,props:{...o.Cl,...f,...g.Fz,modelValue:{required:!1},shadowText:String,type:{type:String,default:"text"},debounce:[String,Number],autogrow:Boolean,inputClass:[Array,String,Object],inputStyle:[Array,String,Object]},emits:[...o.HJ,"paste","change","keydown","click","animationend"],setup(e,{emit:t,attrs:n}){const{proxy:s}=(0,r.FN)(),{$q:a}=s,l={};let u,c,d,h=NaN,f=null;const y=(0,i.iH)(null),S=(0,g.Do)(e),{innerValue:E,hasMask:k,moveCursorForPaste:T,updateMaskValue:C,onMaskedKeydown:I,onMaskedClick:x}=p(e,t,$,y),A=(0,m.Z)(e,!0),R=(0,r.Fl)((()=>(0,o.yV)(E.value))),O=(0,v.Z)(U),N=(0,o.tL)(),P=(0,r.Fl)((()=>"textarea"===e.type||!0===e.autogrow)),F=(0,r.Fl)((()=>!0===P.value||["text","search","url","tel","password"].includes(e.type))),L=(0,r.Fl)((()=>{const t={...N.splitAttrs.listeners.value,onInput:U,onPaste:V,onChange:z,onBlur:H,onFocus:b.sT};return t.onCompositionstart=t.onCompositionupdate=t.onCompositionend=O,!0===k.value&&(t.onKeydown=I,t.onClick=x),!0===e.autogrow&&(t.onAnimationend=B),t})),D=(0,r.Fl)((()=>{const t={tabindex:0,"data-autofocus":!0===e.autofocus||void 0,rows:"textarea"===e.type?6:void 0,"aria-label":e.label,name:S.value,...N.splitAttrs.attributes.value,id:N.targetUid.value,maxlength:e.maxlength,disabled:!0===e.disable,readonly:!0===e.readonly};return!1===P.value&&(t.type=e.type),!0===e.autogrow&&(t.rows=1),t}));function M(){(0,w.jd)((()=>{const e=document.activeElement;null===y.value||y.value===e||null!==e&&e.id===N.targetUid.value||y.value.focus({preventScroll:!0})}))}function q(){null!==y.value&&y.value.select()}function V(n){if(!0===k.value&&!0!==e.reverseFillMask){const e=n.target;T(e,e.selectionStart,e.selectionEnd)}t("paste",n)}function U(n){if(!n||!n.target)return;if("file"===e.type)return void t("update:modelValue",n.target.files);const i=n.target.value;if(!0!==n.target.qComposing){if(!0===k.value)C(i,!1,n.inputType);else if($(i),!0===F.value&&n.target===document.activeElement){const{selectionStart:e,selectionEnd:t}=n.target;void 0!==e&&void 0!==t&&(0,r.Y3)((()=>{n.target===document.activeElement&&0===i.indexOf(n.target.value)&&n.target.setSelectionRange(e,t)}))}!0===e.autogrow&&j()}else l.value=i}function B(e){t("animationend",e),j()}function $(n,i){d=()=>{f=null,"number"!==e.type&&!0===l.hasOwnProperty("value")&&delete l.value,e.modelValue!==n&&h!==n&&(h=n,!0===i&&(c=!0),t("update:modelValue",n),(0,r.Y3)((()=>{h===n&&(h=NaN)}))),d=void 0},"number"===e.type&&(u=!0,l.value=n),void 0!==e.debounce?(null!==f&&clearTimeout(f),l.value=n,f=setTimeout(d,e.debounce)):d()}function j(){requestAnimationFrame((()=>{const e=y.value;if(null!==e){const t=e.parentNode.style,{scrollTop:n}=e,{overflowY:r,maxHeight:i}=!0===a.platform.is.firefox?{}:window.getComputedStyle(e),o=void 0!==r&&"scroll"!==r;!0===o&&(e.style.overflowY="hidden"),t.marginBottom=e.scrollHeight-1+"px",e.style.height="1px",e.style.height=e.scrollHeight+"px",!0===o&&(e.style.overflowY=parseInt(i,10)<e.scrollHeight?"auto":"hidden"),t.marginBottom="",e.scrollTop=n}}))}function z(e){O(e),null!==f&&(clearTimeout(f),f=null),void 0!==d&&d(),t("change",e.target.value)}function H(t){void 0!==t&&(0,b.sT)(t),null!==f&&(clearTimeout(f),f=null),void 0!==d&&d(),u=!1,c=!1,delete l.value,"file"!==e.type&&setTimeout((()=>{null!==y.value&&(y.value.value=void 0!==E.value?E.value:"")}))}function K(){return!0===l.hasOwnProperty("value")?l.value:void 0!==E.value?E.value:""}(0,r.YP)((()=>e.type),(()=>{y.value&&(y.value.value=e.modelValue)})),(0,r.YP)((()=>e.modelValue),(t=>{if(!0===k.value){if(!0===c&&(c=!1,String(t)===h))return;C(t)}else E.value!==t&&(E.value=t,"number"===e.type&&!0===l.hasOwnProperty("value")&&(!0===u?u=!1:delete l.value));!0===e.autogrow&&(0,r.Y3)(j)})),(0,r.YP)((()=>e.autogrow),(e=>{!0===e?(0,r.Y3)(j):null!==y.value&&n.rows>0&&(y.value.style.height="auto")})),(0,r.YP)((()=>e.dense),(()=>{!0===e.autogrow&&(0,r.Y3)(j)})),(0,r.Jd)((()=>{H()})),(0,r.bv)((()=>{!0===e.autogrow&&j()})),Object.assign(N,{innerValue:E,fieldClass:(0,r.Fl)((()=>"q-"+(!0===P.value?"textarea":"input")+(!0===e.autogrow?" q-textarea--autogrow":""))),hasShadow:(0,r.Fl)((()=>"file"!==e.type&&"string"===typeof e.shadowText&&0!==e.shadowText.length)),inputRef:y,emitValue:$,hasValue:R,floatingLabel:(0,r.Fl)((()=>!0===R.value&&("number"!==e.type||!1===isNaN(E.value))||(0,o.yV)(e.displayValue))),getControl:()=>(0,r.h)(!0===P.value?"textarea":"input",{ref:y,class:["q-field__native q-placeholder",e.inputClass],style:e.inputStyle,...D.value,...L.value,..."file"!==e.type?{value:K()}:A.value}),getShadowControl:()=>(0,r.h)("div",{class:"q-field__native q-field__shadow absolute-bottom no-pointer-events"+(!0===P.value?"":" text-no-wrap")},[(0,r.h)("span",{class:"invisible"},K()),(0,r.h)("span",e.shadowText)])});const W=(0,o.ZP)(N);return Object.assign(s,{focus:M,select:q,getNativeElement:()=>y.value}),(0,_.g)(s,"nativeEl",(()=>y.value)),W}})},3115:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(9835),i=n(5987),o=n(2026);const s=(0,i.L)({name:"QItemLabel",props:{overline:Boolean,caption:Boolean,header:Boolean,lines:[Number,String]},setup(e,{slots:t}){const n=(0,r.Fl)((()=>parseInt(e.lines,10))),i=(0,r.Fl)((()=>"q-item__label"+(!0===e.overline?" q-item__label--overline text-overline":"")+(!0===e.caption?" q-item__label--caption text-caption":"")+(!0===e.header?" q-item__label--header":"")+(1===n.value?" ellipsis":""))),s=(0,r.Fl)((()=>void 0!==e.lines&&n.value>1?{overflow:"hidden",display:"-webkit-box","-webkit-box-orient":"vertical","-webkit-line-clamp":n.value}:null));return()=>(0,r.h)("div",{style:s.value,class:i.value},(0,o.KR)(t.default))}})},7605:(e,t,n)=>{"use strict";n.d(t,{Z:()=>g});var r=n(9835),i=n(499),o=n(7506),s=n(5987),a=n(3701),l=n(1384);const{passive:u}=l.listenOpts,c=["both","horizontal","vertical"],d=(0,s.L)({name:"QScrollObserver",props:{axis:{type:String,validator:e=>c.includes(e),default:"vertical"},debounce:[String,Number],scrollTarget:{default:void 0}},emits:["scroll"],setup(e,{emit:t}){const n={position:{top:0,left:0},direction:"down",directionChanged:!1,delta:{top:0,left:0},inflectionPoint:{top:0,left:0}};let i,o,s=null;function c(){null!==s&&s();const r=Math.max(0,(0,a.u3)(i)),o=(0,a.OI)(i),l={top:r-n.position.top,left:o-n.position.left};if("vertical"===e.axis&&0===l.top||"horizontal"===e.axis&&0===l.left)return;const u=Math.abs(l.top)>=Math.abs(l.left)?l.top<0?"up":"down":l.left<0?"left":"right";n.position={top:r,left:o},n.directionChanged=n.direction!==u,n.delta=l,!0===n.directionChanged&&(n.direction=u,n.inflectionPoint=n.position),t("scroll",{...n})}function d(){i=(0,a.b0)(o,e.scrollTarget),i.addEventListener("scroll",f,u),f(!0)}function h(){void 0!==i&&(i.removeEventListener("scroll",f,u),i=void 0)}function f(t){if(!0===t||0===e.debounce||"0"===e.debounce)c();else if(null===s){const[t,n]=e.debounce?[setTimeout(c,e.debounce),clearTimeout]:[requestAnimationFrame(c),cancelAnimationFrame];s=()=>{n(t),s=null}}}(0,r.YP)((()=>e.scrollTarget),(()=>{h(),d()}));const{proxy:p}=(0,r.FN)();return(0,r.YP)((()=>p.$q.lang.rtl),c),(0,r.bv)((()=>{o=p.$el.parentNode,d()})),(0,r.Jd)((()=>{null!==s&&s(),h()})),Object.assign(p,{trigger:f,getPosition:()=>n}),l.ZT}});var h=n(883),f=n(2026),p=n(5439);const g=(0,s.L)({name:"QLayout",props:{container:Boolean,view:{type:String,default:"hhh lpr fff",validator:e=>/^(h|l)h(h|r) lpr (f|l)f(f|r)$/.test(e.toLowerCase())},onScroll:Function,onScrollHeight:Function,onResize:Function},setup(e,{slots:t,emit:n}){const{proxy:{$q:s}}=(0,r.FN)(),l=(0,i.iH)(null),u=(0,i.iH)(s.screen.height),c=(0,i.iH)(!0===e.container?0:s.screen.width),g=(0,i.iH)({position:0,direction:"down",inflectionPoint:0}),m=(0,i.iH)(0),v=(0,i.iH)(!0===o.uX.value?0:(0,a.np)()),y=(0,r.Fl)((()=>"q-layout q-layout--"+(!0===e.container?"containerized":"standard"))),b=(0,r.Fl)((()=>!1===e.container?{minHeight:s.screen.height+"px"}:null)),w=(0,r.Fl)((()=>0!==v.value?{[!0===s.lang.rtl?"left":"right"]:`${v.value}px`}:null)),_=(0,r.Fl)((()=>0!==v.value?{[!0===s.lang.rtl?"right":"left"]:0,[!0===s.lang.rtl?"left":"right"]:`-${v.value}px`,width:`calc(100% + ${v.value}px)`}:null));function S(t){if(!0===e.container||!0!==document.qScrollPrevented){const r={position:t.position.top,direction:t.direction,directionChanged:t.directionChanged,inflectionPoint:t.inflectionPoint.top,delta:t.delta.top};g.value=r,void 0!==e.onScroll&&n("scroll",r)}}function E(t){const{height:r,width:i}=t;let o=!1;u.value!==r&&(o=!0,u.value=r,void 0!==e.onScrollHeight&&n("scrollHeight",r),T()),c.value!==i&&(o=!0,c.value=i),!0===o&&void 0!==e.onResize&&n("resize",t)}function k({height:e}){m.value!==e&&(m.value=e,T())}function T(){if(!0===e.container){const e=u.value>m.value?(0,a.np)():0;v.value!==e&&(v.value=e)}}let C=null;const I={instances:{},view:(0,r.Fl)((()=>e.view)),isContainer:(0,r.Fl)((()=>e.container)),rootRef:l,height:u,containerHeight:m,scrollbarWidth:v,totalWidth:(0,r.Fl)((()=>c.value+v.value)),rows:(0,r.Fl)((()=>{const t=e.view.toLowerCase().split(" ");return{top:t[0].split(""),middle:t[1].split(""),bottom:t[2].split("")}})),header:(0,i.qj)({size:0,offset:0,space:!1}),right:(0,i.qj)({size:300,offset:0,space:!1}),footer:(0,i.qj)({size:0,offset:0,space:!1}),left:(0,i.qj)({size:300,offset:0,space:!1}),scroll:g,animate(){null!==C?clearTimeout(C):document.body.classList.add("q-body--layout-animate"),C=setTimeout((()=>{C=null,document.body.classList.remove("q-body--layout-animate")}),155)},update(e,t,n){I[e][t]=n}};if((0,r.JJ)(p.YE,I),(0,a.np)()>0){let x=null;const A=document.body;function R(){x=null,A.classList.remove("hide-scrollbar")}function O(){if(null===x){if(A.scrollHeight>s.screen.height)return;A.classList.add("hide-scrollbar")}else clearTimeout(x);x=setTimeout(R,300)}function N(e){null!==x&&"remove"===e&&(clearTimeout(x),R()),window[`${e}EventListener`]("resize",O)}(0,r.YP)((()=>!0!==e.container?"add":"remove"),N),!0!==e.container&&N("add"),(0,r.Ah)((()=>{N("remove")}))}return()=>{const n=(0,f.vs)(t.default,[(0,r.h)(d,{onScroll:S}),(0,r.h)(h.Z,{onResize:E})]),i=(0,r.h)("div",{class:y.value,style:b.value,ref:!0===e.container?void 0:l,tabindex:-1},n);return!0===e.container?(0,r.h)("div",{class:"q-layout-container overflow-hidden",ref:l},[(0,r.h)(h.Z,{onResize:k}),(0,r.h)("div",{class:"absolute-full",style:w.value},[(0,r.h)("div",{class:"scroll",style:_.value},[i])])]):i}}})},6362:(e,t,n)=>{"use strict";n.d(t,{Z:()=>T});var r=n(9835),i=n(499),o=n(1957),s=n(4397),a=n(4088),l=n(3842),u=n(8234),c=n(1518),d=n(431),h=n(6916),f=n(2695),p=n(5987),g=n(2909),m=n(3701),v=n(1384),y=n(2026),b=n(6532),w=n(4173),_=n(223),S=n(9092),E=n(7026),k=n(9388);const T=(0,p.L)({name:"QMenu",inheritAttrs:!1,props:{...s.u,...l.vr,...u.S,...d.D,persistent:Boolean,autoClose:Boolean,separateClosePopup:Boolean,noRouteDismiss:Boolean,noRefocus:Boolean,noFocus:Boolean,fit:Boolean,cover:Boolean,square:Boolean,anchor:{type:String,validator:k.$},self:{type:String,validator:k.$},offset:{type:Array,validator:k.io},scrollTarget:{default:void 0},touchPosition:Boolean,maxHeight:{type:String,default:null},maxWidth:{type:String,default:null}},emits:[...l.gH,"click","escapeKey"],setup(e,{slots:t,emit:n,attrs:p}){let T,C,I,x=null;const A=(0,r.FN)(),{proxy:R}=A,{$q:O}=R,N=(0,i.iH)(null),P=(0,i.iH)(!1),F=(0,r.Fl)((()=>!0!==e.persistent&&!0!==e.noRouteDismiss)),L=(0,u.Z)(e,O),{registerTick:D,removeTick:M}=(0,h.Z)(),{registerTimeout:q}=(0,f.Z)(),{transitionProps:V,transitionStyle:U}=(0,d.Z)(e),{localScrollTarget:B,changeScrollEvent:$,unconfigureScrollTarget:j}=(0,a.Z)(e,se),{anchorEl:z,canShow:H}=(0,s.Z)({showing:P}),{hide:K}=(0,l.ZP)({showing:P,canShow:H,handleShow:re,handleHide:ie,hideOnRouteChange:F,processOnMount:!0}),{showPortal:W,hidePortal:Z,renderPortal:G}=(0,c.Z)(A,N,de,"menu"),J={anchorEl:z,innerRef:N,onClickOutside(t){if(!0!==e.persistent&&!0===P.value)return K(t),("touchstart"===t.type||t.target.classList.contains("q-dialog__backdrop"))&&(0,v.NS)(t),!0}},Q=(0,r.Fl)((()=>(0,k.li)(e.anchor||(!0===e.cover?"center middle":"bottom start"),O.lang.rtl))),Y=(0,r.Fl)((()=>!0===e.cover?Q.value:(0,k.li)(e.self||"top start",O.lang.rtl))),X=(0,r.Fl)((()=>(!0===e.square?" q-menu--square":"")+(!0===L.value?" q-menu--dark q-dark":""))),ee=(0,r.Fl)((()=>!0===e.autoClose?{onClick:ae}:{})),te=(0,r.Fl)((()=>!0===P.value&&!0!==e.persistent));function ne(){(0,E.jd)((()=>{let e=N.value;e&&!0!==e.contains(document.activeElement)&&(e=e.querySelector("[autofocus][tabindex], [data-autofocus][tabindex]")||e.querySelector("[autofocus] [tabindex], [data-autofocus] [tabindex]")||e.querySelector("[autofocus], [data-autofocus]")||e,e.focus({preventScroll:!0}))}))}function re(t){if(x=!1===e.noRefocus?document.activeElement:null,(0,w.i)(le),W(),se(),T=void 0,void 0!==t&&(e.touchPosition||e.contextMenu)){const e=(0,v.FK)(t);if(void 0!==e.left){const{top:t,left:n}=z.value.getBoundingClientRect();T={left:e.left-n,top:e.top-t}}}void 0===C&&(C=(0,r.YP)((()=>O.screen.width+"|"+O.screen.height+"|"+e.self+"|"+e.anchor+"|"+O.lang.rtl),ce)),!0!==e.noFocus&&document.activeElement.blur(),D((()=>{ce(),!0!==e.noFocus&&ne()})),q((()=>{!0===O.platform.is.ios&&(I=e.autoClose,N.value.click()),ce(),W(!0),n("show",t)}),e.transitionDuration)}function ie(t){M(),Z(),oe(!0),null===x||void 0!==t&&!0===t.qClickOutside||(((t&&0===t.type.indexOf("key")?x.closest('[tabindex]:not([tabindex^="-"])'):void 0)||x).focus(),x=null),q((()=>{Z(!0),n("hide",t)}),e.transitionDuration)}function oe(e){T=void 0,void 0!==C&&(C(),C=void 0),!0!==e&&!0!==P.value||((0,w.H)(le),j(),(0,S.D)(J),(0,b.k)(ue)),!0!==e&&(x=null)}function se(){null===z.value&&void 0===e.scrollTarget||(B.value=(0,m.b0)(z.value,e.scrollTarget),$(B.value,ce))}function ae(e){!0!==I?((0,g.AH)(R,e),n("click",e)):I=!1}function le(t){!0===te.value&&!0!==e.noFocus&&!0!==(0,_.mY)(N.value,t.target)&&ne()}function ue(e){n("escapeKey"),K(e)}function ce(){const t=N.value;null!==t&&null!==z.value&&(0,k.wq)({el:t,offset:e.offset,anchorEl:z.value,anchorOrigin:Q.value,selfOrigin:Y.value,absoluteOffset:T,fit:e.fit,cover:e.cover,maxHeight:e.maxHeight,maxWidth:e.maxWidth})}function de(){return(0,r.h)(o.uT,V.value,(()=>!0===P.value?(0,r.h)("div",{role:"menu",...p,ref:N,tabindex:-1,class:["q-menu q-position-engine scroll"+X.value,p.class],style:[p.style,U.value],...ee.value},(0,y.KR)(t.default)):null))}return(0,r.YP)(te,(e=>{!0===e?((0,b.c)(ue),(0,S.m)(J)):((0,b.k)(ue),(0,S.D)(J))})),(0,r.Jd)(oe),Object.assign(R,{focus:ne,updatePosition:ce}),G}})},9885:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(9835),i=n(5987),o=n(2026),s=n(5439);const a=(0,i.L)({name:"QPage",props:{padding:Boolean,styleFn:Function},setup(e,{slots:t}){const{proxy:{$q:n}}=(0,r.FN)(),i=(0,r.f3)(s.YE,s.qO);if(i===s.qO)return console.error("QPage needs to be a deep child of QLayout"),s.qO;const a=(0,r.f3)(s.Mw,s.qO);if(a===s.qO)return console.error("QPage needs to be child of QPageContainer"),s.qO;const l=(0,r.Fl)((()=>{const t=(!0===i.header.space?i.header.size:0)+(!0===i.footer.space?i.footer.size:0);if("function"===typeof e.styleFn){const r=!0===i.isContainer.value?i.containerHeight.value:n.screen.height;return e.styleFn(t,r)}return{minHeight:!0===i.isContainer.value?i.containerHeight.value-t+"px":0===n.screen.height?0!==t?`calc(100vh - ${t}px)`:"100vh":n.screen.height-t+"px"}})),u=(0,r.Fl)((()=>"q-page"+(!0===e.padding?" q-layout-padding":"")));return()=>(0,r.h)("main",{class:u.value,style:l.value},(0,o.KR)(t.default))}})},2133:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(9835),i=n(5987),o=n(2026),s=n(5439);const a=(0,i.L)({name:"QPageContainer",setup(e,{slots:t}){const{proxy:{$q:n}}=(0,r.FN)(),i=(0,r.f3)(s.YE,s.qO);if(i===s.qO)return console.error("QPageContainer needs to be child of QLayout"),s.qO;(0,r.JJ)(s.Mw,!0);const a=(0,r.Fl)((()=>{const e={};return!0===i.header.space&&(e.paddingTop=`${i.header.size}px`),!0===i.right.space&&(e["padding"+(!0===n.lang.rtl?"Left":"Right")]=`${i.right.size}px`),!0===i.footer.space&&(e.paddingBottom=`${i.footer.size}px`),!0===i.left.space&&(e["padding"+(!0===n.lang.rtl?"Right":"Left")]=`${i.left.size}px`),e}));return()=>(0,r.h)("div",{class:"q-page-container",style:a.value},(0,o.KR)(t.default))}})},883:(e,t,n)=>{"use strict";n.d(t,{Z:()=>d});var r=n(9835),i=n(499),o=n(7506);function s(){const e=(0,i.iH)(!o.uX.value);return!1===e.value&&(0,r.bv)((()=>{e.value=!0})),e}var a=n(5987),l=n(1384);const u="undefined"!==typeof ResizeObserver,c=!0===u?{}:{style:"display:block;position:absolute;top:0;left:0;right:0;bottom:0;height:100%;width:100%;overflow:hidden;pointer-events:none;z-index:-1;",url:"about:blank"},d=(0,a.L)({name:"QResizeObserver",props:{debounce:{type:[String,Number],default:100}},emits:["resize"],setup(e,{emit:t}){let n,i=null,o={width:-1,height:-1};function a(t){!0===t||0===e.debounce||"0"===e.debounce?d():null===i&&(i=setTimeout(d,e.debounce))}function d(){if(null!==i&&(clearTimeout(i),i=null),n){const{offsetWidth:e,offsetHeight:r}=n;e===o.width&&r===o.height||(o={width:e,height:r},t("resize",o))}}const{proxy:h}=(0,r.FN)();if(!0===u){let f;const p=e=>{n=h.$el.parentNode,n?(f=new ResizeObserver(a),f.observe(n),d()):!0!==e&&(0,r.Y3)((()=>{p(!0)}))};return(0,r.bv)((()=>{p()})),(0,r.Jd)((()=>{null!==i&&clearTimeout(i),void 0!==f&&(void 0!==f.disconnect?f.disconnect():n&&f.unobserve(n))})),l.ZT}{const g=s();let m;function v(){null!==i&&(clearTimeout(i),i=null),void 0!==m&&(void 0!==m.removeEventListener&&m.removeEventListener("resize",a,l.listenOpts.passive),m=void 0)}function y(){v(),n&&n.contentDocument&&(m=n.contentDocument.defaultView,m.addEventListener("resize",a,l.listenOpts.passive),d())}return(0,r.bv)((()=>{(0,r.Y3)((()=>{n=h.$el,n&&y()}))})),(0,r.Jd)(v),h.trigger=a,()=>{if(!0===g.value)return(0,r.h)("object",{style:c.style,tabindex:-1,type:"text/html",data:c.url,"aria-hidden":"true",onLoad:y})}}}})},1290:(e,t,n)=>{"use strict";n.d(t,{Z:()=>x});n(9665);var r=n(9835),i=n(499),o=n(3167),s=n(5987);const a=(0,s.L)({name:"QField",inheritAttrs:!1,props:o.Cl,emits:o.HJ,setup(){return(0,o.ZP)((0,o.tL)())}});var l=n(2857),u=n(7691),c=(n(6890),n(8234)),d=n(945),h=n(2026),f=n(1384),p=n(1705);const g=(0,s.L)({name:"QItem",props:{...c.S,...d.$,tag:{type:String,default:"div"},active:{type:Boolean,default:null},clickable:Boolean,dense:Boolean,insetLevel:Number,tabindex:[String,Number],focused:Boolean,manualFocus:Boolean},emits:["click","keyup"],setup(e,{slots:t,emit:n}){const{proxy:{$q:o}}=(0,r.FN)(),s=(0,c.Z)(e,o),{hasLink:a,linkAttrs:l,linkClass:u,linkTag:g,navigateOnClick:m}=(0,d.Z)(),v=(0,i.iH)(null),y=(0,i.iH)(null),b=(0,r.Fl)((()=>!0===e.clickable||!0===a.value||"label"===e.tag)),w=(0,r.Fl)((()=>!0!==e.disable&&!0===b.value)),_=(0,r.Fl)((()=>"q-item q-item-type row no-wrap"+(!0===e.dense?" q-item--dense":"")+(!0===s.value?" q-item--dark":"")+(!0===a.value&&null===e.active?u.value:!0===e.active?" q-item--active"+(void 0!==e.activeClass?` ${e.activeClass}`:""):"")+(!0===e.disable?" disabled":"")+(!0===w.value?" q-item--clickable q-link cursor-pointer "+(!0===e.manualFocus?"q-manual-focusable":"q-focusable q-hoverable")+(!0===e.focused?" q-manual-focusable--focused":""):""))),S=(0,r.Fl)((()=>{if(void 0===e.insetLevel)return null;const t=!0===o.lang.rtl?"Right":"Left";return{["padding"+t]:16+56*e.insetLevel+"px"}}));function E(e){!0===w.value&&(null!==y.value&&(!0!==e.qKeyEvent&&document.activeElement===v.value?y.value.focus():document.activeElement===y.value&&v.value.focus()),m(e))}function k(e){if(!0===w.value&&!0===(0,p.So)(e,13)){(0,f.NS)(e),e.qKeyEvent=!0;const t=new MouseEvent("click",e);t.qKeyEvent=!0,v.value.dispatchEvent(t)}n("keyup",e)}function T(){const e=(0,h.Bl)(t.default,[]);return!0===w.value&&e.unshift((0,r.h)("div",{class:"q-focus-helper",tabindex:-1,ref:y})),e}return()=>{const t={ref:v,class:_.value,style:S.value,role:"listitem",onClick:E,onKeyup:k};return!0===w.value?(t.tabindex=e.tabindex||"0",Object.assign(t,l.value)):!0===b.value&&(t["aria-disabled"]="true"),(0,r.h)(g.value,t,T())}}}),m=(0,s.L)({name:"QItemSection",props:{avatar:Boolean,thumbnail:Boolean,side:Boolean,top:Boolean,noWrap:Boolean},setup(e,{slots:t}){const n=(0,r.Fl)((()=>"q-item__section column q-item__section--"+(!0===e.avatar||!0===e.side||!0===e.thumbnail?"side":"main")+(!0===e.top?" q-item__section--top justify-start":" justify-center")+(!0===e.avatar?" q-item__section--avatar":"")+(!0===e.thumbnail?" q-item__section--thumbnail":"")+(!0===e.noWrap?" q-item__section--nowrap":"")));return()=>(0,r.h)("div",{class:n.value},(0,h.KR)(t.default))}});var v=n(3115),y=n(6362),b=n(7743),w=n(2380),_=n(9256),S=n(2802),E=n(4680),k=n(321);const T=e=>["add","add-unique","toggle"].includes(e),C=".*+?^${}()|[]\\",I=Object.keys(o.Cl),x=(0,s.L)({name:"QSelect",inheritAttrs:!1,props:{...w.t9,..._.Fz,...o.Cl,modelValue:{required:!0},multiple:Boolean,displayValue:[String,Number],displayValueHtml:Boolean,dropdownIcon:String,options:{type:Array,default:()=>[]},optionValue:[Function,String],optionLabel:[Function,String],optionDisable:[Function,String],hideSelected:Boolean,hideDropdownIcon:Boolean,fillInput:Boolean,maxValues:[Number,String],optionsDense:Boolean,optionsDark:{type:Boolean,default:null},optionsSelectedClass:String,optionsHtml:Boolean,optionsCover:Boolean,menuShrink:Boolean,menuAnchor:String,menuSelf:String,menuOffset:Array,popupContentClass:String,popupContentStyle:[String,Array,Object],useInput:Boolean,useChips:Boolean,newValueMode:{type:String,validator:T},mapOptions:Boolean,emitValue:Boolean,inputDebounce:{type:[Number,String],default:500},inputClass:[Array,String,Object],inputStyle:[Array,String,Object],tabindex:{type:[String,Number],default:0},autocomplete:String,transitionShow:String,transitionHide:String,transitionDuration:[String,Number],behavior:{type:String,validator:e=>["default","menu","dialog"].includes(e),default:"default"},virtualScrollItemSize:{type:[Number,String],default:void 0},onNewValue:Function,onFilter:Function},emits:[...o.HJ,"add","remove","inputValue","newValue","keyup","keypress","keydown","filterAbort"],setup(e,{slots:t,emit:n}){const{proxy:s}=(0,r.FN)(),{$q:c}=s,d=(0,i.iH)(!1),x=(0,i.iH)(!1),A=(0,i.iH)(-1),R=(0,i.iH)(""),O=(0,i.iH)(!1),N=(0,i.iH)(!1);let P,F,L,D,M,q,V,U=null,B=null;const $=(0,i.iH)(null),j=(0,i.iH)(null),z=(0,i.iH)(null),H=(0,i.iH)(null),K=(0,i.iH)(null),W=(0,_.Do)(e),Z=(0,S.Z)(Ge),G=(0,r.Fl)((()=>Array.isArray(e.options)?e.options.length:0)),J=(0,r.Fl)((()=>void 0===e.virtualScrollItemSize?!0===e.optionsDense?24:48:e.virtualScrollItemSize)),{virtualScrollSliceRange:Q,virtualScrollSliceSizeComputed:Y,localResetVirtualScroll:X,padVirtualScroll:ee,onVirtualScrollEvt:te,scrollTo:ne,setVirtualScrollSize:re}=(0,w.vp)({virtualScrollLength:G,getVirtualScrollTarget:He,getVirtualScrollEl:ze,virtualScrollItemSizeComputed:J}),ie=(0,o.tL)(),oe=(0,r.Fl)((()=>{const t=!0===e.mapOptions&&!0!==e.multiple,n=void 0===e.modelValue||null===e.modelValue&&!0!==t?[]:!0===e.multiple&&Array.isArray(e.modelValue)?e.modelValue:[e.modelValue];if(!0===e.mapOptions&&!0===Array.isArray(e.options)){const r=!0===e.mapOptions&&void 0!==P?P:[],i=n.map((e=>De(e,r)));return null===e.modelValue&&!0===t?i.filter((e=>null!==e)):i}return n})),se=(0,r.Fl)((()=>{const t={};return I.forEach((n=>{const r=e[n];void 0!==r&&(t[n]=r)})),t})),ae=(0,r.Fl)((()=>null===e.optionsDark?ie.isDark.value:e.optionsDark)),le=(0,r.Fl)((()=>(0,o.yV)(oe.value))),ue=(0,r.Fl)((()=>{let t="q-field__input q-placeholder col";return!0===e.hideSelected||0===oe.value.length?[t,e.inputClass]:(t+=" q-field__input--padding",void 0===e.inputClass?t:[t,e.inputClass])})),ce=(0,r.Fl)((()=>(!0===e.virtualScrollHorizontal?"q-virtual-scroll--horizontal":"")+(e.popupContentClass?" "+e.popupContentClass:""))),de=(0,r.Fl)((()=>0===G.value)),he=(0,r.Fl)((()=>oe.value.map((e=>Te.value(e))).join(", "))),fe=(0,r.Fl)((()=>void 0!==e.displayValue?e.displayValue:he.value)),pe=(0,r.Fl)((()=>!0===e.optionsHtml?()=>!0:e=>void 0!==e&&null!==e&&!0===e.html)),ge=(0,r.Fl)((()=>!0===e.displayValueHtml||void 0===e.displayValue&&(!0===e.optionsHtml||oe.value.some(pe.value)))),me=(0,r.Fl)((()=>!0===ie.focused.value?e.tabindex:-1)),ve=(0,r.Fl)((()=>{const t={tabindex:e.tabindex,role:"combobox","aria-label":e.label,"aria-readonly":!0===e.readonly?"true":"false","aria-autocomplete":!0===e.useInput?"list":"none","aria-expanded":!0===d.value?"true":"false","aria-controls":`${ie.targetUid.value}_lb`};return A.value>=0&&(t["aria-activedescendant"]=`${ie.targetUid.value}_${A.value}`),t})),ye=(0,r.Fl)((()=>({id:`${ie.targetUid.value}_lb`,role:"listbox","aria-multiselectable":!0===e.multiple?"true":"false"}))),be=(0,r.Fl)((()=>oe.value.map(((e,t)=>({index:t,opt:e,html:pe.value(e),selected:!0,removeAtIndex:Oe,toggleOption:Pe,tabindex:me.value}))))),we=(0,r.Fl)((()=>{if(0===G.value)return[];const{from:t,to:n}=Q.value;return e.options.slice(t,n).map(((n,r)=>{const i=!0===Ce.value(n),o=t+r,s={clickable:!0,active:!1,activeClass:Ee.value,manualFocus:!0,focused:!1,disable:i,tabindex:-1,dense:e.optionsDense,dark:ae.value,role:"option",id:`${ie.targetUid.value}_${o}`,onClick:()=>{Pe(n)}};return!0!==i&&(!0===qe(n)&&(s.active=!0),A.value===o&&(s.focused=!0),s["aria-selected"]=!0===s.active?"true":"false",!0===c.platform.is.desktop&&(s.onMousemove=()=>{!0===d.value&&Fe(o)})),{index:o,opt:n,html:pe.value(n),label:Te.value(n),selected:s.active,focused:s.focused,toggleOption:Pe,setOptionIndex:Fe,itemProps:s}}))})),_e=(0,r.Fl)((()=>void 0!==e.dropdownIcon?e.dropdownIcon:c.iconSet.arrow.dropdown)),Se=(0,r.Fl)((()=>!1===e.optionsCover&&!0!==e.outlined&&!0!==e.standout&&!0!==e.borderless&&!0!==e.rounded)),Ee=(0,r.Fl)((()=>void 0!==e.optionsSelectedClass?e.optionsSelectedClass:void 0!==e.color?`text-${e.color}`:"")),ke=(0,r.Fl)((()=>Me(e.optionValue,"value"))),Te=(0,r.Fl)((()=>Me(e.optionLabel,"label"))),Ce=(0,r.Fl)((()=>Me(e.optionDisable,"disable"))),Ie=(0,r.Fl)((()=>oe.value.map((e=>ke.value(e))))),xe=(0,r.Fl)((()=>{const e={onInput:Ge,onChange:Z,onKeydown:je,onKeyup:Be,onKeypress:$e,onFocus:Ve,onClick(e){!0===F&&(0,f.sT)(e)}};return e.onCompositionstart=e.onCompositionupdate=e.onCompositionend=Z,e}));function Ae(t){return!0===e.emitValue?ke.value(t):t}function Re(t){if(t>-1&&t<oe.value.length)if(!0===e.multiple){const r=e.modelValue.slice();n("remove",{index:t,value:r.splice(t,1)[0]}),n("update:modelValue",r)}else n("update:modelValue",null)}function Oe(e){Re(e),ie.focus()}function Ne(t,r){const i=Ae(t);if(!0!==e.multiple)return!0===e.fillInput&&Qe(Te.value(t),!0,!0),void n("update:modelValue",i);if(0===oe.value.length)return n("add",{index:0,value:i}),void n("update:modelValue",!0===e.multiple?[i]:i);if(!0===r&&!0===qe(t))return;if(void 0!==e.maxValues&&e.modelValue.length>=e.maxValues)return;const o=e.modelValue.slice();n("add",{index:o.length,value:i}),o.push(i),n("update:modelValue",o)}function Pe(t,r){if(!0!==ie.editable.value||void 0===t||!0===Ce.value(t))return;const i=ke.value(t);if(!0!==e.multiple)return!0!==r&&(Qe(!0===e.fillInput?Te.value(t):"",!0,!0),ct()),null!==j.value&&j.value.focus(),void(0!==oe.value.length&&!0===(0,E.xb)(ke.value(oe.value[0]),i)||n("update:modelValue",!0===e.emitValue?i:t));if((!0!==F||!0===O.value)&&ie.focus(),Ve(),0===oe.value.length){const r=!0===e.emitValue?i:t;return n("add",{index:0,value:r}),void n("update:modelValue",!0===e.multiple?[r]:r)}const o=e.modelValue.slice(),s=Ie.value.findIndex((e=>(0,E.xb)(e,i)));if(s>-1)n("remove",{index:s,value:o.splice(s,1)[0]});else{if(void 0!==e.maxValues&&o.length>=e.maxValues)return;const r=!0===e.emitValue?i:t;n("add",{index:o.length,value:r}),o.push(r)}n("update:modelValue",o)}function Fe(e){if(!0!==c.platform.is.desktop)return;const t=e>-1&&e<G.value?e:-1;A.value!==t&&(A.value=t)}function Le(t=1,n){if(!0===d.value){let r=A.value;do{r=(0,k.Uz)(r+t,-1,G.value-1)}while(-1!==r&&r!==A.value&&!0===Ce.value(e.options[r]));A.value!==r&&(Fe(r),ne(r),!0!==n&&!0===e.useInput&&!0===e.fillInput&&Je(r>=0?Te.value(e.options[r]):D))}}function De(t,n){const r=e=>(0,E.xb)(ke.value(e),t);return e.options.find(r)||n.find(r)||t}function Me(e,t){const n=void 0!==e?e:t;return"function"===typeof n?n:e=>null!==e&&"object"===typeof e&&n in e?e[n]:e}function qe(e){const t=ke.value(e);return void 0!==Ie.value.find((e=>(0,E.xb)(e,t)))}function Ve(t){!0===e.useInput&&null!==j.value&&(void 0===t||j.value===t.target&&t.target.value===he.value)&&j.value.select()}function Ue(e){!0===(0,p.So)(e,27)&&!0===d.value&&((0,f.sT)(e),ct(),dt()),n("keyup",e)}function Be(t){const{value:n}=t.target;if(void 0===t.keyCode)if(t.target.value="",null!==U&&(clearTimeout(U),U=null),dt(),"string"===typeof n&&0!==n.length){const t=n.toLocaleLowerCase(),r=n=>{const r=e.options.find((e=>n.value(e).toLocaleLowerCase()===t));return void 0!==r&&(-1===oe.value.indexOf(r)?Pe(r):ct(),!0)},i=e=>{!0!==r(ke)&&!0!==r(Te)&&!0!==e&&Ye(n,!0,(()=>i(!0)))};i()}else ie.clearValue(t);else Ue(t)}function $e(e){n("keypress",e)}function je(t){if(n("keydown",t),!0===(0,p.Wm)(t))return;const i=0!==R.value.length&&(void 0!==e.newValueMode||void 0!==e.onNewValue),o=!0!==t.shiftKey&&!0!==e.multiple&&(A.value>-1||!0===i);if(27===t.keyCode)return void(0,f.X$)(t);if(9===t.keyCode&&!1===o)return void lt();if(void 0===t.target||t.target.id!==ie.targetUid.value)return;if(40===t.keyCode&&!0!==ie.innerLoading.value&&!1===d.value)return(0,f.NS)(t),void ut();if(8===t.keyCode&&!0!==e.hideSelected&&0===R.value.length)return void(!0===e.multiple&&!0===Array.isArray(e.modelValue)?Re(e.modelValue.length-1):!0!==e.multiple&&null!==e.modelValue&&n("update:modelValue",null));35!==t.keyCode&&36!==t.keyCode||"string"===typeof R.value&&0!==R.value.length||((0,f.NS)(t),A.value=-1,Le(36===t.keyCode?1:-1,e.multiple)),33!==t.keyCode&&34!==t.keyCode||void 0===Y.value||((0,f.NS)(t),A.value=Math.max(-1,Math.min(G.value,A.value+(33===t.keyCode?-1:1)*Y.value.view)),Le(33===t.keyCode?1:-1,e.multiple)),38!==t.keyCode&&40!==t.keyCode||((0,f.NS)(t),Le(38===t.keyCode?-1:1,e.multiple));const s=G.value;if((void 0===q||V<Date.now())&&(q=""),s>0&&!0!==e.useInput&&void 0!==t.key&&1===t.key.length&&!1===t.altKey&&!1===t.ctrlKey&&!1===t.metaKey&&(32!==t.keyCode||0!==q.length)){!0!==d.value&&ut(t);const n=t.key.toLocaleLowerCase(),i=1===q.length&&q[0]===n;V=Date.now()+1500,!1===i&&((0,f.NS)(t),q+=n);const o=new RegExp("^"+q.split("").map((e=>C.indexOf(e)>-1?"\\"+e:e)).join(".*"),"i");let a=A.value;if(!0===i||a<0||!0!==o.test(Te.value(e.options[a])))do{a=(0,k.Uz)(a+1,-1,s-1)}while(a!==A.value&&(!0===Ce.value(e.options[a])||!0!==o.test(Te.value(e.options[a]))));A.value!==a&&(0,r.Y3)((()=>{Fe(a),ne(a),a>=0&&!0===e.useInput&&!0===e.fillInput&&Je(Te.value(e.options[a]))}))}else if(13===t.keyCode||32===t.keyCode&&!0!==e.useInput&&""===q||9===t.keyCode&&!1!==o)if(9!==t.keyCode&&(0,f.NS)(t),A.value>-1&&A.value<s)Pe(e.options[A.value]);else{if(!0===i){const t=(t,n)=>{if(n){if(!0!==T(n))return}else n=e.newValueMode;if(void 0===t||null===t)return;Qe("",!0!==e.multiple,!0);const r="toggle"===n?Pe:Ne;r(t,"add-unique"===n),!0!==e.multiple&&(null!==j.value&&j.value.focus(),ct())};if(void 0!==e.onNewValue?n("newValue",R.value,t):t(R.value),!0!==e.multiple)return}!0===d.value?lt():!0!==ie.innerLoading.value&&ut()}}function ze(){return!0===F?K.value:null!==z.value&&null!==z.value.contentEl?z.value.contentEl:void 0}function He(){return ze()}function Ke(){return!0===e.hideSelected?[]:void 0!==t["selected-item"]?be.value.map((e=>t["selected-item"](e))).slice():void 0!==t.selected?[].concat(t.selected()):!0===e.useChips?be.value.map(((t,n)=>(0,r.h)(u.Z,{key:"option-"+n,removable:!0===ie.editable.value&&!0!==Ce.value(t.opt),dense:!0,textColor:e.color,tabindex:me.value,onRemove(){t.removeAtIndex(n)}},(()=>(0,r.h)("span",{class:"ellipsis",[!0===t.html?"innerHTML":"textContent"]:Te.value(t.opt)}))))):[(0,r.h)("span",{[!0===ge.value?"innerHTML":"textContent"]:fe.value})]}function We(){if(!0===de.value)return void 0!==t["no-option"]?t["no-option"]({inputValue:R.value}):void 0;const e=void 0!==t.option?t.option:e=>(0,r.h)(g,{key:e.index,...e.itemProps},(()=>(0,r.h)(m,(()=>(0,r.h)(v.Z,(()=>(0,r.h)("span",{[!0===e.html?"innerHTML":"textContent"]:e.label})))))));let n=ee("div",we.value.map(e));return void 0!==t["before-options"]&&(n=t["before-options"]().concat(n)),(0,h.vs)(t["after-options"],n)}function Ze(t,n){const i=!0===n?{...ve.value,...ie.splitAttrs.attributes.value}:void 0,o={ref:!0===n?j:void 0,key:"i_t",class:ue.value,style:e.inputStyle,value:void 0!==R.value?R.value:"",type:"search",...i,id:!0===n?ie.targetUid.value:void 0,maxlength:e.maxlength,autocomplete:e.autocomplete,"data-autofocus":!0===t||!0===e.autofocus||void 0,disabled:!0===e.disable,readonly:!0===e.readonly,...xe.value};return!0!==t&&!0===F&&(!0===Array.isArray(o.class)?o.class=[...o.class,"no-pointer-events"]:o.class+=" no-pointer-events"),(0,r.h)("input",o)}function Ge(t){null!==U&&(clearTimeout(U),U=null),t&&t.target&&!0===t.target.qComposing||(Je(t.target.value||""),L=!0,D=R.value,!0===ie.focused.value||!0===F&&!0!==O.value||ie.focus(),void 0!==e.onFilter&&(U=setTimeout((()=>{U=null,Ye(R.value)}),e.inputDebounce)))}function Je(e){R.value!==e&&(R.value=e,n("inputValue",e))}function Qe(t,n,r){L=!0!==r,!0===e.useInput&&(Je(t),!0!==n&&!0===r||(D=t),!0!==n&&Ye(t))}function Ye(t,i,o){if(void 0===e.onFilter||!0!==i&&!0!==ie.focused.value)return;!0===ie.innerLoading.value?n("filterAbort"):(ie.innerLoading.value=!0,N.value=!0),""!==t&&!0!==e.multiple&&0!==oe.value.length&&!0!==L&&t===Te.value(oe.value[0])&&(t="");const a=setTimeout((()=>{!0===d.value&&(d.value=!1)}),10);null!==B&&clearTimeout(B),B=a,n("filter",t,((e,t)=>{!0!==i&&!0!==ie.focused.value||B!==a||(clearTimeout(B),"function"===typeof e&&e(),N.value=!1,(0,r.Y3)((()=>{ie.innerLoading.value=!1,!0===ie.editable.value&&(!0===i?!0===d.value&&ct():!0===d.value?ht(!0):d.value=!0),"function"===typeof t&&(0,r.Y3)((()=>{t(s)})),"function"===typeof o&&(0,r.Y3)((()=>{o(s)}))})))}),(()=>{!0===ie.focused.value&&B===a&&(clearTimeout(B),ie.innerLoading.value=!1,N.value=!1),!0===d.value&&(d.value=!1)}))}function Xe(){return(0,r.h)(y.Z,{ref:z,class:ce.value,style:e.popupContentStyle,modelValue:d.value,fit:!0!==e.menuShrink,cover:!0===e.optionsCover&&!0!==de.value&&!0!==e.useInput,anchor:e.menuAnchor,self:e.menuSelf,offset:e.menuOffset,dark:ae.value,noParentEvent:!0,noRefocus:!0,noFocus:!0,square:Se.value,transitionShow:e.transitionShow,transitionHide:e.transitionHide,transitionDuration:e.transitionDuration,separateClosePopup:!0,...ye.value,onScrollPassive:te,onBeforeShow:gt,onBeforeHide:et,onShow:tt},We)}function et(e){mt(e),lt()}function tt(){re()}function nt(e){(0,f.sT)(e),null!==j.value&&j.value.focus(),O.value=!0,window.scrollTo(window.pageXOffset||window.scrollX||document.body.scrollLeft||0,0)}function rt(e){(0,f.sT)(e),(0,r.Y3)((()=>{O.value=!1}))}function it(){const n=[(0,r.h)(a,{class:`col-auto ${ie.fieldClass.value}`,...se.value,for:ie.targetUid.value,dark:ae.value,square:!0,loading:N.value,itemAligned:!1,filled:!0,stackLabel:0!==R.value.length,...ie.splitAttrs.listeners.value,onFocus:nt,onBlur:rt},{...t,rawControl:()=>ie.getControl(!0),before:void 0,after:void 0})];return!0===d.value&&n.push((0,r.h)("div",{ref:K,class:ce.value+" scroll",style:e.popupContentStyle,...ye.value,onClick:f.X$,onScrollPassive:te},We())),(0,r.h)(b.Z,{ref:H,modelValue:x.value,position:!0===e.useInput?"top":void 0,transitionShow:M,transitionHide:e.transitionHide,transitionDuration:e.transitionDuration,onBeforeShow:gt,onBeforeHide:ot,onHide:st,onShow:at},(()=>(0,r.h)("div",{class:"q-select__dialog"+(!0===ae.value?" q-select__dialog--dark q-dark":"")+(!0===O.value?" q-select__dialog--focused":"")},n)))}function ot(e){mt(e),null!==H.value&&H.value.__updateRefocusTarget(ie.rootRef.value.querySelector(".q-field__native > [tabindex]:last-child")),ie.focused.value=!1}function st(e){ct(),!1===ie.focused.value&&n("blur",e),dt()}function at(){const e=document.activeElement;null!==e&&e.id===ie.targetUid.value||null===j.value||j.value===e||j.value.focus(),re()}function lt(){!0!==x.value&&(A.value=-1,!0===d.value&&(d.value=!1),!1===ie.focused.value&&(null!==B&&(clearTimeout(B),B=null),!0===ie.innerLoading.value&&(n("filterAbort"),ie.innerLoading.value=!1,N.value=!1)))}function ut(n){!0===ie.editable.value&&(!0===F?(ie.onControlFocusin(n),x.value=!0,(0,r.Y3)((()=>{ie.focus()}))):ie.focus(),void 0!==e.onFilter?Ye(R.value):!0===de.value&&void 0===t["no-option"]||(d.value=!0))}function ct(){x.value=!1,lt()}function dt(){!0===e.useInput&&Qe(!0!==e.multiple&&!0===e.fillInput&&0!==oe.value.length&&Te.value(oe.value[0])||"",!0,!0)}function ht(t){let n=-1;if(!0===t){if(0!==oe.value.length){const t=ke.value(oe.value[0]);n=e.options.findIndex((e=>(0,E.xb)(ke.value(e),t)))}X(n)}Fe(n)}function ft(e,t){!0===d.value&&!1===ie.innerLoading.value&&(X(-1,!0),(0,r.Y3)((()=>{!0===d.value&&!1===ie.innerLoading.value&&(e>t?X():ht(!0))})))}function pt(){!1===x.value&&null!==z.value&&z.value.updatePosition()}function gt(e){void 0!==e&&(0,f.sT)(e),n("popupShow",e),ie.hasPopupOpen=!0,ie.onControlFocusin(e)}function mt(e){void 0!==e&&(0,f.sT)(e),n("popupHide",e),ie.hasPopupOpen=!1,ie.onControlFocusout(e)}function vt(){F=(!0===c.platform.is.mobile||"dialog"===e.behavior)&&("menu"!==e.behavior&&(!0!==e.useInput||(void 0!==t["no-option"]||void 0!==e.onFilter||!1===de.value))),M=!0===c.platform.is.ios&&!0===F&&!0===e.useInput?"fade":e.transitionShow}return(0,r.YP)(oe,(t=>{P=t,!0===e.useInput&&!0===e.fillInput&&!0!==e.multiple&&!0!==ie.innerLoading.value&&(!0!==x.value&&!0!==d.value||!0!==le.value)&&(!0!==L&&dt(),!0!==x.value&&!0!==d.value||Ye(""))}),{immediate:!0}),(0,r.YP)((()=>e.fillInput),dt),(0,r.YP)(d,ht),(0,r.YP)(G,ft),(0,r.Xn)(vt),(0,r.ic)(pt),vt(),(0,r.Jd)((()=>{null!==U&&clearTimeout(U)})),Object.assign(s,{showPopup:ut,hidePopup:ct,removeAtIndex:Re,add:Ne,toggleOption:Pe,getOptionIndex:()=>A.value,setOptionIndex:Fe,moveOptionSelection:Le,filter:Ye,updateMenuPosition:pt,updateInputValue:Qe,isOptionSelected:qe,getEmittingOptionValue:Ae,isOptionDisabled:(...e)=>!0===Ce.value.apply(null,e),getOptionValue:(...e)=>ke.value.apply(null,e),getOptionLabel:(...e)=>Te.value.apply(null,e)}),Object.assign(ie,{innerValue:oe,fieldClass:(0,r.Fl)((()=>`q-select q-field--auto-height q-select--with${!0!==e.useInput?"out":""}-input q-select--with${!0!==e.useChips?"out":""}-chips q-select--`+(!0===e.multiple?"multiple":"single"))),inputRef:$,targetRef:j,hasValue:le,showPopup:ut,floatingLabel:(0,r.Fl)((()=>!0!==e.hideSelected&&!0===le.value||"number"===typeof R.value||0!==R.value.length||(0,o.yV)(e.displayValue))),getControlChild:()=>{if(!1!==ie.editable.value&&(!0===x.value||!0!==de.value||void 0!==t["no-option"]))return!0===F?it():Xe();!0===ie.hasPopupOpen&&(ie.hasPopupOpen=!1)},controlEvents:{onFocusin(e){ie.onControlFocusin(e)},onFocusout(e){ie.onControlFocusout(e,(()=>{dt(),lt()}))},onClick(e){if((0,f.X$)(e),!0!==F&&!0===d.value)return lt(),void(null!==j.value&&j.value.focus());ut(e)}},getControl:t=>{const n=Ke(),i=!0===t||!0!==x.value||!0!==F;if(!0===e.useInput)n.push(Ze(t,i));else if(!0===ie.editable.value){const o=!0===i?ve.value:void 0;n.push((0,r.h)("input",{ref:!0===i?j:void 0,key:"d_t",class:"q-select__focus-target",id:!0===i?ie.targetUid.value:void 0,value:fe.value,readonly:!0,"data-autofocus":!0===t||!0===e.autofocus||void 0,...o,onKeydown:je,onKeyup:Ue,onKeypress:$e})),!0===i&&"string"===typeof e.autocomplete&&0!==e.autocomplete.length&&n.push((0,r.h)("input",{class:"q-select__autocomplete-input",autocomplete:e.autocomplete,tabindex:-1,onKeyup:Be}))}if(void 0!==W.value&&!0!==e.disable&&0!==Ie.value.length){const t=Ie.value.map((e=>(0,r.h)("option",{value:e,selected:!0})));n.push((0,r.h)("select",{class:"hidden",name:W.value,multiple:e.multiple},t))}const o=!0===e.useInput||!0!==i?void 0:ie.splitAttrs.attributes.value;return(0,r.h)("div",{class:"q-field__native row items-center",...o,...ie.splitAttrs.listeners.value},n)},getInnerAppend:()=>!0!==e.loading&&!0!==N.value&&!0!==e.hideDropdownIcon?[(0,r.h)(l.Z,{class:"q-select__dropdown-icon"+(!0===d.value?" rotate-180":""),name:_e.value})]:null}),(0,o.ZP)(ie)}})},926:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l});var r=n(9835),i=n(8234),o=n(5987);const s={true:"inset",item:"item-inset","item-thumbnail":"item-thumbnail-inset"},a={xs:2,sm:4,md:8,lg:16,xl:24},l=(0,o.L)({name:"QSeparator",props:{...i.S,spaced:[Boolean,String],inset:[Boolean,String],vertical:Boolean,color:String,size:String},setup(e){const t=(0,r.FN)(),n=(0,i.Z)(e,t.proxy.$q),o=(0,r.Fl)((()=>!0===e.vertical?"vertical":"horizontal")),l=(0,r.Fl)((()=>` q-separator--${o.value}`)),u=(0,r.Fl)((()=>!1!==e.inset?`${l.value}-${s[e.inset]}`:"")),c=(0,r.Fl)((()=>`q-separator${l.value}${u.value}`+(void 0!==e.color?` bg-${e.color}`:"")+(!0===n.value?" q-separator--dark":""))),d=(0,r.Fl)((()=>{const t={};if(void 0!==e.size&&(t[!0===e.vertical?"width":"height"]=e.size),!1!==e.spaced){const n=!0===e.spaced?`${a.md}px`:e.spaced in a?`${a[e.spaced]}px`:e.spaced,r=!0===e.vertical?["Left","Right"]:["Top","Bottom"];t[`margin${r[0]}`]=t[`margin${r[1]}`]=n}return t}));return()=>(0,r.h)("hr",{class:c.value,style:d.value,"aria-orientation":o.value})}})},136:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(9835),i=n(5987);const o=(0,r.h)("div",{class:"q-space"}),s=(0,i.L)({name:"QSpace",setup(){return()=>o}})},3940:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l});var r=n(9835),i=n(244);const o={size:{type:[Number,String],default:"1em"},color:String};function s(e){return{cSize:(0,r.Fl)((()=>e.size in i.Ok?`${i.Ok[e.size]}px`:e.size)),classes:(0,r.Fl)((()=>"q-spinner"+(e.color?` text-${e.color}`:"")))}}var a=n(5987);const l=(0,a.L)({name:"QSpinner",props:{...o,thickness:{type:Number,default:5}},setup(e){const{cSize:t,classes:n}=s(e);return()=>(0,r.h)("svg",{class:n.value+" q-spinner-mat",width:t.value,height:t.value,viewBox:"25 25 50 50"},[(0,r.h)("circle",{class:"path",cx:"50",cy:"50",r:"20",fill:"none",stroke:"currentColor","stroke-width":e.thickness,"stroke-miterlimit":"10"})])}})},1906:(e,t,n)=>{"use strict";n.d(t,{Z:()=>ee});n(6890),n(9665);var r=n(9835),i=n(499),o=n(2857),s=n(5987),a=n(2026);const l=(0,s.L)({name:"QTh",props:{props:Object,autoWidth:Boolean},emits:["click"],setup(e,{slots:t,emit:n}){const i=(0,r.FN)(),{proxy:{$q:s}}=i,l=e=>{n("click",e)};return()=>{if(void 0===e.props)return(0,r.h)("th",{class:!0===e.autoWidth?"q-table--col-auto-width":"",onClick:l},(0,a.KR)(t.default));let n,u;const c=i.vnode.key;if(c){if(n=e.props.colsMap[c],void 0===n)return}else n=e.props.col;if(!0===n.sortable){const e="right"===n.align?"unshift":"push";u=(0,a.Bl)(t.default,[]),u[e]((0,r.h)(o.Z,{class:n.__iconClass,name:s.iconSet.table.arrowUp}))}else u=(0,a.KR)(t.default);const d={class:n.__thClass+(!0===e.autoWidth?" q-table--col-auto-width":""),style:n.headerStyle,onClick:t=>{!0===n.sortable&&e.props.sort(n),l(t)}};return(0,r.h)("th",d,u)}}});var u=n(926),c=n(8234);const d=(0,s.L)({name:"QList",props:{...c.S,bordered:Boolean,dense:Boolean,separator:Boolean,padding:Boolean,tag:{type:String,default:"div"}},setup(e,{slots:t}){const n=(0,r.FN)(),i=(0,c.Z)(e,n.proxy.$q),o=(0,r.Fl)((()=>"q-list"+(!0===e.bordered?" q-list--bordered":"")+(!0===e.dense?" q-list--dense":"")+(!0===e.separator?" q-list--separator":"")+(!0===i.value?" q-list--dark":"")+(!0===e.padding?" q-list--padding":"")));return()=>(0,r.h)(e.tag,{class:o.value},(0,a.KR)(t.default))}}),h=["horizontal","vertical","cell","none"],f=(0,s.L)({name:"QMarkupTable",props:{...c.S,dense:Boolean,flat:Boolean,bordered:Boolean,square:Boolean,wrapCells:Boolean,separator:{type:String,default:"horizontal",validator:e=>h.includes(e)}},setup(e,{slots:t}){const n=(0,r.FN)(),i=(0,c.Z)(e,n.proxy.$q),o=(0,r.Fl)((()=>`q-markup-table q-table__container q-table__card q-table--${e.separator}-separator`+(!0===i.value?" q-table--dark q-table__card--dark q-dark":"")+(!0===e.dense?" q-table--dense":"")+(!0===e.flat?" q-table--flat":"")+(!0===e.bordered?" q-table--bordered":"")+(!0===e.square?" q-table--square":"")+(!1===e.wrapCells?" q-table--no-wrap":"")));return()=>(0,r.h)("div",{class:o.value},[(0,r.h)("table",{class:"q-table"},(0,a.KR)(t.default))])}});function p(e,t){return(0,r.h)("div",e,[(0,r.h)("table",{class:"q-table"},t)])}var g=n(2380),m=n(3701),v=n(1384);const y={list:d,table:f},b=["list","table","__qtable"],w=(0,s.L)({name:"QVirtualScroll",props:{...g.t9,type:{type:String,default:"list",validator:e=>b.includes(e)},items:{type:Array,default:()=>[]},itemsFn:Function,itemsSize:Number,scrollTarget:{default:void 0}},setup(e,{slots:t,attrs:n}){let o;const s=(0,i.iH)(null),l=(0,r.Fl)((()=>e.itemsSize>=0&&void 0!==e.itemsFn?parseInt(e.itemsSize,10):Array.isArray(e.items)?e.items.length:0)),{virtualScrollSliceRange:u,localResetVirtualScroll:c,padVirtualScroll:d,onVirtualScrollEvt:h}=(0,g.vp)({virtualScrollLength:l,getVirtualScrollTarget:S,getVirtualScrollEl:_}),f=(0,r.Fl)((()=>{if(0===l.value)return[];const t=(e,t)=>({index:u.value.from+t,item:e});return void 0===e.itemsFn?e.items.slice(u.value.from,u.value.to).map(t):e.itemsFn(u.value.from,u.value.to-u.value.from).map(t)})),b=(0,r.Fl)((()=>"q-virtual-scroll q-virtual-scroll"+(!0===e.virtualScrollHorizontal?"--horizontal":"--vertical")+(void 0!==e.scrollTarget?"":" scroll"))),w=(0,r.Fl)((()=>void 0!==e.scrollTarget?{}:{tabindex:0}));function _(){return s.value.$el||s.value}function S(){return o}function E(){o=(0,m.b0)(_(),e.scrollTarget),o.addEventListener("scroll",h,v.listenOpts.passive)}function k(){void 0!==o&&(o.removeEventListener("scroll",h,v.listenOpts.passive),o=void 0)}function T(){let n=d("list"===e.type?"div":"tbody",f.value.map(t.default));return void 0!==t.before&&(n=t.before().concat(n)),(0,a.vs)(t.after,n)}return(0,r.YP)(l,(()=>{c()})),(0,r.YP)((()=>e.scrollTarget),(()=>{k(),E()})),(0,r.wF)((()=>{c()})),(0,r.bv)((()=>{E()})),(0,r.dl)((()=>{E()})),(0,r.se)((()=>{k()})),(0,r.Jd)((()=>{k()})),()=>{if(void 0!==t.default)return"__qtable"===e.type?p({ref:s,class:"q-table__middle "+b.value},T()):(0,r.h)(y[e.type],{...n,ref:s,class:[n.class,b.value],...w.value},T);console.error("QVirtualScroll: default scoped slot is required for rendering")}}});var _=n(1290),S=n(244);const E={xs:2,sm:4,md:6,lg:10,xl:14};function k(e,t,n){return{transform:!0===t?`translateX(${!0===n.lang.rtl?"-":""}100%) scale3d(${-e},1,1)`:`scale3d(${e},1,1)`}}const T=(0,s.L)({name:"QLinearProgress",props:{...c.S,...S.LU,value:{type:Number,default:0},buffer:Number,color:String,trackColor:String,reverse:Boolean,stripe:Boolean,indeterminate:Boolean,query:Boolean,rounded:Boolean,animationSpeed:{type:[String,Number],default:2100},instantFeedback:Boolean},setup(e,{slots:t}){const{proxy:n}=(0,r.FN)(),i=(0,c.Z)(e,n.$q),o=(0,S.ZP)(e,E),s=(0,r.Fl)((()=>!0===e.indeterminate||!0===e.query)),l=(0,r.Fl)((()=>e.reverse!==e.query)),u=(0,r.Fl)((()=>({...null!==o.value?o.value:{},"--q-linear-progress-speed":`${e.animationSpeed}ms`}))),d=(0,r.Fl)((()=>"q-linear-progress"+(void 0!==e.color?` text-${e.color}`:"")+(!0===e.reverse||!0===e.query?" q-linear-progress--reverse":"")+(!0===e.rounded?" rounded-borders":""))),h=(0,r.Fl)((()=>k(void 0!==e.buffer?e.buffer:1,l.value,n.$q))),f=(0,r.Fl)((()=>`with${!0===e.instantFeedback?"out":""}-transition`)),p=(0,r.Fl)((()=>`q-linear-progress__track absolute-full q-linear-progress__track--${f.value} q-linear-progress__track--`+(!0===i.value?"dark":"light")+(void 0!==e.trackColor?` bg-${e.trackColor}`:""))),g=(0,r.Fl)((()=>k(!0===s.value?1:e.value,l.value,n.$q))),m=(0,r.Fl)((()=>`q-linear-progress__model absolute-full q-linear-progress__model--${f.value} q-linear-progress__model--${!0===s.value?"in":""}determinate`)),v=(0,r.Fl)((()=>({width:100*e.value+"%"}))),y=(0,r.Fl)((()=>"q-linear-progress__stripe absolute-"+(!0===e.reverse?"right":"left")+` q-linear-progress__stripe--${f.value}`));return()=>{const n=[(0,r.h)("div",{class:p.value,style:h.value}),(0,r.h)("div",{class:m.value,style:g.value})];return!0===e.stripe&&!1===s.value&&n.push((0,r.h)("div",{class:y.value,style:v.value})),(0,r.h)("div",{class:d.value,style:u.value,role:"progressbar","aria-valuemin":0,"aria-valuemax":1,"aria-valuenow":!0===e.indeterminate?void 0:e.value},(0,a.vs)(t.default,n))}}});var C=n(5413);const I=(0,r.h)("div",{key:"svg",class:"q-checkbox__bg absolute"},[(0,r.h)("svg",{class:"q-checkbox__svg fit absolute-full",viewBox:"0 0 24 24"},[(0,r.h)("path",{class:"q-checkbox__truthy",fill:"none",d:"M1.73,12.91 8.1,19.28 22.79,4.59"}),(0,r.h)("path",{class:"q-checkbox__indet",d:"M4,14H20V10H4"})])]),x=(0,s.L)({name:"QCheckbox",props:C.Fz,emits:C.ZB,setup(e){function t(t,n){const i=(0,r.Fl)((()=>(!0===t.value?e.checkedIcon:!0===n.value?e.indeterminateIcon:e.uncheckedIcon)||null));return()=>null!==i.value?[(0,r.h)("div",{key:"icon",class:"q-checkbox__icon-container absolute-full flex flex-center no-wrap"},[(0,r.h)(o.Z,{class:"q-checkbox__icon",name:i.value})])]:[I]}return(0,C.ZP)("checkbox",t)}});var A=n(8879),R=n(3929);function O(e,t){return new Date(e)-new Date(t)}var N=n(4680);const P={sortMethod:Function,binaryStateSort:Boolean,columnSortOrder:{type:String,validator:e=>"ad"===e||"da"===e,default:"ad"}};function F(e,t,n,i){const o=(0,r.Fl)((()=>{const{sortBy:e}=t.value;return e&&n.value.find((t=>t.name===e))||null})),s=(0,r.Fl)((()=>void 0!==e.sortMethod?e.sortMethod:(e,t,r)=>{const i=n.value.find((e=>e.name===t));if(void 0===i||void 0===i.field)return e;const o=!0===r?-1:1,s="function"===typeof i.field?e=>i.field(e):e=>e[i.field];return e.sort(((e,t)=>{let n=s(e),r=s(t);return null===n||void 0===n?-1*o:null===r||void 0===r?1*o:void 0!==i.sort?i.sort(n,r,e,t)*o:!0===(0,N.hj)(n)&&!0===(0,N.hj)(r)?(n-r)*o:!0===(0,N.J_)(n)&&!0===(0,N.J_)(r)?O(n,r)*o:"boolean"===typeof n&&"boolean"===typeof r?(n-r)*o:([n,r]=[n,r].map((e=>(e+"").toLocaleString().toLowerCase())),n<r?-1*o:n===r?0:o)}))}));function a(r){let o=e.columnSortOrder;if(!0===(0,N.Kn)(r))r.sortOrder&&(o=r.sortOrder),r=r.name;else{const e=n.value.find((e=>e.name===r));void 0!==e&&e.sortOrder&&(o=e.sortOrder)}let{sortBy:s,descending:a}=t.value;s!==r?(s=r,a="da"===o):!0===e.binaryStateSort?a=!a:!0===a?"ad"===o?s=null:a=!1:"ad"===o?a=!0:s=null,i({sortBy:s,descending:a,page:1})}return{columnToSort:o,computedSortMethod:s,sort:a}}const L={filter:[String,Object],filterMethod:Function};function D(e,t){const n=(0,r.Fl)((()=>void 0!==e.filterMethod?e.filterMethod:(e,t,n,r)=>{const i=t?t.toLowerCase():"";return e.filter((e=>n.some((t=>{const n=r(t,e)+"",o="undefined"===n||"null"===n?"":n.toLowerCase();return-1!==o.indexOf(i)}))))}));return(0,r.YP)((()=>e.filter),(()=>{(0,r.Y3)((()=>{t({page:1},!0)}))}),{deep:!0}),{computedFilterMethod:n}}function M(e,t){for(const n in t)if(t[n]!==e[n])return!1;return!0}function q(e){return e.page<1&&(e.page=1),void 0!==e.rowsPerPage&&e.rowsPerPage<1&&(e.rowsPerPage=0),e}const V={pagination:Object,rowsPerPageOptions:{type:Array,default:()=>[5,7,10,15,20,25,50,0]},"onUpdate:pagination":[Function,Array]};function U(e,t){const{props:n,emit:o}=e,s=(0,i.iH)(Object.assign({sortBy:null,descending:!1,page:1,rowsPerPage:0!==n.rowsPerPageOptions.length?n.rowsPerPageOptions[0]:5},n.pagination)),a=(0,r.Fl)((()=>{const e=void 0!==n["onUpdate:pagination"]?{...s.value,...n.pagination}:s.value;return q(e)})),l=(0,r.Fl)((()=>void 0!==a.value.rowsNumber));function u(e){c({pagination:e,filter:n.filter})}function c(e={}){(0,r.Y3)((()=>{o("request",{pagination:e.pagination||a.value,filter:e.filter||n.filter,getCellValue:t})}))}function d(e,t){const r=q({...a.value,...e});!0!==M(a.value,r)?!0!==l.value?void 0!==n.pagination&&void 0!==n["onUpdate:pagination"]?o("update:pagination",r):s.value=r:u(r):!0===l.value&&!0===t&&u(r)}return{innerPagination:s,computedPagination:a,isServerSide:l,requestServerInteraction:c,setPagination:d}}function B(e,t,n,i,o,s){const{props:a,emit:l,proxy:{$q:u}}=e,c=(0,r.Fl)((()=>!0===i.value?n.value.rowsNumber||0:s.value)),d=(0,r.Fl)((()=>{const{page:e,rowsPerPage:t}=n.value;return(e-1)*t})),h=(0,r.Fl)((()=>{const{page:e,rowsPerPage:t}=n.value;return e*t})),f=(0,r.Fl)((()=>1===n.value.page)),p=(0,r.Fl)((()=>0===n.value.rowsPerPage?1:Math.max(1,Math.ceil(c.value/n.value.rowsPerPage)))),g=(0,r.Fl)((()=>0===h.value||n.value.page>=p.value)),m=(0,r.Fl)((()=>{const e=a.rowsPerPageOptions.includes(t.value.rowsPerPage)?a.rowsPerPageOptions:[t.value.rowsPerPage].concat(a.rowsPerPageOptions);return e.map((e=>({label:0===e?u.lang.table.allRows:""+e,value:e})))}));function v(){o({page:1})}function y(){const{page:e}=n.value;e>1&&o({page:e-1})}function b(){const{page:e,rowsPerPage:t}=n.value;h.value>0&&e*t<c.value&&o({page:e+1})}function w(){o({page:p.value})}return(0,r.YP)(p,((e,t)=>{if(e===t)return;const r=n.value.page;e&&!r?o({page:1}):e<r&&o({page:e})})),void 0!==a["onUpdate:pagination"]&&l("update:pagination",{...n.value}),{firstRowIndex:d,lastRowIndex:h,isFirstPage:f,isLastPage:g,pagesNumber:p,computedRowsPerPageOptions:m,computedRowsNumber:c,firstPage:v,prevPage:y,nextPage:b,lastPage:w}}const $={selection:{type:String,default:"none",validator:e=>["single","multiple","none"].includes(e)},selected:{type:Array,default:()=>[]}},j=["update:selected","selection"];function z(e,t,n,i){const o=(0,r.Fl)((()=>{const t={};return e.selected.map(i.value).forEach((e=>{t[e]=!0})),t})),s=(0,r.Fl)((()=>"none"!==e.selection)),a=(0,r.Fl)((()=>"single"===e.selection)),l=(0,r.Fl)((()=>"multiple"===e.selection)),u=(0,r.Fl)((()=>0!==n.value.length&&n.value.every((e=>!0===o.value[i.value(e)])))),c=(0,r.Fl)((()=>!0!==u.value&&n.value.some((e=>!0===o.value[i.value(e)])))),d=(0,r.Fl)((()=>e.selected.length));function h(e){return!0===o.value[e]}function f(){t("update:selected",[])}function p(n,r,o,s){t("selection",{rows:r,added:o,keys:n,evt:s});const l=!0===a.value?!0===o?r:[]:!0===o?e.selected.concat(r):e.selected.filter((e=>!1===n.includes(i.value(e))));t("update:selected",l)}return{hasSelectionMode:s,singleSelection:a,multipleSelection:l,allRowsSelected:u,someRowsSelected:c,rowsSelectedNumber:d,isRowSelected:h,clearSelection:f,updateSelection:p}}function H(e){return Array.isArray(e)?e.slice():[]}const K={expanded:Array},W=["update:expanded"];function Z(e,t){const n=(0,i.iH)(H(e.expanded));function o(e){return n.value.includes(e)}function s(r){void 0!==e.expanded?t("update:expanded",r):n.value=r}function a(e,t){const r=n.value.slice(),i=r.indexOf(e);!0===t?-1===i&&(r.push(e),s(r)):-1!==i&&(r.splice(i,1),s(r))}return(0,r.YP)((()=>e.expanded),(e=>{n.value=H(e)})),{isRowExpanded:o,setExpanded:s,updateExpanded:a}}const G={visibleColumns:Array};function J(e,t,n){const i=(0,r.Fl)((()=>{if(void 0!==e.columns)return e.columns;const t=e.rows[0];return void 0!==t?Object.keys(t).map((e=>({name:e,label:e.toUpperCase(),field:e,align:(0,N.hj)(t[e])?"right":"left",sortable:!0}))):[]})),o=(0,r.Fl)((()=>{const{sortBy:n,descending:r}=t.value,o=void 0!==e.visibleColumns?i.value.filter((t=>!0===t.required||!0===e.visibleColumns.includes(t.name))):i.value;return o.map((e=>{const t=e.align||"right",i=`text-${t}`;return{...e,align:t,__iconClass:`q-table__sort-icon q-table__sort-icon--${t}`,__thClass:i+(void 0!==e.headerClasses?" "+e.headerClasses:"")+(!0===e.sortable?" sortable":"")+(e.name===n?" sorted "+(!0===r?"sort-desc":""):""),__tdStyle:void 0!==e.style?"function"!==typeof e.style?()=>e.style:e.style:()=>null,__tdClass:void 0!==e.classes?"function"!==typeof e.classes?()=>i+" "+e.classes:t=>i+" "+e.classes(t):()=>i}}))})),s=(0,r.Fl)((()=>{const e={};return o.value.forEach((t=>{e[t.name]=t})),e})),a=(0,r.Fl)((()=>void 0!==e.tableColspan?e.tableColspan:o.value.length+(!0===n.value?1:0)));return{colList:i,computedCols:o,computedColsMap:s,computedColspan:a}}var Q=n(3251);const Y="q-table__bottom row items-center",X={};g.If.forEach((e=>{X[e]={}}));const ee=(0,s.L)({name:"QTable",props:{rows:{type:Array,default:()=>[]},rowKey:{type:[String,Function],default:"id"},columns:Array,loading:Boolean,iconFirstPage:String,iconPrevPage:String,iconNextPage:String,iconLastPage:String,title:String,hideHeader:Boolean,grid:Boolean,gridHeader:Boolean,dense:Boolean,flat:Boolean,bordered:Boolean,square:Boolean,separator:{type:String,default:"horizontal",validator:e=>["horizontal","vertical","cell","none"].includes(e)},wrapCells:Boolean,virtualScroll:Boolean,virtualScrollTarget:{default:void 0},...X,noDataLabel:String,noResultsLabel:String,loadingLabel:String,selectedRowsLabel:Function,rowsPerPageLabel:String,paginationLabel:Function,color:{type:String,default:"grey-8"},titleClass:[String,Array,Object],tableStyle:[String,Array,Object],tableClass:[String,Array,Object],tableHeaderStyle:[String,Array,Object],tableHeaderClass:[String,Array,Object],cardContainerClass:[String,Array,Object],cardContainerStyle:[String,Array,Object],cardStyle:[String,Array,Object],cardClass:[String,Array,Object],hideBottom:Boolean,hideSelectedBanner:Boolean,hideNoData:Boolean,hidePagination:Boolean,onRowClick:Function,onRowDblclick:Function,onRowContextmenu:Function,...c.S,...R.kM,...G,...L,...V,...K,...$,...P},emits:["request","virtualScroll",...R.fL,...W,...j],setup(e,{slots:t,emit:n}){const s=(0,r.FN)(),{proxy:{$q:a}}=s,d=(0,c.Z)(e,a),{inFullscreen:h,toggleFullscreen:f}=(0,R.ZP)(),m=(0,r.Fl)((()=>"function"===typeof e.rowKey?e.rowKey:t=>t[e.rowKey])),v=(0,i.iH)(null),y=(0,i.iH)(null),b=(0,r.Fl)((()=>!0!==e.grid&&!0===e.virtualScroll)),S=(0,r.Fl)((()=>" q-table__card"+(!0===d.value?" q-table__card--dark q-dark":"")+(!0===e.square?" q-table--square":"")+(!0===e.flat?" q-table--flat":"")+(!0===e.bordered?" q-table--bordered":""))),E=(0,r.Fl)((()=>`q-table__container q-table--${e.separator}-separator column no-wrap`+(!0===e.grid?" q-table--grid":S.value)+(!0===d.value?" q-table--dark":"")+(!0===e.dense?" q-table--dense":"")+(!1===e.wrapCells?" q-table--no-wrap":"")+(!0===h.value?" fullscreen scroll":""))),k=(0,r.Fl)((()=>E.value+(!0===e.loading?" q-table--loading":"")));(0,r.YP)((()=>e.tableStyle+e.tableClass+e.tableHeaderStyle+e.tableHeaderClass+E.value),(()=>{!0===b.value&&null!==y.value&&y.value.reset()}));const{innerPagination:C,computedPagination:I,isServerSide:O,requestServerInteraction:N,setPagination:P}=U(s,De),{computedFilterMethod:L}=D(e,P),{isRowExpanded:M,setExpanded:q,updateExpanded:V}=Z(e,n),$=(0,r.Fl)((()=>{let t=e.rows;if(!0===O.value||0===t.length)return t;const{sortBy:n,descending:r}=I.value;return e.filter&&(t=L.value(t,e.filter,se.value,De)),null!==ue.value&&(t=ce.value(e.rows===t?t.slice():t,n,r)),t})),j=(0,r.Fl)((()=>$.value.length)),H=(0,r.Fl)((()=>{let t=$.value;if(!0===O.value)return t;const{rowsPerPage:n}=I.value;return 0!==n&&(0===he.value&&e.rows!==t?t.length>fe.value&&(t=t.slice(0,fe.value)):t=t.slice(he.value,fe.value)),t})),{hasSelectionMode:K,singleSelection:W,multipleSelection:G,allRowsSelected:X,someRowsSelected:ee,rowsSelectedNumber:te,isRowSelected:ne,clearSelection:re,updateSelection:ie}=z(e,n,H,m),{colList:oe,computedCols:se,computedColsMap:ae,computedColspan:le}=J(e,I,K),{columnToSort:ue,computedSortMethod:ce,sort:de}=F(e,I,oe,P),{firstRowIndex:he,lastRowIndex:fe,isFirstPage:pe,isLastPage:ge,pagesNumber:me,computedRowsPerPageOptions:ve,computedRowsNumber:ye,firstPage:be,prevPage:we,nextPage:_e,lastPage:Se}=B(s,C,I,O,P,j),Ee=(0,r.Fl)((()=>0===H.value.length)),ke=(0,r.Fl)((()=>{const t={};return g.If.forEach((n=>{t[n]=e[n]})),void 0===t.virtualScrollItemSize&&(t.virtualScrollItemSize=!0===e.dense?28:48),t}));function Te(){!0===b.value&&y.value.reset()}function Ce(){if(!0===e.grid)return Ge();const n=!0!==e.hideHeader?Ue:null;if(!0===b.value){const i=t["top-row"],o=t["bottom-row"],s={default:e=>Re(e.item,t.body,e.index)};if(void 0!==i){const e=(0,r.h)("tbody",i({cols:se.value}));s.before=null===n?()=>e:()=>[n()].concat(e)}else null!==n&&(s.before=n);return void 0!==o&&(s.after=()=>(0,r.h)("tbody",o({cols:se.value}))),(0,r.h)(w,{ref:y,class:e.tableClass,style:e.tableStyle,...ke.value,scrollTarget:e.virtualScrollTarget,items:H.value,type:"__qtable",tableColspan:le.value,onVirtualScroll:xe},s)}const i=[Oe()];return null!==n&&i.unshift(n()),p({class:["q-table__middle scroll",e.tableClass],style:e.tableStyle},i)}function Ie(t,r){if(null!==y.value)return void y.value.scrollTo(t,r);t=parseInt(t,10);const i=v.value.querySelector(`tbody tr:nth-of-type(${t+1})`);if(null!==i){const r=v.value.querySelector(".q-table__middle.scroll"),o=i.offsetTop-e.virtualScrollStickySizeStart,s=o<r.scrollTop?"decrease":"increase";r.scrollTop=o,n("virtualScroll",{index:t,from:0,to:C.value.rowsPerPage-1,direction:s})}}function xe(e){n("virtualScroll",e)}function Ae(){return[(0,r.h)(T,{class:"q-table__linear-progress",color:e.color,dark:d.value,indeterminate:!0,trackColor:"transparent"})]}function Re(i,o,s){const a=m.value(i),l=ne(a);if(void 0!==o)return o(Ne({key:a,row:i,pageIndex:s,__trClass:l?"selected":""}));const u=t["body-cell"],c=se.value.map((e=>{const n=t[`body-cell-${e.name}`],o=void 0!==n?n:u;return void 0!==o?o(Pe({key:a,row:i,pageIndex:s,col:e})):(0,r.h)("td",{class:e.__tdClass(i),style:e.__tdStyle(i)},De(e,i))}));if(!0===K.value){const n=t["body-selection"],o=void 0!==n?n(Fe({key:a,row:i,pageIndex:s})):[(0,r.h)(x,{modelValue:l,color:e.color,dark:d.value,dense:e.dense,"onUpdate:modelValue":(e,t)=>{ie([a],[i],e,t)}})];c.unshift((0,r.h)("td",{class:"q-table--col-auto-width"},o))}const h={key:a,class:{selected:l}};return void 0!==e.onRowClick&&(h.class["cursor-pointer"]=!0,h.onClick=e=>{n("RowClick",e,i,s)}),void 0!==e.onRowDblclick&&(h.class["cursor-pointer"]=!0,h.onDblclick=e=>{n("RowDblclick",e,i,s)}),void 0!==e.onRowContextmenu&&(h.class["cursor-pointer"]=!0,h.onContextmenu=e=>{n("RowContextmenu",e,i,s)}),(0,r.h)("tr",h,c)}function Oe(){const e=t.body,n=t["top-row"],i=t["bottom-row"];let o=H.value.map(((t,n)=>Re(t,e,n)));return void 0!==n&&(o=n({cols:se.value}).concat(o)),void 0!==i&&(o=o.concat(i({cols:se.value}))),(0,r.h)("tbody",o)}function Ne(e){return Le(e),e.cols=e.cols.map((t=>(0,Q.g)({...t},"value",(()=>De(t,e.row))))),e}function Pe(e){return Le(e),(0,Q.g)(e,"value",(()=>De(e.col,e.row))),e}function Fe(e){return Le(e),e}function Le(t){Object.assign(t,{cols:se.value,colsMap:ae.value,sort:de,rowIndex:he.value+t.pageIndex,color:e.color,dark:d.value,dense:e.dense}),!0===K.value&&(0,Q.g)(t,"selected",(()=>ne(t.key)),((e,n)=>{ie([t.key],[t.row],e,n)})),(0,Q.g)(t,"expand",(()=>M(t.key)),(e=>{V(t.key,e)}))}function De(e,t){const n="function"===typeof e.field?e.field(t):t[e.field];return void 0!==e.format?e.format(n,t):n}const Me=(0,r.Fl)((()=>({pagination:I.value,pagesNumber:me.value,isFirstPage:pe.value,isLastPage:ge.value,firstPage:be,prevPage:we,nextPage:_e,lastPage:Se,inFullscreen:h.value,toggleFullscreen:f})));function qe(){const n=t.top,i=t["top-left"],o=t["top-right"],s=t["top-selection"],a=!0===K.value&&void 0!==s&&te.value>0,l="q-table__top relative-position row items-center";if(void 0!==n)return(0,r.h)("div",{class:l},[n(Me.value)]);let u;return!0===a?u=s(Me.value).slice():(u=[],void 0!==i?u.push((0,r.h)("div",{class:"q-table__control"},[i(Me.value)])):e.title&&u.push((0,r.h)("div",{class:"q-table__control"},[(0,r.h)("div",{class:["q-table__title",e.titleClass]},e.title)]))),void 0!==o&&(u.push((0,r.h)("div",{class:"q-table__separator col"})),u.push((0,r.h)("div",{class:"q-table__control"},[o(Me.value)]))),0!==u.length?(0,r.h)("div",{class:l},u):void 0}const Ve=(0,r.Fl)((()=>!0===ee.value?null:X.value));function Ue(){const n=Be();return!0===e.loading&&void 0===t.loading&&n.push((0,r.h)("tr",{class:"q-table__progress"},[(0,r.h)("th",{class:"relative-position",colspan:le.value},Ae())])),(0,r.h)("thead",n)}function Be(){const n=t.header,i=t["header-cell"];if(void 0!==n)return n($e({header:!0})).slice();const o=se.value.map((e=>{const n=t[`header-cell-${e.name}`],o=void 0!==n?n:i,s=$e({col:e});return void 0!==o?o(s):(0,r.h)(l,{key:e.name,props:s},(()=>e.label))}));if(!0===W.value&&!0!==e.grid)o.unshift((0,r.h)("th",{class:"q-table--col-auto-width"}," "));else if(!0===G.value){const n=t["header-selection"],i=void 0!==n?n($e({})):[(0,r.h)(x,{color:e.color,modelValue:Ve.value,dark:d.value,dense:e.dense,"onUpdate:modelValue":je})];o.unshift((0,r.h)("th",{class:"q-table--col-auto-width"},i))}return[(0,r.h)("tr",{class:e.tableHeaderClass,style:e.tableHeaderStyle},o)]}function $e(t){return Object.assign(t,{cols:se.value,sort:de,colsMap:ae.value,color:e.color,dark:d.value,dense:e.dense}),!0===G.value&&(0,Q.g)(t,"selected",(()=>Ve.value),je),t}function je(e){!0===ee.value&&(e=!1),ie(H.value.map(m.value),H.value,e)}const ze=(0,r.Fl)((()=>{const t=[e.iconFirstPage||a.iconSet.table.firstPage,e.iconPrevPage||a.iconSet.table.prevPage,e.iconNextPage||a.iconSet.table.nextPage,e.iconLastPage||a.iconSet.table.lastPage];return!0===a.lang.rtl?t.reverse():t}));function He(){if(!0===e.hideBottom)return;if(!0===Ee.value){if(!0===e.hideNoData)return;const n=!0===e.loading?e.loadingLabel||a.lang.table.loading:e.filter?e.noResultsLabel||a.lang.table.noResults:e.noDataLabel||a.lang.table.noData,i=t["no-data"],s=void 0!==i?[i({message:n,icon:a.iconSet.table.warning,filter:e.filter})]:[(0,r.h)(o.Z,{class:"q-table__bottom-nodata-icon",name:a.iconSet.table.warning}),n];return(0,r.h)("div",{class:Y+" q-table__bottom--nodata"},s)}const n=t.bottom;if(void 0!==n)return(0,r.h)("div",{class:Y},[n(Me.value)]);const i=!0!==e.hideSelectedBanner&&!0===K.value&&te.value>0?[(0,r.h)("div",{class:"q-table__control"},[(0,r.h)("div",[(e.selectedRowsLabel||a.lang.table.selectedRecords)(te.value)])])]:[];return!0!==e.hidePagination?(0,r.h)("div",{class:Y+" justify-end"},We(i)):0!==i.length?(0,r.h)("div",{class:Y},i):void 0}function Ke(e){P({page:1,rowsPerPage:e.value})}function We(n){let i;const{rowsPerPage:o}=I.value,s=e.paginationLabel||a.lang.table.pagination,l=t.pagination,u=e.rowsPerPageOptions.length>1;if(n.push((0,r.h)("div",{class:"q-table__separator col"})),!0===u&&n.push((0,r.h)("div",{class:"q-table__control"},[(0,r.h)("span",{class:"q-table__bottom-item"},[e.rowsPerPageLabel||a.lang.table.recordsPerPage]),(0,r.h)(_.Z,{class:"q-table__select inline q-table__bottom-item",color:e.color,modelValue:o,options:ve.value,displayValue:0===o?a.lang.table.allRows:o,dark:d.value,borderless:!0,dense:!0,optionsDense:!0,optionsCover:!0,"onUpdate:modelValue":Ke})])),void 0!==l)i=l(Me.value);else if(i=[(0,r.h)("span",0!==o?{class:"q-table__bottom-item"}:{},[o?s(he.value+1,Math.min(fe.value,ye.value),ye.value):s(1,j.value,ye.value)])],0!==o&&me.value>1){const t={color:e.color,round:!0,dense:!0,flat:!0};!0===e.dense&&(t.size="sm"),me.value>2&&i.push((0,r.h)(A.Z,{key:"pgFirst",...t,icon:ze.value[0],disable:pe.value,onClick:be})),i.push((0,r.h)(A.Z,{key:"pgPrev",...t,icon:ze.value[1],disable:pe.value,onClick:we}),(0,r.h)(A.Z,{key:"pgNext",...t,icon:ze.value[2],disable:ge.value,onClick:_e})),me.value>2&&i.push((0,r.h)(A.Z,{key:"pgLast",...t,icon:ze.value[3],disable:ge.value,onClick:Se}))}return n.push((0,r.h)("div",{class:"q-table__control"},i)),n}function Ze(){const n=!0===e.gridHeader?[(0,r.h)("table",{class:"q-table"},[Ue(r.h)])]:!0===e.loading&&void 0===t.loading?Ae(r.h):void 0;return(0,r.h)("div",{class:"q-table__middle"},n)}function Ge(){const i=void 0!==t.item?t.item:i=>{const o=i.cols.map((e=>(0,r.h)("div",{class:"q-table__grid-item-row"},[(0,r.h)("div",{class:"q-table__grid-item-title"},[e.label]),(0,r.h)("div",{class:"q-table__grid-item-value"},[e.value])])));if(!0===K.value){const n=t["body-selection"],s=void 0!==n?n(i):[(0,r.h)(x,{modelValue:i.selected,color:e.color,dark:d.value,dense:e.dense,"onUpdate:modelValue":(e,t)=>{ie([i.key],[i.row],e,t)}})];o.unshift((0,r.h)("div",{class:"q-table__grid-item-row"},s),(0,r.h)(u.Z,{dark:d.value}))}const s={class:["q-table__grid-item-card"+S.value,e.cardClass],style:e.cardStyle};return void 0===e.onRowClick&&void 0===e.onRowDblclick||(s.class[0]+=" cursor-pointer",void 0!==e.onRowClick&&(s.onClick=e=>{n("RowClick",e,i.row,i.pageIndex)}),void 0!==e.onRowDblclick&&(s.onDblclick=e=>{n("RowDblclick",e,i.row,i.pageIndex)})),(0,r.h)("div",{class:"q-table__grid-item col-xs-12 col-sm-6 col-md-4 col-lg-3"+(!0===i.selected?" q-table__grid-item--selected":"")},[(0,r.h)("div",s,o)])};return(0,r.h)("div",{class:["q-table__grid-content row",e.cardContainerClass],style:e.cardContainerStyle},H.value.map(((e,t)=>i(Ne({key:m.value(e),row:e,pageIndex:t})))))}return Object.assign(s.proxy,{requestServerInteraction:N,setPagination:P,firstPage:be,prevPage:we,nextPage:_e,lastPage:Se,isRowSelected:ne,clearSelection:re,isRowExpanded:M,setExpanded:q,sort:de,resetVirtualScroll:Te,scrollTo:Ie,getCellValue:De}),(0,Q.K)(s.proxy,{filteredSortedRows:()=>$.value,computedRows:()=>H.value,computedRowsNumber:()=>ye.value}),()=>{const n=[qe()],i={ref:v,class:k.value};return!0===e.grid?n.push(Ze()):Object.assign(i,{class:[i.class,e.cardClass],style:e.cardStyle}),n.push(Ce(),He()),!0===e.loading&&void 0!==t.loading&&n.push(t.loading()),(0,r.h)("div",i,n)}}})},7220:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(9835),i=n(5987),o=n(2026);const s=(0,i.L)({name:"QTd",props:{props:Object,autoWidth:Boolean,noHover:Boolean},setup(e,{slots:t}){const n=(0,r.FN)(),i=(0,r.Fl)((()=>"q-td"+(!0===e.autoWidth?" q-table--col-auto-width":"")+(!0===e.noHover?" q-td--no-hover":"")+" "));return()=>{if(void 0===e.props)return(0,r.h)("td",{class:i.value},(0,o.KR)(t.default));const s=n.vnode.key,a=(void 0!==e.props.colsMap?e.props.colsMap[s]:null)||e.props.col;if(void 0===a)return;const{row:l}=e.props;return(0,r.h)("td",{class:i.value+a.__tdClass(l),style:a.__tdStyle(l)},(0,o.KR)(t.default))}}})},3175:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(9835),i=n(2857),o=n(5413),s=n(5987);const a=(0,s.L)({name:"QToggle",props:{...o.Fz,icon:String,iconColor:String},emits:o.ZB,setup(e){function t(t,n){const o=(0,r.Fl)((()=>(!0===t.value?e.checkedIcon:!0===n.value?e.indeterminateIcon:e.uncheckedIcon)||e.icon)),s=(0,r.Fl)((()=>!0===t.value?e.iconColor:null));return()=>[(0,r.h)("div",{class:"q-toggle__track"}),(0,r.h)("div",{class:"q-toggle__thumb absolute flex flex-center no-wrap"},void 0!==o.value?[(0,r.h)(i.Z,{name:o.value,color:s.value})]:void 0)]}return(0,o.ZP)("toggle",t)}})},1663:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(9835),i=n(5987),o=n(2026);const s=(0,i.L)({name:"QToolbar",props:{inset:Boolean},setup(e,{slots:t}){const n=(0,r.Fl)((()=>"q-toolbar row no-wrap items-center"+(!0===e.inset?" q-toolbar--inset":"")));return()=>(0,r.h)("div",{class:n.value,role:"toolbar"},(0,o.KR)(t.default))}})},1973:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(9835),i=n(5987),o=n(2026);const s=(0,i.L)({name:"QToolbarTitle",props:{shrink:Boolean},setup(e,{slots:t}){const n=(0,r.Fl)((()=>"q-toolbar__title ellipsis"+(!0===e.shrink?" col-shrink":"")));return()=>(0,r.h)("div",{class:n.value},(0,o.KR)(t.default))}})},6858:(e,t,n)=>{"use strict";n.d(t,{Z:()=>w});var r=n(9835),i=n(499),o=n(1957),s=n(4397),a=n(4088),l=n(3842),u=n(1518),c=n(431),d=n(6916),h=n(2695),f=n(5987),p=n(3701),g=n(1384),m=n(2589),v=n(2026),y=n(9092),b=n(9388);const w=(0,f.L)({name:"QTooltip",inheritAttrs:!1,props:{...s.u,...l.vr,...c.D,maxHeight:{type:String,default:null},maxWidth:{type:String,default:null},transitionShow:{default:"jump-down"},transitionHide:{default:"jump-up"},anchor:{type:String,default:"bottom middle",validator:b.$},self:{type:String,default:"top middle",validator:b.$},offset:{type:Array,default:()=>[14,14],validator:b.io},scrollTarget:{default:void 0},delay:{type:Number,default:0},hideDelay:{type:Number,default:0}},emits:[...l.gH],setup(e,{slots:t,emit:n,attrs:f}){let w,_;const S=(0,r.FN)(),{proxy:{$q:E}}=S,k=(0,i.iH)(null),T=(0,i.iH)(!1),C=(0,r.Fl)((()=>(0,b.li)(e.anchor,E.lang.rtl))),I=(0,r.Fl)((()=>(0,b.li)(e.self,E.lang.rtl))),x=(0,r.Fl)((()=>!0!==e.persistent)),{registerTick:A,removeTick:R}=(0,d.Z)(),{registerTimeout:O}=(0,h.Z)(),{transitionProps:N,transitionStyle:P}=(0,c.Z)(e),{localScrollTarget:F,changeScrollEvent:L,unconfigureScrollTarget:D}=(0,a.Z)(e,Y),{anchorEl:M,canShow:q,anchorEvents:V}=(0,s.Z)({showing:T,configureAnchorEl:Q}),{show:U,hide:B}=(0,l.ZP)({showing:T,canShow:q,handleShow:H,handleHide:K,hideOnRouteChange:x,processOnMount:!0});Object.assign(V,{delayShow:G,delayHide:J});const{showPortal:$,hidePortal:j,renderPortal:z}=(0,u.Z)(S,k,ee,"tooltip");if(!0===E.platform.is.mobile){const t={anchorEl:M,innerRef:k,onClickOutside(e){return B(e),e.target.classList.contains("q-dialog__backdrop")&&(0,g.NS)(e),!0}},n=(0,r.Fl)((()=>null===e.modelValue&&!0!==e.persistent&&!0===T.value));(0,r.YP)(n,(e=>{const n=!0===e?y.m:y.D;n(t)})),(0,r.Jd)((()=>{(0,y.D)(t)}))}function H(t){$(),A((()=>{_=new MutationObserver((()=>Z())),_.observe(k.value,{attributes:!1,childList:!0,characterData:!0,subtree:!0}),Z(),Y()})),void 0===w&&(w=(0,r.YP)((()=>E.screen.width+"|"+E.screen.height+"|"+e.self+"|"+e.anchor+"|"+E.lang.rtl),Z)),O((()=>{$(!0),n("show",t)}),e.transitionDuration)}function K(t){R(),j(),W(),O((()=>{j(!0),n("hide",t)}),e.transitionDuration)}function W(){void 0!==_&&(_.disconnect(),_=void 0),void 0!==w&&(w(),w=void 0),D(),(0,g.ul)(V,"tooltipTemp")}function Z(){const t=k.value;null!==M.value&&t&&(0,b.wq)({el:t,offset:e.offset,anchorEl:M.value,anchorOrigin:C.value,selfOrigin:I.value,maxHeight:e.maxHeight,maxWidth:e.maxWidth})}function G(t){if(!0===E.platform.is.mobile){(0,m.M)(),document.body.classList.add("non-selectable");const e=M.value,t=["touchmove","touchcancel","touchend","click"].map((t=>[e,t,"delayHide","passiveCapture"]));(0,g.M0)(V,"tooltipTemp",t)}O((()=>{U(t)}),e.delay)}function J(t){!0===E.platform.is.mobile&&((0,g.ul)(V,"tooltipTemp"),(0,m.M)(),setTimeout((()=>{document.body.classList.remove("non-selectable")}),10)),O((()=>{B(t)}),e.hideDelay)}function Q(){if(!0===e.noParentEvent||null===M.value)return;const t=!0===E.platform.is.mobile?[[M.value,"touchstart","delayShow","passive"]]:[[M.value,"mouseenter","delayShow","passive"],[M.value,"mouseleave","delayHide","passive"]];(0,g.M0)(V,"anchor",t)}function Y(){if(null!==M.value||void 0!==e.scrollTarget){F.value=(0,p.b0)(M.value,e.scrollTarget);const t=!0===e.noParentEvent?Z:B;L(F.value,t)}}function X(){return!0===T.value?(0,r.h)("div",{...f,ref:k,class:["q-tooltip q-tooltip--style q-position-engine no-pointer-events",f.class],style:[f.style,P.value],role:"tooltip"},(0,v.KR)(t.default)):null}function ee(){return(0,r.h)(o.uT,N.value,X)}return(0,r.Jd)(W),Object.assign(S.proxy,{updatePosition:Z}),z}})},2380:(e,t,n)=>{"use strict";n.d(t,{If:()=>v,vp:()=>b,t9:()=>y});n(9665);var r=n(9835),i=n(499),o=n(899),s=n(1384);let a=!1;{const e=document.createElement("div");e.setAttribute("dir","rtl"),Object.assign(e.style,{width:"1px",height:"1px",overflow:"auto"});const t=document.createElement("div");Object.assign(t.style,{width:"1000px",height:"1px"}),document.body.appendChild(e),e.appendChild(t),e.scrollLeft=-1e3,a=e.scrollLeft>=0,e.remove()}const l=1e3,u=["start","center","end","start-force","center-force","end-force"],c=Array.prototype.filter,d=void 0===window.getComputedStyle(document.body).overflowAnchor?s.ZT:function(e,t){null!==e&&(void 0!==e._qOverflowAnimationFrame&&cancelAnimationFrame(e._qOverflowAnimationFrame),e._qOverflowAnimationFrame=requestAnimationFrame((()=>{if(null===e)return;e._qOverflowAnimationFrame=void 0;const n=e.children||[];c.call(n,(e=>e.dataset&&void 0!==e.dataset.qVsAnchor)).forEach((e=>{delete e.dataset.qVsAnchor}));const r=n[t];r&&r.dataset&&(r.dataset.qVsAnchor="")})))};function h(e,t){return e+t}function f(e,t,n,r,i,o,s,l){const u=e===window?document.scrollingElement||document.documentElement:e,c=!0===i?"offsetWidth":"offsetHeight",d={scrollStart:0,scrollViewSize:-s-l,scrollMaxSize:0,offsetStart:-s,offsetEnd:-l};if(!0===i?(e===window?(d.scrollStart=window.pageXOffset||window.scrollX||document.body.scrollLeft||0,d.scrollViewSize+=document.documentElement.clientWidth):(d.scrollStart=u.scrollLeft,d.scrollViewSize+=u.clientWidth),d.scrollMaxSize=u.scrollWidth,!0===o&&(d.scrollStart=(!0===a?d.scrollMaxSize-d.scrollViewSize:0)-d.scrollStart)):(e===window?(d.scrollStart=window.pageYOffset||window.scrollY||document.body.scrollTop||0,d.scrollViewSize+=document.documentElement.clientHeight):(d.scrollStart=u.scrollTop,d.scrollViewSize+=u.clientHeight),d.scrollMaxSize=u.scrollHeight),null!==n)for(let a=n.previousElementSibling;null!==a;a=a.previousElementSibling)!1===a.classList.contains("q-virtual-scroll--skip")&&(d.offsetStart+=a[c]);if(null!==r)for(let a=r.nextElementSibling;null!==a;a=a.nextElementSibling)!1===a.classList.contains("q-virtual-scroll--skip")&&(d.offsetEnd+=a[c]);if(t!==e){const n=u.getBoundingClientRect(),r=t.getBoundingClientRect();!0===i?(d.offsetStart+=r.left-n.left,d.offsetEnd-=r.width):(d.offsetStart+=r.top-n.top,d.offsetEnd-=r.height),e!==window&&(d.offsetStart+=d.scrollStart),d.offsetEnd+=d.scrollMaxSize-d.offsetStart}return d}function p(e,t,n,r){"end"===t&&(t=(e===window?document.body:e)[!0===n?"scrollWidth":"scrollHeight"]),e===window?!0===n?(!0===r&&(t=(!0===a?document.body.scrollWidth-document.documentElement.clientWidth:0)-t),window.scrollTo(t,window.pageYOffset||window.scrollY||document.body.scrollTop||0)):window.scrollTo(window.pageXOffset||window.scrollX||document.body.scrollLeft||0,t):!0===n?(!0===r&&(t=(!0===a?e.scrollWidth-e.offsetWidth:0)-t),e.scrollLeft=t):e.scrollTop=t}function g(e,t,n,r){if(n>=r)return 0;const i=t.length,o=Math.floor(n/l),s=Math.floor((r-1)/l)+1;let a=e.slice(o,s).reduce(h,0);return n%l!==0&&(a-=t.slice(o*l,n).reduce(h,0)),r%l!==0&&r!==i&&(a-=t.slice(r,s*l).reduce(h,0)),a}const m={virtualScrollSliceSize:{type:[Number,String],default:null},virtualScrollSliceRatioBefore:{type:[Number,String],default:1},virtualScrollSliceRatioAfter:{type:[Number,String],default:1},virtualScrollItemSize:{type:[Number,String],default:24},virtualScrollStickySizeStart:{type:[Number,String],default:0},virtualScrollStickySizeEnd:{type:[Number,String],default:0},tableColspan:[Number,String]},v=Object.keys(m),y={virtualScrollHorizontal:Boolean,onVirtualScroll:Function,...m};function b({virtualScrollLength:e,getVirtualScrollTarget:t,getVirtualScrollEl:n,virtualScrollItemSizeComputed:s}){const a=(0,r.FN)(),{props:m,emit:v,proxy:y}=a,{$q:b}=y;let w,_,S,E,k=[];const T=(0,i.iH)(0),C=(0,i.iH)(0),I=(0,i.iH)({}),x=(0,i.iH)(null),A=(0,i.iH)(null),R=(0,i.iH)(null),O=(0,i.iH)({from:0,to:0}),N=(0,r.Fl)((()=>void 0!==m.tableColspan?m.tableColspan:100));void 0===s&&(s=(0,r.Fl)((()=>m.virtualScrollItemSize)));const P=(0,r.Fl)((()=>s.value+";"+m.virtualScrollHorizontal)),F=(0,r.Fl)((()=>P.value+";"+m.virtualScrollSliceRatioBefore+";"+m.virtualScrollSliceRatioAfter));function L(){$(_,!0)}function D(e){$(void 0===e?_:e)}function M(r,i){const o=t();if(void 0===o||null===o||8===o.nodeType)return;const s=f(o,n(),x.value,A.value,m.virtualScrollHorizontal,b.lang.rtl,m.virtualScrollStickySizeStart,m.virtualScrollStickySizeEnd);S!==s.scrollViewSize&&j(s.scrollViewSize),V(o,s,Math.min(e.value-1,Math.max(0,parseInt(r,10)||0)),0,u.indexOf(i)>-1?i:_>-1&&r>_?"end":"start")}function q(){const r=t();if(void 0===r||null===r||8===r.nodeType)return;const i=f(r,n(),x.value,A.value,m.virtualScrollHorizontal,b.lang.rtl,m.virtualScrollStickySizeStart,m.virtualScrollStickySizeEnd),o=e.value-1,s=i.scrollMaxSize-i.offsetStart-i.offsetEnd-C.value;if(w===i.scrollStart)return;if(i.scrollMaxSize<=0)return void V(r,i,0,0);S!==i.scrollViewSize&&j(i.scrollViewSize),U(O.value.from);const a=Math.floor(i.scrollMaxSize-Math.max(i.scrollViewSize,i.offsetEnd)-Math.min(E[o],i.scrollViewSize/2));if(a>0&&Math.ceil(i.scrollStart)>=a)return void V(r,i,o,i.scrollMaxSize-i.offsetEnd-k.reduce(h,0));let u=0,c=i.scrollStart-i.offsetStart,d=c;if(c<=s&&c+i.scrollViewSize>=T.value)c-=T.value,u=O.value.from,d=c;else for(let e=0;c>=k[e]&&u<o;e++)c-=k[e],u+=l;while(c>0&&u<o)c-=E[u],c>-i.scrollViewSize?(u++,d=c):d=E[u]+c;V(r,i,u,d)}function V(t,n,r,i,o){const s="string"===typeof o&&o.indexOf("-force")>-1,a=!0===s?o.replace("-force",""):o,l=void 0!==a?a:"start";let u=Math.max(0,r-I.value[l]),c=u+I.value.total;c>e.value&&(c=e.value,u=Math.max(0,c-I.value.total)),w=n.scrollStart;const f=u!==O.value.from||c!==O.value.to;if(!1===f&&void 0===a)return void H(r);const{activeElement:v}=document,y=R.value;!0===f&&null!==y&&y!==v&&!0===y.contains(v)&&(y.addEventListener("focusout",B),setTimeout((()=>{null!==y&&y.removeEventListener("focusout",B)}))),d(y,r-u);const _=void 0!==a?E.slice(u,r).reduce(h,0):0;if(!0===f){const t=c>=O.value.from&&u<=O.value.to?O.value.to:c;O.value={from:u,to:t},T.value=g(k,E,0,u),C.value=g(k,E,c,e.value),requestAnimationFrame((()=>{O.value.to!==c&&w===n.scrollStart&&(O.value={from:O.value.from,to:c},C.value=g(k,E,c,e.value))}))}requestAnimationFrame((()=>{if(w!==n.scrollStart)return;!0===f&&U(u);const e=E.slice(u,r).reduce(h,0),o=e+n.offsetStart+T.value,l=o+E[r];let c=o+i;if(void 0!==a){const t=e-_,i=n.scrollStart+t;c=!0!==s&&i<o&&l<i+n.scrollViewSize?i:"end"===a?l-n.scrollViewSize:o-("start"===a?0:Math.round((n.scrollViewSize-E[r])/2))}w=c,p(t,c,m.virtualScrollHorizontal,b.lang.rtl),H(r)}))}function U(e){const t=R.value;if(t){const n=c.call(t.children,(e=>e.classList&&!1===e.classList.contains("q-virtual-scroll--skip"))),r=n.length,i=!0===m.virtualScrollHorizontal?e=>e.getBoundingClientRect().width:e=>e.offsetHeight;let o,s,a=e;for(let e=0;e<r;){o=i(n[e]),e++;while(e<r&&!0===n[e].classList.contains("q-virtual-scroll--with-prev"))o+=i(n[e]),e++;s=o-E[a],0!==s&&(E[a]+=s,k[Math.floor(a/l)]+=s),a++}}}function B(){null!==R.value&&void 0!==R.value&&R.value.focus()}function $(t,n){const i=1*s.value;!0!==n&&!1!==Array.isArray(E)||(E=[]);const o=E.length;E.length=e.value;for(let r=e.value-1;r>=o;r--)E[r]=i;const a=Math.floor((e.value-1)/l);k=[];for(let r=0;r<=a;r++){let t=0;const n=Math.min((r+1)*l,e.value);for(let e=r*l;e<n;e++)t+=E[e];k.push(t)}_=-1,w=void 0,T.value=g(k,E,0,O.value.from),C.value=g(k,E,O.value.to,e.value),t>=0?(U(O.value.from),(0,r.Y3)((()=>{M(t)}))):K()}function j(e){if(void 0===e&&"undefined"!==typeof window){const r=t();void 0!==r&&null!==r&&8!==r.nodeType&&(e=f(r,n(),x.value,A.value,m.virtualScrollHorizontal,b.lang.rtl,m.virtualScrollStickySizeStart,m.virtualScrollStickySizeEnd).scrollViewSize)}S=e;const r=parseFloat(m.virtualScrollSliceRatioBefore)||0,i=parseFloat(m.virtualScrollSliceRatioAfter)||0,o=1+r+i,a=void 0===e||e<=0?1:Math.ceil(e/s.value),l=Math.max(1,a,Math.ceil((m.virtualScrollSliceSize>0?m.virtualScrollSliceSize:10)/o));I.value={total:Math.ceil(l*o),start:Math.ceil(l*r),center:Math.ceil(l*(.5+r)),end:Math.ceil(l*(1+r)),view:a}}function z(e,t){const n=!0===m.virtualScrollHorizontal?"width":"height",i={["--q-virtual-scroll-item-"+n]:s.value+"px"};return["tbody"===e?(0,r.h)(e,{class:"q-virtual-scroll__padding",key:"before",ref:x},[(0,r.h)("tr",[(0,r.h)("td",{style:{[n]:`${T.value}px`,...i},colspan:N.value})])]):(0,r.h)(e,{class:"q-virtual-scroll__padding",key:"before",ref:x,style:{[n]:`${T.value}px`,...i}}),(0,r.h)(e,{class:"q-virtual-scroll__content",key:"content",ref:R,tabindex:-1},t.flat()),"tbody"===e?(0,r.h)(e,{class:"q-virtual-scroll__padding",key:"after",ref:A},[(0,r.h)("tr",[(0,r.h)("td",{style:{[n]:`${C.value}px`,...i},colspan:N.value})])]):(0,r.h)(e,{class:"q-virtual-scroll__padding",key:"after",ref:A,style:{[n]:`${C.value}px`,...i}})]}function H(e){_!==e&&(void 0!==m.onVirtualScroll&&v("virtualScroll",{index:e,from:O.value.from,to:O.value.to-1,direction:e<_?"decrease":"increase",ref:y}),_=e)}(0,r.YP)(F,(()=>{j()})),(0,r.YP)(P,L),j();const K=(0,o.Z)(q,!0===b.platform.is.ios?120:35);(0,r.wF)((()=>{j()}));let W=!1;return(0,r.se)((()=>{W=!0})),(0,r.dl)((()=>{if(!0!==W)return;const e=t();void 0!==w&&void 0!==e&&null!==e&&8!==e.nodeType?p(e,w,m.virtualScrollHorizontal,b.lang.rtl):M(_)})),(0,r.Jd)((()=>{K.cancel()})),Object.assign(y,{scrollTo:M,reset:L,refresh:D}),{virtualScrollSliceRange:O,virtualScrollSliceSizeComputed:I,setVirtualScrollSize:j,onVirtualScrollEvt:K,localResetVirtualScroll:$,padVirtualScroll:z,scrollTo:M,reset:L,refresh:D}}},5065:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>a,jO:()=>s});var r=n(9835);const i={left:"start",center:"center",right:"end",between:"between",around:"around",evenly:"evenly",stretch:"stretch"},o=Object.keys(i),s={align:{type:String,validator:e=>o.includes(e)}};function a(e){return(0,r.Fl)((()=>{const t=void 0===e.align?!0===e.vertical?"stretch":"left":e.align;return`${!0===e.vertical?"items":"justify"}-${i[t]}`}))}},4397:(e,t,n)=>{"use strict";n.d(t,{Z:()=>u,u:()=>l});var r=n(9835),i=n(499),o=n(2589),s=n(1384),a=n(1705);const l={target:{default:!0},noParentEvent:Boolean,contextMenu:Boolean};function u({showing:e,avoidEmit:t,configureAnchorEl:n}){const{props:l,proxy:u,emit:c}=(0,r.FN)(),d=(0,i.iH)(null);let h=null;function f(e){return null!==d.value&&(void 0===e||void 0===e.touches||e.touches.length<=1)}const p={};function g(){(0,s.ul)(p,"anchor")}function m(e){d.value=e;while(d.value.classList.contains("q-anchor--skip"))d.value=d.value.parentNode;n()}function v(){if(!1===l.target||""===l.target||null===u.$el.parentNode)d.value=null;else if(!0===l.target)m(u.$el.parentNode);else{let t=l.target;if("string"===typeof l.target)try{t=document.querySelector(l.target)}catch(e){t=void 0}void 0!==t&&null!==t?(d.value=t.$el||t,n()):(d.value=null,console.error(`Anchor: target "${l.target}" not found`))}}return void 0===n&&(Object.assign(p,{hide(e){u.hide(e)},toggle(e){u.toggle(e),e.qAnchorHandled=!0},toggleKey(e){!0===(0,a.So)(e,13)&&p.toggle(e)},contextClick(e){u.hide(e),(0,s.X$)(e),(0,r.Y3)((()=>{u.show(e),e.qAnchorHandled=!0}))},prevent:s.X$,mobileTouch(e){if(p.mobileCleanup(e),!0!==f(e))return;u.hide(e),d.value.classList.add("non-selectable");const t=e.target;(0,s.M0)(p,"anchor",[[t,"touchmove","mobileCleanup","passive"],[t,"touchend","mobileCleanup","passive"],[t,"touchcancel","mobileCleanup","passive"],[d.value,"contextmenu","prevent","notPassive"]]),h=setTimeout((()=>{h=null,u.show(e),e.qAnchorHandled=!0}),300)},mobileCleanup(t){d.value.classList.remove("non-selectable"),null!==h&&(clearTimeout(h),h=null),!0===e.value&&void 0!==t&&(0,o.M)()}}),n=function(e=l.contextMenu){if(!0===l.noParentEvent||null===d.value)return;let t;t=!0===e?!0===u.$q.platform.is.mobile?[[d.value,"touchstart","mobileTouch","passive"]]:[[d.value,"mousedown","hide","passive"],[d.value,"contextmenu","contextClick","notPassive"]]:[[d.value,"click","toggle","passive"],[d.value,"keyup","toggleKey","passive"]],(0,s.M0)(p,"anchor",t)}),(0,r.YP)((()=>l.contextMenu),(e=>{null!==d.value&&(g(),n(e))})),(0,r.YP)((()=>l.target),(()=>{null!==d.value&&g(),v()})),(0,r.YP)((()=>l.noParentEvent),(e=>{null!==d.value&&(!0===e?g():n())})),(0,r.bv)((()=>{v(),!0!==t&&!0===l.modelValue&&null===d.value&&c("update:modelValue",!1)})),(0,r.Jd)((()=>{null!==h&&clearTimeout(h),g()})),{anchorEl:d,canShow:f,anchorEvents:p}}},8234:(e,t,n)=>{"use strict";n.d(t,{S:()=>i,Z:()=>o});var r=n(9835);const i={dark:{type:Boolean,default:null}};function o(e,t){return(0,r.Fl)((()=>null===e.dark?t.dark.isActive:e.dark))}},3167:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>V,yV:()=>L,HJ:()=>M,Cl:()=>D,tL:()=>q});n(9665);var r=n(9835),i=n(499),o=n(1957),s=n(7506),a=n(2857),l=n(3940),u=n(8234),c=n(5439);function d({validate:e,resetValidation:t,requiresQForm:n}){const i=(0,r.f3)(c.vh,!1);if(!1!==i){const{props:n,proxy:o}=(0,r.FN)();Object.assign(o,{validate:e,resetValidation:t}),(0,r.YP)((()=>n.disable),(e=>{!0===e?("function"===typeof t&&t(),i.unbindComponent(o)):i.bindComponent(o)})),(0,r.bv)((()=>{!0!==n.disable&&i.bindComponent(o)})),(0,r.Jd)((()=>{!0!==n.disable&&i.unbindComponent(o)}))}else!0===n&&console.error("Parent QForm not found on useFormChild()!")}const h=/^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/,f=/^#[0-9a-fA-F]{4}([0-9a-fA-F]{4})?$/,p=/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/,g=/^rgb\(((0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),){2}(0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5])\)$/,m=/^rgba\(((0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),){2}(0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),(0|0\.[0-9]+[1-9]|0\.[1-9]+|1)\)$/,v={date:e=>/^-?[\d]+\/[0-1]\d\/[0-3]\d$/.test(e),time:e=>/^([0-1]?\d|2[0-3]):[0-5]\d$/.test(e),fulltime:e=>/^([0-1]?\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(e),timeOrFulltime:e=>/^([0-1]?\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/.test(e),email:e=>/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(e),hexColor:e=>h.test(e),hexaColor:e=>f.test(e),hexOrHexaColor:e=>p.test(e),rgbColor:e=>g.test(e),rgbaColor:e=>m.test(e),rgbOrRgbaColor:e=>g.test(e)||m.test(e),hexOrRgbColor:e=>h.test(e)||g.test(e),hexaOrRgbaColor:e=>f.test(e)||m.test(e),anyColor:e=>p.test(e)||g.test(e)||m.test(e)};var y=n(899),b=n(3251);const w=[!0,!1,"ondemand"],_={modelValue:{},error:{type:Boolean,default:null},errorMessage:String,noErrorIcon:Boolean,rules:Array,reactiveRules:Boolean,lazyRules:{type:[Boolean,String],validator:e=>w.includes(e)}};function S(e,t){const{props:n,proxy:o}=(0,r.FN)(),s=(0,i.iH)(!1),a=(0,i.iH)(null),l=(0,i.iH)(null);d({validate:w,resetValidation:m});let u,c=0;const h=(0,r.Fl)((()=>void 0!==n.rules&&null!==n.rules&&0!==n.rules.length)),f=(0,r.Fl)((()=>!0!==n.disable&&!0===h.value)),p=(0,r.Fl)((()=>!0===n.error||!0===s.value)),g=(0,r.Fl)((()=>"string"===typeof n.errorMessage&&0!==n.errorMessage.length?n.errorMessage:a.value));function m(){c++,t.value=!1,l.value=null,s.value=!1,a.value=null,S.cancel()}function w(e=n.modelValue){if(!0!==f.value)return!0;const r=++c,i=!0!==t.value?()=>{l.value=!0}:()=>{},o=(e,n)=>{!0===e&&i(),s.value=e,a.value=n||null,t.value=!1},u=[];for(let t=0;t<n.rules.length;t++){const r=n.rules[t];let i;if("function"===typeof r?i=r(e,v):"string"===typeof r&&void 0!==v[r]&&(i=v[r](e)),!1===i||"string"===typeof i)return o(!0,i),!1;!0!==i&&void 0!==i&&u.push(i)}return 0===u.length?(o(!1),!0):(t.value=!0,Promise.all(u).then((e=>{if(void 0===e||!1===Array.isArray(e)||0===e.length)return r===c&&o(!1),!0;const t=e.find((e=>!1===e||"string"===typeof e));return r===c&&o(void 0!==t,t),void 0===t}),(e=>(r===c&&(console.error(e),o(!0)),!1))))}function _(e){!0===f.value&&"ondemand"!==n.lazyRules&&(!0===l.value||!0!==n.lazyRules&&!0!==e)&&S()}(0,r.YP)((()=>n.modelValue),(()=>{_()})),(0,r.YP)((()=>n.reactiveRules),(e=>{!0===e?void 0===u&&(u=(0,r.YP)((()=>n.rules),(()=>{_(!0)}))):void 0!==u&&(u(),u=void 0)}),{immediate:!0}),(0,r.YP)(e,(e=>{!0===e?null===l.value&&(l.value=!1):!1===l.value&&(l.value=!0,!0===f.value&&"ondemand"!==n.lazyRules&&!1===t.value&&S())}));const S=(0,y.Z)(w,0);return(0,r.Jd)((()=>{void 0!==u&&u(),S.cancel()})),Object.assign(o,{resetValidation:m,validate:w}),(0,b.g)(o,"hasError",(()=>p.value)),{isDirtyModel:l,hasRules:h,hasError:p,errorMessage:g,validate:w,resetValidation:m}}const E=/^on[A-Z]/;function k(e,t){const n={listeners:(0,i.iH)({}),attributes:(0,i.iH)({})};function o(){const r={},i={};for(const t in e)"class"!==t&&"style"!==t&&!1===E.test(t)&&(r[t]=e[t]);for(const e in t.props)!0===E.test(e)&&(i[e]=t.props[e]);n.attributes.value=r,n.listeners.value=i}return(0,r.Xn)(o),o(),n}var T=n(2026);n(5231),n(3075),n(548),n(2279),n(2157),n(6735);let C,I=0;const x=new Array(256);for(let U=0;U<256;U++)x[U]=(U+256).toString(16).substring(1);const A=(()=>{const e="undefined"!==typeof crypto?crypto:"undefined"!==typeof window?window.crypto||window.msCrypto:void 0;if(void 0!==e){if(void 0!==e.randomBytes)return e.randomBytes;if(void 0!==e.getRandomValues)return t=>{const n=new Uint8Array(t);return e.getRandomValues(n),n}}return e=>{const t=[];for(let n=e;n>0;n--)t.push(Math.floor(256*Math.random()));return t}})(),R=4096;function O(){(void 0===C||I+16>R)&&(I=0,C=A(R));const e=Array.prototype.slice.call(C,I,I+=16);return e[6]=15&e[6]|64,e[8]=63&e[8]|128,x[e[0]]+x[e[1]]+x[e[2]]+x[e[3]]+"-"+x[e[4]]+x[e[5]]+"-"+x[e[6]]+x[e[7]]+"-"+x[e[8]]+x[e[9]]+"-"+x[e[10]]+x[e[11]]+x[e[12]]+x[e[13]]+x[e[14]]+x[e[15]]}var N=n(1384),P=n(7026);function F(e){return void 0===e?`f_${O()}`:e}function L(e){return void 0!==e&&null!==e&&0!==(""+e).length}const D={...u.S,..._,label:String,stackLabel:Boolean,hint:String,hideHint:Boolean,prefix:String,suffix:String,labelColor:String,color:String,bgColor:String,filled:Boolean,outlined:Boolean,borderless:Boolean,standout:[Boolean,String],square:Boolean,loading:Boolean,labelSlot:Boolean,bottomSlots:Boolean,hideBottomSpace:Boolean,rounded:Boolean,dense:Boolean,itemAligned:Boolean,counter:Boolean,clearable:Boolean,clearIcon:String,disable:Boolean,readonly:Boolean,autofocus:Boolean,for:String,maxlength:[Number,String]},M=["update:modelValue","clear","focus","blur","popupShow","popupHide"];function q(){const{props:e,attrs:t,proxy:n,vnode:o}=(0,r.FN)(),s=(0,u.Z)(e,n.$q);return{isDark:s,editable:(0,r.Fl)((()=>!0!==e.disable&&!0!==e.readonly)),innerLoading:(0,i.iH)(!1),focused:(0,i.iH)(!1),hasPopupOpen:!1,splitAttrs:k(t,o),targetUid:(0,i.iH)(F(e.for)),rootRef:(0,i.iH)(null),targetRef:(0,i.iH)(null),controlRef:(0,i.iH)(null)}}function V(e){const{props:t,emit:n,slots:i,attrs:u,proxy:c}=(0,r.FN)(),{$q:d}=c;let h=null;void 0===e.hasValue&&(e.hasValue=(0,r.Fl)((()=>L(t.modelValue)))),void 0===e.emitValue&&(e.emitValue=e=>{n("update:modelValue",e)}),void 0===e.controlEvents&&(e.controlEvents={onFocusin:D,onFocusout:M}),Object.assign(e,{clearValue:q,onControlFocusin:D,onControlFocusout:M,focus:R}),void 0===e.computedCounter&&(e.computedCounter=(0,r.Fl)((()=>{if(!1!==t.counter){const e="string"===typeof t.modelValue||"number"===typeof t.modelValue?(""+t.modelValue).length:!0===Array.isArray(t.modelValue)?t.modelValue.length:0,n=void 0!==t.maxlength?t.maxlength:t.maxValues;return e+(void 0!==n?" / "+n:"")}})));const{isDirtyModel:f,hasRules:p,hasError:g,errorMessage:m,resetValidation:v}=S(e.focused,e.innerLoading),y=void 0!==e.floatingLabel?(0,r.Fl)((()=>!0===t.stackLabel||!0===e.focused.value||!0===e.floatingLabel.value)):(0,r.Fl)((()=>!0===t.stackLabel||!0===e.focused.value||!0===e.hasValue.value)),b=(0,r.Fl)((()=>!0===t.bottomSlots||void 0!==t.hint||!0===p.value||!0===t.counter||null!==t.error)),w=(0,r.Fl)((()=>!0===t.filled?"filled":!0===t.outlined?"outlined":!0===t.borderless?"borderless":t.standout?"standout":"standard")),_=(0,r.Fl)((()=>`q-field row no-wrap items-start q-field--${w.value}`+(void 0!==e.fieldClass?` ${e.fieldClass.value}`:"")+(!0===t.rounded?" q-field--rounded":"")+(!0===t.square?" q-field--square":"")+(!0===y.value?" q-field--float":"")+(!0===k.value?" q-field--labeled":"")+(!0===t.dense?" q-field--dense":"")+(!0===t.itemAligned?" q-field--item-aligned q-item-type":"")+(!0===e.isDark.value?" q-field--dark":"")+(void 0===e.getControl?" q-field--auto-height":"")+(!0===e.focused.value?" q-field--focused":"")+(!0===g.value?" q-field--error":"")+(!0===g.value||!0===e.focused.value?" q-field--highlighted":"")+(!0!==t.hideBottomSpace&&!0===b.value?" q-field--with-bottom":"")+(!0===t.disable?" q-field--disabled":!0===t.readonly?" q-field--readonly":""))),E=(0,r.Fl)((()=>"q-field__control relative-position row no-wrap"+(void 0!==t.bgColor?` bg-${t.bgColor}`:"")+(!0===g.value?" text-negative":"string"===typeof t.standout&&0!==t.standout.length&&!0===e.focused.value?` ${t.standout}`:void 0!==t.color?` text-${t.color}`:""))),k=(0,r.Fl)((()=>!0===t.labelSlot||void 0!==t.label)),C=(0,r.Fl)((()=>"q-field__label no-pointer-events absolute ellipsis"+(void 0!==t.labelColor&&!0!==g.value?` text-${t.labelColor}`:""))),I=(0,r.Fl)((()=>({id:e.targetUid.value,editable:e.editable.value,focused:e.focused.value,floatingLabel:y.value,modelValue:t.modelValue,emitValue:e.emitValue}))),x=(0,r.Fl)((()=>{const n={for:e.targetUid.value};return!0===t.disable?n["aria-disabled"]="true":!0===t.readonly&&(n["aria-readonly"]="true"),n}));function A(){const t=document.activeElement;let n=void 0!==e.targetRef&&e.targetRef.value;!n||null!==t&&t.id===e.targetUid.value||(!0===n.hasAttribute("tabindex")||(n=n.querySelector("[tabindex]")),n&&n!==t&&n.focus({preventScroll:!0}))}function R(){(0,P.jd)(A)}function O(){(0,P.fP)(A);const t=document.activeElement;null!==t&&e.rootRef.value.contains(t)&&t.blur()}function D(t){null!==h&&(clearTimeout(h),h=null),!0===e.editable.value&&!1===e.focused.value&&(e.focused.value=!0,n("focus",t))}function M(t,r){null!==h&&clearTimeout(h),h=setTimeout((()=>{h=null,(!0!==document.hasFocus()||!0!==e.hasPopupOpen&&void 0!==e.controlRef&&null!==e.controlRef.value&&!1===e.controlRef.value.contains(document.activeElement))&&(!0===e.focused.value&&(e.focused.value=!1,n("blur",t)),void 0!==r&&r())}))}function q(i){if((0,N.NS)(i),!0!==d.platform.is.mobile){const t=void 0!==e.targetRef&&e.targetRef.value||e.rootRef.value;t.focus()}else!0===e.rootRef.value.contains(document.activeElement)&&document.activeElement.blur();"file"===t.type&&(e.inputRef.value.value=null),n("update:modelValue",null),n("clear",t.modelValue),(0,r.Y3)((()=>{v(),!0!==d.platform.is.mobile&&(f.value=!1)}))}function V(){const n=[];return void 0!==i.prepend&&n.push((0,r.h)("div",{class:"q-field__prepend q-field__marginal row no-wrap items-center",key:"prepend",onClick:N.X$},i.prepend())),n.push((0,r.h)("div",{class:"q-field__control-container col relative-position row no-wrap q-anchor--skip"},U())),!0===g.value&&!1===t.noErrorIcon&&n.push($("error",[(0,r.h)(a.Z,{name:d.iconSet.field.error,color:"negative"})])),!0===t.loading||!0===e.innerLoading.value?n.push($("inner-loading-append",void 0!==i.loading?i.loading():[(0,r.h)(l.Z,{color:t.color})])):!0===t.clearable&&!0===e.hasValue.value&&!0===e.editable.value&&n.push($("inner-clearable-append",[(0,r.h)(a.Z,{class:"q-field__focusable-action",tag:"button",name:t.clearIcon||d.iconSet.field.clear,tabindex:0,type:"button","aria-hidden":null,role:null,onClick:q})])),void 0!==i.append&&n.push((0,r.h)("div",{class:"q-field__append q-field__marginal row no-wrap items-center",key:"append",onClick:N.X$},i.append())),void 0!==e.getInnerAppend&&n.push($("inner-append",e.getInnerAppend())),void 0!==e.getControlChild&&n.push(e.getControlChild()),n}function U(){const n=[];return void 0!==t.prefix&&null!==t.prefix&&n.push((0,r.h)("div",{class:"q-field__prefix no-pointer-events row items-center"},t.prefix)),void 0!==e.getShadowControl&&!0===e.hasShadow.value&&n.push(e.getShadowControl()),void 0!==e.getControl?n.push(e.getControl()):void 0!==i.rawControl?n.push(i.rawControl()):void 0!==i.control&&n.push((0,r.h)("div",{ref:e.targetRef,class:"q-field__native row",tabindex:-1,...e.splitAttrs.attributes.value,"data-autofocus":!0===t.autofocus||void 0},i.control(I.value))),!0===k.value&&n.push((0,r.h)("div",{class:C.value},(0,T.KR)(i.label,t.label))),void 0!==t.suffix&&null!==t.suffix&&n.push((0,r.h)("div",{class:"q-field__suffix no-pointer-events row items-center"},t.suffix)),n.concat((0,T.KR)(i.default))}function B(){let n,s;!0===g.value?null!==m.value?(n=[(0,r.h)("div",{role:"alert"},m.value)],s=`q--slot-error-${m.value}`):(n=(0,T.KR)(i.error),s="q--slot-error"):!0===t.hideHint&&!0!==e.focused.value||(void 0!==t.hint?(n=[(0,r.h)("div",t.hint)],s=`q--slot-hint-${t.hint}`):(n=(0,T.KR)(i.hint),s="q--slot-hint"));const a=!0===t.counter||void 0!==i.counter;if(!0===t.hideBottomSpace&&!1===a&&void 0===n)return;const l=(0,r.h)("div",{key:s,class:"q-field__messages col"},n);return(0,r.h)("div",{class:"q-field__bottom row items-start q-field__bottom--"+(!0!==t.hideBottomSpace?"animated":"stale"),onClick:N.X$},[!0===t.hideBottomSpace?l:(0,r.h)(o.uT,{name:"q-transition--field-message"},(()=>l)),!0===a?(0,r.h)("div",{class:"q-field__counter"},void 0!==i.counter?i.counter():e.computedCounter.value):null])}function $(e,t){return null===t?null:(0,r.h)("div",{key:e,class:"q-field__append q-field__marginal row no-wrap items-center q-anchor--skip"},t)}(0,r.YP)((()=>t.for),(t=>{e.targetUid.value=F(t)}));let j=!1;return(0,r.se)((()=>{j=!0})),(0,r.dl)((()=>{!0===j&&!0===t.autofocus&&c.focus()})),(0,r.bv)((()=>{!0===s.uX.value&&void 0===t.for&&(e.targetUid.value=F()),!0===t.autofocus&&c.focus()})),(0,r.Jd)((()=>{null!==h&&clearTimeout(h)})),Object.assign(c,{focus:R,blur:O}),function(){const n=void 0===e.getControl&&void 0===i.control?{...e.splitAttrs.attributes.value,"data-autofocus":!0===t.autofocus||void 0,...x.value}:x.value;return(0,r.h)("label",{ref:e.rootRef,class:[_.value,u.class],style:u.style,...n},[void 0!==i.before?(0,r.h)("div",{class:"q-field__before q-field__marginal row no-wrap items-center",onClick:N.X$},i.before()):null,(0,r.h)("div",{class:"q-field__inner relative-position col self-stretch"},[(0,r.h)("div",{ref:e.controlRef,class:E.value,tabindex:-1,...e.controlEvents},V()),!0===b.value?B():null]),void 0!==i.after?(0,r.h)("div",{class:"q-field__after q-field__marginal row no-wrap items-center",onClick:N.X$},i.after()):null])}}},7915:(e,t,n)=>{"use strict";n.d(t,{Z:()=>i});var r=n(9835);function i(e,t){function n(){const t=e.modelValue;try{const e="DataTransfer"in window?new DataTransfer:"ClipboardEvent"in window?new ClipboardEvent("").clipboardData:void 0;return Object(t)===t&&("length"in t?Array.from(t):[t]).forEach((t=>{e.items.add(t)})),{files:e.files}}catch(n){return{files:void 0}}}return!0===t?(0,r.Fl)((()=>{if("file"===e.type)return n()})):(0,r.Fl)(n)}},9256:(e,t,n)=>{"use strict";n.d(t,{Do:()=>s,Fz:()=>i,eX:()=>o});var r=n(9835);const i={name:String};function o(e={}){return(t,n,i)=>{t[n]((0,r.h)("input",{class:"hidden"+(i||""),...e.value}))}}function s(e){return(0,r.Fl)((()=>e.name||e.for))}},3929:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>c,fL:()=>u,kM:()=>l});var r=n(9835),i=n(499),o=n(5310),s=n(2046);let a=0;const l={fullscreen:Boolean,noRouteFullscreenExit:Boolean},u=["update:fullscreen","fullscreen"];function c(){const e=(0,r.FN)(),{props:t,emit:n,proxy:l}=e;let u,c,d;const h=(0,i.iH)(!1);function f(){!0===h.value?g():p()}function p(){!0!==h.value&&(h.value=!0,d=l.$el.parentNode,d.replaceChild(c,l.$el),document.body.appendChild(l.$el),a++,1===a&&document.body.classList.add("q-body--fullscreen-mixin"),u={handler:g},o.Z.add(u))}function g(){!0===h.value&&(void 0!==u&&(o.Z.remove(u),u=void 0),d.replaceChild(l.$el,c),h.value=!1,a=Math.max(0,a-1),0===a&&(document.body.classList.remove("q-body--fullscreen-mixin"),void 0!==l.$el.scrollIntoView&&setTimeout((()=>{l.$el.scrollIntoView()}))))}return!0===(0,s.Rb)(e)&&(0,r.YP)((()=>l.$route.fullPath),(()=>{!0!==t.noRouteFullscreenExit&&g()})),(0,r.YP)((()=>t.fullscreen),(e=>{h.value!==e&&f()})),(0,r.YP)(h,(e=>{n("update:fullscreen",e),n("fullscreen",e)})),(0,r.wF)((()=>{c=document.createElement("span")})),(0,r.bv)((()=>{!0===t.fullscreen&&p()})),(0,r.Jd)(g),Object.assign(l,{toggleFullscreen:f,setFullscreen:p,exitFullscreen:g}),{inFullscreen:h,toggleFullscreen:f}}},2802:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l});var r=n(7506);const i=/[\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uff9f\u4e00-\u9faf\u3400-\u4dbf]/,o=/[\u4e00-\u9fff\u3400-\u4dbf\u{20000}-\u{2a6df}\u{2a700}-\u{2b73f}\u{2b740}-\u{2b81f}\u{2b820}-\u{2ceaf}\uf900-\ufaff\u3300-\u33ff\ufe30-\ufe4f\uf900-\ufaff\u{2f800}-\u{2fa1f}]/u,s=/[\u3131-\u314e\u314f-\u3163\uac00-\ud7a3]/,a=/[a-z0-9_ -]$/i;function l(e){return function(t){if("compositionend"===t.type||"change"===t.type){if(!0!==t.target.qComposing)return;t.target.qComposing=!1,e(t)}else if("compositionupdate"===t.type&&!0!==t.target.qComposing&&"string"===typeof t.data){const e=!0===r.client.is.firefox?!1===a.test(t.data):!0===i.test(t.data)||!0===o.test(t.data)||!0===s.test(t.data);!0===e&&(t.target.qComposing=!0)}}}},3842:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>a,gH:()=>s,vr:()=>o});var r=n(9835),i=n(2046);const o={modelValue:{type:Boolean,default:null},"onUpdate:modelValue":[Function,Array]},s=["beforeShow","show","beforeHide","hide"];function a({showing:e,canShow:t,hideOnRouteChange:n,handleShow:o,handleHide:s,processOnMount:a}){const l=(0,r.FN)(),{props:u,emit:c,proxy:d}=l;let h;function f(t){!0===e.value?m(t):p(t)}function p(e){if(!0===u.disable||void 0!==e&&!0===e.qAnchorHandled||void 0!==t&&!0!==t(e))return;const n=void 0!==u["onUpdate:modelValue"];!0===n&&(c("update:modelValue",!0),h=e,(0,r.Y3)((()=>{h===e&&(h=void 0)}))),null!==u.modelValue&&!1!==n||g(e)}function g(t){!0!==e.value&&(e.value=!0,c("beforeShow",t),void 0!==o?o(t):c("show",t))}function m(e){if(!0===u.disable)return;const t=void 0!==u["onUpdate:modelValue"];!0===t&&(c("update:modelValue",!1),h=e,(0,r.Y3)((()=>{h===e&&(h=void 0)}))),null!==u.modelValue&&!1!==t||v(e)}function v(t){!1!==e.value&&(e.value=!1,c("beforeHide",t),void 0!==s?s(t):c("hide",t))}function y(t){if(!0===u.disable&&!0===t)void 0!==u["onUpdate:modelValue"]&&c("update:modelValue",!1);else if(!0===t!==e.value){const e=!0===t?g:v;e(h)}}(0,r.YP)((()=>u.modelValue),y),void 0!==n&&!0===(0,i.Rb)(l)&&(0,r.YP)((()=>d.$route.fullPath),(()=>{!0===n.value&&!0===e.value&&m()})),!0===a&&(0,r.bv)((()=>{y(u.modelValue)}));const b={show:p,hide:m,toggle:f};return Object.assign(d,b),b}},3936:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>k,vZ:()=>w,K6:()=>E,t6:()=>S});var r=n(9835),i=n(499),o=n(1957),s=n(7506),a=n(5987);const l={left:!0,right:!0,up:!0,down:!0,horizontal:!0,vertical:!0},u=Object.keys(l);function c(e){const t={};for(const n of u)!0===e[n]&&(t[n]=!0);return 0===Object.keys(t).length?l:(!0===t.horizontal?t.left=t.right=!0:!0===t.left&&!0===t.right&&(t.horizontal=!0),!0===t.vertical?t.up=t.down=!0:!0===t.up&&!0===t.down&&(t.vertical=!0),!0===t.horizontal&&!0===t.vertical&&(t.all=!0),t)}l.all=!0;const d=["INPUT","TEXTAREA"];function h(e,t){return void 0===t.event&&void 0!==e.target&&!0!==e.target.draggable&&"function"===typeof t.handler&&!1===d.includes(e.target.nodeName.toUpperCase())&&(void 0===e.qClonedBy||-1===e.qClonedBy.indexOf(t.uid))}var f=n(1384),p=n(2589);function g(e){const t=[.06,6,50];return"string"===typeof e&&e.length&&e.split(":").forEach(((e,n)=>{const r=parseFloat(e);r&&(t[n]=r)})),t}const m=(0,a.f)({name:"touch-swipe",beforeMount(e,{value:t,arg:n,modifiers:r}){if(!0!==r.mouse&&!0!==s.client.has.touch)return;const i=!0===r.mouseCapture?"Capture":"",o={handler:t,sensitivity:g(n),direction:c(r),noop:f.ZT,mouseStart(e){h(e,o)&&(0,f.du)(e)&&((0,f.M0)(o,"temp",[[document,"mousemove","move",`notPassive${i}`],[document,"mouseup","end","notPassiveCapture"]]),o.start(e,!0))},touchStart(e){if(h(e,o)){const t=e.target;(0,f.M0)(o,"temp",[[t,"touchmove","move","notPassiveCapture"],[t,"touchcancel","end","notPassiveCapture"],[t,"touchend","end","notPassiveCapture"]]),o.start(e)}},start(t,n){!0===s.client.is.firefox&&(0,f.Jf)(e,!0);const r=(0,f.FK)(t);o.event={x:r.left,y:r.top,time:Date.now(),mouse:!0===n,dir:!1}},move(e){if(void 0===o.event)return;if(!1!==o.event.dir)return void(0,f.NS)(e);const t=Date.now()-o.event.time;if(0===t)return;const n=(0,f.FK)(e),r=n.left-o.event.x,i=Math.abs(r),s=n.top-o.event.y,a=Math.abs(s);if(!0!==o.event.mouse){if(i<o.sensitivity[1]&&a<o.sensitivity[1])return void o.end(e)}else{if(""!==window.getSelection().toString())return void o.end(e);if(i<o.sensitivity[2]&&a<o.sensitivity[2])return}const l=i/t,u=a/t;!0===o.direction.vertical&&i<a&&i<100&&u>o.sensitivity[0]&&(o.event.dir=s<0?"up":"down"),!0===o.direction.horizontal&&i>a&&a<100&&l>o.sensitivity[0]&&(o.event.dir=r<0?"left":"right"),!0===o.direction.up&&i<a&&s<0&&i<100&&u>o.sensitivity[0]&&(o.event.dir="up"),!0===o.direction.down&&i<a&&s>0&&i<100&&u>o.sensitivity[0]&&(o.event.dir="down"),!0===o.direction.left&&i>a&&r<0&&a<100&&l>o.sensitivity[0]&&(o.event.dir="left"),!0===o.direction.right&&i>a&&r>0&&a<100&&l>o.sensitivity[0]&&(o.event.dir="right"),!1!==o.event.dir?((0,f.NS)(e),!0===o.event.mouse&&(document.body.classList.add("no-pointer-events--children"),document.body.classList.add("non-selectable"),(0,p.M)(),o.styleCleanup=e=>{o.styleCleanup=void 0,document.body.classList.remove("non-selectable");const t=()=>{document.body.classList.remove("no-pointer-events--children")};!0===e?setTimeout(t,50):t()}),o.handler({evt:e,touch:!0!==o.event.mouse,mouse:o.event.mouse,direction:o.event.dir,duration:t,distance:{x:i,y:a}})):o.end(e)},end(t){void 0!==o.event&&((0,f.ul)(o,"temp"),!0===s.client.is.firefox&&(0,f.Jf)(e,!1),void 0!==o.styleCleanup&&o.styleCleanup(!0),void 0!==t&&!1!==o.event.dir&&(0,f.NS)(t),o.event=void 0)}};if(e.__qtouchswipe=o,!0===r.mouse){const t=!0===r.mouseCapture||!0===r.mousecapture?"Capture":"";(0,f.M0)(o,"main",[[e,"mousedown","mouseStart",`passive${t}`]])}!0===s.client.has.touch&&(0,f.M0)(o,"main",[[e,"touchstart","touchStart","passive"+(!0===r.capture?"Capture":"")],[e,"touchmove","noop","notPassiveCapture"]])},updated(e,t){const n=e.__qtouchswipe;void 0!==n&&(t.oldValue!==t.value&&("function"!==typeof t.value&&n.end(),n.handler=t.value),n.direction=c(t.modifiers))},beforeUnmount(e){const t=e.__qtouchswipe;void 0!==t&&((0,f.ul)(t,"main"),(0,f.ul)(t,"temp"),!0===s.client.is.firefox&&(0,f.Jf)(e,!1),void 0!==t.styleCleanup&&t.styleCleanup(),delete e.__qtouchswipe)}});function v(){const e=new Map;return{getCache:function(t,n){return void 0===e[t]?e[t]=n:e[t]},getCacheWithFn:function(t,n){return void 0===e[t]?e[t]=n():e[t]}}}var y=n(2026),b=n(2046);const w={name:{required:!0},disable:Boolean},_={setup(e,{slots:t}){return()=>(0,r.h)("div",{class:"q-panel scroll",role:"tabpanel"},(0,y.KR)(t.default))}},S={modelValue:{required:!0},animated:Boolean,infinite:Boolean,swipeable:Boolean,vertical:Boolean,transitionPrev:String,transitionNext:String,transitionDuration:{type:[String,Number],default:300},keepAlive:Boolean,keepAliveInclude:[String,Array,RegExp],keepAliveExclude:[String,Array,RegExp],keepAliveMax:Number},E=["update:modelValue","beforeTransition","transition"];function k(){const{props:e,emit:t,proxy:n}=(0,r.FN)(),{getCacheWithFn:s}=v();let a,l;const u=(0,i.iH)(null),c=(0,i.iH)(null);function d(t){const r=!0===e.vertical?"up":"left";O((!0===n.$q.lang.rtl?-1:1)*(t.direction===r?1:-1))}const h=(0,r.Fl)((()=>[[m,d,void 0,{horizontal:!0!==e.vertical,vertical:e.vertical,mouse:!0}]])),f=(0,r.Fl)((()=>e.transitionPrev||"slide-"+(!0===e.vertical?"down":"right"))),p=(0,r.Fl)((()=>e.transitionNext||"slide-"+(!0===e.vertical?"up":"left"))),g=(0,r.Fl)((()=>`--q-transition-duration: ${e.transitionDuration}ms`)),w=(0,r.Fl)((()=>"string"===typeof e.modelValue||"number"===typeof e.modelValue?e.modelValue:String(e.modelValue))),S=(0,r.Fl)((()=>({include:e.keepAliveInclude,exclude:e.keepAliveExclude,max:e.keepAliveMax}))),E=(0,r.Fl)((()=>void 0!==e.keepAliveInclude||void 0!==e.keepAliveExclude));function k(){O(1)}function T(){O(-1)}function C(e){t("update:modelValue",e)}function I(e){return void 0!==e&&null!==e&&""!==e}function x(e){return a.findIndex((t=>t.props.name===e&&""!==t.props.disable&&!0!==t.props.disable))}function A(){return a.filter((e=>""!==e.props.disable&&!0!==e.props.disable))}function R(t){const n=0!==t&&!0===e.animated&&-1!==u.value?"q-transition--"+(-1===t?f.value:p.value):null;c.value!==n&&(c.value=n)}function O(n,r=u.value){let i=r+n;while(i>-1&&i<a.length){const e=a[i];if(void 0!==e&&""!==e.props.disable&&!0!==e.props.disable)return R(n),l=!0,t("update:modelValue",e.props.name),void setTimeout((()=>{l=!1}));i+=n}!0===e.infinite&&0!==a.length&&-1!==r&&r!==a.length&&O(n,-1===n?a.length:-1)}function N(){const t=x(e.modelValue);return u.value!==t&&(u.value=t),!0}function P(){const t=!0===I(e.modelValue)&&N()&&a[u.value];return!0===e.keepAlive?[(0,r.h)(r.Ob,S.value,[(0,r.h)(!0===E.value?s(w.value,(()=>({..._,name:w.value}))):_,{key:w.value,style:g.value},(()=>t))])]:[(0,r.h)("div",{class:"q-panel scroll",style:g.value,key:w.value,role:"tabpanel"},[t])]}function F(){if(0!==a.length)return!0===e.animated?[(0,r.h)(o.uT,{name:c.value},P)]:P()}function L(e){return a=(0,b.Pf)((0,y.KR)(e.default,[])).filter((e=>null!==e.props&&void 0===e.props.slot&&!0===I(e.props.name))),a.length}function D(){return a}return(0,r.YP)((()=>e.modelValue),((e,n)=>{const i=!0===I(e)?x(e):-1;!0!==l&&R(-1===i?0:i<x(n)?-1:1),u.value!==i&&(u.value=i,t("beforeTransition",e,n),(0,r.Y3)((()=>{t("transition",e,n)})))})),Object.assign(n,{next:k,previous:T,goTo:C}),{panelIndex:u,panelDirectives:h,updatePanelsList:L,updatePanelIndex:N,getPanelContent:F,getEnabledPanels:A,getPanels:D,isValidPanelName:I,keepAliveProps:S,needsUniqueKeepAliveWrapper:E,goToPanelByOffset:O,goToPanel:C,nextPanel:k,previousPanel:T}}},1518:(e,t,n)=>{"use strict";n.d(t,{Z:()=>c});n(9665);var r=n(499),i=n(9835),o=(n(1384),n(7026)),s=n(6669),a=n(2909),l=n(3251);function u(e){e=e.parent;while(void 0!==e&&null!==e){if("QGlobalDialog"===e.type.name)return!0;if("QDialog"===e.type.name||"QMenu"===e.type.name)return!1;e=e.parent}return!1}function c(e,t,n,c){const d=(0,r.iH)(!1),h=(0,r.iH)(!1);let f=null;const p={},g="dialog"===c&&u(e);function m(t){if(!0===t)return(0,o.xF)(p),void(h.value=!0);h.value=!1,!1===d.value&&(!1===g&&null===f&&(f=(0,s.q_)(!1,c)),d.value=!0,a.Q$.push(e.proxy),(0,o.YX)(p))}function v(t){if(h.value=!1,!0!==t)return;(0,o.xF)(p),d.value=!1;const n=a.Q$.indexOf(e.proxy);-1!==n&&a.Q$.splice(n,1),null!==f&&((0,s.pB)(f),f=null)}return(0,i.Ah)((()=>{v(!0)})),e.proxy.__qPortal=!0,(0,l.g)(e.proxy,"contentEl",(()=>t.value)),{showPortal:m,hidePortal:v,portalIsActive:d,portalIsAccessible:h,renderPortal:()=>!0===g?n():!0===d.value?[(0,i.h)(i.lR,{to:f},n())]:void 0}}},945:(e,t,n)=>{"use strict";n.d(t,{$:()=>d,Z:()=>h});var r=n(9835),i=n(2046);function o(e){return e?e.aliasOf?e.aliasOf.path:e.path:""}function s(e,t){return(e.aliasOf||e)===(t.aliasOf||t)}function a(e,t){for(const n in t){const r=t[n],i=e[n];if("string"===typeof r){if(r!==i)return!1}else if(!1===Array.isArray(i)||i.length!==r.length||r.some(((e,t)=>e!==i[t])))return!1}return!0}function l(e,t){return!0===Array.isArray(t)?e.length===t.length&&e.every(((e,n)=>e===t[n])):1===e.length&&e[0]===t}function u(e,t){return!0===Array.isArray(e)?l(e,t):!0===Array.isArray(t)?l(t,e):e===t}function c(e,t){if(Object.keys(e).length!==Object.keys(t).length)return!1;for(const n in e)if(!1===u(e[n],t[n]))return!1;return!0}const d={to:[String,Object],replace:Boolean,exact:Boolean,activeClass:{type:String,default:"q-router-link--active"},exactActiveClass:{type:String,default:"q-router-link--exact-active"},href:String,target:String,disable:Boolean};function h({fallbackTag:e,useDisableForRouterLinkProps:t=!0}={}){const n=(0,r.FN)(),{props:l,proxy:u,emit:d}=n,h=(0,i.Rb)(n),f=(0,r.Fl)((()=>!0!==l.disable&&void 0!==l.href)),p=!0===t?(0,r.Fl)((()=>!0===h&&!0!==l.disable&&!0!==f.value&&void 0!==l.to&&null!==l.to&&""!==l.to)):(0,r.Fl)((()=>!0===h&&!0!==f.value&&void 0!==l.to&&null!==l.to&&""!==l.to)),g=(0,r.Fl)((()=>!0===p.value?k(l.to):null)),m=(0,r.Fl)((()=>null!==g.value)),v=(0,r.Fl)((()=>!0===f.value||!0===m.value)),y=(0,r.Fl)((()=>"a"===l.type||!0===v.value?"a":l.tag||e||"div")),b=(0,r.Fl)((()=>!0===f.value?{href:l.href,target:l.target}:!0===m.value?{href:g.value.href,target:l.target}:{})),w=(0,r.Fl)((()=>{if(!1===m.value)return-1;const{matched:e}=g.value,{length:t}=e,n=e[t-1];if(void 0===n)return-1;const r=u.$route.matched;if(0===r.length)return-1;const i=r.findIndex(s.bind(null,n));if(i>-1)return i;const a=o(e[t-2]);return t>1&&o(n)===a&&r[r.length-1].path!==a?r.findIndex(s.bind(null,e[t-2])):i})),_=(0,r.Fl)((()=>!0===m.value&&-1!==w.value&&a(u.$route.params,g.value.params))),S=(0,r.Fl)((()=>!0===_.value&&w.value===u.$route.matched.length-1&&c(u.$route.params,g.value.params))),E=(0,r.Fl)((()=>!0===m.value?!0===S.value?` ${l.exactActiveClass} ${l.activeClass}`:!0===l.exact?"":!0===_.value?` ${l.activeClass}`:"":""));function k(e){try{return u.$router.resolve(e)}catch(t){}return null}function T(e,{returnRouterError:t,to:n=l.to,replace:r=l.replace}={}){if(!0===l.disable)return e.preventDefault(),Promise.resolve(!1);if(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey||void 0!==e.button&&0!==e.button||"_blank"===l.target)return Promise.resolve(!1);e.preventDefault();const i=u.$router[!0===r?"replace":"push"](n);return!0===t?i:i.then((()=>{})).catch((()=>{}))}function C(e){if(!0===m.value){const t=t=>T(e,t);d("click",e,t),!0!==e.defaultPrevented&&t()}else d("click",e)}return{hasRouterLink:m,hasHrefLink:f,hasLink:v,linkTag:y,resolvedLink:g,linkIsActive:_,linkIsExactActive:S,linkClass:E,linkAttrs:b,getLink:k,navigateToRouterLink:T,navigateOnClick:C}}},4088:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(499),i=n(9835),o=n(1384);function s(e,t){const n=(0,r.iH)(null);let s;function a(e,t){const n=(void 0!==t?"add":"remove")+"EventListener",r=void 0!==t?t:s;e!==window&&e[n]("scroll",r,o.listenOpts.passive),window[n]("scroll",r,o.listenOpts.passive),s=t}function l(){null!==n.value&&(a(n.value),n.value=null)}const u=(0,i.YP)((()=>e.noParentEvent),(()=>{null!==n.value&&(l(),t())}));return(0,i.Jd)(u),{localScrollTarget:n,unconfigureScrollTarget:l,changeScrollEvent:a}}},244:(e,t,n)=>{"use strict";n.d(t,{LU:()=>o,Ok:()=>i,ZP:()=>s});var r=n(9835);const i={xs:18,sm:24,md:32,lg:38,xl:46},o={size:String};function s(e,t=i){return(0,r.Fl)((()=>void 0!==e.size?{fontSize:e.size in t?`${t[e.size]}px`:e.size}:null))}},6916:(e,t,n)=>{"use strict";n.d(t,{Z:()=>o});var r=n(9835),i=n(2046);function o(){let e;const t=(0,r.FN)();function n(){e=void 0}return(0,r.se)(n),(0,r.Jd)(n),{removeTick:n,registerTick(n){e=n,(0,r.Y3)((()=>{e===n&&(!1===(0,i.$D)(t)&&e(),e=void 0)}))}}}},2695:(e,t,n)=>{"use strict";n.d(t,{Z:()=>o});var r=n(9835),i=n(2046);function o(){let e=null;const t=(0,r.FN)();function n(){null!==e&&(clearTimeout(e),e=null)}return(0,r.se)(n),(0,r.Jd)(n),{removeTimeout:n,registerTimeout(r,o){n(e),!1===(0,i.$D)(t)&&(e=setTimeout(r,o))}}}},431:(e,t,n)=>{"use strict";n.d(t,{D:()=>i,Z:()=>o});var r=n(9835);const i={transitionShow:{type:String,default:"fade"},transitionHide:{type:String,default:"fade"},transitionDuration:{type:[String,Number],default:300}};function o(e,t=(()=>{}),n=(()=>{})){return{transitionProps:(0,r.Fl)((()=>{const r=`q-transition--${e.transitionShow||t()}`,i=`q-transition--${e.transitionHide||n()}`;return{appear:!0,enterFromClass:`${r}-enter-from`,enterActiveClass:`${r}-enter-active`,enterToClass:`${r}-enter-to`,leaveFromClass:`${i}-leave-from`,leaveActiveClass:`${i}-leave-active`,leaveToClass:`${i}-leave-to`}})),transitionStyle:(0,r.Fl)((()=>`--q-transition-duration: ${e.transitionDuration}ms`))}}},9302:(e,t,n)=>{"use strict";n.d(t,{Z:()=>o});var r=n(9835),i=n(5439);function o(){return(0,r.f3)(i.Ng)}},2146:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(5987),i=n(2909),o=n(1705);function s(e){if(!1===e)return 0;if(!0===e||void 0===e)return 1;const t=parseInt(e,10);return isNaN(t)?0:t}const a=(0,r.f)({name:"close-popup",beforeMount(e,{value:t}){const n={depth:s(t),handler(t){0!==n.depth&&setTimeout((()=>{const r=(0,i.je)(e);void 0!==r&&(0,i.S7)(r,t,n.depth)}))},handlerKey(e){!0===(0,o.So)(e,13)&&n.handler(e)}};e.__qclosepopup=n,e.addEventListener("click",n.handler),e.addEventListener("keyup",n.handlerKey)},updated(e,{value:t,oldValue:n}){t!==n&&(e.__qclosepopup.depth=s(t))},beforeUnmount(e){const t=e.__qclosepopup;e.removeEventListener("click",t.handler),e.removeEventListener("keyup",t.handlerKey),delete e.__qclosepopup}})},1136:(e,t,n)=>{"use strict";n.d(t,{Z:()=>c});n(9665);var r=n(5987),i=n(223),o=n(1384),s=n(1705);function a(e,t=250){let n,r=!1;return function(){return!1===r&&(r=!0,setTimeout((()=>{r=!1}),t),n=e.apply(this,arguments)),n}}function l(e,t,n,r){!0===n.modifiers.stop&&(0,o.sT)(e);const s=n.modifiers.color;let a=n.modifiers.center;a=!0===a||!0===r;const l=document.createElement("span"),u=document.createElement("span"),c=(0,o.FK)(e),{left:d,top:h,width:f,height:p}=t.getBoundingClientRect(),g=Math.sqrt(f*f+p*p),m=g/2,v=(f-g)/2+"px",y=a?v:c.left-d-m+"px",b=(p-g)/2+"px",w=a?b:c.top-h-m+"px";u.className="q-ripple__inner",(0,i.iv)(u,{height:`${g}px`,width:`${g}px`,transform:`translate3d(${y},${w},0) scale3d(.2,.2,1)`,opacity:0}),l.className="q-ripple"+(s?" text-"+s:""),l.setAttribute("dir","ltr"),l.appendChild(u),t.appendChild(l);const _=()=>{l.remove(),clearTimeout(S)};n.abort.push(_);let S=setTimeout((()=>{u.classList.add("q-ripple__inner--enter"),u.style.transform=`translate3d(${v},${b},0) scale3d(1,1,1)`,u.style.opacity=.2,S=setTimeout((()=>{u.classList.remove("q-ripple__inner--enter"),u.classList.add("q-ripple__inner--leave"),u.style.opacity=0,S=setTimeout((()=>{l.remove(),n.abort.splice(n.abort.indexOf(_),1)}),275)}),250)}),50)}function u(e,{modifiers:t,value:n,arg:r}){const i=Object.assign({},e.cfg.ripple,t,n);e.modifiers={early:!0===i.early,stop:!0===i.stop,center:!0===i.center,color:i.color||r,keyCodes:[].concat(i.keyCodes||13)}}const c=(0,r.f)({name:"ripple",beforeMount(e,t){const n=t.instance.$.appContext.config.globalProperties.$q.config||{};if(!1===n.ripple)return;const r={cfg:n,enabled:!1!==t.value,modifiers:{},abort:[],start(t){!0===r.enabled&&!0!==t.qSkipRipple&&t.type===(!0===r.modifiers.early?"pointerdown":"click")&&l(t,e,r,!0===t.qKeyEvent)},keystart:a((t=>{!0===r.enabled&&!0!==t.qSkipRipple&&!0===(0,s.So)(t,r.modifiers.keyCodes)&&t.type==="key"+(!0===r.modifiers.early?"down":"up")&&l(t,e,r,!0)}),300)};u(r,t),e.__qripple=r,(0,o.M0)(r,"main",[[e,"pointerdown","start","passive"],[e,"click","start","passive"],[e,"keydown","keystart","passive"],[e,"keyup","keystart","passive"]])},updated(e,t){if(t.oldValue!==t.value){const n=e.__qripple;void 0!==n&&(n.enabled=!1!==t.value,!0===n.enabled&&Object(t.value)===t.value&&u(n,t))}},beforeUnmount(e){const t=e.__qripple;void 0!==t&&(t.abort.forEach((e=>{e()})),(0,o.ul)(t,"main"),delete e._qripple)}})},5310:(e,t,n)=>{"use strict";n.d(t,{Z:()=>u});n(9665);var r=n(7506),i=n(1384);const o=()=>!0;function s(e){return"string"===typeof e&&""!==e&&"/"!==e&&"#/"!==e}function a(e){return!0===e.startsWith("#")&&(e=e.substring(1)),!1===e.startsWith("/")&&(e="/"+e),!0===e.endsWith("/")&&(e=e.substring(0,e.length-1)),"#"+e}function l(e){if(!1===e.backButtonExit)return()=>!1;if("*"===e.backButtonExit)return o;const t=["#/"];return!0===Array.isArray(e.backButtonExit)&&t.push(...e.backButtonExit.filter(s).map(a)),()=>t.includes(window.location.hash)}const u={__history:[],add:i.ZT,remove:i.ZT,install({$q:e}){if(!0===this.__installed)return;const{cordova:t,capacitor:n}=r.client.is;if(!0!==t&&!0!==n)return;const i=e.config[!0===t?"cordova":"capacitor"];if(void 0!==i&&!1===i.backButton)return;if(!0===n&&(void 0===window.Capacitor||void 0===window.Capacitor.Plugins.App))return;this.add=e=>{void 0===e.condition&&(e.condition=o),this.__history.push(e)},this.remove=e=>{const t=this.__history.indexOf(e);t>=0&&this.__history.splice(t,1)};const s=l(Object.assign({backButtonExit:!0},i)),a=()=>{if(this.__history.length){const e=this.__history[this.__history.length-1];!0===e.condition()&&(this.__history.pop(),e.handler())}else!0===s()?navigator.app.exitApp():window.history.back()};!0===t?document.addEventListener("deviceready",(()=>{document.addEventListener("backbutton",a,!1)})):window.Capacitor.Plugins.App.addListener("backButton",a)}}},2289:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(4124),i=n(3251);const o={name:"material-icons",type:{positive:"check_circle",negative:"warning",info:"info",warning:"priority_high"},arrow:{up:"arrow_upward",right:"arrow_forward",down:"arrow_downward",left:"arrow_back",dropdown:"arrow_drop_down"},chevron:{left:"chevron_left",right:"chevron_right"},colorPicker:{spectrum:"gradient",tune:"tune",palette:"style"},pullToRefresh:{icon:"refresh"},carousel:{left:"chevron_left",right:"chevron_right",up:"keyboard_arrow_up",down:"keyboard_arrow_down",navigationIcon:"lens"},chip:{remove:"cancel",selected:"check"},datetime:{arrowLeft:"chevron_left",arrowRight:"chevron_right",now:"access_time",today:"today"},editor:{bold:"format_bold",italic:"format_italic",strikethrough:"strikethrough_s",underline:"format_underlined",unorderedList:"format_list_bulleted",orderedList:"format_list_numbered",subscript:"vertical_align_bottom",superscript:"vertical_align_top",hyperlink:"link",toggleFullscreen:"fullscreen",quote:"format_quote",left:"format_align_left",center:"format_align_center",right:"format_align_right",justify:"format_align_justify",print:"print",outdent:"format_indent_decrease",indent:"format_indent_increase",removeFormat:"format_clear",formatting:"text_format",fontSize:"format_size",align:"format_align_left",hr:"remove",undo:"undo",redo:"redo",heading:"format_size",code:"code",size:"format_size",font:"font_download",viewSource:"code"},expansionItem:{icon:"keyboard_arrow_down",denseIcon:"arrow_drop_down"},fab:{icon:"add",activeIcon:"close"},field:{clear:"cancel",error:"error"},pagination:{first:"first_page",prev:"keyboard_arrow_left",next:"keyboard_arrow_right",last:"last_page"},rating:{icon:"grade"},stepper:{done:"check",active:"edit",error:"warning"},tabs:{left:"chevron_left",right:"chevron_right",up:"keyboard_arrow_up",down:"keyboard_arrow_down"},table:{arrowUp:"arrow_upward",warning:"warning",firstPage:"first_page",prevPage:"chevron_left",nextPage:"chevron_right",lastPage:"last_page"},tree:{icon:"play_arrow"},uploader:{done:"done",clear:"clear",add:"add_box",upload:"cloud_upload",removeQueue:"clear_all",removeUploaded:"done_all"}},s=(0,r.Z)({iconMapFn:null,__icons:{}},{set(e,t){const n={...e,rtl:!0===e.rtl};n.set=s.set,Object.assign(s.__icons,n)},install({$q:e,iconSet:t,ssrContext:n}){void 0!==e.config.iconMapFn&&(this.iconMapFn=e.config.iconMapFn),e.iconSet=this.__icons,(0,i.g)(e,"iconMapFn",(()=>this.iconMapFn),(e=>{this.iconMapFn=e})),!0===this.__installed?void 0!==t&&this.set(t):this.set(t||o)}}),a=s},7451:(e,t,n)=>{"use strict";n.d(t,{$:()=>I,Z:()=>R});var r=n(1957),i=n(7506),o=(n(9665),n(4124)),s=n(1384),a=n(899);const l=["sm","md","lg","xl"],{passive:u}=s.listenOpts,c=(0,o.Z)({width:0,height:0,name:"xs",sizes:{sm:600,md:1024,lg:1440,xl:1920},lt:{sm:!0,md:!0,lg:!0,xl:!0},gt:{xs:!1,sm:!1,md:!1,lg:!1},xs:!0,sm:!1,md:!1,lg:!1,xl:!1},{setSizes:s.ZT,setDebounce:s.ZT,install({$q:e,onSSRHydrated:t}){if(e.screen=this,!0===this.__installed)return void(void 0!==e.config.screen&&(!1===e.config.screen.bodyClasses?document.body.classList.remove(`screen--${this.name}`):this.__update(!0)));const{visualViewport:n}=window,r=n||window,o=document.scrollingElement||document.documentElement,s=void 0===n||!0===i.client.is.mobile?()=>[Math.max(window.innerWidth,o.clientWidth),Math.max(window.innerHeight,o.clientHeight)]:()=>[n.width*n.scale+window.innerWidth-o.clientWidth,n.height*n.scale+window.innerHeight-o.clientHeight],c=void 0!==e.config.screen&&!0===e.config.screen.bodyClasses;this.__update=e=>{const[t,n]=s();if(n!==this.height&&(this.height=n),t!==this.width)this.width=t;else if(!0!==e)return;let r=this.sizes;this.gt.xs=t>=r.sm,this.gt.sm=t>=r.md,this.gt.md=t>=r.lg,this.gt.lg=t>=r.xl,this.lt.sm=t<r.sm,this.lt.md=t<r.md,this.lt.lg=t<r.lg,this.lt.xl=t<r.xl,this.xs=this.lt.sm,this.sm=!0===this.gt.xs&&!0===this.lt.md,this.md=!0===this.gt.sm&&!0===this.lt.lg,this.lg=!0===this.gt.md&&!0===this.lt.xl,this.xl=this.gt.lg,r=(!0===this.xs?"xs":!0===this.sm&&"sm")||!0===this.md&&"md"||!0===this.lg&&"lg"||"xl",r!==this.name&&(!0===c&&(document.body.classList.remove(`screen--${this.name}`),document.body.classList.add(`screen--${r}`)),this.name=r)};let d,h={},f=16;this.setSizes=e=>{l.forEach((t=>{void 0!==e[t]&&(h[t]=e[t])}))},this.setDebounce=e=>{f=e};const p=()=>{const e=getComputedStyle(document.body);e.getPropertyValue("--q-size-sm")&&l.forEach((t=>{this.sizes[t]=parseInt(e.getPropertyValue(`--q-size-${t}`),10)})),this.setSizes=e=>{l.forEach((t=>{e[t]&&(this.sizes[t]=e[t])})),this.__update(!0)},this.setDebounce=e=>{void 0!==d&&r.removeEventListener("resize",d,u),d=e>0?(0,a.Z)(this.__update,e):this.__update,r.addEventListener("resize",d,u)},this.setDebounce(f),0!==Object.keys(h).length?(this.setSizes(h),h=void 0):this.__update(),!0===c&&"xs"===this.name&&document.body.classList.add("screen--xs")};!0===i.uX.value?t.push(p):p()}}),d=(0,o.Z)({isActive:!1,mode:!1},{__media:void 0,set(e){d.mode=e,"auto"===e?(void 0===d.__media&&(d.__media=window.matchMedia("(prefers-color-scheme: dark)"),d.__updateMedia=()=>{d.set("auto")},d.__media.addListener(d.__updateMedia)),e=d.__media.matches):void 0!==d.__media&&(d.__media.removeListener(d.__updateMedia),d.__media=void 0),d.isActive=!0===e,document.body.classList.remove("body--"+(!0===e?"light":"dark")),document.body.classList.add("body--"+(!0===e?"dark":"light"))},toggle(){d.set(!1===d.isActive)},install({$q:e,onSSRHydrated:t,ssrContext:n}){const{dark:r}=e.config;if(e.dark=this,!0===this.__installed&&void 0===r)return;this.isActive=!0===r;const o=void 0!==r&&r;if(!0===i.uX.value){const e=e=>{this.__fromSSR=e},n=this.set;this.set=e,e(o),t.push((()=>{this.set=n,this.set(this.__fromSSR)}))}else this.set(o)}}),h=d;var f=n(5310),p=n(3558);function g(e,t,n=document.body){if("string"!==typeof e)throw new TypeError("Expected a string as propName");if("string"!==typeof t)throw new TypeError("Expected a string as value");if(!(n instanceof Element))throw new TypeError("Expected a DOM element");n.style.setProperty(`--q-${e}`,t)}var m=n(1705);function v(e){return!0===e.ios?"ios":!0===e.android?"android":void 0}function y({is:e,has:t,within:n},r){const i=[!0===e.desktop?"desktop":"mobile",(!1===t.touch?"no-":"")+"touch"];if(!0===e.mobile){const t=v(e);void 0!==t&&i.push("platform-"+t)}if(!0===e.nativeMobile){const t=e.nativeMobileWrapper;i.push(t),i.push("native-mobile"),!0!==e.ios||void 0!==r[t]&&!1===r[t].iosStatusBarPadding||i.push("q-ios-padding")}else!0===e.electron?i.push("electron"):!0===e.bex&&i.push("bex");return!0===n.iframe&&i.push("within-iframe"),i}function b(){const{is:e}=i.client,t=document.body.className,n=new Set(t.replace(/ {2}/g," ").split(" "));if(void 0!==i.aG)n.delete("desktop"),n.add("platform-ios"),n.add("mobile");else if(!0!==e.nativeMobile&&!0!==e.electron&&!0!==e.bex)if(!0===e.desktop)n.delete("mobile"),n.delete("platform-ios"),n.delete("platform-android"),n.add("desktop");else if(!0===e.mobile){n.delete("desktop"),n.add("mobile");const t=v(e);void 0!==t?(n.add(`platform-${t}`),n.delete("platform-"+("ios"===t?"android":"ios"))):(n.delete("platform-ios"),n.delete("platform-android"))}!0===i.client.has.touch&&(n.delete("no-touch"),n.add("touch")),!0===i.client.within.iframe&&n.add("within-iframe");const r=Array.from(n).join(" ");t!==r&&(document.body.className=r)}function w(e){for(const t in e)g(t,e[t])}const _={install(e){if(!0!==this.__installed){if(!0===i.uX.value)b();else{const{$q:t}=e;void 0!==t.config.brand&&w(t.config.brand);const n=y(i.client,t.config);document.body.classList.add.apply(document.body.classList,n)}!0===i.client.is.ios&&document.body.addEventListener("touchstart",s.ZT),window.addEventListener("keydown",m.ZK,!0)}}};var S=n(2289),E=n(5439),k=n(7495),T=n(4680);const C=[i.ZP,_,h,c,f.Z,p.Z,S.Z];function I(e,t){const n=(0,r.ri)(e);n.config.globalProperties=t.config.globalProperties;const{reload:i,...o}=t._context;return Object.assign(n._context,o),n}function x(e,t){t.forEach((t=>{t.install(e),t.__installed=!0}))}function A(e,t,n){e.config.globalProperties.$q=n.$q,e.provide(E.Ng,n.$q),x(n,C),void 0!==t.components&&Object.values(t.components).forEach((t=>{!0===(0,T.Kn)(t)&&void 0!==t.name&&e.component(t.name,t)})),void 0!==t.directives&&Object.values(t.directives).forEach((t=>{!0===(0,T.Kn)(t)&&void 0!==t.name&&e.directive(t.name,t)})),void 0!==t.plugins&&x(n,Object.values(t.plugins).filter((e=>"function"===typeof e.install&&!1===C.includes(e)))),!0===i.uX.value&&(n.$q.onSSRHydrated=()=>{n.onSSRHydrated.forEach((e=>{e()})),n.$q.onSSRHydrated=()=>{}})}const R=function(e,t={}){const n={version:"2.12.0"};!1===k.Uf?(void 0!==t.config&&Object.assign(k.w6,t.config),n.config={...k.w6},(0,k.tP)()):n.config=t.config||{},A(e,t,{parentApp:e,$q:n,lang:t.lang,iconSet:t.iconSet,onSSRHydrated:[]})}},3558:(e,t,n)=>{"use strict";n.d(t,{Z:()=>a});var r=n(4124);const i={isoName:"en-US",nativeName:"English (US)",label:{clear:"Clear",ok:"OK",cancel:"Cancel",close:"Close",set:"Set",select:"Select",reset:"Reset",remove:"Remove",update:"Update",create:"Create",search:"Search",filter:"Filter",refresh:"Refresh",expand:e=>e?`Expand "${e}"`:"Expand",collapse:e=>e?`Collapse "${e}"`:"Collapse"},date:{days:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),daysShort:"Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),monthsShort:"Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),firstDayOfWeek:0,format24h:!1,pluralDay:"days"},table:{noData:"No data available",noResults:"No matching records found",loading:"Loading...",selectedRecords:e=>1===e?"1 record selected.":(0===e?"No":e)+" records selected.",recordsPerPage:"Records per page:",allRows:"All",pagination:(e,t,n)=>e+"-"+t+" of "+n,columns:"Columns"},editor:{url:"URL",bold:"Bold",italic:"Italic",strikethrough:"Strikethrough",underline:"Underline",unorderedList:"Unordered List",orderedList:"Ordered List",subscript:"Subscript",superscript:"Superscript",hyperlink:"Hyperlink",toggleFullscreen:"Toggle Fullscreen",quote:"Quote",left:"Left align",center:"Center align",right:"Right align",justify:"Justify align",print:"Print",outdent:"Decrease indentation",indent:"Increase indentation",removeFormat:"Remove formatting",formatting:"Formatting",fontSize:"Font Size",align:"Align",hr:"Insert Horizontal Rule",undo:"Undo",redo:"Redo",heading1:"Heading 1",heading2:"Heading 2",heading3:"Heading 3",heading4:"Heading 4",heading5:"Heading 5",heading6:"Heading 6",paragraph:"Paragraph",code:"Code",size1:"Very small",size2:"A bit small",size3:"Normal",size4:"Medium-large",size5:"Big",size6:"Very big",size7:"Maximum",defaultFont:"Default Font",viewSource:"View Source"},tree:{noNodes:"No nodes available",noResults:"No matching nodes found"}};function o(){const e=!0===Array.isArray(navigator.languages)&&0!==navigator.languages.length?navigator.languages[0]:navigator.language;if("string"===typeof e)return e.split(/[-_]/).map(((e,t)=>0===t?e.toLowerCase():t>1||e.length<4?e.toUpperCase():e[0].toUpperCase()+e.slice(1).toLowerCase())).join("-")}const s=(0,r.Z)({__langPack:{}},{getLocale:o,set(e=i,t){const n={...e,rtl:!0===e.rtl,getLocale:o};if(n.set=s.set,void 0===s.__langConfig||!0!==s.__langConfig.noHtmlAttrs){const e=document.documentElement;e.setAttribute("dir",!0===n.rtl?"rtl":"ltr"),e.setAttribute("lang",n.isoName)}Object.assign(s.__langPack,n),s.props=n,s.isoName=n.isoName,s.nativeName=n.nativeName},install({$q:e,lang:t,ssrContext:n}){e.lang=s.__langPack,s.__langConfig=e.config.lang,!0===this.__installed?void 0!==t&&this.set(t):this.set(t||i)}}),a=s},6827:(e,t,n)=>{"use strict";n.d(t,{Z:()=>A});n(9665);var r=n(499),i=n(9835),o=n(1957),s=n(1357),a=n(2857),l=n(8879),u=n(3940),c=n(5987),d=(n(1384),n(6669)),h=n(7451),f=n(4680);let p=0;const g={},m={},v={},y={},b=/^\s*$/,w=[],_=["top-left","top-right","bottom-left","bottom-right","top","bottom","left","right","center"],S=["top-left","top-right","bottom-left","bottom-right"],E={positive:{icon:e=>e.iconSet.type.positive,color:"positive"},negative:{icon:e=>e.iconSet.type.negative,color:"negative"},warning:{icon:e=>e.iconSet.type.warning,color:"warning",textColor:"dark"},info:{icon:e=>e.iconSet.type.info,color:"info"},ongoing:{group:!1,timeout:0,spinner:!0,color:"grey-8"}};function k(e,t,n){if(!e)return I("parameter required");let i;const o={textColor:"white"};if(!0!==e.ignoreDefaults&&Object.assign(o,g),!1===(0,f.Kn)(e)&&(o.type&&Object.assign(o,E[o.type]),e={message:e}),Object.assign(o,E[e.type||o.type],e),"function"===typeof o.icon&&(o.icon=o.icon(t)),o.spinner?(!0===o.spinner&&(o.spinner=u.Z),o.spinner=(0,r.Xl)(o.spinner)):o.spinner=!1,o.meta={hasMedia:Boolean(!1!==o.spinner||o.icon||o.avatar),hasText:C(o.message)||C(o.caption)},o.position){if(!1===_.includes(o.position))return I("wrong position",e)}else o.position="bottom";if(void 0===o.timeout)o.timeout=5e3;else{const t=parseInt(o.timeout,10);if(isNaN(t)||t<0)return I("wrong timeout",e);o.timeout=t}0===o.timeout?o.progress=!1:!0===o.progress&&(o.meta.progressClass="q-notification__progress"+(o.progressClass?` ${o.progressClass}`:""),o.meta.progressStyle={animationDuration:`${o.timeout+1e3}ms`});const s=(!0===Array.isArray(e.actions)?e.actions:[]).concat(!0!==e.ignoreDefaults&&!0===Array.isArray(g.actions)?g.actions:[]).concat(void 0!==E[e.type]&&!0===Array.isArray(E[e.type].actions)?E[e.type].actions:[]),{closeBtn:a}=o;if(a&&s.push({label:"string"===typeof a?a:t.lang.label.close}),o.actions=s.map((({handler:e,noDismiss:t,...n})=>({flat:!0,...n,onClick:"function"===typeof e?()=>{e(),!0!==t&&l()}:()=>{l()}}))),void 0===o.multiLine&&(o.multiLine=o.actions.length>1),Object.assign(o.meta,{class:"q-notification row items-stretch q-notification--"+(!0===o.multiLine?"multi-line":"standard")+(void 0!==o.color?` bg-${o.color}`:"")+(void 0!==o.textColor?` text-${o.textColor}`:"")+(void 0!==o.classes?` ${o.classes}`:""),wrapperClass:"q-notification__wrapper col relative-position border-radius-inherit "+(!0===o.multiLine?"column no-wrap justify-center":"row items-center"),contentClass:"q-notification__content row items-center"+(!0===o.multiLine?"":" col"),leftClass:!0===o.meta.hasText?"additional":"single",attrs:{role:"alert",...o.attrs}}),!1===o.group?(o.group=void 0,o.meta.group=void 0):(void 0!==o.group&&!0!==o.group||(o.group=[o.message,o.caption,o.multiline].concat(o.actions.map((e=>`${e.label}*${e.icon}`))).join("|")),o.meta.group=o.group+"|"+o.position),0===o.actions.length?o.actions=void 0:o.meta.actionsClass="q-notification__actions row items-center "+(!0===o.multiLine?"justify-end":"col-auto")+(!0===o.meta.hasMedia?" q-notification__actions--with-media":""),void 0!==n){n.notif.meta.timer&&(clearTimeout(n.notif.meta.timer),n.notif.meta.timer=void 0),o.meta.uid=n.notif.meta.uid;const e=v[o.position].value.indexOf(n.notif);v[o.position].value[e]=o}else{const t=m[o.meta.group];if(void 0===t){if(o.meta.uid=p++,o.meta.badge=1,-1!==["left","right","center"].indexOf(o.position))v[o.position].value.splice(Math.floor(v[o.position].value.length/2),0,o);else{const e=o.position.indexOf("top")>-1?"unshift":"push";v[o.position].value[e](o)}void 0!==o.group&&(m[o.meta.group]=o)}else{if(t.meta.timer&&(clearTimeout(t.meta.timer),t.meta.timer=void 0),void 0!==o.badgePosition){if(!1===S.includes(o.badgePosition))return I("wrong badgePosition",e)}else o.badgePosition="top-"+(o.position.indexOf("left")>-1?"right":"left");o.meta.uid=t.meta.uid,o.meta.badge=t.meta.badge+1,o.meta.badgeClass=`q-notification__badge q-notification__badge--${o.badgePosition}`+(void 0!==o.badgeColor?` bg-${o.badgeColor}`:"")+(void 0!==o.badgeTextColor?` text-${o.badgeTextColor}`:"")+(o.badgeClass?` ${o.badgeClass}`:"");const n=v[o.position].value.indexOf(t);v[o.position].value[n]=m[o.meta.group]=o}}const l=()=>{T(o),i=void 0};return o.timeout>0&&(o.meta.timer=setTimeout((()=>{o.meta.timer=void 0,l()}),o.timeout+1e3)),void 0!==o.group?t=>{void 0!==t?I("trying to update a grouped one which is forbidden",e):l()}:(i={dismiss:l,config:e,notif:o},void 0===n?e=>{if(void 0!==i)if(void 0===e)i.dismiss();else{const n=Object.assign({},i.config,e,{group:!1,position:o.position});k(n,t,i)}}:void Object.assign(n,i))}function T(e){e.meta.timer&&(clearTimeout(e.meta.timer),e.meta.timer=void 0);const t=v[e.position].value.indexOf(e);if(-1!==t){void 0!==e.group&&delete m[e.meta.group];const n=w[""+e.meta.uid];if(n){const{width:e,height:t}=getComputedStyle(n);n.style.left=`${n.offsetLeft}px`,n.style.width=e,n.style.height=t}v[e.position].value.splice(t,1),"function"===typeof e.onDismiss&&e.onDismiss()}}function C(e){return void 0!==e&&null!==e&&!0!==b.test(e)}function I(e,t){return console.error(`Notify: ${e}`,t),!1}function x(){return(0,c.L)({name:"QNotifications",devtools:{hide:!0},setup(){return()=>(0,i.h)("div",{class:"q-notifications"},_.map((e=>(0,i.h)(o.W3,{key:e,class:y[e],tag:"div",name:`q-notification--${e}`},(()=>v[e].value.map((e=>{const t=e.meta,n=[];if(!0===t.hasMedia&&(!1!==e.spinner?n.push((0,i.h)(e.spinner,{class:"q-notification__spinner q-notification__spinner--"+t.leftClass,color:e.spinnerColor,size:e.spinnerSize})):e.icon?n.push((0,i.h)(a.Z,{class:"q-notification__icon q-notification__icon--"+t.leftClass,name:e.icon,color:e.iconColor,size:e.iconSize,role:"img"})):e.avatar&&n.push((0,i.h)(s.Z,{class:"q-notification__avatar q-notification__avatar--"+t.leftClass},(()=>(0,i.h)("img",{src:e.avatar,"aria-hidden":"true"}))))),!0===t.hasText){let t;const r={class:"q-notification__message col"};if(!0===e.html)r.innerHTML=e.caption?`<div>${e.message}</div><div class="q-notification__caption">${e.caption}</div>`:e.message;else{const n=[e.message];t=e.caption?[(0,i.h)("div",n),(0,i.h)("div",{class:"q-notification__caption"},[e.caption])]:n}n.push((0,i.h)("div",r,t))}const r=[(0,i.h)("div",{class:t.contentClass},n)];return!0===e.progress&&r.push((0,i.h)("div",{key:`${t.uid}|p|${t.badge}`,class:t.progressClass,style:t.progressStyle})),void 0!==e.actions&&r.push((0,i.h)("div",{class:t.actionsClass},e.actions.map((e=>(0,i.h)(l.Z,e))))),t.badge>1&&r.push((0,i.h)("div",{key:`${t.uid}|${t.badge}`,class:e.meta.badgeClass,style:e.badgeStyle},[t.badge])),(0,i.h)("div",{ref:e=>{w[""+t.uid]=e},key:t.uid,class:t.class,...t.attrs},[(0,i.h)("div",{class:t.wrapperClass},r)])})))))))}})}const A={setDefaults(e){!0===(0,f.Kn)(e)&&Object.assign(g,e)},registerType(e,t){!0===(0,f.Kn)(t)&&(E[e]=t)},install({$q:e,parentApp:t}){if(e.notify=this.create=t=>k(t,e),e.notify.setDefaults=this.setDefaults,e.notify.registerType=this.registerType,void 0!==e.config.notify&&this.setDefaults(e.config.notify),!0!==this.__installed){_.forEach((e=>{v[e]=(0,r.iH)([]);const t=!0===["left","center","right"].includes(e)?"center":e.indexOf("top")>-1?"top":"bottom",n=e.indexOf("left")>-1?"start":e.indexOf("right")>-1?"end":"center",i=["left","right"].includes(e)?`items-${"left"===e?"start":"end"} justify-center`:"center"===e?"flex-center":`items-${n}`;y[e]=`q-notifications__list q-notifications__list--${t} fixed column no-wrap ${i}`}));const e=(0,d.q_)("q-notify");(0,h.$)(x(),t).mount(e)}}}},7506:(e,t,n)=>{"use strict";n.d(t,{ZP:()=>v,aG:()=>s,client:()=>g,uX:()=>o});n(9665);var r=n(499),i=n(3251);const o=(0,r.iH)(!1);let s,a=!1;function l(e,t){const n=/(edg|edge|edga|edgios)\/([\w.]+)/.exec(e)||/(opr)[\/]([\w.]+)/.exec(e)||/(vivaldi)[\/]([\w.]+)/.exec(e)||/(chrome|crios)[\/]([\w.]+)/.exec(e)||/(version)(applewebkit)[\/]([\w.]+).*(safari)[\/]([\w.]+)/.exec(e)||/(webkit)[\/]([\w.]+).*(version)[\/]([\w.]+).*(safari)[\/]([\w.]+)/.exec(e)||/(firefox|fxios)[\/]([\w.]+)/.exec(e)||/(webkit)[\/]([\w.]+)/.exec(e)||/(opera)(?:.*version|)[\/]([\w.]+)/.exec(e)||[];return{browser:n[5]||n[3]||n[1]||"",version:n[2]||n[4]||"0",versionNumber:n[4]||n[2]||"0",platform:t[0]||""}}function u(e){return/(ipad)/.exec(e)||/(ipod)/.exec(e)||/(windows phone)/.exec(e)||/(iphone)/.exec(e)||/(kindle)/.exec(e)||/(silk)/.exec(e)||/(android)/.exec(e)||/(win)/.exec(e)||/(mac)/.exec(e)||/(linux)/.exec(e)||/(cros)/.exec(e)||/(playbook)/.exec(e)||/(bb)/.exec(e)||/(blackberry)/.exec(e)||[]}const c="ontouchstart"in window||window.navigator.maxTouchPoints>0;function d(e){s={is:{...e}},delete e.mac,delete e.desktop;const t=Math.min(window.innerHeight,window.innerWidth)>414?"ipad":"iphone";Object.assign(e,{mobile:!0,ios:!0,platform:t,[t]:!0})}function h(e){const t=e.toLowerCase(),n=u(t),r=l(t,n),i={};r.browser&&(i[r.browser]=!0,i.version=r.version,i.versionNumber=parseInt(r.versionNumber,10)),r.platform&&(i[r.platform]=!0);const o=i.android||i.ios||i.bb||i.blackberry||i.ipad||i.iphone||i.ipod||i.kindle||i.playbook||i.silk||i["windows phone"];return!0===o||t.indexOf("mobile")>-1?(i.mobile=!0,i.edga||i.edgios?(i.edge=!0,r.browser="edge"):i.crios?(i.chrome=!0,r.browser="chrome"):i.fxios&&(i.firefox=!0,r.browser="firefox")):i.desktop=!0,(i.ipod||i.ipad||i.iphone)&&(i.ios=!0),i["windows phone"]&&(i.winphone=!0,delete i["windows phone"]),(i.chrome||i.opr||i.safari||i.vivaldi||!0===i.mobile&&!0!==i.ios&&!0!==o)&&(i.webkit=!0),i.edg&&(r.browser="edgechromium",i.edgeChromium=!0),(i.safari&&i.blackberry||i.bb)&&(r.browser="blackberry",i.blackberry=!0),i.safari&&i.playbook&&(r.browser="playbook",i.playbook=!0),i.opr&&(r.browser="opera",i.opera=!0),i.safari&&i.android&&(r.browser="android",i.android=!0),i.safari&&i.kindle&&(r.browser="kindle",i.kindle=!0),i.safari&&i.silk&&(r.browser="silk",i.silk=!0),i.vivaldi&&(r.browser="vivaldi",i.vivaldi=!0),i.name=r.browser,i.platform=r.platform,t.indexOf("electron")>-1?i.electron=!0:document.location.href.indexOf("-extension://")>-1?i.bex=!0:(void 0!==window.Capacitor?(i.capacitor=!0,i.nativeMobile=!0,i.nativeMobileWrapper="capacitor"):void 0===window._cordovaNative&&void 0===window.cordova||(i.cordova=!0,i.nativeMobile=!0,i.nativeMobileWrapper="cordova"),!0===c&&!0===i.mac&&(!0===i.desktop&&!0===i.safari||!0===i.nativeMobile&&!0!==i.android&&!0!==i.ios&&!0!==i.ipad)&&d(i)),i}const f=navigator.userAgent||navigator.vendor||window.opera,p={has:{touch:!1,webStorage:!1},within:{iframe:!1}},g={userAgent:f,is:h(f),has:{touch:c},within:{iframe:window.self!==window.top}},m={install(e){const{$q:t}=e;!0===o.value?(e.onSSRHydrated.push((()=>{Object.assign(t.platform,g),o.value=!1,s=void 0})),t.platform=(0,r.qj)(this)):t.platform=this}};{let e;(0,i.g)(g.has,"webStorage",(()=>{if(void 0!==e)return e;try{if(window.localStorage)return e=!0,!0}catch(t){}return e=!1,!1})),a=!0===g.is.ios&&-1===window.navigator.vendor.toLowerCase().indexOf("apple"),!0===o.value?Object.assign(m,g,s,p):Object.assign(m,g)}const v=m},899:(e,t,n)=>{"use strict";function r(e,t=250,n){let r=null;function i(){const i=arguments,o=()=>{r=null,!0!==n&&e.apply(this,i)};null!==r?clearTimeout(r):!0===n&&e.apply(this,i),r=setTimeout(o,t)}return i.cancel=()=>{null!==r&&clearTimeout(r)},i}n.d(t,{Z:()=>r})},223:(e,t,n)=>{"use strict";n.d(t,{iv:()=>i,mY:()=>s,sb:()=>o});var r=n(499);function i(e,t){const n=e.style;for(const r in t)n[r]=t[r]}function o(e){if(void 0===e||null===e)return;if("string"===typeof e)try{return document.querySelector(e)||void 0}catch(n){return}const t=(0,r.SU)(e);return t?t.$el||t:void 0}function s(e,t){if(void 0===e||null===e||!0===e.contains(t))return!0;for(let n=e.nextElementSibling;null!==n;n=n.nextElementSibling)if(n.contains(t))return!0;return!1}},1384:(e,t,n)=>{"use strict";n.d(t,{AZ:()=>a,FK:()=>s,Jf:()=>d,M0:()=>h,NS:()=>c,X$:()=>u,ZT:()=>i,du:()=>o,listenOpts:()=>r,sT:()=>l,ul:()=>f});n(9665);const r={hasPassive:!1,passiveCapture:!0,notPassiveCapture:!0};try{const e=Object.defineProperty({},"passive",{get(){Object.assign(r,{hasPassive:!0,passive:{passive:!0},notPassive:{passive:!1},passiveCapture:{passive:!0,capture:!0},notPassiveCapture:{passive:!1,capture:!0}})}});window.addEventListener("qtest",null,e),window.removeEventListener("qtest",null,e)}catch(p){}function i(){}function o(e){return 0===e.button}function s(e){return e.touches&&e.touches[0]?e=e.touches[0]:e.changedTouches&&e.changedTouches[0]?e=e.changedTouches[0]:e.targetTouches&&e.targetTouches[0]&&(e=e.targetTouches[0]),{top:e.clientY,left:e.clientX}}function a(e){if(e.path)return e.path;if(e.composedPath)return e.composedPath();const t=[];let n=e.target;while(n){if(t.push(n),"HTML"===n.tagName)return t.push(document),t.push(window),t;n=n.parentElement}}function l(e){e.stopPropagation()}function u(e){!1!==e.cancelable&&e.preventDefault()}function c(e){!1!==e.cancelable&&e.preventDefault(),e.stopPropagation()}function d(e,t){if(void 0===e||!0===t&&!0===e.__dragPrevented)return;const n=!0===t?e=>{e.__dragPrevented=!0,e.addEventListener("dragstart",u,r.notPassiveCapture)}:e=>{delete e.__dragPrevented,e.removeEventListener("dragstart",u,r.notPassiveCapture)};e.querySelectorAll("a, img").forEach(n)}function h(e,t,n){const i=`__q_${t}_evt`;e[i]=void 0!==e[i]?e[i].concat(n):n,n.forEach((t=>{t[0].addEventListener(t[1],e[t[2]],r[t[3]])}))}function f(e,t){const n=`__q_${t}_evt`;void 0!==e[n]&&(e[n].forEach((t=>{t[0].removeEventListener(t[1],e[t[2]],r[t[3]])})),e[n]=void 0)}},321:(e,t,n)=>{"use strict";n.d(t,{Uz:()=>o,rB:()=>i});const r=["B","KB","MB","GB","TB","PB"];function i(e){let t=0;while(parseInt(e,10)>=1024&&t<r.length-1)e/=1024,++t;return`${e.toFixed(1)}${r[t]}`}function o(e,t,n){if(n<=t)return t;const r=n-t+1;let i=t+(e-t)%r;return i<t&&(i=r+i),0===i?0:i}},4680:(e,t,n)=>{"use strict";n.d(t,{J_:()=>o,Kn:()=>i,hj:()=>s,xb:()=>r});n(3122);function r(e,t){if(e===t)return!0;if(null!==e&&null!==t&&"object"===typeof e&&"object"===typeof t){if(e.constructor!==t.constructor)return!1;let n,i;if(e.constructor===Array){if(n=e.length,n!==t.length)return!1;for(i=n;0!==i--;)if(!0!==r(e[i],t[i]))return!1;return!0}if(e.constructor===Map){if(e.size!==t.size)return!1;let n=e.entries();i=n.next();while(!0!==i.done){if(!0!==t.has(i.value[0]))return!1;i=n.next()}n=e.entries(),i=n.next();while(!0!==i.done){if(!0!==r(i.value[1],t.get(i.value[0])))return!1;i=n.next()}return!0}if(e.constructor===Set){if(e.size!==t.size)return!1;const n=e.entries();i=n.next();while(!0!==i.done){if(!0!==t.has(i.value[0]))return!1;i=n.next()}return!0}if(null!=e.buffer&&e.buffer.constructor===ArrayBuffer){if(n=e.length,n!==t.length)return!1;for(i=n;0!==i--;)if(e[i]!==t[i])return!1;return!0}if(e.constructor===RegExp)return e.source===t.source&&e.flags===t.flags;if(e.valueOf!==Object.prototype.valueOf)return e.valueOf()===t.valueOf();if(e.toString!==Object.prototype.toString)return e.toString()===t.toString();const o=Object.keys(e).filter((t=>void 0!==e[t]));if(n=o.length,n!==Object.keys(t).filter((e=>void 0!==t[e])).length)return!1;for(i=n;0!==i--;){const n=o[i];if(!0!==r(e[n],t[n]))return!1}return!0}return e!==e&&t!==t}function i(e){return null!==e&&"object"===typeof e&&!0!==Array.isArray(e)}function o(e){return"[object Date]"===Object.prototype.toString.call(e)}function s(e){return"number"===typeof e&&isFinite(e)}},9092:(e,t,n)=>{"use strict";n.d(t,{D:()=>c,m:()=>u});n(9665);var r=n(1384),i=n(2909);let o=null;const{notPassiveCapture:s}=r.listenOpts,a=[];function l(e){null!==o&&(clearTimeout(o),o=null);const t=e.target;if(void 0===t||8===t.nodeType||!0===t.classList.contains("no-pointer-events"))return;let n=i.Q$.length-1;while(n>=0){const e=i.Q$[n].$;if("QDialog"!==e.type.name)break;if(!0!==e.props.seamless)return;n--}for(let r=a.length-1;r>=0;r--){const n=a[r];if(null!==n.anchorEl.value&&!1!==n.anchorEl.value.contains(t)||t!==document.body&&(null===n.innerRef.value||!1!==n.innerRef.value.contains(t)))return;e.qClickOutside=!0,n.onClickOutside(e)}}function u(e){a.push(e),1===a.length&&(document.addEventListener("mousedown",l,s),document.addEventListener("touchstart",l,s))}function c(e){const t=a.findIndex((t=>t===e));t>-1&&(a.splice(t,1),0===a.length&&(null!==o&&(clearTimeout(o),o=null),document.removeEventListener("mousedown",l,s),document.removeEventListener("touchstart",l,s)))}},5987:(e,t,n)=>{"use strict";n.d(t,{L:()=>o,f:()=>s});var r=n(499),i=n(9835);const o=e=>(0,r.Xl)((0,i.aZ)(e)),s=e=>(0,r.Xl)(e)},4124:(e,t,n)=>{"use strict";n.d(t,{Z:()=>o});var r=n(499),i=n(3251);const o=(e,t)=>{const n=(0,r.qj)(e);for(const r in e)(0,i.g)(t,r,(()=>n[r]),(e=>{n[r]=e}));return t}},6532:(e,t,n)=>{"use strict";n.d(t,{c:()=>d,k:()=>h});n(9665);var r=n(7506),i=n(1705);const o=[];let s;function a(e){s=27===e.keyCode}function l(){!0===s&&(s=!1)}function u(e){!0===s&&(s=!1,!0===(0,i.So)(e,27)&&o[o.length-1](e))}function c(e){window[e]("keydown",a),window[e]("blur",l),window[e]("keyup",u),s=!1}function d(e){!0===r.client.is.desktop&&(o.push(e),1===o.length&&c("addEventListener"))}function h(e){const t=o.indexOf(e);t>-1&&(o.splice(t,1),0===o.length&&c("removeEventListener"))}},7026:(e,t,n)=>{"use strict";n.d(t,{YX:()=>s,fP:()=>u,jd:()=>l,xF:()=>a});n(9665);let r=[],i=[];function o(e){i=i.filter((t=>t!==e))}function s(e){o(e),i.push(e)}function a(e){o(e),0===i.length&&0!==r.length&&(r[r.length-1](),r=[])}function l(e){0===i.length?e():r.push(e)}function u(e){r=r.filter((t=>t!==e))}},4173:(e,t,n)=>{"use strict";n.d(t,{H:()=>a,i:()=>s});n(9665);var r=n(7506);const i=[];function o(e){i[i.length-1](e)}function s(e){!0===r.client.is.desktop&&(i.push(e),1===i.length&&document.body.addEventListener("focusin",o))}function a(e){const t=i.indexOf(e);t>-1&&(i.splice(t,1),0===i.length&&document.body.removeEventListener("focusin",o))}},7495:(e,t,n)=>{"use strict";n.d(t,{Uf:()=>i,tP:()=>o,w6:()=>r});const r={};let i=!1;function o(){i=!0}},6669:(e,t,n)=>{"use strict";n.d(t,{pB:()=>u,q_:()=>l});n(9665);var r=n(7495);const i=[],o=[];let s=1,a=document.body;function l(e,t){const n=document.createElement("div");if(n.id=void 0!==t?`q-portal--${t}--${s++}`:e,void 0!==r.w6.globalNodes){const e=r.w6.globalNodes.class;void 0!==e&&(n.className=e)}return a.appendChild(n),i.push(n),o.push(t),n}function u(e){const t=i.indexOf(e);i.splice(t,1),o.splice(t,1),e.remove()}},3251:(e,t,n)=>{"use strict";function r(e,t,n,r){return Object.defineProperty(e,t,{get:n,set:r,enumerable:!0}),e}function i(e,t){for(const n in t)r(e,n,t[n]);return e}n.d(t,{K:()=>i,g:()=>r})},1705:(e,t,n)=>{"use strict";n.d(t,{So:()=>s,Wm:()=>o,ZK:()=>i});let r=!1;function i(e){r=!0===e.isComposing}function o(e){return!0===r||e!==Object(e)||!0===e.isComposing||!0===e.qKeyEvent}function s(e,t){return!0!==o(e)&&[].concat(t).includes(e.keyCode)}},2909:(e,t,n)=>{"use strict";n.d(t,{AH:()=>s,Q$:()=>i,S7:()=>a,je:()=>o});var r=n(2046);const i=[];function o(e){return i.find((t=>null!==t.contentEl&&t.contentEl.contains(e)))}function s(e,t){do{if("QMenu"===e.$options.name){if(e.hide(t),!0===e.$props.separateClosePopup)return(0,r.O2)(e)}else if(!0===e.__qPortal){const n=(0,r.O2)(e);return void 0!==n&&"QPopupProxy"===n.$options.name?(e.hide(t),n):e}e=(0,r.O2)(e)}while(void 0!==e&&null!==e)}function a(e,t,n){while(0!==n&&void 0!==e&&null!==e){if(!0===e.__qPortal){if(n--,"QMenu"===e.$options.name){e=s(e,t);continue}e.hide(t)}e=(0,r.O2)(e)}}},9388:(e,t,n)=>{"use strict";n.d(t,{$:()=>a,io:()=>l,li:()=>c,wq:()=>g});var r=n(3701),i=n(7506);let o,s;function a(e){const t=e.split(" ");return 2===t.length&&(!0!==["top","center","bottom"].includes(t[0])?(console.error("Anchor/Self position must start with one of top/center/bottom"),!1):!0===["left","middle","right","start","end"].includes(t[1])||(console.error("Anchor/Self position must end with one of left/middle/right/start/end"),!1))}function l(e){return!e||2===e.length&&("number"===typeof e[0]&&"number"===typeof e[1])}const u={"start#ltr":"left","start#rtl":"right","end#ltr":"right","end#rtl":"left"};function c(e,t){const n=e.split(" ");return{vertical:n[0],horizontal:u[`${n[1]}#${!0===t?"rtl":"ltr"}`]}}function d(e,t){let{top:n,left:r,right:i,bottom:o,width:s,height:a}=e.getBoundingClientRect();return void 0!==t&&(n-=t[1],r-=t[0],o+=t[1],i+=t[0],s+=t[0],a+=t[1]),{top:n,bottom:o,height:a,left:r,right:i,width:s,middle:r+(i-r)/2,center:n+(o-n)/2}}function h(e,t,n){let{top:r,left:i}=e.getBoundingClientRect();return r+=t.top,i+=t.left,void 0!==n&&(r+=n[1],i+=n[0]),{top:r,bottom:r+1,height:1,left:i,right:i+1,width:1,middle:i,center:r}}function f(e){return{top:0,center:e.offsetHeight/2,bottom:e.offsetHeight,left:0,middle:e.offsetWidth/2,right:e.offsetWidth}}function p(e,t,n){return{top:e[n.anchorOrigin.vertical]-t[n.selfOrigin.vertical],left:e[n.anchorOrigin.horizontal]-t[n.selfOrigin.horizontal]}}function g(e){if(!0===i.client.is.ios&&void 0!==window.visualViewport){const e=document.body.style,{offsetLeft:t,offsetTop:n}=window.visualViewport;t!==o&&(e.setProperty("--q-pe-left",t+"px"),o=t),n!==s&&(e.setProperty("--q-pe-top",n+"px"),s=n)}const{scrollLeft:t,scrollTop:n}=e.el,r=void 0===e.absoluteOffset?d(e.anchorEl,!0===e.cover?[0,0]:e.offset):h(e.anchorEl,e.absoluteOffset,e.offset);let a={maxHeight:e.maxHeight,maxWidth:e.maxWidth,visibility:"visible"};!0!==e.fit&&!0!==e.cover||(a.minWidth=r.width+"px",!0===e.cover&&(a.minHeight=r.height+"px")),Object.assign(e.el.style,a);const l=f(e.el);let u=p(r,l,e);if(void 0===e.absoluteOffset||void 0===e.offset)m(u,r,l,e.anchorOrigin,e.selfOrigin);else{const{top:t,left:n}=u;m(u,r,l,e.anchorOrigin,e.selfOrigin);let i=!1;if(u.top!==t){i=!0;const t=2*e.offset[1];r.center=r.top-=t,r.bottom-=t+2}if(u.left!==n){i=!0;const t=2*e.offset[0];r.middle=r.left-=t,r.right-=t+2}!0===i&&(u=p(r,l,e),m(u,r,l,e.anchorOrigin,e.selfOrigin))}a={top:u.top+"px",left:u.left+"px"},void 0!==u.maxHeight&&(a.maxHeight=u.maxHeight+"px",r.height>u.maxHeight&&(a.minHeight=a.maxHeight)),void 0!==u.maxWidth&&(a.maxWidth=u.maxWidth+"px",r.width>u.maxWidth&&(a.minWidth=a.maxWidth)),Object.assign(e.el.style,a),e.el.scrollTop!==n&&(e.el.scrollTop=n),e.el.scrollLeft!==t&&(e.el.scrollLeft=t)}function m(e,t,n,i,o){const s=n.bottom,a=n.right,l=(0,r.np)(),u=window.innerHeight-l,c=document.body.clientWidth;if(e.top<0||e.top+s>u)if("center"===o.vertical)e.top=t[i.vertical]>u/2?Math.max(0,u-s):0,e.maxHeight=Math.min(s,u);else if(t[i.vertical]>u/2){const n=Math.min(u,"center"===i.vertical?t.center:i.vertical===o.vertical?t.bottom:t.top);e.maxHeight=Math.min(s,n),e.top=Math.max(0,n-s)}else e.top=Math.max(0,"center"===i.vertical?t.center:i.vertical===o.vertical?t.top:t.bottom),e.maxHeight=Math.min(s,u-e.top);if(e.left<0||e.left+a>c)if(e.maxWidth=Math.min(a,c),"middle"===o.horizontal)e.left=t[i.horizontal]>c/2?Math.max(0,c-a):0;else if(t[i.horizontal]>c/2){const n=Math.min(c,"middle"===i.horizontal?t.middle:i.horizontal===o.horizontal?t.right:t.left);e.maxWidth=Math.min(a,n),e.left=Math.max(0,n-e.maxWidth)}else e.left=Math.max(0,"middle"===i.horizontal?t.middle:i.horizontal===o.horizontal?t.left:t.right),e.maxWidth=Math.min(a,c-e.left)}["left","middle","right"].forEach((e=>{u[`${e}#ltr`]=e,u[`${e}#rtl`]=e}))},2026:(e,t,n)=>{"use strict";n.d(t,{Bl:()=>o,Jl:()=>l,KR:()=>i,pf:()=>a,vs:()=>s});var r=n(9835);function i(e,t){return void 0!==e&&e()||t}function o(e,t){if(void 0!==e){const t=e();if(void 0!==t&&null!==t)return t.slice()}return t}function s(e,t){return void 0!==e?t.concat(e()):t}function a(e,t){return void 0===e?t:void 0!==t?t.concat(e()):e()}function l(e,t,n,i,o,s){t.key=i+o;const a=(0,r.h)(e,t,n);return!0===o?(0,r.wy)(a,s()):a}},2589:(e,t,n)=>{"use strict";n.d(t,{M:()=>i});var r=n(7506);function i(){if(void 0!==window.getSelection){const e=window.getSelection();void 0!==e.empty?e.empty():void 0!==e.removeAllRanges&&(e.removeAllRanges(),!0!==r.ZP.is.mobile&&e.addRange(document.createRange()))}else void 0!==document.selection&&document.selection.empty()}},5439:(e,t,n)=>{"use strict";n.d(t,{Mw:()=>o,Ng:()=>r,YE:()=>i,qO:()=>a,vh:()=>s});const r="_q_",i="_q_l_",o="_q_pc_",s="_q_fo_",a=()=>{}},2046:(e,t,n)=>{"use strict";function r(e){if(Object(e.$parent)===e.$parent)return e.$parent;let{parent:t}=e.$;while(Object(t)===t){if(Object(t.proxy)===t.proxy)return t.proxy;t=t.parent}}function i(e,t){"symbol"===typeof t.type?!0===Array.isArray(t.children)&&t.children.forEach((t=>{i(e,t)})):e.add(t)}function o(e){const t=new Set;return e.forEach((e=>{i(t,e)})),Array.from(t)}function s(e){return void 0!==e.appContext.config.globalProperties.$router}function a(e){return!0===e.isUnmounted||!0===e.isDeactivated}n.d(t,{$D:()=>a,O2:()=>r,Pf:()=>o,Rb:()=>s})},3701:(e,t,n)=>{"use strict";n.d(t,{OI:()=>a,QA:()=>c,b0:()=>o,np:()=>u,u3:()=>s});var r=n(223);const i=[null,document,document.body,document.scrollingElement,document.documentElement];function o(e,t){let n=(0,r.sb)(t);if(void 0===n){if(void 0===e||null===e)return window;n=e.closest(".scroll,.scroll-y,.overflow-auto")}return i.includes(n)?window:n}function s(e){return e===window?window.pageYOffset||window.scrollY||document.body.scrollTop||0:e.scrollTop}function a(e){return e===window?window.pageXOffset||window.scrollX||document.body.scrollLeft||0:e.scrollLeft}let l;function u(){if(void 0!==l)return l;const e=document.createElement("p"),t=document.createElement("div");(0,r.iv)(e,{width:"100%",height:"200px"}),(0,r.iv)(t,{position:"absolute",top:"0px",left:"0px",visibility:"hidden",width:"200px",height:"150px",overflow:"hidden"}),t.appendChild(e),document.body.appendChild(t);const n=e.offsetWidth;t.style.overflow="scroll";let i=e.offsetWidth;return n===i&&(i=t.clientWidth),t.remove(),l=n-i,l}function c(e,t=!0){return!(!e||e.nodeType!==Node.ELEMENT_NODE)&&(t?e.scrollHeight>e.clientHeight&&(e.classList.contains("scroll")||e.classList.contains("overflow-auto")||["auto","scroll"].includes(window.getComputedStyle(e)["overflow-y"])):e.scrollWidth>e.clientWidth&&(e.classList.contains("scroll")||e.classList.contains("overflow-auto")||["auto","scroll"].includes(window.getComputedStyle(e)["overflow-x"])))}},1947:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(7451),i=n(3558),o=n(2289);const s={version:"2.12.0",install:r.Z,lang:i.Z,iconSet:o.Z}},8762:(e,t,n)=>{var r=n(6107),i=n(7545),o=TypeError;e.exports=function(e){if(r(e))return e;throw o(i(e)+" is not a function")}},9220:(e,t,n)=>{var r=n(6107),i=String,o=TypeError;e.exports=function(e){if("object"==typeof e||r(e))return e;throw o("Can't set "+i(e)+" as a prototype")}},616:(e,t,n)=>{var r=n(1419),i=String,o=TypeError;e.exports=function(e){if(r(e))return e;throw o(i(e)+" is not an object")}},8389:e=>{e.exports="undefined"!=typeof ArrayBuffer&&"undefined"!=typeof DataView},8086:(e,t,n)=>{"use strict";var r,i,o,s=n(8389),a=n(4133),l=n(3834),u=n(6107),c=n(1419),d=n(2924),h=n(4239),f=n(7545),p=n(4722),g=n(4076),m=n(9570),v=n(6123),y=n(7886),b=n(6534),w=n(4103),_=n(3965),S=n(780),E=S.enforce,k=S.get,T=l.Int8Array,C=T&&T.prototype,I=l.Uint8ClampedArray,x=I&&I.prototype,A=T&&y(T),R=C&&y(C),O=Object.prototype,N=l.TypeError,P=w("toStringTag"),F=_("TYPED_ARRAY_TAG"),L="TypedArrayConstructor",D=s&&!!b&&"Opera"!==h(l.opera),M=!1,q={Int8Array:1,Uint8Array:1,Uint8ClampedArray:1,Int16Array:2,Uint16Array:2,Int32Array:4,Uint32Array:4,Float32Array:4,Float64Array:8},V={BigInt64Array:8,BigUint64Array:8},U=function(e){if(!c(e))return!1;var t=h(e);return"DataView"===t||d(q,t)||d(V,t)},B=function(e){var t=y(e);if(c(t)){var n=k(t);return n&&d(n,L)?n[L]:B(t)}},$=function(e){if(!c(e))return!1;var t=h(e);return d(q,t)||d(V,t)},j=function(e){if($(e))return e;throw N("Target is not a typed array")},z=function(e){if(u(e)&&(!b||v(A,e)))return e;throw N(f(e)+" is not a typed array constructor")},H=function(e,t,n,r){if(a){if(n)for(var i in q){var o=l[i];if(o&&d(o.prototype,e))try{delete o.prototype[e]}catch(s){try{o.prototype[e]=t}catch(u){}}}R[e]&&!n||g(R,e,n?t:D&&C[e]||t,r)}},K=function(e,t,n){var r,i;if(a){if(b){if(n)for(r in q)if(i=l[r],i&&d(i,e))try{delete i[e]}catch(o){}if(A[e]&&!n)return;try{return g(A,e,n?t:D&&A[e]||t)}catch(o){}}for(r in q)i=l[r],!i||i[e]&&!n||g(i,e,t)}};for(r in q)i=l[r],o=i&&i.prototype,o?E(o)[L]=i:D=!1;for(r in V)i=l[r],o=i&&i.prototype,o&&(E(o)[L]=i);if((!D||!u(A)||A===Function.prototype)&&(A=function(){throw N("Incorrect invocation")},D))for(r in q)l[r]&&b(l[r],A);if((!D||!R||R===O)&&(R=A.prototype,D))for(r in q)l[r]&&b(l[r].prototype,R);if(D&&y(x)!==R&&b(x,R),a&&!d(R,P))for(r in M=!0,m(R,P,{configurable:!0,get:function(){return c(this)?this[F]:void 0}}),q)l[r]&&p(l[r],F,r);e.exports={NATIVE_ARRAY_BUFFER_VIEWS:D,TYPED_ARRAY_TAG:M&&F,aTypedArray:j,aTypedArrayConstructor:z,exportTypedArrayMethod:H,exportTypedArrayStaticMethod:K,getTypedArrayConstructor:B,isView:U,isTypedArray:$,TypedArray:A,TypedArrayPrototype:R}},3364:(e,t,n)=>{var r=n(8600);e.exports=function(e,t){var n=0,i=r(t),o=new e(i);while(i>n)o[n]=t[n++];return o}},7714:(e,t,n)=>{var r=n(7447),i=n(2661),o=n(8600),s=function(e){return function(t,n,s){var a,l=r(t),u=o(l),c=i(s,u);if(e&&n!=n){while(u>c)if(a=l[c++],a!=a)return!0}else for(;u>c;c++)if((e||c in l)&&l[c]===n)return e||c||0;return!e&&-1}};e.exports={includes:s(!0),indexOf:s(!1)}},9275:(e,t,n)=>{var r=n(6158),i=n(3972),o=n(8332),s=n(8600),a=function(e){var t=1==e;return function(n,a,l){var u,c,d=o(n),h=i(d),f=r(a,l),p=s(h);while(p-- >0)if(u=h[p],c=f(u,p,d),c)switch(e){case 0:return u;case 1:return p}return t?-1:void 0}};e.exports={findLast:a(0),findLastIndex:a(1)}},3614:(e,t,n)=>{"use strict";var r=n(4133),i=n(6555),o=TypeError,s=Object.getOwnPropertyDescriptor,a=r&&!function(){if(void 0!==this)return!0;try{Object.defineProperty([],"length",{writable:!1}).length=1}catch(e){return e instanceof TypeError}}();e.exports=a?function(e,t){if(i(e)&&!s(e,"length").writable)throw o("Cannot set read only .length");return e.length=t}:function(e,t){return e.length=t}},7579:(e,t,n)=>{var r=n(8600);e.exports=function(e,t){for(var n=r(e),i=new t(n),o=0;o<n;o++)i[o]=e[n-o-1];return i}},5330:(e,t,n)=>{var r=n(8600),i=n(6675),o=RangeError;e.exports=function(e,t,n,s){var a=r(e),l=i(n),u=l<0?a+l:l;if(u>=a||u<0)throw o("Incorrect index");for(var c=new t(a),d=0;d<a;d++)c[d]=d===u?s:e[d];return c}},6749:(e,t,n)=>{var r=n(1636),i=r({}.toString),o=r("".slice);e.exports=function(e){return o(i(e),8,-1)}},4239:(e,t,n)=>{var r=n(4130),i=n(6107),o=n(6749),s=n(4103),a=s("toStringTag"),l=Object,u="Arguments"==o(function(){return arguments}()),c=function(e,t){try{return e[t]}catch(n){}};e.exports=r?o:function(e){var t,n,r;return void 0===e?"Undefined":null===e?"Null":"string"==typeof(n=c(t=l(e),a))?n:u?o(t):"Object"==(r=o(t))&&i(t.callee)?"Arguments":r}},7366:(e,t,n)=>{var r=n(2924),i=n(1240),o=n(863),s=n(1012);e.exports=function(e,t,n){for(var a=i(t),l=s.f,u=o.f,c=0;c<a.length;c++){var d=a[c];r(e,d)||n&&r(n,d)||l(e,d,u(t,d))}}},911:(e,t,n)=>{var r=n(8814);e.exports=!r((function(){function e(){}return e.prototype.constructor=null,Object.getPrototypeOf(new e)!==e.prototype}))},4722:(e,t,n)=>{var r=n(4133),i=n(1012),o=n(3386);e.exports=r?function(e,t,n){return i.f(e,t,o(1,n))}:function(e,t,n){return e[t]=n,e}},3386:e=>{e.exports=function(e,t){return{enumerable:!(1&e),configurable:!(2&e),writable:!(4&e),value:t}}},9570:(e,t,n)=>{var r=n(2358),i=n(1012);e.exports=function(e,t,n){return n.get&&r(n.get,t,{getter:!0}),n.set&&r(n.set,t,{setter:!0}),i.f(e,t,n)}},4076:(e,t,n)=>{var r=n(6107),i=n(1012),o=n(2358),s=n(5437);e.exports=function(e,t,n,a){a||(a={});var l=a.enumerable,u=void 0!==a.name?a.name:t;if(r(n)&&o(n,u,a),a.global)l?e[t]=n:s(t,n);else{try{a.unsafe?e[t]&&(l=!0):delete e[t]}catch(c){}l?e[t]=n:i.f(e,t,{value:n,enumerable:!1,configurable:!a.nonConfigurable,writable:!a.nonWritable})}return e}},5437:(e,t,n)=>{var r=n(3834),i=Object.defineProperty;e.exports=function(e,t){try{i(r,e,{value:t,configurable:!0,writable:!0})}catch(n){r[e]=t}return t}},6405:(e,t,n)=>{"use strict";var r=n(7545),i=TypeError;e.exports=function(e,t){if(!delete e[t])throw i("Cannot delete property "+r(t)+" of "+r(e))}},4133:(e,t,n)=>{var r=n(8814);e.exports=!r((function(){return 7!=Object.defineProperty({},1,{get:function(){return 7}})[1]}))},948:e=>{var t="object"==typeof document&&document.all,n="undefined"==typeof t&&void 0!==t;e.exports={all:t,IS_HTMLDDA:n}},1657:(e,t,n)=>{var r=n(3834),i=n(1419),o=r.document,s=i(o)&&i(o.createElement);e.exports=function(e){return s?o.createElement(e):{}}},6689:e=>{var t=TypeError,n=9007199254740991;e.exports=function(e){if(e>n)throw t("Maximum allowed index exceeded");return e}},322:e=>{e.exports="undefined"!=typeof navigator&&String(navigator.userAgent)||""},1418:(e,t,n)=>{var r,i,o=n(3834),s=n(322),a=o.process,l=o.Deno,u=a&&a.versions||l&&l.version,c=u&&u.v8;c&&(r=c.split("."),i=r[0]>0&&r[0]<4?1:+(r[0]+r[1])),!i&&s&&(r=s.match(/Edge\/(\d+)/),(!r||r[1]>=74)&&(r=s.match(/Chrome\/(\d+)/),r&&(i=+r[1]))),e.exports=i},203:e=>{e.exports=["constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf"]},6943:(e,t,n)=>{var r=n(3834),i=n(863).f,o=n(4722),s=n(4076),a=n(5437),l=n(7366),u=n(2764);e.exports=function(e,t){var n,c,d,h,f,p,g=e.target,m=e.global,v=e.stat;if(c=m?r:v?r[g]||a(g,{}):(r[g]||{}).prototype,c)for(d in t){if(f=t[d],e.dontCallGetSet?(p=i(c,d),h=p&&p.value):h=c[d],n=u(m?d:g+(v?".":"#")+d,e.forced),!n&&void 0!==h){if(typeof f==typeof h)continue;l(f,h)}(e.sham||h&&h.sham)&&o(f,"sham",!0),s(c,d,f,e)}}},8814:e=>{e.exports=function(e){try{return!!e()}catch(t){return!0}}},6158:(e,t,n)=>{var r=n(9287),i=n(8762),o=n(9793),s=r(r.bind);e.exports=function(e,t){return i(e),void 0===t?e:o?s(e,t):function(){return e.apply(t,arguments)}}},9793:(e,t,n)=>{var r=n(8814);e.exports=!r((function(){var e=function(){}.bind();return"function"!=typeof e||e.hasOwnProperty("prototype")}))},6654:(e,t,n)=>{var r=n(9793),i=Function.prototype.call;e.exports=r?i.bind(i):function(){return i.apply(i,arguments)}},9104:(e,t,n)=>{var r=n(4133),i=n(2924),o=Function.prototype,s=r&&Object.getOwnPropertyDescriptor,a=i(o,"name"),l=a&&"something"===function(){}.name,u=a&&(!r||r&&s(o,"name").configurable);e.exports={EXISTS:a,PROPER:l,CONFIGURABLE:u}},5478:(e,t,n)=>{var r=n(1636),i=n(8762);e.exports=function(e,t,n){try{return r(i(Object.getOwnPropertyDescriptor(e,t)[n]))}catch(o){}}},9287:(e,t,n)=>{var r=n(6749),i=n(1636);e.exports=function(e){if("Function"===r(e))return i(e)}},1636:(e,t,n)=>{var r=n(9793),i=Function.prototype,o=i.call,s=r&&i.bind.bind(o,o);e.exports=r?s:function(e){return function(){return o.apply(e,arguments)}}},7859:(e,t,n)=>{var r=n(3834),i=n(6107),o=function(e){return i(e)?e:void 0};e.exports=function(e,t){return arguments.length<2?o(r[e]):r[e]&&r[e][t]}},7689:(e,t,n)=>{var r=n(8762),i=n(3873);e.exports=function(e,t){var n=e[t];return i(n)?void 0:r(n)}},3834:function(e,t,n){var r=function(e){return e&&e.Math==Math&&e};e.exports=r("object"==typeof globalThis&&globalThis)||r("object"==typeof window&&window)||r("object"==typeof self&&self)||r("object"==typeof n.g&&n.g)||function(){return this}()||this||Function("return this")()},2924:(e,t,n)=>{var r=n(1636),i=n(8332),o=r({}.hasOwnProperty);e.exports=Object.hasOwn||function(e,t){return o(i(e),t)}},1999:e=>{e.exports={}},6335:(e,t,n)=>{var r=n(4133),i=n(8814),o=n(1657);e.exports=!r&&!i((function(){return 7!=Object.defineProperty(o("div"),"a",{get:function(){return 7}}).a}))},3972:(e,t,n)=>{var r=n(1636),i=n(8814),o=n(6749),s=Object,a=r("".split);e.exports=i((function(){return!s("z").propertyIsEnumerable(0)}))?function(e){return"String"==o(e)?a(e,""):s(e)}:s},6461:(e,t,n)=>{var r=n(1636),i=n(6107),o=n(6081),s=r(Function.toString);i(o.inspectSource)||(o.inspectSource=function(e){return s(e)}),e.exports=o.inspectSource},780:(e,t,n)=>{var r,i,o,s=n(5779),a=n(3834),l=n(1419),u=n(4722),c=n(2924),d=n(6081),h=n(5315),f=n(1999),p="Object already initialized",g=a.TypeError,m=a.WeakMap,v=function(e){return o(e)?i(e):r(e,{})},y=function(e){return function(t){var n;if(!l(t)||(n=i(t)).type!==e)throw g("Incompatible receiver, "+e+" required");return n}};if(s||d.state){var b=d.state||(d.state=new m);b.get=b.get,b.has=b.has,b.set=b.set,r=function(e,t){if(b.has(e))throw g(p);return t.facade=e,b.set(e,t),t},i=function(e){return b.get(e)||{}},o=function(e){return b.has(e)}}else{var w=h("state");f[w]=!0,r=function(e,t){if(c(e,w))throw g(p);return t.facade=e,u(e,w,t),t},i=function(e){return c(e,w)?e[w]:{}},o=function(e){return c(e,w)}}e.exports={set:r,get:i,has:o,enforce:v,getterFor:y}},6555:(e,t,n)=>{var r=n(6749);e.exports=Array.isArray||function(e){return"Array"==r(e)}},354:(e,t,n)=>{var r=n(4239);e.exports=function(e){var t=r(e);return"BigInt64Array"==t||"BigUint64Array"==t}},6107:(e,t,n)=>{var r=n(948),i=r.all;e.exports=r.IS_HTMLDDA?function(e){return"function"==typeof e||e===i}:function(e){return"function"==typeof e}},2764:(e,t,n)=>{var r=n(8814),i=n(6107),o=/#|\.prototype\./,s=function(e,t){var n=l[a(e)];return n==c||n!=u&&(i(t)?r(t):!!t)},a=s.normalize=function(e){return String(e).replace(o,".").toLowerCase()},l=s.data={},u=s.NATIVE="N",c=s.POLYFILL="P";e.exports=s},3873:e=>{e.exports=function(e){return null===e||void 0===e}},1419:(e,t,n)=>{var r=n(6107),i=n(948),o=i.all;e.exports=i.IS_HTMLDDA?function(e){return"object"==typeof e?null!==e:r(e)||e===o}:function(e){return"object"==typeof e?null!==e:r(e)}},200:e=>{e.exports=!1},1637:(e,t,n)=>{var r=n(7859),i=n(6107),o=n(6123),s=n(49),a=Object;e.exports=s?function(e){return"symbol"==typeof e}:function(e){var t=r("Symbol");return i(t)&&o(t.prototype,a(e))}},8600:(e,t,n)=>{var r=n(7302);e.exports=function(e){return r(e.length)}},2358:(e,t,n)=>{var r=n(1636),i=n(8814),o=n(6107),s=n(2924),a=n(4133),l=n(9104).CONFIGURABLE,u=n(6461),c=n(780),d=c.enforce,h=c.get,f=String,p=Object.defineProperty,g=r("".slice),m=r("".replace),v=r([].join),y=a&&!i((function(){return 8!==p((function(){}),"length",{value:8}).length})),b=String(String).split("String"),w=e.exports=function(e,t,n){"Symbol("===g(f(t),0,7)&&(t="["+m(f(t),/^Symbol\(([^)]*)\)/,"$1")+"]"),n&&n.getter&&(t="get "+t),n&&n.setter&&(t="set "+t),(!s(e,"name")||l&&e.name!==t)&&(a?p(e,"name",{value:t,configurable:!0}):e.name=t),y&&n&&s(n,"arity")&&e.length!==n.arity&&p(e,"length",{value:n.arity});try{n&&s(n,"constructor")&&n.constructor?a&&p(e,"prototype",{writable:!1}):e.prototype&&(e.prototype=void 0)}catch(i){}var r=d(e);return s(r,"source")||(r.source=v(b,"string"==typeof t?t:"")),e};Function.prototype.toString=w((function(){return o(this)&&h(this).source||u(this)}),"toString")},7233:e=>{var t=Math.ceil,n=Math.floor;e.exports=Math.trunc||function(e){var r=+e;return(r>0?n:t)(r)}},1012:(e,t,n)=>{var r=n(4133),i=n(6335),o=n(64),s=n(616),a=n(1017),l=TypeError,u=Object.defineProperty,c=Object.getOwnPropertyDescriptor,d="enumerable",h="configurable",f="writable";t.f=r?o?function(e,t,n){if(s(e),t=a(t),s(n),"function"===typeof e&&"prototype"===t&&"value"in n&&f in n&&!n[f]){var r=c(e,t);r&&r[f]&&(e[t]=n.value,n={configurable:h in n?n[h]:r[h],enumerable:d in n?n[d]:r[d],writable:!1})}return u(e,t,n)}:u:function(e,t,n){if(s(e),t=a(t),s(n),i)try{return u(e,t,n)}catch(r){}if("get"in n||"set"in n)throw l("Accessors not supported");return"value"in n&&(e[t]=n.value),e}},863:(e,t,n)=>{var r=n(4133),i=n(6654),o=n(8068),s=n(3386),a=n(7447),l=n(1017),u=n(2924),c=n(6335),d=Object.getOwnPropertyDescriptor;t.f=r?d:function(e,t){if(e=a(e),t=l(t),c)try{return d(e,t)}catch(n){}if(u(e,t))return s(!i(o.f,e,t),e[t])}},3450:(e,t,n)=>{var r=n(6682),i=n(203),o=i.concat("length","prototype");t.f=Object.getOwnPropertyNames||function(e){return r(e,o)}},1996:(e,t)=>{t.f=Object.getOwnPropertySymbols},7886:(e,t,n)=>{var r=n(2924),i=n(6107),o=n(8332),s=n(5315),a=n(911),l=s("IE_PROTO"),u=Object,c=u.prototype;e.exports=a?u.getPrototypeOf:function(e){var t=o(e);if(r(t,l))return t[l];var n=t.constructor;return i(n)&&t instanceof n?n.prototype:t instanceof u?c:null}},6123:(e,t,n)=>{var r=n(1636);e.exports=r({}.isPrototypeOf)},6682:(e,t,n)=>{var r=n(1636),i=n(2924),o=n(7447),s=n(7714).indexOf,a=n(1999),l=r([].push);e.exports=function(e,t){var n,r=o(e),u=0,c=[];for(n in r)!i(a,n)&&i(r,n)&&l(c,n);while(t.length>u)i(r,n=t[u++])&&(~s(c,n)||l(c,n));return c}},8068:(e,t)=>{"use strict";var n={}.propertyIsEnumerable,r=Object.getOwnPropertyDescriptor,i=r&&!n.call({1:2},1);t.f=i?function(e){var t=r(this,e);return!!t&&t.enumerable}:n},6534:(e,t,n)=>{var r=n(5478),i=n(616),o=n(9220);e.exports=Object.setPrototypeOf||("__proto__"in{}?function(){var e,t=!1,n={};try{e=r(Object.prototype,"__proto__","set"),e(n,[]),t=n instanceof Array}catch(s){}return function(n,r){return i(n),o(r),t?e(n,r):n.__proto__=r,n}}():void 0)},9370:(e,t,n)=>{var r=n(6654),i=n(6107),o=n(1419),s=TypeError;e.exports=function(e,t){var n,a;if("string"===t&&i(n=e.toString)&&!o(a=r(n,e)))return a;if(i(n=e.valueOf)&&!o(a=r(n,e)))return a;if("string"!==t&&i(n=e.toString)&&!o(a=r(n,e)))return a;throw s("Can't convert object to primitive value")}},1240:(e,t,n)=>{var r=n(7859),i=n(1636),o=n(3450),s=n(1996),a=n(616),l=i([].concat);e.exports=r("Reflect","ownKeys")||function(e){var t=o.f(a(e)),n=s.f;return n?l(t,n(e)):t}},9592:(e,t,n)=>{"use strict";var r=n(616);e.exports=function(){var e=r(this),t="";return e.hasIndices&&(t+="d"),e.global&&(t+="g"),e.ignoreCase&&(t+="i"),e.multiline&&(t+="m"),e.dotAll&&(t+="s"),e.unicode&&(t+="u"),e.unicodeSets&&(t+="v"),e.sticky&&(t+="y"),t}},5177:(e,t,n)=>{var r=n(3873),i=TypeError;e.exports=function(e){if(r(e))throw i("Can't call method on "+e);return e}},5315:(e,t,n)=>{var r=n(8850),i=n(3965),o=r("keys");e.exports=function(e){return o[e]||(o[e]=i(e))}},6081:(e,t,n)=>{var r=n(3834),i=n(5437),o="__core-js_shared__",s=r[o]||i(o,{});e.exports=s},8850:(e,t,n)=>{var r=n(200),i=n(6081);(e.exports=function(e,t){return i[e]||(i[e]=void 0!==t?t:{})})("versions",[]).push({version:"3.31.0",mode:r?"pure":"global",copyright:"© 2014-2023 Denis Pushkarev (zloirock.ru)",license:"https://github.com/zloirock/core-js/blob/v3.31.0/LICENSE",source:"https://github.com/zloirock/core-js"})},4651:(e,t,n)=>{var r=n(1418),i=n(8814),o=n(3834),s=o.String;e.exports=!!Object.getOwnPropertySymbols&&!i((function(){var e=Symbol();return!s(e)||!(Object(e)instanceof Symbol)||!Symbol.sham&&r&&r<41}))},2661:(e,t,n)=>{var r=n(6675),i=Math.max,o=Math.min;e.exports=function(e,t){var n=r(e);return n<0?i(n+t,0):o(n,t)}},7385:(e,t,n)=>{var r=n(4384),i=TypeError;e.exports=function(e){var t=r(e,"number");if("number"==typeof t)throw i("Can't convert number to bigint");return BigInt(t)}},7447:(e,t,n)=>{var r=n(3972),i=n(5177);e.exports=function(e){return r(i(e))}},6675:(e,t,n)=>{var r=n(7233);e.exports=function(e){var t=+e;return t!==t||0===t?0:r(t)}},7302:(e,t,n)=>{var r=n(6675),i=Math.min;e.exports=function(e){return e>0?i(r(e),9007199254740991):0}},8332:(e,t,n)=>{var r=n(5177),i=Object;e.exports=function(e){return i(r(e))}},4384:(e,t,n)=>{var r=n(6654),i=n(1419),o=n(1637),s=n(7689),a=n(9370),l=n(4103),u=TypeError,c=l("toPrimitive");e.exports=function(e,t){if(!i(e)||o(e))return e;var n,l=s(e,c);if(l){if(void 0===t&&(t="default"),n=r(l,e,t),!i(n)||o(n))return n;throw u("Can't convert object to primitive value")}return void 0===t&&(t="number"),a(e,t)}},1017:(e,t,n)=>{var r=n(4384),i=n(1637);e.exports=function(e){var t=r(e,"string");return i(t)?t:t+""}},4130:(e,t,n)=>{var r=n(4103),i=r("toStringTag"),o={};o[i]="z",e.exports="[object z]"===String(o)},7545:e=>{var t=String;e.exports=function(e){try{return t(e)}catch(n){return"Object"}}},3965:(e,t,n)=>{var r=n(1636),i=0,o=Math.random(),s=r(1..toString);e.exports=function(e){return"Symbol("+(void 0===e?"":e)+")_"+s(++i+o,36)}},49:(e,t,n)=>{var r=n(4651);e.exports=r&&!Symbol.sham&&"symbol"==typeof Symbol.iterator},64:(e,t,n)=>{var r=n(4133),i=n(8814);e.exports=r&&i((function(){return 42!=Object.defineProperty((function(){}),"prototype",{value:42,writable:!1}).prototype}))},5779:(e,t,n)=>{var r=n(3834),i=n(6107),o=r.WeakMap;e.exports=i(o)&&/native code/.test(String(o))},4103:(e,t,n)=>{var r=n(3834),i=n(8850),o=n(2924),s=n(3965),a=n(4651),l=n(49),u=r.Symbol,c=i("wks"),d=l?u["for"]||u:u&&u.withoutSetter||s;e.exports=function(e){return o(c,e)||(c[e]=a&&o(u,e)?u[e]:d("Symbol."+e)),c[e]}},9665:(e,t,n)=>{"use strict";var r=n(6943),i=n(8332),o=n(8600),s=n(3614),a=n(6689),l=n(8814),u=l((function(){return 4294967297!==[].push.call({length:4294967296},1)})),c=function(){try{Object.defineProperty([],"length",{writable:!1}).push()}catch(e){return e instanceof TypeError}},d=u||!c();r({target:"Array",proto:!0,arity:1,forced:d},{push:function(e){var t=i(this),n=o(t),r=arguments.length;a(n+r);for(var l=0;l<r;l++)t[n]=arguments[l],n++;return s(t,n),n}})},6890:(e,t,n)=>{"use strict";var r=n(6943),i=n(8332),o=n(8600),s=n(3614),a=n(6405),l=n(6689),u=1!==[].unshift(0),c=function(){try{Object.defineProperty([],"length",{writable:!1}).unshift()}catch(e){return e instanceof TypeError}},d=u||!c();r({target:"Array",proto:!0,arity:1,forced:d},{unshift:function(e){var t=i(this),n=o(t),r=arguments.length;if(r){l(n+r);var u=n;while(u--){var c=u+r;u in t?t[c]=t[u]:a(t,c)}for(var d=0;d<r;d++)t[d]=arguments[d]}return s(t,n+r)}})},3122:(e,t,n)=>{var r=n(3834),i=n(4133),o=n(9570),s=n(9592),a=n(8814),l=r.RegExp,u=l.prototype,c=i&&a((function(){var e=!0;try{l(".","d")}catch(c){e=!1}var t={},n="",r=e?"dgimsy":"gimsy",i=function(e,r){Object.defineProperty(t,e,{get:function(){return n+=r,!0}})},o={dotAll:"s",global:"g",ignoreCase:"i",multiline:"m",sticky:"y"};for(var s in e&&(o.hasIndices="d"),o)i(s,o[s]);var a=Object.getOwnPropertyDescriptor(u,"flags").get.call(t);return a!==r||n!==r}));c&&o(u,"flags",{configurable:!0,get:s})},5231:(e,t,n)=>{"use strict";var r=n(8086),i=n(8600),o=n(6675),s=r.aTypedArray,a=r.exportTypedArrayMethod;a("at",(function(e){var t=s(this),n=i(t),r=o(e),a=r>=0?r:n+r;return a<0||a>=n?void 0:t[a]}))},548:(e,t,n)=>{"use strict";var r=n(8086),i=n(9275).findLastIndex,o=r.aTypedArray,s=r.exportTypedArrayMethod;s("findLastIndex",(function(e){return i(o(this),e,arguments.length>1?arguments[1]:void 0)}))},3075:(e,t,n)=>{"use strict";var r=n(8086),i=n(9275).findLast,o=r.aTypedArray,s=r.exportTypedArrayMethod;s("findLast",(function(e){return i(o(this),e,arguments.length>1?arguments[1]:void 0)}))},2279:(e,t,n)=>{"use strict";var r=n(7579),i=n(8086),o=i.aTypedArray,s=i.exportTypedArrayMethod,a=i.getTypedArrayConstructor;s("toReversed",(function(){return r(o(this),a(this))}))},2157:(e,t,n)=>{"use strict";var r=n(8086),i=n(1636),o=n(8762),s=n(3364),a=r.aTypedArray,l=r.getTypedArrayConstructor,u=r.exportTypedArrayMethod,c=i(r.TypedArrayPrototype.sort);u("toSorted",(function(e){void 0!==e&&o(e);var t=a(this),n=s(l(t),t);return c(n,e)}))},6735:(e,t,n)=>{"use strict";var r=n(5330),i=n(8086),o=n(354),s=n(6675),a=n(7385),l=i.aTypedArray,u=i.getTypedArrayConstructor,c=i.exportTypedArrayMethod,d=!!function(){try{new Int8Array(1)["with"](2,{valueOf:function(){throw 8}})}catch(e){return 8===e}}();c("with",{with:function(e,t){var n=l(this),i=s(e),c=o(n)?a(t):+t;return r(n,u(n),i,c)}}["with"],!d)},1639:(e,t)=>{"use strict";t.Z=(e,t)=>{const n=e.__vccOpts||e;for(const[r,i]of t)n[r]=i;return n}},9719:(e,t,n)=>{"use strict";n.d(t,{Z:()=>r});const r={isoName:"pt-BR",nativeName:"Português (BR)",label:{clear:"Limpar",ok:"OK",cancel:"Cancelar",close:"Fechar",set:"Escolher",select:"Selecionar",reset:"Redefinir",remove:"Remover",update:"Atualizar",create:"Criar",search:"Buscar",filter:"Filtrar",refresh:"Recarregar",expand:e=>e?`Expandir "${e}"`:"Expandir",collapse:e=>e?`Recolher "${e}"`:"Colapso"},date:{days:"Domingo_Segunda-feira_Terça-feira_Quarta-feira_Quinta-feira_Sexta-feira_Sábado".split("_"),daysShort:"Dom_Seg_Ter_Qua_Qui_Sex_Sáb".split("_"),months:"Janeiro_Fevereiro_Março_Abril_Maio_Junho_Julho_Agosto_Setembro_Outubro_Novembro_Dezembro".split("_"),monthsShort:"Jan_Fev_Mar_Abr_Mai_Jun_Jul_Ago_Set_Out_Nov_Dez".split("_"),firstDayOfWeek:0,format24h:!0,pluralDay:"dias"},table:{noData:"Sem dados disponíveis",noResults:"Nenhum dado correspondente encontrado",loading:"Carregando...",selectedRecords:e=>e>0?e+" registro"+(1===e?" selecionado":"s selecionados")+".":"Nenhum registro selecionado.",recordsPerPage:"Registros por página:",allRows:"Todos",pagination:(e,t,n)=>e+"-"+t+" de "+n,columns:"Colunas"},editor:{url:"URL",bold:"Negrito",italic:"Itálico",strikethrough:"Riscado",underline:"Sublinhado",unorderedList:"Lista não-ordenada",orderedList:"Lista ordenada",subscript:"Subscrito",superscript:"Sobrescrito",hyperlink:"Hyperlink",toggleFullscreen:"Tela cheia",quote:"Citação",left:"Alinhado à esquerda",center:"Alinhado ao centro",right:"Alinhado à direita",justify:"Justificado",print:"Imprimir",outdent:"Diminuir indentação",indent:"Aumentar indentação",removeFormat:"Remover formatação",formatting:"Formatação",fontSize:"Tamanho de fonte",align:"Alinhar",hr:"Inserir divisória horizontal",undo:"Desfazer",redo:"Refazer",heading1:"Cabeçalho 1",heading2:"Cabeçalho 2",heading3:"Cabeçalho 3",heading4:"Cabeçalho 4",heading5:"Cabeçalho 5",heading6:"Cabeçalho 6",paragraph:"Parágrafo",code:"Código",size1:"Muito pequeno",size2:"Pequeno",size3:"Normal",size4:"Médio",size5:"Grande",size6:"Enorme",size7:"Máximo",defaultFont:"Fonte padrão",viewSource:"Exibir fonte"},tree:{noNodes:"Sem nós disponíveis",noResults:"Nenhum nó correspondente encontrado"}}},3340:(e,t,n)=>{"use strict";function r(e){return e}n.d(t,{BC:()=>r})},8339:(e,t,n)=>{"use strict";n.d(t,{p7:()=>nt,r5:()=>U});var r=n(9835),i=n(499);
/*!
  * vue-router v4.2.2
  * (c) 2023 Eduardo San Martin Morote
  * @license MIT
  */
const o="undefined"!==typeof window;function s(e){return e.__esModule||"Module"===e[Symbol.toStringTag]}const a=Object.assign;function l(e,t){const n={};for(const r in t){const i=t[r];n[r]=c(i)?i.map(e):e(i)}return n}const u=()=>{},c=Array.isArray;const d=/\/$/,h=e=>e.replace(d,"");function f(e,t,n="/"){let r,i={},o="",s="";const a=t.indexOf("#");let l=t.indexOf("?");return a<l&&a>=0&&(l=-1),l>-1&&(r=t.slice(0,l),o=t.slice(l+1,a>-1?a:t.length),i=e(o)),a>-1&&(r=r||t.slice(0,a),s=t.slice(a,t.length)),r=_(null!=r?r:t,n),{fullPath:r+(o&&"?")+o+s,path:r,query:i,hash:s}}function p(e,t){const n=t.query?e(t.query):"";return t.path+(n&&"?")+n+(t.hash||"")}function g(e,t){return t&&e.toLowerCase().startsWith(t.toLowerCase())?e.slice(t.length)||"/":e}function m(e,t,n){const r=t.matched.length-1,i=n.matched.length-1;return r>-1&&r===i&&v(t.matched[r],n.matched[i])&&y(t.params,n.params)&&e(t.query)===e(n.query)&&t.hash===n.hash}function v(e,t){return(e.aliasOf||e)===(t.aliasOf||t)}function y(e,t){if(Object.keys(e).length!==Object.keys(t).length)return!1;for(const n in e)if(!b(e[n],t[n]))return!1;return!0}function b(e,t){return c(e)?w(e,t):c(t)?w(t,e):e===t}function w(e,t){return c(t)?e.length===t.length&&e.every(((e,n)=>e===t[n])):1===e.length&&e[0]===t}function _(e,t){if(e.startsWith("/"))return e;if(!e)return t;const n=t.split("/"),r=e.split("/"),i=r[r.length-1];".."!==i&&"."!==i||r.push("");let o,s,a=n.length-1;for(o=0;o<r.length;o++)if(s=r[o],"."!==s){if(".."!==s)break;a>1&&a--}return n.slice(0,a).join("/")+"/"+r.slice(o-(o===r.length?1:0)).join("/")}var S,E;(function(e){e["pop"]="pop",e["push"]="push"})(S||(S={})),function(e){e["back"]="back",e["forward"]="forward",e["unknown"]=""}(E||(E={}));function k(e){if(!e)if(o){const t=document.querySelector("base");e=t&&t.getAttribute("href")||"/",e=e.replace(/^\w+:\/\/[^\/]+/,"")}else e="/";return"/"!==e[0]&&"#"!==e[0]&&(e="/"+e),h(e)}const T=/^[^#]+#/;function C(e,t){return e.replace(T,"#")+t}function I(e,t){const n=document.documentElement.getBoundingClientRect(),r=e.getBoundingClientRect();return{behavior:t.behavior,left:r.left-n.left-(t.left||0),top:r.top-n.top-(t.top||0)}}const x=()=>({left:window.pageXOffset,top:window.pageYOffset});function A(e){let t;if("el"in e){const n=e.el,r="string"===typeof n&&n.startsWith("#");0;const i="string"===typeof n?r?document.getElementById(n.slice(1)):document.querySelector(n):n;if(!i)return;t=I(i,e)}else t=e;"scrollBehavior"in document.documentElement.style?window.scrollTo(t):window.scrollTo(null!=t.left?t.left:window.pageXOffset,null!=t.top?t.top:window.pageYOffset)}function R(e,t){const n=history.state?history.state.position-t:-1;return n+e}const O=new Map;function N(e,t){O.set(e,t)}function P(e){const t=O.get(e);return O.delete(e),t}let F=()=>location.protocol+"//"+location.host;function L(e,t){const{pathname:n,search:r,hash:i}=t,o=e.indexOf("#");if(o>-1){let t=i.includes(e.slice(o))?e.slice(o).length:1,n=i.slice(t);return"/"!==n[0]&&(n="/"+n),g(n,"")}const s=g(n,e);return s+r+i}function D(e,t,n,r){let i=[],o=[],s=null;const l=({state:o})=>{const a=L(e,location),l=n.value,u=t.value;let c=0;if(o){if(n.value=a,t.value=o,s&&s===l)return void(s=null);c=u?o.position-u.position:0}else r(a);i.forEach((e=>{e(n.value,l,{delta:c,type:S.pop,direction:c?c>0?E.forward:E.back:E.unknown})}))};function u(){s=n.value}function c(e){i.push(e);const t=()=>{const t=i.indexOf(e);t>-1&&i.splice(t,1)};return o.push(t),t}function d(){const{history:e}=window;e.state&&e.replaceState(a({},e.state,{scroll:x()}),"")}function h(){for(const e of o)e();o=[],window.removeEventListener("popstate",l),window.removeEventListener("beforeunload",d)}return window.addEventListener("popstate",l),window.addEventListener("beforeunload",d,{passive:!0}),{pauseListeners:u,listen:c,destroy:h}}function M(e,t,n,r=!1,i=!1){return{back:e,current:t,forward:n,replaced:r,position:window.history.length,scroll:i?x():null}}function q(e){const{history:t,location:n}=window,r={value:L(e,n)},i={value:t.state};function o(r,o,s){const a=e.indexOf("#"),l=a>-1?(n.host&&document.querySelector("base")?e:e.slice(a))+r:F()+e+r;try{t[s?"replaceState":"pushState"](o,"",l),i.value=o}catch(u){console.error(u),n[s?"replace":"assign"](l)}}function s(e,n){const s=a({},t.state,M(i.value.back,e,i.value.forward,!0),n,{position:i.value.position});o(e,s,!0),r.value=e}function l(e,n){const s=a({},i.value,t.state,{forward:e,scroll:x()});o(s.current,s,!0);const l=a({},M(r.value,e,null),{position:s.position+1},n);o(e,l,!1),r.value=e}return i.value||o(r.value,{back:null,current:r.value,forward:null,position:t.length-1,replaced:!0,scroll:null},!0),{location:r,state:i,push:l,replace:s}}function V(e){e=k(e);const t=q(e),n=D(e,t.state,t.location,t.replace);function r(e,t=!0){t||n.pauseListeners(),history.go(e)}const i=a({location:"",base:e,go:r,createHref:C.bind(null,e)},t,n);return Object.defineProperty(i,"location",{enumerable:!0,get:()=>t.location.value}),Object.defineProperty(i,"state",{enumerable:!0,get:()=>t.state.value}),i}function U(e){return e=location.host?e||location.pathname+location.search:"",e.includes("#")||(e+="#"),V(e)}function B(e){return"string"===typeof e||e&&"object"===typeof e}function $(e){return"string"===typeof e||"symbol"===typeof e}const j={path:"/",name:void 0,params:{},query:{},hash:"",fullPath:"/",matched:[],meta:{},redirectedFrom:void 0},z=Symbol("");var H;(function(e){e[e["aborted"]=4]="aborted",e[e["cancelled"]=8]="cancelled",e[e["duplicated"]=16]="duplicated"})(H||(H={}));function K(e,t){return a(new Error,{type:e,[z]:!0},t)}function W(e,t){return e instanceof Error&&z in e&&(null==t||!!(e.type&t))}const Z="[^/]+?",G={sensitive:!1,strict:!1,start:!0,end:!0},J=/[.+*?^${}()[\]/\\]/g;function Q(e,t){const n=a({},G,t),r=[];let i=n.start?"^":"";const o=[];for(const a of e){const e=a.length?[]:[90];n.strict&&!a.length&&(i+="/");for(let t=0;t<a.length;t++){const r=a[t];let s=40+(n.sensitive?.25:0);if(0===r.type)t||(i+="/"),i+=r.value.replace(J,"\\$&"),s+=40;else if(1===r.type){const{value:e,repeatable:n,optional:l,regexp:u}=r;o.push({name:e,repeatable:n,optional:l});const c=u||Z;if(c!==Z){s+=10;try{new RegExp(`(${c})`)}catch(d){throw new Error(`Invalid custom RegExp for param "${e}" (${c}): `+d.message)}}let h=n?`((?:${c})(?:/(?:${c}))*)`:`(${c})`;t||(h=l&&a.length<2?`(?:/${h})`:"/"+h),l&&(h+="?"),i+=h,s+=20,l&&(s+=-8),n&&(s+=-20),".*"===c&&(s+=-50)}e.push(s)}r.push(e)}if(n.strict&&n.end){const e=r.length-1;r[e][r[e].length-1]+=.7000000000000001}n.strict||(i+="/?"),n.end?i+="$":n.strict&&(i+="(?:/|$)");const s=new RegExp(i,n.sensitive?"":"i");function l(e){const t=e.match(s),n={};if(!t)return null;for(let r=1;r<t.length;r++){const e=t[r]||"",i=o[r-1];n[i.name]=e&&i.repeatable?e.split("/"):e}return n}function u(t){let n="",r=!1;for(const i of e){r&&n.endsWith("/")||(n+="/"),r=!1;for(const e of i)if(0===e.type)n+=e.value;else if(1===e.type){const{value:o,repeatable:s,optional:a}=e,l=o in t?t[o]:"";if(c(l)&&!s)throw new Error(`Provided param "${o}" is an array but it is not repeatable (* or + modifiers)`);const u=c(l)?l.join("/"):l;if(!u){if(!a)throw new Error(`Missing required param "${o}"`);i.length<2&&(n.endsWith("/")?n=n.slice(0,-1):r=!0)}n+=u}}return n||"/"}return{re:s,score:r,keys:o,parse:l,stringify:u}}function Y(e,t){let n=0;while(n<e.length&&n<t.length){const r=t[n]-e[n];if(r)return r;n++}return e.length<t.length?1===e.length&&80===e[0]?-1:1:e.length>t.length?1===t.length&&80===t[0]?1:-1:0}function X(e,t){let n=0;const r=e.score,i=t.score;while(n<r.length&&n<i.length){const e=Y(r[n],i[n]);if(e)return e;n++}if(1===Math.abs(i.length-r.length)){if(ee(r))return 1;if(ee(i))return-1}return i.length-r.length}function ee(e){const t=e[e.length-1];return e.length>0&&t[t.length-1]<0}const te={type:0,value:""},ne=/[a-zA-Z0-9_]/;function re(e){if(!e)return[[]];if("/"===e)return[[te]];if(!e.startsWith("/"))throw new Error(`Invalid path "${e}"`);function t(e){throw new Error(`ERR (${n})/"${u}": ${e}`)}let n=0,r=n;const i=[];let o;function s(){o&&i.push(o),o=[]}let a,l=0,u="",c="";function d(){u&&(0===n?o.push({type:0,value:u}):1===n||2===n||3===n?(o.length>1&&("*"===a||"+"===a)&&t(`A repeatable param (${u}) must be alone in its segment. eg: '/:ids+.`),o.push({type:1,value:u,regexp:c,repeatable:"*"===a||"+"===a,optional:"*"===a||"?"===a})):t("Invalid state to consume buffer"),u="")}function h(){u+=a}while(l<e.length)if(a=e[l++],"\\"!==a||2===n)switch(n){case 0:"/"===a?(u&&d(),s()):":"===a?(d(),n=1):h();break;case 4:h(),n=r;break;case 1:"("===a?n=2:ne.test(a)?h():(d(),n=0,"*"!==a&&"?"!==a&&"+"!==a&&l--);break;case 2:")"===a?"\\"==c[c.length-1]?c=c.slice(0,-1)+a:n=3:c+=a;break;case 3:d(),n=0,"*"!==a&&"?"!==a&&"+"!==a&&l--,c="";break;default:t("Unknown state");break}else r=n,n=4;return 2===n&&t(`Unfinished custom RegExp for param "${u}"`),d(),s(),i}function ie(e,t,n){const r=Q(re(e.path),n);const i=a(r,{record:e,parent:t,children:[],alias:[]});return t&&!i.record.aliasOf===!t.record.aliasOf&&t.children.push(i),i}function oe(e,t){const n=[],r=new Map;function i(e){return r.get(e)}function o(e,n,r){const i=!r,l=ae(e);l.aliasOf=r&&r.record;const d=de(t,e),h=[l];if("alias"in e){const t="string"===typeof e.alias?[e.alias]:e.alias;for(const e of t)h.push(a({},l,{components:r?r.record.components:l.components,path:e,aliasOf:r?r.record:l}))}let f,p;for(const t of h){const{path:a}=t;if(n&&"/"!==a[0]){const e=n.record.path,r="/"===e[e.length-1]?"":"/";t.path=n.record.path+(a&&r+a)}if(f=ie(t,n,d),r?r.alias.push(f):(p=p||f,p!==f&&p.alias.push(f),i&&e.name&&!ue(f)&&s(e.name)),l.children){const e=l.children;for(let t=0;t<e.length;t++)o(e[t],f,r&&r.children[t])}r=r||f,(f.record.components&&Object.keys(f.record.components).length||f.record.name||f.record.redirect)&&c(f)}return p?()=>{s(p)}:u}function s(e){if($(e)){const t=r.get(e);t&&(r.delete(e),n.splice(n.indexOf(t),1),t.children.forEach(s),t.alias.forEach(s))}else{const t=n.indexOf(e);t>-1&&(n.splice(t,1),e.record.name&&r.delete(e.record.name),e.children.forEach(s),e.alias.forEach(s))}}function l(){return n}function c(e){let t=0;while(t<n.length&&X(e,n[t])>=0&&(e.record.path!==n[t].record.path||!he(e,n[t])))t++;n.splice(t,0,e),e.record.name&&!ue(e)&&r.set(e.record.name,e)}function d(e,t){let i,o,s,l={};if("name"in e&&e.name){if(i=r.get(e.name),!i)throw K(1,{location:e});0,s=i.record.name,l=a(se(t.params,i.keys.filter((e=>!e.optional)).map((e=>e.name))),e.params&&se(e.params,i.keys.map((e=>e.name)))),o=i.stringify(l)}else if("path"in e)o=e.path,i=n.find((e=>e.re.test(o))),i&&(l=i.parse(o),s=i.record.name);else{if(i=t.name?r.get(t.name):n.find((e=>e.re.test(t.path))),!i)throw K(1,{location:e,currentLocation:t});s=i.record.name,l=a({},t.params,e.params),o=i.stringify(l)}const u=[];let c=i;while(c)u.unshift(c.record),c=c.parent;return{name:s,path:o,params:l,matched:u,meta:ce(u)}}return t=de({strict:!1,end:!0,sensitive:!1},t),e.forEach((e=>o(e))),{addRoute:o,resolve:d,removeRoute:s,getRoutes:l,getRecordMatcher:i}}function se(e,t){const n={};for(const r of t)r in e&&(n[r]=e[r]);return n}function ae(e){return{path:e.path,redirect:e.redirect,name:e.name,meta:e.meta||{},aliasOf:void 0,beforeEnter:e.beforeEnter,props:le(e),children:e.children||[],instances:{},leaveGuards:new Set,updateGuards:new Set,enterCallbacks:{},components:"components"in e?e.components||null:e.component&&{default:e.component}}}function le(e){const t={},n=e.props||!1;if("component"in e)t.default=n;else for(const r in e.components)t[r]="boolean"===typeof n?n:n[r];return t}function ue(e){while(e){if(e.record.aliasOf)return!0;e=e.parent}return!1}function ce(e){return e.reduce(((e,t)=>a(e,t.meta)),{})}function de(e,t){const n={};for(const r in e)n[r]=r in t?t[r]:e[r];return n}function he(e,t){return t.children.some((t=>t===e||he(e,t)))}const fe=/#/g,pe=/&/g,ge=/\//g,me=/=/g,ve=/\?/g,ye=/\+/g,be=/%5B/g,we=/%5D/g,_e=/%5E/g,Se=/%60/g,Ee=/%7B/g,ke=/%7C/g,Te=/%7D/g,Ce=/%20/g;function Ie(e){return encodeURI(""+e).replace(ke,"|").replace(be,"[").replace(we,"]")}function xe(e){return Ie(e).replace(Ee,"{").replace(Te,"}").replace(_e,"^")}function Ae(e){return Ie(e).replace(ye,"%2B").replace(Ce,"+").replace(fe,"%23").replace(pe,"%26").replace(Se,"`").replace(Ee,"{").replace(Te,"}").replace(_e,"^")}function Re(e){return Ae(e).replace(me,"%3D")}function Oe(e){return Ie(e).replace(fe,"%23").replace(ve,"%3F")}function Ne(e){return null==e?"":Oe(e).replace(ge,"%2F")}function Pe(e){try{return decodeURIComponent(""+e)}catch(t){}return""+e}function Fe(e){const t={};if(""===e||"?"===e)return t;const n="?"===e[0],r=(n?e.slice(1):e).split("&");for(let i=0;i<r.length;++i){const e=r[i].replace(ye," "),n=e.indexOf("="),o=Pe(n<0?e:e.slice(0,n)),s=n<0?null:Pe(e.slice(n+1));if(o in t){let e=t[o];c(e)||(e=t[o]=[e]),e.push(s)}else t[o]=s}return t}function Le(e){let t="";for(let n in e){const r=e[n];if(n=Re(n),null==r){void 0!==r&&(t+=(t.length?"&":"")+n);continue}const i=c(r)?r.map((e=>e&&Ae(e))):[r&&Ae(r)];i.forEach((e=>{void 0!==e&&(t+=(t.length?"&":"")+n,null!=e&&(t+="="+e))}))}return t}function De(e){const t={};for(const n in e){const r=e[n];void 0!==r&&(t[n]=c(r)?r.map((e=>null==e?null:""+e)):null==r?r:""+r)}return t}const Me=Symbol(""),qe=Symbol(""),Ve=Symbol(""),Ue=Symbol(""),Be=Symbol("");function $e(){let e=[];function t(t){return e.push(t),()=>{const n=e.indexOf(t);n>-1&&e.splice(n,1)}}function n(){e=[]}return{add:t,list:()=>e,reset:n}}function je(e,t,n,r,i){const o=r&&(r.enterCallbacks[i]=r.enterCallbacks[i]||[]);return()=>new Promise(((s,a)=>{const l=e=>{!1===e?a(K(4,{from:n,to:t})):e instanceof Error?a(e):B(e)?a(K(2,{from:t,to:e})):(o&&r.enterCallbacks[i]===o&&"function"===typeof e&&o.push(e),s())},u=e.call(r&&r.instances[i],t,n,l);let c=Promise.resolve(u);e.length<3&&(c=c.then(l)),c.catch((e=>a(e)))}))}function ze(e,t,n,r){const i=[];for(const o of e){0;for(const e in o.components){let a=o.components[e];if("beforeRouteEnter"===t||o.instances[e])if(He(a)){const s=a.__vccOpts||a,l=s[t];l&&i.push(je(l,n,r,o,e))}else{let l=a();0,i.push((()=>l.then((i=>{if(!i)return Promise.reject(new Error(`Couldn't resolve component "${e}" at "${o.path}"`));const a=s(i)?i.default:i;o.components[e]=a;const l=a.__vccOpts||a,u=l[t];return u&&je(u,n,r,o,e)()}))))}}}return i}function He(e){return"object"===typeof e||"displayName"in e||"props"in e||"__vccOpts"in e}function Ke(e){const t=(0,r.f3)(Ve),n=(0,r.f3)(Ue),o=(0,r.Fl)((()=>t.resolve((0,i.SU)(e.to)))),s=(0,r.Fl)((()=>{const{matched:e}=o.value,{length:t}=e,r=e[t-1],i=n.matched;if(!r||!i.length)return-1;const s=i.findIndex(v.bind(null,r));if(s>-1)return s;const a=Qe(e[t-2]);return t>1&&Qe(r)===a&&i[i.length-1].path!==a?i.findIndex(v.bind(null,e[t-2])):s})),a=(0,r.Fl)((()=>s.value>-1&&Je(n.params,o.value.params))),l=(0,r.Fl)((()=>s.value>-1&&s.value===n.matched.length-1&&y(n.params,o.value.params)));function c(n={}){return Ge(n)?t[(0,i.SU)(e.replace)?"replace":"push"]((0,i.SU)(e.to)).catch(u):Promise.resolve()}return{route:o,href:(0,r.Fl)((()=>o.value.href)),isActive:a,isExactActive:l,navigate:c}}const We=(0,r.aZ)({name:"RouterLink",compatConfig:{MODE:3},props:{to:{type:[String,Object],required:!0},replace:Boolean,activeClass:String,exactActiveClass:String,custom:Boolean,ariaCurrentValue:{type:String,default:"page"}},useLink:Ke,setup(e,{slots:t}){const n=(0,i.qj)(Ke(e)),{options:o}=(0,r.f3)(Ve),s=(0,r.Fl)((()=>({[Ye(e.activeClass,o.linkActiveClass,"router-link-active")]:n.isActive,[Ye(e.exactActiveClass,o.linkExactActiveClass,"router-link-exact-active")]:n.isExactActive})));return()=>{const i=t.default&&t.default(n);return e.custom?i:(0,r.h)("a",{"aria-current":n.isExactActive?e.ariaCurrentValue:null,href:n.href,onClick:n.navigate,class:s.value},i)}}}),Ze=We;function Ge(e){if(!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)&&!e.defaultPrevented&&(void 0===e.button||0===e.button)){if(e.currentTarget&&e.currentTarget.getAttribute){const t=e.currentTarget.getAttribute("target");if(/\b_blank\b/i.test(t))return}return e.preventDefault&&e.preventDefault(),!0}}function Je(e,t){for(const n in t){const r=t[n],i=e[n];if("string"===typeof r){if(r!==i)return!1}else if(!c(i)||i.length!==r.length||r.some(((e,t)=>e!==i[t])))return!1}return!0}function Qe(e){return e?e.aliasOf?e.aliasOf.path:e.path:""}const Ye=(e,t,n)=>null!=e?e:null!=t?t:n,Xe=(0,r.aZ)({name:"RouterView",inheritAttrs:!1,props:{name:{type:String,default:"default"},route:Object},compatConfig:{MODE:3},setup(e,{attrs:t,slots:n}){const o=(0,r.f3)(Be),s=(0,r.Fl)((()=>e.route||o.value)),l=(0,r.f3)(qe,0),u=(0,r.Fl)((()=>{let e=(0,i.SU)(l);const{matched:t}=s.value;let n;while((n=t[e])&&!n.components)e++;return e})),c=(0,r.Fl)((()=>s.value.matched[u.value]));(0,r.JJ)(qe,(0,r.Fl)((()=>u.value+1))),(0,r.JJ)(Me,c),(0,r.JJ)(Be,s);const d=(0,i.iH)();return(0,r.YP)((()=>[d.value,c.value,e.name]),(([e,t,n],[r,i,o])=>{t&&(t.instances[n]=e,i&&i!==t&&e&&e===r&&(t.leaveGuards.size||(t.leaveGuards=i.leaveGuards),t.updateGuards.size||(t.updateGuards=i.updateGuards))),!e||!t||i&&v(t,i)&&r||(t.enterCallbacks[n]||[]).forEach((t=>t(e)))}),{flush:"post"}),()=>{const i=s.value,o=e.name,l=c.value,u=l&&l.components[o];if(!u)return et(n.default,{Component:u,route:i});const h=l.props[o],f=h?!0===h?i.params:"function"===typeof h?h(i):h:null,p=e=>{e.component.isUnmounted&&(l.instances[o]=null)},g=(0,r.h)(u,a({},f,t,{onVnodeUnmounted:p,ref:d}));return et(n.default,{Component:g,route:i})||g}}});function et(e,t){if(!e)return null;const n=e(t);return 1===n.length?n[0]:n}const tt=Xe;function nt(e){const t=oe(e.routes,e),n=e.parseQuery||Fe,s=e.stringifyQuery||Le,d=e.history;const h=$e(),g=$e(),v=$e(),y=(0,i.XI)(j);let b=j;o&&e.scrollBehavior&&"scrollRestoration"in history&&(history.scrollRestoration="manual");const w=l.bind(null,(e=>""+e)),_=l.bind(null,Ne),E=l.bind(null,Pe);function k(e,n){let r,i;return $(e)?(r=t.getRecordMatcher(e),i=n):i=e,t.addRoute(i,r)}function T(e){const n=t.getRecordMatcher(e);n&&t.removeRoute(n)}function C(){return t.getRoutes().map((e=>e.record))}function I(e){return!!t.getRecordMatcher(e)}function O(e,r){if(r=a({},r||y.value),"string"===typeof e){const i=f(n,e,r.path),o=t.resolve({path:i.path},r),s=d.createHref(i.fullPath);return a(i,o,{params:E(o.params),hash:Pe(i.hash),redirectedFrom:void 0,href:s})}let i;if("path"in e)i=a({},e,{path:f(n,e.path,r.path).path});else{const t=a({},e.params);for(const e in t)null==t[e]&&delete t[e];i=a({},e,{params:_(t)}),r.params=_(r.params)}const o=t.resolve(i,r),l=e.hash||"";o.params=w(E(o.params));const u=p(s,a({},e,{hash:xe(l),path:o.path})),c=d.createHref(u);return a({fullPath:u,hash:l,query:s===Le?De(e.query):e.query||{}},o,{redirectedFrom:void 0,href:c})}function F(e){return"string"===typeof e?f(n,e,y.value.path):a({},e)}function L(e,t){if(b!==e)return K(8,{from:t,to:e})}function D(e){return V(e)}function M(e){return D(a(F(e),{replace:!0}))}function q(e){const t=e.matched[e.matched.length-1];if(t&&t.redirect){const{redirect:n}=t;let r="function"===typeof n?n(e):n;return"string"===typeof r&&(r=r.includes("?")||r.includes("#")?r=F(r):{path:r},r.params={}),a({query:e.query,hash:e.hash,params:"path"in r?{}:e.params},r)}}function V(e,t){const n=b=O(e),r=y.value,i=e.state,o=e.force,l=!0===e.replace,u=q(n);if(u)return V(a(F(u),{state:"object"===typeof u?a({},i,u.state):i,force:o,replace:l}),t||n);const c=n;let d;return c.redirectedFrom=t,!o&&m(s,r,n)&&(d=K(16,{to:c,from:r}),re(r,r,!0,!1)),(d?Promise.resolve(d):z(c,r)).catch((e=>W(e)?W(e,2)?e:ne(e):ee(e,c,r))).then((e=>{if(e){if(W(e,2))return V(a({replace:l},F(e.to),{state:"object"===typeof e.to?a({},i,e.to.state):i,force:o}),t||c)}else e=Z(c,r,!0,l,i);return H(c,r,e),e}))}function U(e,t){const n=L(e,t);return n?Promise.reject(n):Promise.resolve()}function B(e){const t=ae.values().next().value;return t&&"function"===typeof t.runWithContext?t.runWithContext(e):e()}function z(e,t){let n;const[r,i,o]=rt(e,t);n=ze(r.reverse(),"beforeRouteLeave",e,t);for(const a of r)a.leaveGuards.forEach((r=>{n.push(je(r,e,t))}));const s=U.bind(null,e,t);return n.push(s),ue(n).then((()=>{n=[];for(const r of h.list())n.push(je(r,e,t));return n.push(s),ue(n)})).then((()=>{n=ze(i,"beforeRouteUpdate",e,t);for(const r of i)r.updateGuards.forEach((r=>{n.push(je(r,e,t))}));return n.push(s),ue(n)})).then((()=>{n=[];for(const r of e.matched)if(r.beforeEnter&&!t.matched.includes(r))if(c(r.beforeEnter))for(const i of r.beforeEnter)n.push(je(i,e,t));else n.push(je(r.beforeEnter,e,t));return n.push(s),ue(n)})).then((()=>(e.matched.forEach((e=>e.enterCallbacks={})),n=ze(o,"beforeRouteEnter",e,t),n.push(s),ue(n)))).then((()=>{n=[];for(const r of g.list())n.push(je(r,e,t));return n.push(s),ue(n)})).catch((e=>W(e,8)?e:Promise.reject(e)))}function H(e,t,n){for(const r of v.list())B((()=>r(e,t,n)))}function Z(e,t,n,r,i){const s=L(e,t);if(s)return s;const l=t===j,u=o?history.state:{};n&&(r||l?d.replace(e.fullPath,a({scroll:l&&u&&u.scroll},i)):d.push(e.fullPath,i)),y.value=e,re(e,t,n,l),ne()}let G;function J(){G||(G=d.listen(((e,t,n)=>{if(!le.listening)return;const r=O(e),i=q(r);if(i)return void V(a(i,{replace:!0}),r).catch(u);b=r;const s=y.value;o&&N(R(s.fullPath,n.delta),x()),z(r,s).catch((e=>W(e,12)?e:W(e,2)?(V(e.to,r).then((e=>{W(e,20)&&!n.delta&&n.type===S.pop&&d.go(-1,!1)})).catch(u),Promise.reject()):(n.delta&&d.go(-n.delta,!1),ee(e,r,s)))).then((e=>{e=e||Z(r,s,!1),e&&(n.delta&&!W(e,8)?d.go(-n.delta,!1):n.type===S.pop&&W(e,20)&&d.go(-1,!1)),H(r,s,e)})).catch(u)})))}let Q,Y=$e(),X=$e();function ee(e,t,n){ne(e);const r=X.list();return r.length?r.forEach((r=>r(e,t,n))):console.error(e),Promise.reject(e)}function te(){return Q&&y.value!==j?Promise.resolve():new Promise(((e,t)=>{Y.add([e,t])}))}function ne(e){return Q||(Q=!e,J(),Y.list().forEach((([t,n])=>e?n(e):t())),Y.reset()),e}function re(t,n,i,s){const{scrollBehavior:a}=e;if(!o||!a)return Promise.resolve();const l=!i&&P(R(t.fullPath,0))||(s||!i)&&history.state&&history.state.scroll||null;return(0,r.Y3)().then((()=>a(t,n,l))).then((e=>e&&A(e))).catch((e=>ee(e,t,n)))}const ie=e=>d.go(e);let se;const ae=new Set,le={currentRoute:y,listening:!0,addRoute:k,removeRoute:T,hasRoute:I,getRoutes:C,resolve:O,options:e,push:D,replace:M,go:ie,back:()=>ie(-1),forward:()=>ie(1),beforeEach:h.add,beforeResolve:g.add,afterEach:v.add,onError:X.add,isReady:te,install(e){const t=this;e.component("RouterLink",Ze),e.component("RouterView",tt),e.config.globalProperties.$router=t,Object.defineProperty(e.config.globalProperties,"$route",{enumerable:!0,get:()=>(0,i.SU)(y)}),o&&!se&&y.value===j&&(se=!0,D(d.location).catch((e=>{0})));const n={};for(const i in j)n[i]=(0,r.Fl)((()=>y.value[i]));e.provide(Ve,t),e.provide(Ue,(0,i.qj)(n)),e.provide(Be,y);const s=e.unmount;ae.add(e),e.unmount=function(){ae.delete(e),ae.size<1&&(b=j,G&&G(),G=null,y.value=j,se=!1,Q=!1),s()}}};function ue(e){return e.reduce(((e,t)=>e.then((()=>B(t)))),Promise.resolve())}return le}function rt(e,t){const n=[],r=[],i=[],o=Math.max(t.matched.length,e.matched.length);for(let s=0;s<o;s++){const o=t.matched[s];o&&(e.matched.find((e=>v(e,o)))?r.push(o):n.push(o));const a=e.matched[s];a&&(t.matched.find((e=>v(e,a)))||i.push(a))}return[n,r,i]}},8897:(e,t,n)=>{"use strict";n.d(t,{Jn:()=>ge,qX:()=>de,Xd:()=>ce,Mq:()=>ve,ZF:()=>me,KN:()=>ye});var r=n(3513),i=n(9795),o=n(5505);const s=(e,t)=>t.some((t=>e instanceof t));let a,l;function u(){return a||(a=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function c(){return l||(l=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const d=new WeakMap,h=new WeakMap,f=new WeakMap,p=new WeakMap,g=new WeakMap;function m(e){const t=new Promise(((t,n)=>{const r=()=>{e.removeEventListener("success",i),e.removeEventListener("error",o)},i=()=>{t(S(e.result)),r()},o=()=>{n(e.error),r()};e.addEventListener("success",i),e.addEventListener("error",o)}));return t.then((t=>{t instanceof IDBCursor&&d.set(t,e)})).catch((()=>{})),g.set(t,e),t}function v(e){if(h.has(e))return;const t=new Promise(((t,n)=>{const r=()=>{e.removeEventListener("complete",i),e.removeEventListener("error",o),e.removeEventListener("abort",o)},i=()=>{t(),r()},o=()=>{n(e.error||new DOMException("AbortError","AbortError")),r()};e.addEventListener("complete",i),e.addEventListener("error",o),e.addEventListener("abort",o)}));h.set(e,t)}let y={get(e,t,n){if(e instanceof IDBTransaction){if("done"===t)return h.get(e);if("objectStoreNames"===t)return e.objectStoreNames||f.get(e);if("store"===t)return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return S(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&("done"===t||"store"===t)||t in e}};function b(e){y=e(y)}function w(e){return e!==IDBDatabase.prototype.transaction||"objectStoreNames"in IDBTransaction.prototype?c().includes(e)?function(...t){return e.apply(E(this),t),S(d.get(this))}:function(...t){return S(e.apply(E(this),t))}:function(t,...n){const r=e.call(E(this),t,...n);return f.set(r,t.sort?t.sort():[t]),S(r)}}function _(e){return"function"===typeof e?w(e):(e instanceof IDBTransaction&&v(e),s(e,u())?new Proxy(e,y):e)}function S(e){if(e instanceof IDBRequest)return m(e);if(p.has(e))return p.get(e);const t=_(e);return t!==e&&(p.set(e,t),g.set(t,e)),t}const E=e=>g.get(e);function k(e,t,{blocked:n,upgrade:r,blocking:i,terminated:o}={}){const s=indexedDB.open(e,t),a=S(s);return r&&s.addEventListener("upgradeneeded",(e=>{r(S(s.result),e.oldVersion,e.newVersion,S(s.transaction),e)})),n&&s.addEventListener("blocked",(e=>n(e.oldVersion,e.newVersion,e))),a.then((e=>{o&&e.addEventListener("close",(()=>o())),i&&e.addEventListener("versionchange",(e=>i(e.oldVersion,e.newVersion,e)))})).catch((()=>{})),a}const T=["get","getKey","getAll","getAllKeys","count"],C=["put","add","delete","clear"],I=new Map;function x(e,t){if(!(e instanceof IDBDatabase)||t in e||"string"!==typeof t)return;if(I.get(t))return I.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,i=C.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!i&&!T.includes(n))return;const o=async function(e,...t){const o=this.transaction(e,i?"readwrite":"readonly");let s=o.store;return r&&(s=s.index(t.shift())),(await Promise.all([s[n](...t),i&&o.done]))[0]};return I.set(t,o),o}b((e=>({...e,get:(t,n,r)=>x(t,n)||e.get(t,n,r),has:(t,n)=>!!x(t,n)||e.has(t,n)})));
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class A{constructor(e){this.container=e}getPlatformInfoString(){const e=this.container.getProviders();return e.map((e=>{if(R(e)){const t=e.getImmediate();return`${t.library}/${t.version}`}return null})).filter((e=>e)).join(" ")}}function R(e){const t=e.getComponent();return"VERSION"===(null===t||void 0===t?void 0:t.type)}const O="@firebase/app",N="0.9.12",P=new i.Yd("@firebase/app"),F="@firebase/app-compat",L="@firebase/analytics-compat",D="@firebase/analytics",M="@firebase/app-check-compat",q="@firebase/app-check",V="@firebase/auth",U="@firebase/auth-compat",B="@firebase/database",$="@firebase/database-compat",j="@firebase/functions",z="@firebase/functions-compat",H="@firebase/installations",K="@firebase/installations-compat",W="@firebase/messaging",Z="@firebase/messaging-compat",G="@firebase/performance",J="@firebase/performance-compat",Q="@firebase/remote-config",Y="@firebase/remote-config-compat",X="@firebase/storage",ee="@firebase/storage-compat",te="@firebase/firestore",ne="@firebase/firestore-compat",re="firebase",ie="9.22.2",oe="[DEFAULT]",se={[O]:"fire-core",[F]:"fire-core-compat",[D]:"fire-analytics",[L]:"fire-analytics-compat",[q]:"fire-app-check",[M]:"fire-app-check-compat",[V]:"fire-auth",[U]:"fire-auth-compat",[B]:"fire-rtdb",[$]:"fire-rtdb-compat",[j]:"fire-fn",[z]:"fire-fn-compat",[H]:"fire-iid",[K]:"fire-iid-compat",[W]:"fire-fcm",[Z]:"fire-fcm-compat",[G]:"fire-perf",[J]:"fire-perf-compat",[Q]:"fire-rc",[Y]:"fire-rc-compat",[X]:"fire-gcs",[ee]:"fire-gcs-compat",[te]:"fire-fst",[ne]:"fire-fst-compat","fire-js":"fire-js",[re]:"fire-js-all"},ae=new Map,le=new Map;function ue(e,t){try{e.container.addComponent(t)}catch(n){P.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`,n)}}function ce(e){const t=e.name;if(le.has(t))return P.debug(`There were multiple attempts to register component ${t}.`),!1;le.set(t,e);for(const n of ae.values())ue(n,e);return!0}function de(e,t){const n=e.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),e.container.getProvider(t)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const he={["no-app"]:"No Firebase App '{$appName}' has been created - call initializeApp() first",["bad-app-name"]:"Illegal App name: '{$appName}",["duplicate-app"]:"Firebase App named '{$appName}' already exists with different options or config",["app-deleted"]:"Firebase App named '{$appName}' already deleted",["no-options"]:"Need to provide options, when not being deployed to hosting via source.",["invalid-app-argument"]:"firebase.{$appName}() takes either no argument or a Firebase App instance.",["invalid-log-argument"]:"First argument to `onLog` must be null or a function.",["idb-open"]:"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",["idb-get"]:"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",["idb-set"]:"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",["idb-delete"]:"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}."},fe=new o.LL("app","Firebase",he);
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe{constructor(e,t,n){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=n,this.container.addComponent(new r.wA("app",(()=>this),"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw fe.create("app-deleted",{appName:this._name})}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ge=ie;function me(e,t={}){let n=e;if("object"!==typeof t){const e=t;t={name:e}}const i=Object.assign({name:oe,automaticDataCollectionEnabled:!1},t),s=i.name;if("string"!==typeof s||!s)throw fe.create("bad-app-name",{appName:String(s)});if(n||(n=(0,o.aH)()),!n)throw fe.create("no-options");const a=ae.get(s);if(a){if((0,o.vZ)(n,a.options)&&(0,o.vZ)(i,a.config))return a;throw fe.create("duplicate-app",{appName:s})}const l=new r.H0(s);for(const r of le.values())l.addComponent(r);const u=new pe(n,i,l);return ae.set(s,u),u}function ve(e=oe){const t=ae.get(e);if(!t&&e===oe&&(0,o.aH)())return me();if(!t)throw fe.create("no-app",{appName:e});return t}function ye(e,t,n){var i;let o=null!==(i=se[e])&&void 0!==i?i:e;n&&(o+=`-${n}`);const s=o.match(/\s|\//),a=t.match(/\s|\//);if(s||a){const e=[`Unable to register library "${o}" with version "${t}":`];return s&&e.push(`library name "${o}" contains illegal characters (whitespace or "/")`),s&&a&&e.push("and"),a&&e.push(`version name "${t}" contains illegal characters (whitespace or "/")`),void P.warn(e.join(" "))}ce(new r.wA(`${o}-version`,(()=>({library:o,version:t})),"VERSION"))}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const be="firebase-heartbeat-database",we=1,_e="firebase-heartbeat-store";let Se=null;function Ee(){return Se||(Se=k(be,we,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(_e)}}}).catch((e=>{throw fe.create("idb-open",{originalErrorMessage:e.message})}))),Se}async function ke(e){try{const t=await Ee(),n=await t.transaction(_e).objectStore(_e).get(Ce(e));return n}catch(t){if(t instanceof o.ZR)P.warn(t.message);else{const e=fe.create("idb-get",{originalErrorMessage:null===t||void 0===t?void 0:t.message});P.warn(e.message)}}}async function Te(e,t){try{const n=await Ee(),r=n.transaction(_e,"readwrite"),i=r.objectStore(_e);await i.put(t,Ce(e)),await r.done}catch(n){if(n instanceof o.ZR)P.warn(n.message);else{const e=fe.create("idb-set",{originalErrorMessage:null===n||void 0===n?void 0:n.message});P.warn(e.message)}}}function Ce(e){return`${e.name}!${e.options.appId}`}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ie=1024,xe=2592e6;class Ae{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new Ne(t),this._heartbeatsCachePromise=this._storage.read().then((e=>(this._heartbeatsCache=e,e)))}async triggerHeartbeat(){const e=this.container.getProvider("platform-logger").getImmediate(),t=e.getPlatformInfoString(),n=Re();if(null===this._heartbeatsCache&&(this._heartbeatsCache=await this._heartbeatsCachePromise),this._heartbeatsCache.lastSentHeartbeatDate!==n&&!this._heartbeatsCache.heartbeats.some((e=>e.date===n)))return this._heartbeatsCache.heartbeats.push({date:n,agent:t}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter((e=>{const t=new Date(e.date).valueOf(),n=Date.now();return n-t<=xe})),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){if(null===this._heartbeatsCache&&await this._heartbeatsCachePromise,null===this._heartbeatsCache||0===this._heartbeatsCache.heartbeats.length)return"";const e=Re(),{heartbeatsToSend:t,unsentEntries:n}=Oe(this._heartbeatsCache.heartbeats),r=(0,o.L)(JSON.stringify({version:2,heartbeats:t}));return this._heartbeatsCache.lastSentHeartbeatDate=e,n.length>0?(this._heartbeatsCache.heartbeats=n,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),r}}function Re(){const e=new Date;return e.toISOString().substring(0,10)}function Oe(e,t=Ie){const n=[];let r=e.slice();for(const i of e){const e=n.find((e=>e.agent===i.agent));if(e){if(e.dates.push(i.date),Pe(n)>t){e.dates.pop();break}}else if(n.push({agent:i.agent,dates:[i.date]}),Pe(n)>t){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class Ne{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return!!(0,o.hl)()&&(0,o.eu)().then((()=>!0)).catch((()=>!1))}async read(){const e=await this._canUseIndexedDBPromise;if(e){const e=await ke(this.app);return e||{heartbeats:[]}}return{heartbeats:[]}}async overwrite(e){var t;const n=await this._canUseIndexedDBPromise;if(n){const n=await this.read();return Te(this.app,{lastSentHeartbeatDate:null!==(t=e.lastSentHeartbeatDate)&&void 0!==t?t:n.lastSentHeartbeatDate,heartbeats:e.heartbeats})}}async add(e){var t;const n=await this._canUseIndexedDBPromise;if(n){const n=await this.read();return Te(this.app,{lastSentHeartbeatDate:null!==(t=e.lastSentHeartbeatDate)&&void 0!==t?t:n.lastSentHeartbeatDate,heartbeats:[...n.heartbeats,...e.heartbeats]})}}}function Pe(e){return(0,o.L)(JSON.stringify({version:2,heartbeats:e})).length}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fe(e){ce(new r.wA("platform-logger",(e=>new A(e)),"PRIVATE")),ce(new r.wA("heartbeat",(e=>new Ae(e)),"PRIVATE")),ye(O,N,e),ye(O,N,"esm2017"),ye("fire-js","")}Fe("")},3513:(e,t,n)=>{"use strict";n.d(t,{H0:()=>u,wA:()=>i});var r=n(5505);class i{constructor(e,t,n){this.name=e,this.instanceFactory=t,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const o="[DEFAULT]";
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class s{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const e=new r.BH;if(this.instancesDeferred.set(t,e),this.isInitialized(t)||this.shouldAutoInitialize())try{const n=this.getOrInitializeService({instanceIdentifier:t});n&&e.resolve(n)}catch(n){}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;const n=this.normalizeInstanceIdentifier(null===e||void 0===e?void 0:e.identifier),r=null!==(t=null===e||void 0===e?void 0:e.optional)&&void 0!==t&&t;if(!this.isInitialized(n)&&!this.shouldAutoInitialize()){if(r)return null;throw Error(`Service ${this.name} is not available`)}try{return this.getOrInitializeService({instanceIdentifier:n})}catch(i){if(r)return null;throw i}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,this.shouldAutoInitialize()){if(l(e))try{this.getOrInitializeService({instanceIdentifier:o})}catch(t){}for(const[e,n]of this.instancesDeferred.entries()){const r=this.normalizeInstanceIdentifier(e);try{const e=this.getOrInitializeService({instanceIdentifier:r});n.resolve(e)}catch(t){}}}}clearInstance(e=o){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter((e=>"INTERNAL"in e)).map((e=>e.INTERNAL.delete())),...e.filter((e=>"_delete"in e)).map((e=>e._delete()))])}isComponentSet(){return null!=this.component}isInitialized(e=o){return this.instances.has(e)}getOptions(e=o){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,n=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(n))throw Error(`${this.name}(${n}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const r=this.getOrInitializeService({instanceIdentifier:n,options:t});for(const[i,o]of this.instancesDeferred.entries()){const e=this.normalizeInstanceIdentifier(i);n===e&&o.resolve(r)}return r}onInit(e,t){var n;const r=this.normalizeInstanceIdentifier(t),i=null!==(n=this.onInitCallbacks.get(r))&&void 0!==n?n:new Set;i.add(e),this.onInitCallbacks.set(r,i);const o=this.instances.get(r);return o&&e(o,r),()=>{i.delete(e)}}invokeOnInitCallbacks(e,t){const n=this.onInitCallbacks.get(t);if(n)for(const i of n)try{i(e,t)}catch(r){}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let n=this.instances.get(e);if(!n&&this.component&&(n=this.component.instanceFactory(this.container,{instanceIdentifier:a(e),options:t}),this.instances.set(e,n),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(n,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,n)}catch(r){}return n||null}normalizeInstanceIdentifier(e=o){return this.component?this.component.multipleInstances?e:o:e}shouldAutoInitialize(){return!!this.component&&"EXPLICIT"!==this.component.instantiationMode}}function a(e){return e===o?void 0:e}function l(e){return"EAGER"===e.instantiationMode}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class u{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){const t=this.getProvider(e.name);t.isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new s(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}},9795:(e,t,n)=>{"use strict";n.d(t,{Yd:()=>u,in:()=>i});
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r=[];var i;(function(e){e[e["DEBUG"]=0]="DEBUG",e[e["VERBOSE"]=1]="VERBOSE",e[e["INFO"]=2]="INFO",e[e["WARN"]=3]="WARN",e[e["ERROR"]=4]="ERROR",e[e["SILENT"]=5]="SILENT"})(i||(i={}));const o={debug:i.DEBUG,verbose:i.VERBOSE,info:i.INFO,warn:i.WARN,error:i.ERROR,silent:i.SILENT},s=i.INFO,a={[i.DEBUG]:"log",[i.VERBOSE]:"log",[i.INFO]:"info",[i.WARN]:"warn",[i.ERROR]:"error"},l=(e,t,...n)=>{if(t<e.logLevel)return;const r=(new Date).toISOString(),i=a[t];if(!i)throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`);console[i](`[${r}]  ${e.name}:`,...n)};class u{constructor(e){this.name=e,this._logLevel=s,this._logHandler=l,this._userLogHandler=null,r.push(this)}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in i))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel="string"===typeof e?o[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if("function"!==typeof e)throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,i.DEBUG,...e),this._logHandler(this,i.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,i.VERBOSE,...e),this._logHandler(this,i.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,i.INFO,...e),this._logHandler(this,i.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,i.WARN,...e),this._logHandler(this,i.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,i.ERROR,...e),this._logHandler(this,i.ERROR,...e)}}},7141:(e,t,n)=>{"use strict";n.d(t,{ZF:()=>r.ZF});var r=n(8897),i="firebase",o="9.22.2";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
(0,r.KN)(i,o,"app")},5099:(e,t,n)=>{"use strict";n.d(t,{Xb:()=>Tt,v0:()=>Dr,e5:()=>Ct});var r=n(5505),i=n(8897);function o(e,t){var n={};for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&t.indexOf(r)<0&&(n[r]=e[r]);if(null!=e&&"function"===typeof Object.getOwnPropertySymbols){var i=0;for(r=Object.getOwnPropertySymbols(e);i<r.length;i++)t.indexOf(r[i])<0&&Object.prototype.propertyIsEnumerable.call(e,r[i])&&(n[r[i]]=e[r[i]])}return n}Object.create;Object.create;var s=n(9795),a=n(3513);function l(){return{["dependent-sdk-initialized-before-auth"]:"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const u=l,c=new r.LL("auth","Firebase",l()),d=new s.Yd("@firebase/auth");function h(e,...t){d.logLevel<=s["in"].WARN&&d.warn(`Auth (${i.Jn}): ${e}`,...t)}function f(e,...t){d.logLevel<=s["in"].ERROR&&d.error(`Auth (${i.Jn}): ${e}`,...t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function p(e,...t){throw v(e,...t)}function g(e,...t){return v(e,...t)}function m(e,t,n){const i=Object.assign(Object.assign({},u()),{[t]:n}),o=new r.LL("auth","Firebase",i);return o.create(t,{appName:e.name})}function v(e,...t){if("string"!==typeof e){const n=t[0],r=[...t.slice(1)];return r[0]&&(r[0].appName=e.name),e._errorFactory.create(n,...r)}return c.create(e,...t)}function y(e,t,...n){if(!e)throw v(t,...n)}function b(e){const t="INTERNAL ASSERTION FAILED: "+e;throw f(t),new Error(t)}function w(e,t){e||b(t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _(){var e;return"undefined"!==typeof self&&(null===(e=self.location)||void 0===e?void 0:e.href)||""}function S(){return"http:"===E()||"https:"===E()}function E(){var e;return"undefined"!==typeof self&&(null===(e=self.location)||void 0===e?void 0:e.protocol)||null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function k(){return!("undefined"!==typeof navigator&&navigator&&"onLine"in navigator&&"boolean"===typeof navigator.onLine&&(S()||(0,r.ru)()||"connection"in navigator))||navigator.onLine}function T(){if("undefined"===typeof navigator)return null;const e=navigator;return e.languages&&e.languages[0]||e.language||null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class C{constructor(e,t){this.shortDelay=e,this.longDelay=t,w(t>e,"Short delay should be less than long delay!"),this.isMobile=(0,r.uI)()||(0,r.b$)()}get(){return k()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function I(e,t){w(e.emulator,"Emulator should always be set here");const{url:n}=e.emulator;return t?`${n}${t.startsWith("/")?t.slice(1):t}`:n}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class x{static initialize(e,t,n){this.fetchImpl=e,t&&(this.headersImpl=t),n&&(this.responseImpl=n)}static fetch(){return this.fetchImpl?this.fetchImpl:"undefined"!==typeof self&&"fetch"in self?self.fetch:void b("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){return this.headersImpl?this.headersImpl:"undefined"!==typeof self&&"Headers"in self?self.Headers:void b("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){return this.responseImpl?this.responseImpl:"undefined"!==typeof self&&"Response"in self?self.Response:void b("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const A={["CREDENTIAL_MISMATCH"]:"custom-token-mismatch",["MISSING_CUSTOM_TOKEN"]:"internal-error",["INVALID_IDENTIFIER"]:"invalid-email",["MISSING_CONTINUE_URI"]:"internal-error",["INVALID_PASSWORD"]:"wrong-password",["MISSING_PASSWORD"]:"missing-password",["EMAIL_EXISTS"]:"email-already-in-use",["PASSWORD_LOGIN_DISABLED"]:"operation-not-allowed",["INVALID_IDP_RESPONSE"]:"invalid-credential",["INVALID_PENDING_TOKEN"]:"invalid-credential",["FEDERATED_USER_ID_ALREADY_LINKED"]:"credential-already-in-use",["MISSING_REQ_TYPE"]:"internal-error",["EMAIL_NOT_FOUND"]:"user-not-found",["RESET_PASSWORD_EXCEED_LIMIT"]:"too-many-requests",["EXPIRED_OOB_CODE"]:"expired-action-code",["INVALID_OOB_CODE"]:"invalid-action-code",["MISSING_OOB_CODE"]:"internal-error",["CREDENTIAL_TOO_OLD_LOGIN_AGAIN"]:"requires-recent-login",["INVALID_ID_TOKEN"]:"invalid-user-token",["TOKEN_EXPIRED"]:"user-token-expired",["USER_NOT_FOUND"]:"user-token-expired",["TOO_MANY_ATTEMPTS_TRY_LATER"]:"too-many-requests",["INVALID_CODE"]:"invalid-verification-code",["INVALID_SESSION_INFO"]:"invalid-verification-id",["INVALID_TEMPORARY_PROOF"]:"invalid-credential",["MISSING_SESSION_INFO"]:"missing-verification-id",["SESSION_EXPIRED"]:"code-expired",["MISSING_ANDROID_PACKAGE_NAME"]:"missing-android-pkg-name",["UNAUTHORIZED_DOMAIN"]:"unauthorized-continue-uri",["INVALID_OAUTH_CLIENT_ID"]:"invalid-oauth-client-id",["ADMIN_ONLY_OPERATION"]:"admin-restricted-operation",["INVALID_MFA_PENDING_CREDENTIAL"]:"invalid-multi-factor-session",["MFA_ENROLLMENT_NOT_FOUND"]:"multi-factor-info-not-found",["MISSING_MFA_ENROLLMENT_ID"]:"missing-multi-factor-info",["MISSING_MFA_PENDING_CREDENTIAL"]:"missing-multi-factor-session",["SECOND_FACTOR_EXISTS"]:"second-factor-already-in-use",["SECOND_FACTOR_LIMIT_EXCEEDED"]:"maximum-second-factor-count-exceeded",["BLOCKING_FUNCTION_ERROR_RESPONSE"]:"internal-error",["RECAPTCHA_NOT_ENABLED"]:"recaptcha-not-enabled",["MISSING_RECAPTCHA_TOKEN"]:"missing-recaptcha-token",["INVALID_RECAPTCHA_TOKEN"]:"invalid-recaptcha-token",["INVALID_RECAPTCHA_ACTION"]:"invalid-recaptcha-action",["MISSING_CLIENT_TYPE"]:"missing-client-type",["MISSING_RECAPTCHA_VERSION"]:"missing-recaptcha-version",["INVALID_RECAPTCHA_VERSION"]:"invalid-recaptcha-version",["INVALID_REQ_TYPE"]:"invalid-req-type"},R=new C(3e4,6e4);
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function O(e,t){return e.tenantId&&!t.tenantId?Object.assign(Object.assign({},t),{tenantId:e.tenantId}):t}async function N(e,t,n,i,o={}){return P(e,o,(async()=>{let o={},s={};i&&("GET"===t?s=i:o={body:JSON.stringify(i)});const a=(0,r.xO)(Object.assign({key:e.config.apiKey},s)).slice(1),l=await e._getAdditionalHeaders();return l["Content-Type"]="application/json",e.languageCode&&(l["X-Firebase-Locale"]=e.languageCode),x.fetch()(L(e,e.config.apiHost,n,a),Object.assign({method:t,headers:l,referrerPolicy:"no-referrer"},o))}))}async function P(e,t,n){e._canInitEmulator=!1;const i=Object.assign(Object.assign({},A),t);try{const t=new D(e),r=await Promise.race([n(),t.promise]);t.clearNetworkTimeout();const o=await r.json();if("needConfirmation"in o)throw M(e,"account-exists-with-different-credential",o);if(r.ok&&!("errorMessage"in o))return o;{const t=r.ok?o.errorMessage:o.error.message,[n,s]=t.split(" : ");if("FEDERATED_USER_ID_ALREADY_LINKED"===n)throw M(e,"credential-already-in-use",o);if("EMAIL_EXISTS"===n)throw M(e,"email-already-in-use",o);if("USER_DISABLED"===n)throw M(e,"user-disabled",o);const a=i[n]||n.toLowerCase().replace(/[_\s]+/g,"-");if(s)throw m(e,a,s);p(e,a)}}catch(o){if(o instanceof r.ZR)throw o;p(e,"network-request-failed",{message:String(o)})}}async function F(e,t,n,r,i={}){const o=await N(e,t,n,r,i);return"mfaPendingCredential"in o&&p(e,"multi-factor-auth-required",{_serverResponse:o}),o}function L(e,t,n,r){const i=`${t}${n}?${r}`;return e.config.emulator?I(e.config,i):`${e.config.apiScheme}://${i}`}class D{constructor(e){this.auth=e,this.timer=null,this.promise=new Promise(((e,t)=>{this.timer=setTimeout((()=>t(g(this.auth,"network-request-failed"))),R.get())}))}clearNetworkTimeout(){clearTimeout(this.timer)}}function M(e,t,n){const r={appName:e.name};n.email&&(r.email=n.email),n.phoneNumber&&(r.phoneNumber=n.phoneNumber);const i=g(e,t,r);return i.customData._tokenResponse=n,i}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function q(e,t){return N(e,"POST","/v1/accounts:delete",t)}async function V(e,t){return N(e,"POST","/v1/accounts:lookup",t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function U(e){if(e)try{const t=new Date(Number(e));if(!isNaN(t.getTime()))return t.toUTCString()}catch(t){}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function B(e,t=!1){const n=(0,r.m9)(e),i=await n.getIdToken(t),o=j(i);y(o&&o.exp&&o.auth_time&&o.iat,n.auth,"internal-error");const s="object"===typeof o.firebase?o.firebase:void 0,a=null===s||void 0===s?void 0:s["sign_in_provider"];return{claims:o,token:i,authTime:U($(o.auth_time)),issuedAtTime:U($(o.iat)),expirationTime:U($(o.exp)),signInProvider:a||null,signInSecondFactor:(null===s||void 0===s?void 0:s["sign_in_second_factor"])||null}}function $(e){return 1e3*Number(e)}function j(e){const[t,n,i]=e.split(".");if(void 0===t||void 0===n||void 0===i)return f("JWT malformed, contained fewer than 3 sections"),null;try{const e=(0,r.tV)(n);return e?JSON.parse(e):(f("Failed to decode base64 JWT payload"),null)}catch(o){return f("Caught error parsing JWT payload as JSON",null===o||void 0===o?void 0:o.toString()),null}}function z(e){const t=j(e);return y(t,"internal-error"),y("undefined"!==typeof t.exp,"internal-error"),y("undefined"!==typeof t.iat,"internal-error"),Number(t.exp)-Number(t.iat)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function H(e,t,n=!1){if(n)return t;try{return await t}catch(i){throw i instanceof r.ZR&&K(i)&&e.auth.currentUser===e&&await e.auth.signOut(),i}}function K({code:e}){return"auth/user-disabled"===e||"auth/user-token-expired"===e}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,null!==this.timerId&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){const e=this.errorBackoff;return this.errorBackoff=Math.min(2*this.errorBackoff,96e4),e}{this.errorBackoff=3e4;const e=null!==(t=this.user.stsTokenManager.expirationTime)&&void 0!==t?t:0,n=e-Date.now()-3e5;return Math.max(0,n)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout((async()=>{await this.iteration()}),t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){return void("auth/network-request-failed"===(null===e||void 0===e?void 0:e.code)&&this.schedule(!0))}this.schedule()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Z{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=U(this.lastLoginAt),this.creationTime=U(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function G(e){var t;const n=e.auth,r=await e.getIdToken(),i=await H(e,V(n,{idToken:r}));y(null===i||void 0===i?void 0:i.users.length,n,"internal-error");const o=i.users[0];e._notifyReloadListener(o);const s=(null===(t=o.providerUserInfo)||void 0===t?void 0:t.length)?Y(o.providerUserInfo):[],a=Q(e.providerData,s),l=e.isAnonymous,u=!(e.email&&o.passwordHash)&&!(null===a||void 0===a?void 0:a.length),c=!!l&&u,d={uid:o.localId,displayName:o.displayName||null,photoURL:o.photoUrl||null,email:o.email||null,emailVerified:o.emailVerified||!1,phoneNumber:o.phoneNumber||null,tenantId:o.tenantId||null,providerData:a,metadata:new Z(o.createdAt,o.lastLoginAt),isAnonymous:c};Object.assign(e,d)}async function J(e){const t=(0,r.m9)(e);await G(t),await t.auth._persistUserIfCurrent(t),t.auth._notifyListenersIfCurrent(t)}function Q(e,t){const n=e.filter((e=>!t.some((t=>t.providerId===e.providerId))));return[...n,...t]}function Y(e){return e.map((e=>{var{providerId:t}=e,n=o(e,["providerId"]);return{providerId:t,uid:n.rawId||"",displayName:n.displayName||null,email:n.email||null,phoneNumber:n.phoneNumber||null,photoURL:n.photoUrl||null}}))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function X(e,t){const n=await P(e,{},(async()=>{const n=(0,r.xO)({grant_type:"refresh_token",refresh_token:t}).slice(1),{tokenApiHost:i,apiKey:o}=e.config,s=L(e,i,"/v1/token",`key=${o}`),a=await e._getAdditionalHeaders();return a["Content-Type"]="application/x-www-form-urlencoded",x.fetch()(s,{method:"POST",headers:a,body:n})}));return{accessToken:n.access_token,expiresIn:n.expires_in,refreshToken:n.refresh_token}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ee{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){y(e.idToken,"internal-error"),y("undefined"!==typeof e.idToken,"internal-error"),y("undefined"!==typeof e.refreshToken,"internal-error");const t="expiresIn"in e&&"undefined"!==typeof e.expiresIn?Number(e.expiresIn):z(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}async getToken(e,t=!1){return y(!this.accessToken||this.refreshToken,e,"user-token-expired"),t||!this.accessToken||this.isExpired?this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null:this.accessToken}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:n,refreshToken:r,expiresIn:i}=await X(e,t);this.updateTokensAndExpiration(n,r,Number(i))}updateTokensAndExpiration(e,t,n){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+1e3*n}static fromJSON(e,t){const{refreshToken:n,accessToken:r,expirationTime:i}=t,o=new ee;return n&&(y("string"===typeof n,"internal-error",{appName:e}),o.refreshToken=n),r&&(y("string"===typeof r,"internal-error",{appName:e}),o.accessToken=r),i&&(y("number"===typeof i,"internal-error",{appName:e}),o.expirationTime=i),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new ee,this.toJSON())}_performRefresh(){return b("not implemented")}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function te(e,t){y("string"===typeof e||"undefined"===typeof e,"internal-error",{appName:t})}class ne{constructor(e){var{uid:t,auth:n,stsTokenManager:r}=e,i=o(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new W(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=n,this.stsTokenManager=r,this.accessToken=r.accessToken,this.displayName=i.displayName||null,this.email=i.email||null,this.emailVerified=i.emailVerified||!1,this.phoneNumber=i.phoneNumber||null,this.photoURL=i.photoURL||null,this.isAnonymous=i.isAnonymous||!1,this.tenantId=i.tenantId||null,this.providerData=i.providerData?[...i.providerData]:[],this.metadata=new Z(i.createdAt||void 0,i.lastLoginAt||void 0)}async getIdToken(e){const t=await H(this,this.stsTokenManager.getToken(this.auth,e));return y(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return B(this,e)}reload(){return J(this)}_assign(e){this!==e&&(y(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map((e=>Object.assign({},e))),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new ne(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){y(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let n=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),n=!0),t&&await G(this),await this.auth._persistUserIfCurrent(this),n&&this.auth._notifyListenersIfCurrent(this)}async delete(){const e=await this.getIdToken();return await H(this,q(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map((e=>Object.assign({},e))),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var n,r,i,o,s,a,l,u;const c=null!==(n=t.displayName)&&void 0!==n?n:void 0,d=null!==(r=t.email)&&void 0!==r?r:void 0,h=null!==(i=t.phoneNumber)&&void 0!==i?i:void 0,f=null!==(o=t.photoURL)&&void 0!==o?o:void 0,p=null!==(s=t.tenantId)&&void 0!==s?s:void 0,g=null!==(a=t._redirectEventId)&&void 0!==a?a:void 0,m=null!==(l=t.createdAt)&&void 0!==l?l:void 0,v=null!==(u=t.lastLoginAt)&&void 0!==u?u:void 0,{uid:b,emailVerified:w,isAnonymous:_,providerData:S,stsTokenManager:E}=t;y(b&&E,e,"internal-error");const k=ee.fromJSON(this.name,E);y("string"===typeof b,e,"internal-error"),te(c,e.name),te(d,e.name),y("boolean"===typeof w,e,"internal-error"),y("boolean"===typeof _,e,"internal-error"),te(h,e.name),te(f,e.name),te(p,e.name),te(g,e.name),te(m,e.name),te(v,e.name);const T=new ne({uid:b,auth:e,email:d,emailVerified:w,displayName:c,isAnonymous:_,photoURL:f,phoneNumber:h,tenantId:p,stsTokenManager:k,createdAt:m,lastLoginAt:v});return S&&Array.isArray(S)&&(T.providerData=S.map((e=>Object.assign({},e)))),g&&(T._redirectEventId=g),T}static async _fromIdTokenResponse(e,t,n=!1){const r=new ee;r.updateFromServerResponse(t);const i=new ne({uid:t.localId,auth:e,stsTokenManager:r,isAnonymous:n});return await G(i),i}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const re=new Map;function ie(e){w(e instanceof Function,"Expected a class definition");let t=re.get(e);return t?(w(t instanceof e,"Instance stored in cache mismatched with class"),t):(t=new e,re.set(e,t),t)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oe{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return void 0===t?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}oe.type="NONE";const se=oe;
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ae(e,t,n){return`firebase:${e}:${t}:${n}`}class le{constructor(e,t,n){this.persistence=e,this.auth=t,this.userKey=n;const{config:r,name:i}=this.auth;this.fullUserKey=ae(this.userKey,r.apiKey,i),this.fullPersistenceKey=ae("persistence",r.apiKey,i),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);return e?ne._fromJSON(this.auth,e):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();return await this.removeCurrentUser(),this.persistence=e,t?this.setCurrentUser(t):void 0}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,n="authUser"){if(!t.length)return new le(ie(se),e,n);const r=(await Promise.all(t.map((async e=>{if(await e._isAvailable())return e})))).filter((e=>e));let i=r[0]||ie(se);const o=ae(n,e.config.apiKey,e.name);let s=null;for(const u of t)try{const t=await u._get(o);if(t){const n=ne._fromJSON(e,t);u!==i&&(s=n),i=u;break}}catch(l){}const a=r.filter((e=>e._shouldAllowMigration));return i._shouldAllowMigration&&a.length?(i=a[0],s&&await i._set(o,s.toJSON()),await Promise.all(t.map((async e=>{if(e!==i)try{await e._remove(o)}catch(l){}}))),new le(i,e,n)):new le(i,e,n)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ue(e){const t=e.toLowerCase();if(t.includes("opera/")||t.includes("opr/")||t.includes("opios/"))return"Opera";if(fe(t))return"IEMobile";if(t.includes("msie")||t.includes("trident/"))return"IE";if(t.includes("edge/"))return"Edge";if(ce(t))return"Firefox";if(t.includes("silk/"))return"Silk";if(ge(t))return"Blackberry";if(me(t))return"Webos";if(de(t))return"Safari";if((t.includes("chrome/")||he(t))&&!t.includes("edge/"))return"Chrome";if(pe(t))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,n=e.match(t);if(2===(null===n||void 0===n?void 0:n.length))return n[1]}return"Other"}function ce(e=(0,r.z$)()){return/firefox\//i.test(e)}function de(e=(0,r.z$)()){const t=e.toLowerCase();return t.includes("safari/")&&!t.includes("chrome/")&&!t.includes("crios/")&&!t.includes("android")}function he(e=(0,r.z$)()){return/crios\//i.test(e)}function fe(e=(0,r.z$)()){return/iemobile/i.test(e)}function pe(e=(0,r.z$)()){return/android/i.test(e)}function ge(e=(0,r.z$)()){return/blackberry/i.test(e)}function me(e=(0,r.z$)()){return/webos/i.test(e)}function ve(e=(0,r.z$)()){return/iphone|ipad|ipod/i.test(e)||/macintosh/i.test(e)&&/mobile/i.test(e)}function ye(e=(0,r.z$)()){var t;return ve(e)&&!!(null===(t=window.navigator)||void 0===t?void 0:t.standalone)}function be(){return(0,r.w1)()&&10===document.documentMode}function we(e=(0,r.z$)()){return ve(e)||pe(e)||me(e)||ge(e)||/windows phone/i.test(e)||fe(e)}function _e(){try{return!(!window||window===window.top)}catch(e){return!1}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Se(e,t=[]){let n;switch(e){case"Browser":n=ue((0,r.z$)());break;case"Worker":n=`${ue((0,r.z$)())}-${e}`;break;default:n=e}const o=t.length?t.join(","):"FirebaseCore-web";return`${n}/JsCore/${i.Jn}/${o}`}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ee(e,t){return N(e,"GET","/v2/recaptchaConfig",O(e,t))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ke(e){return void 0!==e&&void 0!==e.enterprise}class Te{constructor(e){if(this.siteKey="",this.emailPasswordEnabled=!1,void 0===e.recaptchaKey)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.emailPasswordEnabled=e.recaptchaEnforcementState.some((e=>"EMAIL_PASSWORD_PROVIDER"===e.provider&&"OFF"!==e.enforcementState))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ce(){var e,t;return null!==(t=null===(e=document.getElementsByTagName("head"))||void 0===e?void 0:e[0])&&void 0!==t?t:document}function Ie(e){return new Promise(((t,n)=>{const r=document.createElement("script");r.setAttribute("src",e),r.onload=t,r.onerror=e=>{const t=g("internal-error");t.customData=e,n(t)},r.type="text/javascript",r.charset="UTF-8",Ce().appendChild(r)}))}function xe(e){return`__${e}${Math.floor(1e6*Math.random())}`}const Ae="https://www.google.com/recaptcha/enterprise.js?render=",Re="recaptcha-enterprise",Oe="NO_RECAPTCHA";class Ne{constructor(e){this.type=Re,this.auth=De(e)}async verify(e="verify",t=!1){async function n(e){if(!t){if(null==e.tenantId&&null!=e._agentRecaptchaConfig)return e._agentRecaptchaConfig.siteKey;if(null!=e.tenantId&&void 0!==e._tenantRecaptchaConfigs[e.tenantId])return e._tenantRecaptchaConfigs[e.tenantId].siteKey}return new Promise((async(t,n)=>{Ee(e,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then((r=>{if(void 0!==r.recaptchaKey){const n=new Te(r);return null==e.tenantId?e._agentRecaptchaConfig=n:e._tenantRecaptchaConfigs[e.tenantId]=n,t(n.siteKey)}n(new Error("recaptcha Enterprise site key undefined"))})).catch((e=>{n(e)}))}))}function r(t,n,r){const i=window.grecaptcha;ke(i)?i.enterprise.ready((()=>{i.enterprise.execute(t,{action:e}).then((e=>{n(e)})).catch((()=>{n(Oe)}))})):r(Error("No reCAPTCHA enterprise script loaded."))}return new Promise(((e,i)=>{n(this.auth).then((n=>{if(!t&&ke(window.grecaptcha))r(n,e,i);else{if("undefined"===typeof window)return void i(new Error("RecaptchaVerifier is only supported in browser"));Ie(Ae+n).then((()=>{r(n,e,i)})).catch((e=>{i(e)}))}})).catch((e=>{i(e)}))}))}}async function Pe(e,t,n,r=!1){const i=new Ne(e);let o;try{o=await i.verify(n)}catch(a){o=await i.verify(n,!0)}const s=Object.assign({},t);return r?Object.assign(s,{captchaResp:o}):Object.assign(s,{captchaResponse:o}),Object.assign(s,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(s,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),s}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fe{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const n=t=>new Promise(((n,r)=>{try{const r=e(t);n(r)}catch(i){r(i)}}));n.onAbort=t,this.queue.push(n);const r=this.queue.length-1;return()=>{this.queue[r]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const n of this.queue)await n(e),n.onAbort&&t.push(n.onAbort)}catch(n){t.reverse();for(const e of t)try{e()}catch(r){}throw this.auth._errorFactory.create("login-blocked",{originalMessage:null===n||void 0===n?void 0:n.message})}}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Le{constructor(e,t,n,r){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=n,this.config=r,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Me(this),this.idTokenSubscription=new Me(this),this.beforeStateQueue=new Fe(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=c,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=r.sdkClientVersion}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=ie(t)),this._initializationPromise=this.queue((async()=>{var n,r;if(!this._deleted&&(this.persistenceManager=await le.create(this,e),!this._deleted)){if(null===(n=this._popupRedirectResolver)||void 0===n?void 0:n._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch(i){}await this.initializeCurrentUser(t),this.lastNotifiedUid=(null===(r=this.currentUser)||void 0===r?void 0:r.uid)||null,this._deleted||(this._isInitialized=!0)}})),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();return this.currentUser||e?this.currentUser&&e&&this.currentUser.uid===e.uid?(this._currentUser._assign(e),void await this.currentUser.getIdToken()):void await this._updateCurrentUser(e,!0):void 0}async initializeCurrentUser(e){var t;const n=await this.assertedPersistence.getCurrentUser();let r=n,i=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const n=null===(t=this.redirectUser)||void 0===t?void 0:t._redirectEventId,o=null===r||void 0===r?void 0:r._redirectEventId,s=await this.tryRedirectSignIn(e);n&&n!==o||!(null===s||void 0===s?void 0:s.user)||(r=s.user,i=!0)}if(!r)return this.directlySetCurrentUser(null);if(!r._redirectEventId){if(i)try{await this.beforeStateQueue.runMiddleware(r)}catch(o){r=n,this._popupRedirectResolver._overrideRedirectResult(this,(()=>Promise.reject(o)))}return r?this.reloadAndSetCurrentUserOrClear(r):this.directlySetCurrentUser(null)}return y(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===r._redirectEventId?this.directlySetCurrentUser(r):this.reloadAndSetCurrentUserOrClear(r)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch(n){await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await G(e)}catch(t){if("auth/network-request-failed"!==(null===t||void 0===t?void 0:t.code))return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=T()}async _delete(){this._deleted=!0}async updateCurrentUser(e){const t=e?(0,r.m9)(e):null;return t&&y(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&y(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue((async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()}))}async signOut(){return await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0)}setPersistence(e){return this.queue((async()=>{await this.assertedPersistence.setPersistence(ie(e))}))}async initializeRecaptchaConfig(){const e=await Ee(this,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}),t=new Te(e);if(null==this.tenantId?this._agentRecaptchaConfig=t:this._tenantRecaptchaConfigs[this.tenantId]=t,t.emailPasswordEnabled){const e=new Ne(this);e.verify()}}_getRecaptchaConfig(){return null==this.tenantId?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(e){this._errorFactory=new r.LL("auth","Firebase",e())}onAuthStateChanged(e,t,n){return this.registerStateListener(this.authStateSubscription,e,t,n)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,n){return this.registerStateListener(this.idTokenSubscription,e,t,n)}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:null===(e=this._currentUser)||void 0===e?void 0:e.toJSON()}}async _setRedirectUser(e,t){const n=await this.getOrInitRedirectPersistenceManager(t);return null===e?n.removeCurrentUser():n.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&ie(e)||this._popupRedirectResolver;y(t,this,"argument-error"),this.redirectPersistenceManager=await le.create(this,[ie(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,n;return this._isInitialized&&await this.queue((async()=>{})),(null===(t=this._currentUser)||void 0===t?void 0:t._redirectEventId)===e?this._currentUser:(null===(n=this.redirectUser)||void 0===n?void 0:n._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue((async()=>this.directlySetCurrentUser(e)))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const n=null!==(t=null===(e=this.currentUser)||void 0===e?void 0:e.uid)&&void 0!==t?t:null;this.lastNotifiedUid!==n&&(this.lastNotifiedUid=n,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,n,r){if(this._deleted)return()=>{};const i="function"===typeof t?t:t.next.bind(t),o=this._isInitialized?Promise.resolve():this._initializationPromise;return y(o,this,"internal-error"),o.then((()=>i(this.currentUser))),"function"===typeof t?e.addObserver(t,n,r):e.addObserver(t)}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return y(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){e&&!this.frameworks.includes(e)&&(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Se(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const t={["X-Client-Version"]:this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);const n=await(null===(e=this.heartbeatServiceProvider.getImmediate({optional:!0}))||void 0===e?void 0:e.getHeartbeatsHeader());n&&(t["X-Firebase-Client"]=n);const r=await this._getAppCheckToken();return r&&(t["X-Firebase-AppCheck"]=r),t}async _getAppCheckToken(){var e;const t=await(null===(e=this.appCheckServiceProvider.getImmediate({optional:!0}))||void 0===e?void 0:e.getToken());return(null===t||void 0===t?void 0:t.error)&&h(`Error while retrieving App Check token: ${t.error}`),null===t||void 0===t?void 0:t.token}}function De(e){return(0,r.m9)(e)}class Me{constructor(e){this.auth=e,this.observer=null,this.addObserver=(0,r.ne)((e=>this.observer=e))}get next(){return y(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qe(e,t){const n=(0,i.qX)(e,"auth");if(n.isInitialized()){const e=n.getImmediate(),i=n.getOptions();if((0,r.vZ)(i,null!==t&&void 0!==t?t:{}))return e;p(e,"already-initialized")}const o=n.initialize({options:t});return o}function Ve(e,t){const n=(null===t||void 0===t?void 0:t.persistence)||[],r=(Array.isArray(n)?n:[n]).map(ie);(null===t||void 0===t?void 0:t.errorMap)&&e._updateErrorMap(t.errorMap),e._initializeWithPersistence(r,null===t||void 0===t?void 0:t.popupRedirectResolver)}function Ue(e,t,n){const r=De(e);y(r._canInitEmulator,r,"emulator-config-failed"),y(/^https?:\/\//.test(t),r,"invalid-emulator-scheme");const i=!!(null===n||void 0===n?void 0:n.disableWarnings),o=Be(t),{host:s,port:a}=$e(t),l=null===a?"":`:${a}`;r.config.emulator={url:`${o}//${s}${l}/`},r.settings.appVerificationDisabledForTesting=!0,r.emulatorConfig=Object.freeze({host:s,port:a,protocol:o.replace(":",""),options:Object.freeze({disableWarnings:i})}),i||ze()}function Be(e){const t=e.indexOf(":");return t<0?"":e.substr(0,t+1)}function $e(e){const t=Be(e),n=/(\/\/)?([^?#/]+)/.exec(e.substr(t.length));if(!n)return{host:"",port:null};const r=n[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(r);if(i){const e=i[1];return{host:e,port:je(r.substr(e.length+1))}}{const[e,t]=r.split(":");return{host:e,port:je(t)}}}function je(e){if(!e)return null;const t=Number(e);return isNaN(t)?null:t}function ze(){function e(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}"undefined"!==typeof console&&"function"===typeof console.info&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),"undefined"!==typeof window&&"undefined"!==typeof document&&("loading"===document.readyState?window.addEventListener("DOMContentLoaded",e):e())}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class He{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return b("not implemented")}_getIdTokenResponse(e){return b("not implemented")}_linkToIdToken(e,t){return b("not implemented")}_getReauthenticationResolver(e){return b("not implemented")}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ke(e,t){return N(e,"POST","/v1/accounts:update",t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function We(e,t){return F(e,"POST","/v1/accounts:signInWithPassword",O(e,t))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(e,t){return F(e,"POST","/v1/accounts:signInWithEmailLink",O(e,t))}async function Ge(e,t){return F(e,"POST","/v1/accounts:signInWithEmailLink",O(e,t))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Je extends He{constructor(e,t,n,r=null){super("password",n),this._email=e,this._password=t,this._tenantId=r}static _fromEmailAndPassword(e,t){return new Je(e,t,"password")}static _fromEmailAndCode(e,t,n=null){return new Je(e,t,"emailLink",n)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t="string"===typeof e?JSON.parse(e):e;if((null===t||void 0===t?void 0:t.email)&&(null===t||void 0===t?void 0:t.password)){if("password"===t.signInMethod)return this._fromEmailAndPassword(t.email,t.password);if("emailLink"===t.signInMethod)return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){var t;switch(this.signInMethod){case"password":const n={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};if(null===(t=e._getRecaptchaConfig())||void 0===t?void 0:t.emailPasswordEnabled){const t=await Pe(e,n,"signInWithPassword");return We(e,t)}return We(e,n).catch((async t=>{if("auth/missing-recaptcha-token"===t.code){console.log("Sign-in with email address and password is protected by reCAPTCHA for this project. Automatically triggering the reCAPTCHA flow and restarting the sign-in flow.");const t=await Pe(e,n,"signInWithPassword");return We(e,t)}return Promise.reject(t)}));case"emailLink":return Ze(e,{email:this._email,oobCode:this._password});default:p(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":return Ke(e,{idToken:t,returnSecureToken:!0,email:this._email,password:this._password});case"emailLink":return Ge(e,{idToken:t,email:this._email,oobCode:this._password});default:p(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Qe(e,t){return F(e,"POST","/v1/accounts:signInWithIdp",O(e,t))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ye="http://localhost";class Xe extends He{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Xe(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):p("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t="string"===typeof e?JSON.parse(e):e,{providerId:n,signInMethod:r}=t,i=o(t,["providerId","signInMethod"]);if(!n||!r)return null;const s=new Xe(n,r);return s.idToken=i.idToken||void 0,s.accessToken=i.accessToken||void 0,s.secret=i.secret,s.nonce=i.nonce,s.pendingToken=i.pendingToken||null,s}_getIdTokenResponse(e){const t=this.buildRequest();return Qe(e,t)}_linkToIdToken(e,t){const n=this.buildRequest();return n.idToken=t,Qe(e,n)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,Qe(e,t)}buildRequest(){const e={requestUri:Ye,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t["id_token"]=this.idToken),this.accessToken&&(t["access_token"]=this.accessToken),this.secret&&(t["oauth_token_secret"]=this.secret),t["providerId"]=this.providerId,this.nonce&&!this.pendingToken&&(t["nonce"]=this.nonce),e.postBody=(0,r.xO)(t)}return e}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function et(e,t){return N(e,"POST","/v1/accounts:sendVerificationCode",O(e,t))}async function tt(e,t){return F(e,"POST","/v1/accounts:signInWithPhoneNumber",O(e,t))}async function nt(e,t){const n=await F(e,"POST","/v1/accounts:signInWithPhoneNumber",O(e,t));if(n.temporaryProof)throw M(e,"account-exists-with-different-credential",n);return n}const rt={["USER_NOT_FOUND"]:"user-not-found"};async function it(e,t){const n=Object.assign(Object.assign({},t),{operation:"REAUTH"});return F(e,"POST","/v1/accounts:signInWithPhoneNumber",O(e,n),rt)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ot extends He{constructor(e){super("phone","phone"),this.params=e}static _fromVerification(e,t){return new ot({verificationId:e,verificationCode:t})}static _fromTokenResponse(e,t){return new ot({phoneNumber:e,temporaryProof:t})}_getIdTokenResponse(e){return tt(e,this._makeVerificationRequest())}_linkToIdToken(e,t){return nt(e,Object.assign({idToken:t},this._makeVerificationRequest()))}_getReauthenticationResolver(e){return it(e,this._makeVerificationRequest())}_makeVerificationRequest(){const{temporaryProof:e,phoneNumber:t,verificationId:n,verificationCode:r}=this.params;return e&&t?{temporaryProof:e,phoneNumber:t}:{sessionInfo:n,code:r}}toJSON(){const e={providerId:this.providerId};return this.params.phoneNumber&&(e.phoneNumber=this.params.phoneNumber),this.params.temporaryProof&&(e.temporaryProof=this.params.temporaryProof),this.params.verificationCode&&(e.verificationCode=this.params.verificationCode),this.params.verificationId&&(e.verificationId=this.params.verificationId),e}static fromJSON(e){"string"===typeof e&&(e=JSON.parse(e));const{verificationId:t,verificationCode:n,phoneNumber:r,temporaryProof:i}=e;return n||t||r||i?new ot({verificationId:t,verificationCode:n,phoneNumber:r,temporaryProof:i}):null}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function st(e){switch(e){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function at(e){const t=(0,r.zd)((0,r.pd)(e))["link"],n=t?(0,r.zd)((0,r.pd)(t))["deep_link_id"]:null,i=(0,r.zd)((0,r.pd)(e))["deep_link_id"],o=i?(0,r.zd)((0,r.pd)(i))["link"]:null;return o||i||n||t||e}class lt{constructor(e){var t,n,i,o,s,a;const l=(0,r.zd)((0,r.pd)(e)),u=null!==(t=l["apiKey"])&&void 0!==t?t:null,c=null!==(n=l["oobCode"])&&void 0!==n?n:null,d=st(null!==(i=l["mode"])&&void 0!==i?i:null);y(u&&c&&d,"argument-error"),this.apiKey=u,this.operation=d,this.code=c,this.continueUrl=null!==(o=l["continueUrl"])&&void 0!==o?o:null,this.languageCode=null!==(s=l["languageCode"])&&void 0!==s?s:null,this.tenantId=null!==(a=l["tenantId"])&&void 0!==a?a:null}static parseLink(e){const t=at(e);try{return new lt(t)}catch(n){return null}}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ut{constructor(){this.providerId=ut.PROVIDER_ID}static credential(e,t){return Je._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const n=lt.parseLink(t);return y(n,"argument-error"),Je._fromEmailAndCode(e,n.code,n.tenantId)}}ut.PROVIDER_ID="password",ut.EMAIL_PASSWORD_SIGN_IN_METHOD="password",ut.EMAIL_LINK_SIGN_IN_METHOD="emailLink";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ct{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dt extends ct{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ht extends dt{constructor(){super("facebook.com")}static credential(e){return Xe._fromParams({providerId:ht.PROVIDER_ID,signInMethod:ht.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return ht.credentialFromTaggedObject(e)}static credentialFromError(e){return ht.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e))return null;if(!e.oauthAccessToken)return null;try{return ht.credential(e.oauthAccessToken)}catch(t){return null}}}ht.FACEBOOK_SIGN_IN_METHOD="facebook.com",ht.PROVIDER_ID="facebook.com";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft extends dt{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Xe._fromParams({providerId:ft.PROVIDER_ID,signInMethod:ft.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return ft.credentialFromTaggedObject(e)}static credentialFromError(e){return ft.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:n}=e;if(!t&&!n)return null;try{return ft.credential(t,n)}catch(r){return null}}}ft.GOOGLE_SIGN_IN_METHOD="google.com",ft.PROVIDER_ID="google.com";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt extends dt{constructor(){super("github.com")}static credential(e){return Xe._fromParams({providerId:pt.PROVIDER_ID,signInMethod:pt.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return pt.credentialFromTaggedObject(e)}static credentialFromError(e){return pt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e))return null;if(!e.oauthAccessToken)return null;try{return pt.credential(e.oauthAccessToken)}catch(t){return null}}}pt.GITHUB_SIGN_IN_METHOD="github.com",pt.PROVIDER_ID="github.com";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gt extends dt{constructor(){super("twitter.com")}static credential(e,t){return Xe._fromParams({providerId:gt.PROVIDER_ID,signInMethod:gt.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return gt.credentialFromTaggedObject(e)}static credentialFromError(e){return gt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:n}=e;if(!t||!n)return null;try{return gt.credential(t,n)}catch(r){return null}}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mt(e,t){return F(e,"POST","/v1/accounts:signUp",O(e,t))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */gt.TWITTER_SIGN_IN_METHOD="twitter.com",gt.PROVIDER_ID="twitter.com";class vt{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,n,r=!1){const i=await ne._fromIdTokenResponse(e,n,r),o=yt(n),s=new vt({user:i,providerId:o,_tokenResponse:n,operationType:t});return s}static async _forOperation(e,t,n){await e._updateTokensIfNecessary(n,!0);const r=yt(n);return new vt({user:e,providerId:r,_tokenResponse:n,operationType:t})}}function yt(e){return e.providerId?e.providerId:"phoneNumber"in e?"phone":null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bt extends r.ZR{constructor(e,t,n,r){var i;super(t.code,t.message),this.operationType=n,this.user=r,Object.setPrototypeOf(this,bt.prototype),this.customData={appName:e.name,tenantId:null!==(i=e.tenantId)&&void 0!==i?i:void 0,_serverResponse:t.customData._serverResponse,operationType:n}}static _fromErrorAndOperation(e,t,n,r){return new bt(e,t,n,r)}}function wt(e,t,n,r){const i="reauthenticate"===t?n._getReauthenticationResolver(e):n._getIdTokenResponse(e);return i.catch((n=>{if("auth/multi-factor-auth-required"===n.code)throw bt._fromErrorAndOperation(e,n,t,r);throw n}))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _t(e,t,n=!1){const r=await H(e,t._linkToIdToken(e.auth,await e.getIdToken()),n);return vt._forOperation(e,"link",r)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function St(e,t,n=!1){const{auth:r}=e,i="reauthenticate";try{const o=await H(e,wt(r,i,t,e),n);y(o.idToken,r,"internal-error");const s=j(o.idToken);y(s,r,"internal-error");const{sub:a}=s;return y(e.uid===a,r,"user-mismatch"),vt._forOperation(e,i,o)}catch(o){throw"auth/user-not-found"===(null===o||void 0===o?void 0:o.code)&&p(r,"user-mismatch"),o}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Et(e,t,n=!1){const r="signIn",i=await wt(e,r,t),o=await vt._fromIdTokenResponse(e,r,i);return n||await e._updateCurrentUser(o.user),o}async function kt(e,t){return Et(De(e),t)}async function Tt(e,t,n){var r;const i=De(e),o={returnSecureToken:!0,email:t,password:n,clientType:"CLIENT_TYPE_WEB"};let s;if(null===(r=i._getRecaptchaConfig())||void 0===r?void 0:r.emailPasswordEnabled){const e=await Pe(i,o,"signUpPassword");s=mt(i,e)}else s=mt(i,o).catch((async e=>{if("auth/missing-recaptcha-token"===e.code){console.log("Sign-up is protected by reCAPTCHA for this project. Automatically triggering the reCAPTCHA flow and restarting the sign-up flow.");const e=await Pe(i,o,"signUpPassword");return mt(i,e)}return Promise.reject(e)}));const a=await s.catch((e=>Promise.reject(e))),l=await vt._fromIdTokenResponse(i,"signIn",a);return await i._updateCurrentUser(l.user),l}function Ct(e,t,n){return kt((0,r.m9)(e),ut.credential(t,n))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function It(e,t,n,i){return(0,r.m9)(e).onIdTokenChanged(t,n,i)}function xt(e,t,n){return(0,r.m9)(e).beforeAuthStateChanged(t,n)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(e,t){return N(e,"POST","/v2/accounts/mfaEnrollment:start",O(e,t))}function Rt(e,t){return N(e,"POST","/v2/accounts/mfaEnrollment:finalize",O(e,t))}function Ot(e,t){return N(e,"POST","/v2/accounts/mfaEnrollment:start",O(e,t))}function Nt(e,t){return N(e,"POST","/v2/accounts/mfaEnrollment:finalize",O(e,t))}new WeakMap;const Pt="__sak";
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ft{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Pt,"1"),this.storage.removeItem(Pt),Promise.resolve(!0)):Promise.resolve(!1)}catch(e){return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lt(){const e=(0,r.z$)();return de(e)||ve(e)}const Dt=1e3,Mt=10;class qt extends Ft{constructor(){super((()=>window.localStorage),"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=Lt()&&_e(),this.fallbackToPolling=we(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const n=this.storage.getItem(t),r=this.localCache[t];n!==r&&e(t,r,n)}}onStorageEvent(e,t=!1){if(!e.key)return void this.forAllChangedKeys(((e,t,n)=>{this.notifyListeners(e,n)}));const n=e.key;if(t?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){const r=this.storage.getItem(n);if(e.newValue!==r)null!==e.newValue?this.storage.setItem(n,e.newValue):this.storage.removeItem(n);else if(this.localCache[n]===e.newValue&&!t)return}const r=()=>{const e=this.storage.getItem(n);(t||this.localCache[n]!==e)&&this.notifyListeners(n,e)},i=this.storage.getItem(n);be()&&i!==e.newValue&&e.newValue!==e.oldValue?setTimeout(r,Mt):r()}notifyListeners(e,t){this.localCache[e]=t;const n=this.listeners[e];if(n)for(const r of Array.from(n))r(t?JSON.parse(t):t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval((()=>{this.forAllChangedKeys(((e,t,n)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:n}),!0)}))}),Dt)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){0===Object.keys(this.listeners).length&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),0===this.listeners[e].size&&delete this.listeners[e]),0===Object.keys(this.listeners).length&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}qt.type="LOCAL";const Vt=qt;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ut extends Ft{constructor(){super((()=>window.sessionStorage),"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Ut.type="SESSION";const Bt=Ut;
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $t(e){return Promise.all(e.map((async e=>{try{const t=await e;return{fulfilled:!0,value:t}}catch(t){return{fulfilled:!1,reason:t}}})))}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jt{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find((t=>t.isListeningto(e)));if(t)return t;const n=new jt(e);return this.receivers.push(n),n}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:n,eventType:r,data:i}=t.data,o=this.handlersMap[r];if(!(null===o||void 0===o?void 0:o.size))return;t.ports[0].postMessage({status:"ack",eventId:n,eventType:r});const s=Array.from(o).map((async e=>e(t.origin,i))),a=await $t(s);t.ports[0].postMessage({status:"done",eventId:n,eventType:r,response:a})}_subscribe(e,t){0===Object.keys(this.handlersMap).length&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),t&&0!==this.handlersMap[e].size||delete this.handlersMap[e],0===Object.keys(this.handlersMap).length&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function zt(e="",t=10){let n="";for(let r=0;r<t;r++)n+=Math.floor(10*Math.random());return e+n}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */jt.receivers=[];class Ht{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,n=50){const r="undefined"!==typeof MessageChannel?new MessageChannel:null;if(!r)throw new Error("connection_unavailable");let i,o;return new Promise(((s,a)=>{const l=zt("",20);r.port1.start();const u=setTimeout((()=>{a(new Error("unsupported_event"))}),n);o={messageChannel:r,onMessage(e){const t=e;if(t.data.eventId===l)switch(t.data.status){case"ack":clearTimeout(u),i=setTimeout((()=>{a(new Error("timeout"))}),3e3);break;case"done":clearTimeout(i),s(t.data.response);break;default:clearTimeout(u),clearTimeout(i),a(new Error("invalid_response"));break}}},this.handlers.add(o),r.port1.addEventListener("message",o.onMessage),this.target.postMessage({eventType:e,eventId:l,data:t},[r.port2])})).finally((()=>{o&&this.removeMessageHandler(o)}))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kt(){return window}function Wt(e){Kt().location.href=e}
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zt(){return"undefined"!==typeof Kt()["WorkerGlobalScope"]&&"function"===typeof Kt()["importScripts"]}async function Gt(){if(!(null===navigator||void 0===navigator?void 0:navigator.serviceWorker))return null;try{const e=await navigator.serviceWorker.ready;return e.active}catch(e){return null}}function Jt(){var e;return(null===(e=null===navigator||void 0===navigator?void 0:navigator.serviceWorker)||void 0===e?void 0:e.controller)||null}function Qt(){return Zt()?self:null}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Yt="firebaseLocalStorageDb",Xt=1,en="firebaseLocalStorage",tn="fbase_key";class nn{constructor(e){this.request=e}toPromise(){return new Promise(((e,t)=>{this.request.addEventListener("success",(()=>{e(this.request.result)})),this.request.addEventListener("error",(()=>{t(this.request.error)}))}))}}function rn(e,t){return e.transaction([en],t?"readwrite":"readonly").objectStore(en)}function on(){const e=indexedDB.deleteDatabase(Yt);return new nn(e).toPromise()}function sn(){const e=indexedDB.open(Yt,Xt);return new Promise(((t,n)=>{e.addEventListener("error",(()=>{n(e.error)})),e.addEventListener("upgradeneeded",(()=>{const t=e.result;try{t.createObjectStore(en,{keyPath:tn})}catch(r){n(r)}})),e.addEventListener("success",(async()=>{const n=e.result;n.objectStoreNames.contains(en)?t(n):(n.close(),await on(),t(await sn()))}))}))}async function an(e,t,n){const r=rn(e,!0).put({[tn]:t,value:n});return new nn(r).toPromise()}async function ln(e,t){const n=rn(e,!1).get(t),r=await new nn(n).toPromise();return void 0===r?null:r.value}function un(e,t){const n=rn(e,!0).delete(t);return new nn(n).toPromise()}const cn=800,dn=3;class hn{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then((()=>{}),(()=>{}))}async _openDb(){return this.db||(this.db=await sn()),this.db}async _withRetries(e){let t=0;while(1)try{const t=await this._openDb();return await e(t)}catch(n){if(t++>dn)throw n;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Zt()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=jt._getInstance(Qt()),this.receiver._subscribe("keyChanged",(async(e,t)=>{const n=await this._poll();return{keyProcessed:n.includes(t.key)}})),this.receiver._subscribe("ping",(async(e,t)=>["keyChanged"]))}async initializeSender(){var e,t;if(this.activeServiceWorker=await Gt(),!this.activeServiceWorker)return;this.sender=new Ht(this.activeServiceWorker);const n=await this.sender._send("ping",{},800);n&&(null===(e=n[0])||void 0===e?void 0:e.fulfilled)&&(null===(t=n[0])||void 0===t?void 0:t.value.includes("keyChanged"))&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(this.sender&&this.activeServiceWorker&&Jt()===this.activeServiceWorker)try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch(t){}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await sn();return await an(e,Pt,"1"),await un(e,Pt),!0}catch(e){}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite((async()=>(await this._withRetries((n=>an(n,e,t))),this.localCache[e]=t,this.notifyServiceWorker(e))))}async _get(e){const t=await this._withRetries((t=>ln(t,e)));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite((async()=>(await this._withRetries((t=>un(t,e))),delete this.localCache[e],this.notifyServiceWorker(e))))}async _poll(){const e=await this._withRetries((e=>{const t=rn(e,!1).getAll();return new nn(t).toPromise()}));if(!e)return[];if(0!==this.pendingWrites)return[];const t=[],n=new Set;for(const{fbase_key:r,value:i}of e)n.add(r),JSON.stringify(this.localCache[r])!==JSON.stringify(i)&&(this.notifyListeners(r,i),t.push(r));for(const r of Object.keys(this.localCache))this.localCache[r]&&!n.has(r)&&(this.notifyListeners(r,null),t.push(r));return t}notifyListeners(e,t){this.localCache[e]=t;const n=this.listeners[e];if(n)for(const r of Array.from(n))r(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval((async()=>this._poll()),cn)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){0===Object.keys(this.listeners).length&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),0===this.listeners[e].size&&delete this.listeners[e]),0===Object.keys(this.listeners).length&&this.stopPolling()}}hn.type="LOCAL";const fn=hn;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pn(e,t){return N(e,"POST","/v2/accounts/mfaSignIn:start",O(e,t))}function gn(e,t){return N(e,"POST","/v2/accounts/mfaSignIn:finalize",O(e,t))}function mn(e,t){return N(e,"POST","/v2/accounts/mfaSignIn:finalize",O(e,t))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
xe("rcb"),new C(3e4,6e4);
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vn="recaptcha";async function yn(e,t,n){var r;const i=await n.verify();try{let o;if(y("string"===typeof i,e,"argument-error"),y(n.type===vn,e,"argument-error"),o="string"===typeof t?{phoneNumber:t}:t,"session"in o){const t=o.session;if("phoneNumber"in o){y("enroll"===t.type,e,"internal-error");const n=await At(e,{idToken:t.credential,phoneEnrollmentInfo:{phoneNumber:o.phoneNumber,recaptchaToken:i}});return n.phoneSessionInfo.sessionInfo}{y("signin"===t.type,e,"internal-error");const n=(null===(r=o.multiFactorHint)||void 0===r?void 0:r.uid)||o.multiFactorUid;y(n,e,"missing-multi-factor-info");const s=await pn(e,{mfaPendingCredential:t.credential,mfaEnrollmentId:n,phoneSignInInfo:{recaptchaToken:i}});return s.phoneResponseInfo.sessionInfo}}{const{sessionInfo:t}=await et(e,{phoneNumber:o.phoneNumber,recaptchaToken:i});return t}}finally{n._reset()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bn{constructor(e){this.providerId=bn.PROVIDER_ID,this.auth=De(e)}verifyPhoneNumber(e,t){return yn(this.auth,e,(0,r.m9)(t))}static credential(e,t){return ot._fromVerification(e,t)}static credentialFromResult(e){const t=e;return bn.credentialFromTaggedObject(t)}static credentialFromError(e){return bn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{phoneNumber:t,temporaryProof:n}=e;return t&&n?ot._fromTokenResponse(t,n):null}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wn(e,t){return t?ie(t):(y(e._popupRedirectResolver,e,"argument-error"),e._popupRedirectResolver)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */bn.PROVIDER_ID="phone",bn.PHONE_SIGN_IN_METHOD="phone";class _n extends He{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return Qe(e,this._buildIdpRequest())}_linkToIdToken(e,t){return Qe(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return Qe(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function Sn(e){return Et(e.auth,new _n(e),e.bypassAuthState)}function En(e){const{auth:t,user:n}=e;return y(n,t,"internal-error"),St(n,new _n(e),e.bypassAuthState)}async function kn(e){const{auth:t,user:n}=e;return y(n,t,"internal-error"),_t(n,new _n(e),e.bypassAuthState)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tn{constructor(e,t,n,r,i=!1){this.auth=e,this.resolver=n,this.user=r,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise((async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(n){this.reject(n)}}))}async onAuthEvent(e){const{urlResponse:t,sessionId:n,postBody:r,tenantId:i,error:o,type:s}=e;if(o)return void this.reject(o);const a={auth:this.auth,requestUri:t,sessionId:n,tenantId:i||void 0,postBody:r||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(s)(a))}catch(l){this.reject(l)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return Sn;case"linkViaPopup":case"linkViaRedirect":return kn;case"reauthViaPopup":case"reauthViaRedirect":return En;default:p(this.auth,"internal-error")}}resolve(e){w(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){w(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cn=new C(2e3,1e4);class In extends Tn{constructor(e,t,n,r,i){super(e,t,r,i),this.provider=n,this.authWindow=null,this.pollId=null,In.currentPopupAction&&In.currentPopupAction.cancel(),In.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return y(e,this.auth,"internal-error"),e}async onExecution(){w(1===this.filter.length,"Popup operations only handle one event");const e=zt();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch((e=>{this.reject(e)})),this.resolver._isIframeWebStorageSupported(this.auth,(e=>{e||this.reject(g(this.auth,"web-storage-unsupported"))})),this.pollUserCancellation()}get eventId(){var e;return(null===(e=this.authWindow)||void 0===e?void 0:e.associatedEvent)||null}cancel(){this.reject(g(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,In.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,n;(null===(n=null===(t=this.authWindow)||void 0===t?void 0:t.window)||void 0===n?void 0:n.closed)?this.pollId=window.setTimeout((()=>{this.pollId=null,this.reject(g(this.auth,"popup-closed-by-user"))}),8e3):this.pollId=window.setTimeout(e,Cn.get())};e()}}In.currentPopupAction=null;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xn="pendingRedirect",An=new Map;class Rn extends Tn{constructor(e,t,n=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,n),this.eventId=null}async execute(){let e=An.get(this.auth._key());if(!e){try{const t=await On(this.resolver,this.auth),n=t?await super.execute():null;e=()=>Promise.resolve(n)}catch(t){e=()=>Promise.reject(t)}An.set(this.auth._key(),e)}return this.bypassAuthState||An.set(this.auth._key(),(()=>Promise.resolve(null))),e()}async onAuthEvent(e){if("signInViaRedirect"===e.type)return super.onAuthEvent(e);if("unknown"!==e.type){if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}else this.resolve(null)}async onExecution(){}cleanUp(){}}async function On(e,t){const n=Fn(t),r=Pn(e);if(!await r._isAvailable())return!1;const i="true"===await r._get(n);return await r._remove(n),i}function Nn(e,t){An.set(e._key(),t)}function Pn(e){return ie(e._redirectPersistence)}function Fn(e){return ae(xn,e.config.apiKey,e.name)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ln(e,t,n=!1){const r=De(e),i=wn(r,t),o=new Rn(r,i,n),s=await o.execute();return s&&!n&&(delete s.user._redirectEventId,await r._persistUserIfCurrent(s.user),await r._setRedirectUser(null,t)),s}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dn=6e5;class Mn{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach((n=>{this.isEventForConsumer(e,n)&&(t=!0,this.sendToConsumer(e,n),this.saveEventToCache(e))})),this.hasHandledPotentialRedirect||!Un(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var n;if(e.error&&!Vn(e)){const r=(null===(n=e.error.code)||void 0===n?void 0:n.split("auth/")[1])||"internal-error";t.onError(g(this.auth,r))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const n=null===t.eventId||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&n}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=Dn&&this.cachedEventUids.clear(),this.cachedEventUids.has(qn(e))}saveEventToCache(e){this.cachedEventUids.add(qn(e)),this.lastProcessedEventTime=Date.now()}}function qn(e){return[e.type,e.eventId,e.sessionId,e.tenantId].filter((e=>e)).join("-")}function Vn({type:e,error:t}){return"unknown"===e&&"auth/no-auth-event"===(null===t||void 0===t?void 0:t.code)}function Un(e){switch(e.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Vn(e);default:return!1}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Bn(e,t={}){return N(e,"GET","/v1/projects",t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $n=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,jn=/^https?/;async function zn(e){if(e.config.emulator)return;const{authorizedDomains:t}=await Bn(e);for(const r of t)try{if(Hn(r))return}catch(n){}p(e,"unauthorized-domain")}function Hn(e){const t=_(),{protocol:n,hostname:r}=new URL(t);if(e.startsWith("chrome-extension://")){const i=new URL(e);return""===i.hostname&&""===r?"chrome-extension:"===n&&e.replace("chrome-extension://","")===t.replace("chrome-extension://",""):"chrome-extension:"===n&&i.hostname===r}if(!jn.test(n))return!1;if($n.test(e))return r===e;const i=e.replace(/\./g,"\\."),o=new RegExp("^(.+\\."+i+"|"+i+")$","i");return o.test(r)}
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kn=new C(3e4,6e4);function Wn(){const e=Kt().___jsl;if(null===e||void 0===e?void 0:e.H)for(const t of Object.keys(e.H))if(e.H[t].r=e.H[t].r||[],e.H[t].L=e.H[t].L||[],e.H[t].r=[...e.H[t].L],e.CP)for(let n=0;n<e.CP.length;n++)e.CP[n]=null}function Zn(e){return new Promise(((t,n)=>{var r,i,o;function s(){Wn(),gapi.load("gapi.iframes",{callback:()=>{t(gapi.iframes.getContext())},ontimeout:()=>{Wn(),n(g(e,"network-request-failed"))},timeout:Kn.get()})}if(null===(i=null===(r=Kt().gapi)||void 0===r?void 0:r.iframes)||void 0===i?void 0:i.Iframe)t(gapi.iframes.getContext());else{if(!(null===(o=Kt().gapi)||void 0===o?void 0:o.load)){const t=xe("iframefcb");return Kt()[t]=()=>{gapi.load?s():n(g(e,"network-request-failed"))},Ie(`https://apis.google.com/js/api.js?onload=${t}`).catch((e=>n(e)))}s()}})).catch((e=>{throw Gn=null,e}))}let Gn=null;function Jn(e){return Gn=Gn||Zn(e),Gn}
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qn=new C(5e3,15e3),Yn="__/auth/iframe",Xn="emulator/auth/iframe",er={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},tr=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function nr(e){const t=e.config;y(t.authDomain,e,"auth-domain-config-required");const n=t.emulator?I(t,Xn):`https://${e.config.authDomain}/${Yn}`,o={apiKey:t.apiKey,appName:e.name,v:i.Jn},s=tr.get(e.config.apiHost);s&&(o.eid=s);const a=e._getFrameworks();return a.length&&(o.fw=a.join(",")),`${n}?${(0,r.xO)(o).slice(1)}`}async function rr(e){const t=await Jn(e),n=Kt().gapi;return y(n,e,"internal-error"),t.open({where:document.body,url:nr(e),messageHandlersFilter:n.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:er,dontclear:!0},(t=>new Promise((async(n,r)=>{await t.restyle({setHideOnLeave:!1});const i=g(e,"network-request-failed"),o=Kt().setTimeout((()=>{r(i)}),Qn.get());function s(){Kt().clearTimeout(o),n(t)}t.ping(s).then(s,(()=>{r(i)}))}))))}
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ir={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},or=500,sr=600,ar="_blank",lr="http://localhost";class ur{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch(e){}}}function cr(e,t,n,i=or,o=sr){const s=Math.max((window.screen.availHeight-o)/2,0).toString(),a=Math.max((window.screen.availWidth-i)/2,0).toString();let l="";const u=Object.assign(Object.assign({},ir),{width:i.toString(),height:o.toString(),top:s,left:a}),c=(0,r.z$)().toLowerCase();n&&(l=he(c)?ar:n),ce(c)&&(t=t||lr,u.scrollbars="yes");const d=Object.entries(u).reduce(((e,[t,n])=>`${e}${t}=${n},`),"");if(ye(c)&&"_self"!==l)return dr(t||"",l),new ur(null);const h=window.open(t||"",l,d);y(h,e,"popup-blocked");try{h.focus()}catch(f){}return new ur(h)}function dr(e,t){const n=document.createElement("a");n.href=e,n.target=t;const r=document.createEvent("MouseEvent");r.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),n.dispatchEvent(r)}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hr="__/auth/handler",fr="emulator/auth/handler",pr=encodeURIComponent("fac");async function gr(e,t,n,o,s,a){y(e.config.authDomain,e,"auth-domain-config-required"),y(e.config.apiKey,e,"invalid-api-key");const l={apiKey:e.config.apiKey,appName:e.name,authType:n,redirectUrl:o,v:i.Jn,eventId:s};if(t instanceof ct){t.setDefaultLanguage(e.languageCode),l.providerId=t.providerId||"",(0,r.xb)(t.getCustomParameters())||(l.customParameters=JSON.stringify(t.getCustomParameters()));for(const[e,t]of Object.entries(a||{}))l[e]=t}if(t instanceof dt){const e=t.getScopes().filter((e=>""!==e));e.length>0&&(l.scopes=e.join(","))}e.tenantId&&(l.tid=e.tenantId);const u=l;for(const r of Object.keys(u))void 0===u[r]&&delete u[r];const c=await e._getAppCheckToken(),d=c?`#${pr}=${encodeURIComponent(c)}`:"";return`${mr(e)}?${(0,r.xO)(u).slice(1)}${d}`}function mr({config:e}){return e.emulator?I(e,fr):`https://${e.authDomain}/${hr}`}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vr="webStorageSupport";class yr{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Bt,this._completeRedirectFn=Ln,this._overrideRedirectResult=Nn}async _openPopup(e,t,n,r){var i;w(null===(i=this.eventManagers[e._key()])||void 0===i?void 0:i.manager,"_initialize() not called before _openPopup()");const o=await gr(e,t,n,_(),r);return cr(e,o,zt())}async _openRedirect(e,t,n,r){await this._originValidation(e);const i=await gr(e,t,n,_(),r);return Wt(i),new Promise((()=>{}))}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:e,promise:n}=this.eventManagers[t];return e?Promise.resolve(e):(w(n,"If manager is not set, promise should be"),n)}const n=this.initAndGetManager(e);return this.eventManagers[t]={promise:n},n.catch((()=>{delete this.eventManagers[t]})),n}async initAndGetManager(e){const t=await rr(e),n=new Mn(e);return t.register("authEvent",(t=>{y(null===t||void 0===t?void 0:t.authEvent,e,"invalid-auth-event");const r=n.onEvent(t.authEvent);return{status:r?"ACK":"ERROR"}}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:n},this.iframes[e._key()]=t,n}_isIframeWebStorageSupported(e,t){const n=this.iframes[e._key()];n.send(vr,{type:vr},(n=>{var r;const i=null===(r=null===n||void 0===n?void 0:n[0])||void 0===r?void 0:r[vr];void 0!==i&&t(!!i),p(e,"internal-error")}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=zn(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return we()||de()||ve()}}const br=yr;class wr{constructor(e){this.factorId=e}_process(e,t,n){switch(t.type){case"enroll":return this._finalizeEnroll(e,t.credential,n);case"signin":return this._finalizeSignIn(e,t.credential);default:return b("unexpected MultiFactorSessionType")}}}class _r extends wr{constructor(e){super("phone"),this.credential=e}static _fromCredential(e){return new _r(e)}_finalizeEnroll(e,t,n){return Rt(e,{idToken:t,displayName:n,phoneVerificationInfo:this.credential._makeVerificationRequest()})}_finalizeSignIn(e,t){return gn(e,{mfaPendingCredential:t,phoneVerificationInfo:this.credential._makeVerificationRequest()})}}class Sr{constructor(){}static assertion(e){return _r._fromCredential(e)}}Sr.FACTOR_ID="phone";class Er{static assertionForEnrollment(e,t){return kr._fromSecret(e,t)}static assertionForSignIn(e,t){return kr._fromEnrollmentId(e,t)}static async generateSecret(e){const t=e;y("undefined"!==typeof t.auth,"internal-error");const n=await Ot(t.auth,{idToken:t.credential,totpEnrollmentInfo:{}});return Tr._fromStartTotpMfaEnrollmentResponse(n,t.auth)}}Er.FACTOR_ID="totp";class kr extends wr{constructor(e,t,n){super("totp"),this.otp=e,this.enrollmentId=t,this.secret=n}static _fromSecret(e,t){return new kr(t,void 0,e)}static _fromEnrollmentId(e,t){return new kr(t,e)}async _finalizeEnroll(e,t,n){return y("undefined"!==typeof this.secret,e,"argument-error"),Nt(e,{idToken:t,displayName:n,totpVerificationInfo:this.secret._makeTotpVerificationInfo(this.otp)})}async _finalizeSignIn(e,t){y(void 0!==this.enrollmentId&&void 0!==this.otp,e,"argument-error");const n={verificationCode:this.otp};return mn(e,{mfaPendingCredential:t,mfaEnrollmentId:this.enrollmentId,totpVerificationInfo:n})}}class Tr{constructor(e,t,n,r,i,o,s){this.sessionInfo=o,this.auth=s,this.secretKey=e,this.hashingAlgorithm=t,this.codeLength=n,this.codeIntervalSeconds=r,this.enrollmentCompletionDeadline=i}static _fromStartTotpMfaEnrollmentResponse(e,t){return new Tr(e.totpSessionInfo.sharedSecretKey,e.totpSessionInfo.hashingAlgorithm,e.totpSessionInfo.verificationCodeLength,e.totpSessionInfo.periodSec,new Date(e.totpSessionInfo.finalizeEnrollmentTime).toUTCString(),e.totpSessionInfo.sessionInfo,t)}_makeTotpVerificationInfo(e){return{sessionInfo:this.sessionInfo,verificationCode:e}}generateQrCodeUrl(e,t){var n;let r=!1;return(Cr(e)||Cr(t))&&(r=!0),r&&(Cr(e)&&(e=(null===(n=this.auth.currentUser)||void 0===n?void 0:n.email)||"unknownuser"),Cr(t)&&(t=this.auth.name)),`otpauth://totp/${t}:${e}?secret=${this.secretKey}&issuer=${t}&algorithm=${this.hashingAlgorithm}&digits=${this.codeLength}`}}function Cr(e){return"undefined"===typeof e||0===(null===e||void 0===e?void 0:e.length)}var Ir="@firebase/auth",xr="0.23.2";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ar{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),(null===(e=this.auth.currentUser)||void 0===e?void 0:e.uid)||null}async getToken(e){if(this.assertAuthConfigured(),await this.auth._initializationPromise,!this.auth.currentUser)return null;const t=await this.auth.currentUser.getIdToken(e);return{accessToken:t}}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged((t=>{e((null===t||void 0===t?void 0:t.stsTokenManager.accessToken)||null)}));this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){y(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rr(e){switch(e){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";default:return}}function Or(e){(0,i.Xd)(new a.wA("auth",((t,{options:n})=>{const r=t.getProvider("app").getImmediate(),i=t.getProvider("heartbeat"),o=t.getProvider("app-check-internal"),{apiKey:s,authDomain:a}=r.options;y(s&&!s.includes(":"),"invalid-api-key",{appName:r.name});const l={apiKey:s,authDomain:a,clientPlatform:e,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Se(e)},u=new Le(r,i,o,l);return Ve(u,n),u}),"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback(((e,t,n)=>{const r=e.getProvider("auth-internal");r.initialize()}))),(0,i.Xd)(new a.wA("auth-internal",(e=>{const t=De(e.getProvider("auth").getImmediate());return(e=>new Ar(e))(t)}),"PRIVATE").setInstantiationMode("EXPLICIT")),(0,i.KN)(Ir,xr,Rr(e)),(0,i.KN)(Ir,xr,"esm2017")}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nr=300,Pr=(0,r.Pz)("authIdTokenMaxAge")||Nr;let Fr=null;const Lr=e=>async t=>{const n=t&&await t.getIdTokenResult(),r=n&&((new Date).getTime()-Date.parse(n.issuedAtTime))/1e3;if(r&&r>Pr)return;const i=null===n||void 0===n?void 0:n.token;Fr!==i&&(Fr=i,await fetch(e,{method:i?"POST":"DELETE",headers:i?{Authorization:`Bearer ${i}`}:{}}))};function Dr(e=(0,i.Mq)()){const t=(0,i.qX)(e,"auth");if(t.isInitialized())return t.getImmediate();const n=qe(e,{popupRedirectResolver:br,persistence:[fn,Vt,Bt]}),o=(0,r.Pz)("authTokenSyncURL");if(o){const e=Lr(o);xt(n,e,(()=>e(n.currentUser))),It(n,(t=>e(t)))}const s=(0,r.q4)("auth");return s&&Ue(n,`http://${s}`),n}Or("Browser")},7656:(e,t,n)=>{"use strict";n.d(t,{ET:()=>lh,hJ:()=>sd,JU:()=>ad,PL:()=>sh,ad:()=>cd,IO:()=>zd,r7:()=>ah,ar:()=>Kd});var r,i=n(8897),o=n(3513),s=n(9795),a=n(5505),l="undefined"!==typeof globalThis?globalThis:"undefined"!==typeof window?window:"undefined"!==typeof global?global:"undefined"!==typeof self?self:{},u={},c=c||{},d=l||self;function h(e){var t=typeof e;return t="object"!=t?t:e?Array.isArray(e)?"array":t:"null","array"==t||"object"==t&&"number"==typeof e.length}function f(e){var t=typeof e;return"object"==t&&null!=e||"function"==t}function p(e){return Object.prototype.hasOwnProperty.call(e,g)&&e[g]||(e[g]=++m)}var g="closure_uid_"+(1e9*Math.random()>>>0),m=0;function v(e,t,n){return e.call.apply(e.bind,arguments)}function y(e,t,n){if(!e)throw Error();if(2<arguments.length){var r=Array.prototype.slice.call(arguments,2);return function(){var n=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(n,r),e.apply(t,n)}}return function(){return e.apply(t,arguments)}}function b(e,t,n){return b=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?v:y,b.apply(null,arguments)}function w(e,t){var n=Array.prototype.slice.call(arguments,1);return function(){var t=n.slice();return t.push.apply(t,arguments),e.apply(this,t)}}function _(e,t){function n(){}n.prototype=t.prototype,e.$=t.prototype,e.prototype=new n,e.prototype.constructor=e,e.ac=function(e,n,r){for(var i=Array(arguments.length-2),o=2;o<arguments.length;o++)i[o-2]=arguments[o];return t.prototype[n].apply(e,i)}}function S(){this.s=this.s,this.o=this.o}var E=0;S.prototype.s=!1,S.prototype.sa=function(){this.s||(this.s=!0,this.N(),0==E)||p(this)},S.prototype.N=function(){if(this.o)for(;this.o.length;)this.o.shift()()};const k=Array.prototype.indexOf?function(e,t){return Array.prototype.indexOf.call(e,t,void 0)}:function(e,t){if("string"===typeof e)return"string"!==typeof t||1!=t.length?-1:e.indexOf(t,0);for(let n=0;n<e.length;n++)if(n in e&&e[n]===t)return n;return-1};function T(e){const t=e.length;if(0<t){const n=Array(t);for(let r=0;r<t;r++)n[r]=e[r];return n}return[]}function C(e,t){for(let n=1;n<arguments.length;n++){const t=arguments[n];if(h(t)){const n=e.length||0,r=t.length||0;e.length=n+r;for(let i=0;i<r;i++)e[n+i]=t[i]}else e.push(t)}}function I(e,t){this.type=e,this.g=this.target=t,this.defaultPrevented=!1}I.prototype.h=function(){this.defaultPrevented=!0};var x=function(){if(!d.addEventListener||!Object.defineProperty)return!1;var e=!1,t=Object.defineProperty({},"passive",{get:function(){e=!0}});try{d.addEventListener("test",(()=>{}),t),d.removeEventListener("test",(()=>{}),t)}catch(n){}return e}();function A(e){return/^[\s\xa0]*$/.test(e)}function R(){var e=d.navigator;return e&&(e=e.userAgent)?e:""}function O(e){return-1!=R().indexOf(e)}function N(e){return N[" "](e),e}function P(e,t){var n=wr;return Object.prototype.hasOwnProperty.call(n,e)?n[e]:n[e]=t(e)}N[" "]=function(){};var F,L,D=O("Opera"),M=O("Trident")||O("MSIE"),q=O("Edge"),V=q||M,U=O("Gecko")&&!(-1!=R().toLowerCase().indexOf("webkit")&&!O("Edge"))&&!(O("Trident")||O("MSIE"))&&!O("Edge"),B=-1!=R().toLowerCase().indexOf("webkit")&&!O("Edge");function $(){var e=d.document;return e?e.documentMode:void 0}e:{var j="",z=function(){var e=R();return U?/rv:([^\);]+)(\)|;)/.exec(e):q?/Edge\/([\d\.]+)/.exec(e):M?/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(e):B?/WebKit\/(\S+)/.exec(e):D?/(?:Version)[ \/]?(\S+)/.exec(e):void 0}();if(z&&(j=z?z[1]:""),M){var H=$();if(null!=H&&H>parseFloat(j)){F=String(H);break e}}F=j}if(d.document&&M){var K=$();L=K||(parseInt(F,10)||void 0)}else L=void 0;var W=L;function Z(e,t){if(I.call(this,e?e.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,e){var n=this.type=e.type,r=e.changedTouches&&e.changedTouches.length?e.changedTouches[0]:null;if(this.target=e.target||e.srcElement,this.g=t,t=e.relatedTarget){if(U){e:{try{N(t.nodeName);var i=!0;break e}catch(o){}i=!1}i||(t=null)}}else"mouseover"==n?t=e.fromElement:"mouseout"==n&&(t=e.toElement);this.relatedTarget=t,r?(this.clientX=void 0!==r.clientX?r.clientX:r.pageX,this.clientY=void 0!==r.clientY?r.clientY:r.pageY,this.screenX=r.screenX||0,this.screenY=r.screenY||0):(this.clientX=void 0!==e.clientX?e.clientX:e.pageX,this.clientY=void 0!==e.clientY?e.clientY:e.pageY,this.screenX=e.screenX||0,this.screenY=e.screenY||0),this.button=e.button,this.key=e.key||"",this.ctrlKey=e.ctrlKey,this.altKey=e.altKey,this.shiftKey=e.shiftKey,this.metaKey=e.metaKey,this.pointerId=e.pointerId||0,this.pointerType="string"===typeof e.pointerType?e.pointerType:G[e.pointerType]||"",this.state=e.state,this.i=e,e.defaultPrevented&&Z.$.h.call(this)}}_(Z,I);var G={2:"touch",3:"pen",4:"mouse"};Z.prototype.h=function(){Z.$.h.call(this);var e=this.i;e.preventDefault?e.preventDefault():e.returnValue=!1};var J="closure_listenable_"+(1e6*Math.random()|0),Q=0;function Y(e,t,n,r,i){this.listener=e,this.proxy=null,this.src=t,this.type=n,this.capture=!!r,this.la=i,this.key=++Q,this.fa=this.ia=!1}function X(e){e.fa=!0,e.listener=null,e.proxy=null,e.src=null,e.la=null}function ee(e,t,n){for(const r in e)t.call(n,e[r],r,e)}function te(e,t){for(const n in e)t.call(void 0,e[n],n,e)}function ne(e){const t={};for(const n in e)t[n]=e[n];return t}const re="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function ie(e,t){let n,r;for(let i=1;i<arguments.length;i++){for(n in r=arguments[i],r)e[n]=r[n];for(let t=0;t<re.length;t++)n=re[t],Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}}function oe(e){this.src=e,this.g={},this.h=0}function se(e,t){var n=t.type;if(n in e.g){var r,i=e.g[n],o=k(i,t);(r=0<=o)&&Array.prototype.splice.call(i,o,1),r&&(X(t),0==e.g[n].length&&(delete e.g[n],e.h--))}}function ae(e,t,n,r){for(var i=0;i<e.length;++i){var o=e[i];if(!o.fa&&o.listener==t&&o.capture==!!n&&o.la==r)return i}return-1}oe.prototype.add=function(e,t,n,r,i){var o=e.toString();e=this.g[o],e||(e=this.g[o]=[],this.h++);var s=ae(e,t,r,i);return-1<s?(t=e[s],n||(t.ia=!1)):(t=new Y(t,this.src,o,!!r,i),t.ia=n,e.push(t)),t};var le="closure_lm_"+(1e6*Math.random()|0),ue={};function ce(e,t,n,r,i){if(r&&r.once)return fe(e,t,n,r,i);if(Array.isArray(t)){for(var o=0;o<t.length;o++)ce(e,t[o],n,r,i);return null}return n=we(n),e&&e[J]?e.O(t,n,f(r)?!!r.capture:!!r,i):de(e,t,n,!1,r,i)}function de(e,t,n,r,i,o){if(!t)throw Error("Invalid event type");var s=f(i)?!!i.capture:!!i,a=ye(e);if(a||(e[le]=a=new oe(e)),n=a.add(t,n,r,s,o),n.proxy)return n;if(r=he(),n.proxy=r,r.src=e,r.listener=n,e.addEventListener)x||(i=s),void 0===i&&(i=!1),e.addEventListener(t.toString(),r,i);else if(e.attachEvent)e.attachEvent(me(t.toString()),r);else{if(!e.addListener||!e.removeListener)throw Error("addEventListener and attachEvent are unavailable.");e.addListener(r)}return n}function he(){function e(n){return t.call(e.src,e.listener,n)}const t=ve;return e}function fe(e,t,n,r,i){if(Array.isArray(t)){for(var o=0;o<t.length;o++)fe(e,t[o],n,r,i);return null}return n=we(n),e&&e[J]?e.P(t,n,f(r)?!!r.capture:!!r,i):de(e,t,n,!0,r,i)}function pe(e,t,n,r,i){if(Array.isArray(t))for(var o=0;o<t.length;o++)pe(e,t[o],n,r,i);else r=f(r)?!!r.capture:!!r,n=we(n),e&&e[J]?(e=e.i,t=String(t).toString(),t in e.g&&(o=e.g[t],n=ae(o,n,r,i),-1<n&&(X(o[n]),Array.prototype.splice.call(o,n,1),0==o.length&&(delete e.g[t],e.h--)))):e&&(e=ye(e))&&(t=e.g[t.toString()],e=-1,t&&(e=ae(t,n,r,i)),(n=-1<e?t[e]:null)&&ge(n))}function ge(e){if("number"!==typeof e&&e&&!e.fa){var t=e.src;if(t&&t[J])se(t.i,e);else{var n=e.type,r=e.proxy;t.removeEventListener?t.removeEventListener(n,r,e.capture):t.detachEvent?t.detachEvent(me(n),r):t.addListener&&t.removeListener&&t.removeListener(r),(n=ye(t))?(se(n,e),0==n.h&&(n.src=null,t[le]=null)):X(e)}}}function me(e){return e in ue?ue[e]:ue[e]="on"+e}function ve(e,t){if(e.fa)e=!0;else{t=new Z(t,this);var n=e.listener,r=e.la||e.src;e.ia&&ge(e),e=n.call(r,t)}return e}function ye(e){return e=e[le],e instanceof oe?e:null}var be="__closure_events_fn_"+(1e9*Math.random()>>>0);function we(e){return"function"===typeof e?e:(e[be]||(e[be]=function(t){return e.handleEvent(t)}),e[be])}function _e(){S.call(this),this.i=new oe(this),this.S=this,this.J=null}function Se(e,t){var n,r=e.J;if(r)for(n=[];r;r=r.J)n.push(r);if(e=e.S,r=t.type||t,"string"===typeof t)t=new I(t,e);else if(t instanceof I)t.target=t.target||e;else{var i=t;t=new I(r,e),ie(t,i)}if(i=!0,n)for(var o=n.length-1;0<=o;o--){var s=t.g=n[o];i=Ee(s,r,!0,t)&&i}if(s=t.g=e,i=Ee(s,r,!0,t)&&i,i=Ee(s,r,!1,t)&&i,n)for(o=0;o<n.length;o++)s=t.g=n[o],i=Ee(s,r,!1,t)&&i}function Ee(e,t,n,r){if(t=e.i.g[String(t)],!t)return!0;t=t.concat();for(var i=!0,o=0;o<t.length;++o){var s=t[o];if(s&&!s.fa&&s.capture==n){var a=s.listener,l=s.la||s.src;s.ia&&se(e.i,s),i=!1!==a.call(l,r)&&i}}return i&&!r.defaultPrevented}_(_e,S),_e.prototype[J]=!0,_e.prototype.removeEventListener=function(e,t,n,r){pe(this,e,t,n,r)},_e.prototype.N=function(){if(_e.$.N.call(this),this.i){var e,t=this.i;for(e in t.g){for(var n=t.g[e],r=0;r<n.length;r++)X(n[r]);delete t.g[e],t.h--}}this.J=null},_e.prototype.O=function(e,t,n,r){return this.i.add(String(e),t,!1,n,r)},_e.prototype.P=function(e,t,n,r){return this.i.add(String(e),t,!0,n,r)};var ke=d.JSON.stringify;class Te{constructor(e,t){this.i=e,this.j=t,this.h=0,this.g=null}get(){let e;return 0<this.h?(this.h--,e=this.g,this.g=e.next,e.next=null):e=this.i(),e}}function Ce(){var e=Fe;let t=null;return e.g&&(t=e.g,e.g=e.g.next,e.g||(e.h=null),t.next=null),t}class Ie{constructor(){this.h=this.g=null}add(e,t){const n=xe.get();n.set(e,t),this.h?this.h.next=n:this.g=n,this.h=n}}var xe=new Te((()=>new Ae),(e=>e.reset()));class Ae{constructor(){this.next=this.g=this.h=null}set(e,t){this.h=e,this.g=t,this.next=null}reset(){this.next=this.g=this.h=null}}function Re(e){var t=1;e=e.split(":");const n=[];for(;0<t&&e.length;)n.push(e.shift()),t--;return e.length&&n.push(e.join(":")),n}function Oe(e){d.setTimeout((()=>{throw e}),0)}let Ne,Pe=!1,Fe=new Ie,Le=()=>{const e=d.Promise.resolve(void 0);Ne=()=>{e.then(De)}};var De=()=>{for(var e;e=Ce();){try{e.h.call(e.g)}catch(n){Oe(n)}var t=xe;t.j(e),100>t.h&&(t.h++,e.next=t.g,t.g=e)}Pe=!1};function Me(e,t){_e.call(this),this.h=e||1,this.g=t||d,this.j=b(this.qb,this),this.l=Date.now()}function qe(e){e.ga=!1,e.T&&(e.g.clearTimeout(e.T),e.T=null)}function Ve(e,t,n){if("function"===typeof e)n&&(e=b(e,n));else{if(!e||"function"!=typeof e.handleEvent)throw Error("Invalid listener argument");e=b(e.handleEvent,e)}return 2147483647<Number(t)?-1:d.setTimeout(e,t||0)}function Ue(e){e.g=Ve((()=>{e.g=null,e.i&&(e.i=!1,Ue(e))}),e.j);const t=e.h;e.h=null,e.m.apply(null,t)}_(Me,_e),r=Me.prototype,r.ga=!1,r.T=null,r.qb=function(){if(this.ga){var e=Date.now()-this.l;0<e&&e<.8*this.h?this.T=this.g.setTimeout(this.j,this.h-e):(this.T&&(this.g.clearTimeout(this.T),this.T=null),Se(this,"tick"),this.ga&&(qe(this),this.start()))}},r.start=function(){this.ga=!0,this.T||(this.T=this.g.setTimeout(this.j,this.h),this.l=Date.now())},r.N=function(){Me.$.N.call(this),qe(this),delete this.g};class Be extends S{constructor(e,t){super(),this.m=e,this.j=t,this.h=null,this.i=!1,this.g=null}l(e){this.h=arguments,this.g?this.i=!0:Ue(this)}N(){super.N(),this.g&&(d.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function $e(e){S.call(this),this.h=e,this.g={}}_($e,S);var je=[];function ze(e,t,n,r){Array.isArray(n)||(n&&(je[0]=n.toString()),n=je);for(var i=0;i<n.length;i++){var o=ce(t,n[i],r||e.handleEvent,!1,e.h||e);if(!o)break;e.g[o.key]=o}}function He(e){ee(e.g,(function(e,t){this.g.hasOwnProperty(t)&&ge(e)}),e),e.g={}}function Ke(){this.g=!0}function We(e,t,n,r,i,o){e.info((function(){if(e.g)if(o)for(var s="",a=o.split("&"),l=0;l<a.length;l++){var u=a[l].split("=");if(1<u.length){var c=u[0];u=u[1];var d=c.split("_");s=2<=d.length&&"type"==d[1]?s+(c+"=")+u+"&":s+(c+"=redacted&")}}else s=null;else s=o;return"XMLHTTP REQ ("+r+") [attempt "+i+"]: "+t+"\n"+n+"\n"+s}))}function Ze(e,t,n,r,i,o,s){e.info((function(){return"XMLHTTP RESP ("+r+") [ attempt "+i+"]: "+t+"\n"+n+"\n"+o+" "+s}))}function Ge(e,t,n,r){e.info((function(){return"XMLHTTP TEXT ("+t+"): "+Qe(e,n)+(r?" "+r:"")}))}function Je(e,t){e.info((function(){return"TIMEOUT: "+t}))}function Qe(e,t){if(!e.g)return t;if(!t)return null;try{var n=JSON.parse(t);if(n)for(e=0;e<n.length;e++)if(Array.isArray(n[e])){var r=n[e];if(!(2>r.length)){var i=r[1];if(Array.isArray(i)&&!(1>i.length)){var o=i[0];if("noop"!=o&&"stop"!=o&&"close"!=o)for(var s=1;s<i.length;s++)i[s]=""}}}return ke(n)}catch(a){return t}}$e.prototype.N=function(){$e.$.N.call(this),He(this)},$e.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")},Ke.prototype.Ea=function(){this.g=!1},Ke.prototype.info=function(){};var Ye={},Xe=null;function et(){return Xe=Xe||new _e}function tt(e){I.call(this,Ye.Ta,e)}function nt(e){const t=et();Se(t,new tt(t))}function rt(e,t){I.call(this,Ye.STAT_EVENT,e),this.stat=t}function it(e){const t=et();Se(t,new rt(t,e))}function ot(e,t){I.call(this,Ye.Ua,e),this.size=t}function st(e,t){if("function"!==typeof e)throw Error("Fn must not be null and must be a function");return d.setTimeout((function(){e()}),t)}Ye.Ta="serverreachability",_(tt,I),Ye.STAT_EVENT="statevent",_(rt,I),Ye.Ua="timingevent",_(ot,I);var at={NO_ERROR:0,rb:1,Eb:2,Db:3,yb:4,Cb:5,Fb:6,Qa:7,TIMEOUT:8,Ib:9},lt={wb:"complete",Sb:"success",Ra:"error",Qa:"abort",Kb:"ready",Lb:"readystatechange",TIMEOUT:"timeout",Gb:"incrementaldata",Jb:"progress",zb:"downloadprogress",$b:"uploadprogress"};function ut(){}function ct(e){return e.h||(e.h=e.i())}function dt(){}ut.prototype.h=null;var ht,ft={OPEN:"a",vb:"b",Ra:"c",Hb:"d"};function pt(){I.call(this,"d")}function gt(){I.call(this,"c")}function mt(){}function vt(e,t,n,r){this.l=e,this.j=t,this.m=n,this.W=r||1,this.U=new $e(this),this.P=bt,e=V?125:void 0,this.V=new Me(e),this.I=null,this.i=!1,this.s=this.A=this.v=this.L=this.G=this.Y=this.B=null,this.F=[],this.g=null,this.C=0,this.o=this.u=null,this.ca=-1,this.J=!1,this.O=0,this.M=null,this.ba=this.K=this.aa=this.S=!1,this.h=new yt}function yt(){this.i=null,this.g="",this.h=!1}_(pt,I),_(gt,I),_(mt,ut),mt.prototype.g=function(){return new XMLHttpRequest},mt.prototype.i=function(){return{}},ht=new mt;var bt=45e3,wt={},_t={};function St(e,t,n){e.L=1,e.v=zt(Vt(t)),e.s=n,e.S=!0,Et(e,null)}function Et(e,t){e.G=Date.now(),It(e),e.A=Vt(e.v);var n=e.A,r=e.W;Array.isArray(r)||(r=[String(r)]),rn(n.i,"t",r),e.C=0,n=e.l.J,e.h=new yt,e.g=ur(e.l,n?t:null,!e.s),0<e.O&&(e.M=new Be(b(e.Pa,e,e.g),e.O)),ze(e.U,e.g,"readystatechange",e.nb),t=e.I?ne(e.I):{},e.s?(e.u||(e.u="POST"),t["Content-Type"]="application/x-www-form-urlencoded",e.g.ha(e.A,e.u,e.s,t)):(e.u="GET",e.g.ha(e.A,e.u,null,t)),nt(),We(e.j,e.u,e.A,e.m,e.W,e.s)}function kt(e){return!!e.g&&("GET"==e.u&&2!=e.L&&e.l.Ha)}function Tt(e,t,n){let r,i=!0;for(;!e.J&&e.C<n.length;){if(r=Ct(e,n),r==_t){4==t&&(e.o=4,it(14),i=!1),Ge(e.j,e.m,null,"[Incomplete Response]");break}if(r==wt){e.o=4,it(15),Ge(e.j,e.m,n,"[Invalid Chunk]"),i=!1;break}Ge(e.j,e.m,r,null),Nt(e,r)}kt(e)&&r!=_t&&r!=wt&&(e.h.g="",e.C=0),4!=t||0!=n.length||e.h.h||(e.o=1,it(16),i=!1),e.i=e.i&&i,i?0<n.length&&!e.ba&&(e.ba=!0,t=e.l,t.g==e&&t.ca&&!t.M&&(t.l.info("Great, no buffering proxy detected. Bytes received: "+n.length),tr(t),t.M=!0,it(11))):(Ge(e.j,e.m,n,"[Invalid Chunked Response]"),Ot(e),Rt(e))}function Ct(e,t){var n=e.C,r=t.indexOf("\n",n);return-1==r?_t:(n=Number(t.substring(n,r)),isNaN(n)?wt:(r+=1,r+n>t.length?_t:(t=t.slice(r,r+n),e.C=r+n,t)))}function It(e){e.Y=Date.now()+e.P,xt(e,e.P)}function xt(e,t){if(null!=e.B)throw Error("WatchDog timer not null");e.B=st(b(e.lb,e),t)}function At(e){e.B&&(d.clearTimeout(e.B),e.B=null)}function Rt(e){0==e.l.H||e.J||ir(e.l,e)}function Ot(e){At(e);var t=e.M;t&&"function"==typeof t.sa&&t.sa(),e.M=null,qe(e.V),He(e.U),e.g&&(t=e.g,e.g=null,t.abort(),t.sa())}function Nt(e,t){try{var n=e.l;if(0!=n.H&&(n.g==e||hn(n.i,e)))if(!e.K&&hn(n.i,e)&&3==n.H){try{var r=n.Ja.g.parse(t)}catch(u){r=null}if(Array.isArray(r)&&3==r.length){var i=r;if(0==i[0]){e:if(!n.u){if(n.g){if(!(n.g.G+3e3<e.G))break e;rr(n),Kn(n)}er(n),it(18)}}else n.Fa=i[1],0<n.Fa-n.V&&37500>i[2]&&n.G&&0==n.A&&!n.v&&(n.v=st(b(n.ib,n),6e3));if(1>=dn(n.i)&&n.oa){try{n.oa()}catch(u){}n.oa=void 0}}else sr(n,11)}else if((e.K||n.g==e)&&rr(n),!A(t))for(i=n.Ja.g.parse(t),t=0;t<i.length;t++){let u=i[t];if(n.V=u[0],u=u[1],2==n.H)if("c"==u[0]){n.K=u[1],n.pa=u[2];const t=u[3];null!=t&&(n.ra=t,n.l.info("VER="+n.ra));const i=u[4];null!=i&&(n.Ga=i,n.l.info("SVER="+n.Ga));const c=u[5];null!=c&&"number"===typeof c&&0<c&&(r=1.5*c,n.L=r,n.l.info("backChannelRequestTimeoutMs_="+r)),r=n;const d=e.g;if(d){const e=d.g?d.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(e){var o=r.i;o.g||-1==e.indexOf("spdy")&&-1==e.indexOf("quic")&&-1==e.indexOf("h2")||(o.j=o.l,o.g=new Set,o.h&&(fn(o,o.h),o.h=null))}if(r.F){const e=d.g?d.g.getResponseHeader("X-HTTP-Session-Id"):null;e&&(r.Da=e,jt(r.I,r.F,e))}}n.H=3,n.h&&n.h.Ba(),n.ca&&(n.S=Date.now()-e.G,n.l.info("Handshake RTT: "+n.S+"ms")),r=n;var s=e;if(r.wa=lr(r,r.J?r.pa:null,r.Y),s.K){pn(r.i,s);var a=s,l=r.L;l&&a.setTimeout(l),a.B&&(At(a),It(a)),r.g=s}else Xn(r);0<n.j.length&&Zn(n)}else"stop"!=u[0]&&"close"!=u[0]||sr(n,7);else 3==n.H&&("stop"==u[0]||"close"==u[0]?"stop"==u[0]?sr(n,7):Hn(n):"noop"!=u[0]&&n.h&&n.h.Aa(u),n.A=0)}nt(4)}catch(u){}}function Pt(e){if(e.Z&&"function"==typeof e.Z)return e.Z();if("undefined"!==typeof Map&&e instanceof Map||"undefined"!==typeof Set&&e instanceof Set)return Array.from(e.values());if("string"===typeof e)return e.split("");if(h(e)){for(var t=[],n=e.length,r=0;r<n;r++)t.push(e[r]);return t}for(r in t=[],n=0,e)t[n++]=e[r];return t}function Ft(e){if(e.ta&&"function"==typeof e.ta)return e.ta();if(!e.Z||"function"!=typeof e.Z){if("undefined"!==typeof Map&&e instanceof Map)return Array.from(e.keys());if(!("undefined"!==typeof Set&&e instanceof Set)){if(h(e)||"string"===typeof e){var t=[];e=e.length;for(var n=0;n<e;n++)t.push(n);return t}t=[],n=0;for(const r in e)t[n++]=r;return t}}}function Lt(e,t){if(e.forEach&&"function"==typeof e.forEach)e.forEach(t,void 0);else if(h(e)||"string"===typeof e)Array.prototype.forEach.call(e,t,void 0);else for(var n=Ft(e),r=Pt(e),i=r.length,o=0;o<i;o++)t.call(void 0,r[o],n&&n[o],e)}r=vt.prototype,r.setTimeout=function(e){this.P=e},r.nb=function(e){e=e.target;const t=this.M;t&&3==qn(e)?t.l():this.Pa(e)},r.Pa=function(e){try{if(e==this.g)e:{const c=qn(this.g);var t=this.g.Ia();const h=this.g.da();if(!(3>c)&&(3!=c||V||this.g&&(this.h.h||this.g.ja()||Vn(this.g)))){this.J||4!=c||7==t||nt(8==t||0>=h?3:2),At(this);var n=this.g.da();this.ca=n;t:if(kt(this)){var r=Vn(this.g);e="";var i=r.length,o=4==qn(this.g);if(!this.h.i){if("undefined"===typeof TextDecoder){Ot(this),Rt(this);var s="";break t}this.h.i=new d.TextDecoder}for(t=0;t<i;t++)this.h.h=!0,e+=this.h.i.decode(r[t],{stream:o&&t==i-1});r.splice(0,i),this.h.g+=e,this.C=0,s=this.h.g}else s=this.g.ja();if(this.i=200==n,Ze(this.j,this.u,this.A,this.m,this.W,c,n),this.i){if(this.aa&&!this.K){t:{if(this.g){var a,l=this.g;if((a=l.g?l.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!A(a)){var u=a;break t}}u=null}if(!(n=u)){this.i=!1,this.o=3,it(12),Ot(this),Rt(this);break e}Ge(this.j,this.m,n,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,Nt(this,n)}this.S?(Tt(this,c,s),V&&this.i&&3==c&&(ze(this.U,this.V,"tick",this.mb),this.V.start())):(Ge(this.j,this.m,s,null),Nt(this,s)),4==c&&Ot(this),this.i&&!this.J&&(4==c?ir(this.l,this):(this.i=!1,It(this)))}else Un(this.g),400==n&&0<s.indexOf("Unknown SID")?(this.o=3,it(12)):(this.o=0,it(13)),Ot(this),Rt(this)}}}catch(c){}},r.mb=function(){if(this.g){var e=qn(this.g),t=this.g.ja();this.C<t.length&&(At(this),Tt(this,e,t),this.i&&4!=e&&It(this))}},r.cancel=function(){this.J=!0,Ot(this)},r.lb=function(){this.B=null;const e=Date.now();0<=e-this.Y?(Je(this.j,this.A),2!=this.L&&(nt(),it(17)),Ot(this),this.o=2,Rt(this)):xt(this,this.Y-e)};var Dt=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Mt(e,t){if(e){e=e.split("&");for(var n=0;n<e.length;n++){var r=e[n].indexOf("="),i=null;if(0<=r){var o=e[n].substring(0,r);i=e[n].substring(r+1)}else o=e[n];t(o,i?decodeURIComponent(i.replace(/\+/g," ")):"")}}}function qt(e){if(this.g=this.s=this.j="",this.m=null,this.o=this.l="",this.h=!1,e instanceof qt){this.h=e.h,Ut(this,e.j),this.s=e.s,this.g=e.g,Bt(this,e.m),this.l=e.l;var t=e.i,n=new Xt;n.i=t.i,t.g&&(n.g=new Map(t.g),n.h=t.h),$t(this,n),this.o=e.o}else e&&(t=String(e).match(Dt))?(this.h=!1,Ut(this,t[1]||"",!0),this.s=Ht(t[2]||""),this.g=Ht(t[3]||"",!0),Bt(this,t[4]),this.l=Ht(t[5]||"",!0),$t(this,t[6]||"",!0),this.o=Ht(t[7]||"")):(this.h=!1,this.i=new Xt(null,this.h))}function Vt(e){return new qt(e)}function Ut(e,t,n){e.j=n?Ht(t,!0):t,e.j&&(e.j=e.j.replace(/:$/,""))}function Bt(e,t){if(t){if(t=Number(t),isNaN(t)||0>t)throw Error("Bad port number "+t);e.m=t}else e.m=null}function $t(e,t,n){t instanceof Xt?(e.i=t,sn(e.i,e.h)):(n||(t=Kt(t,Qt)),e.i=new Xt(t,e.h))}function jt(e,t,n){e.i.set(t,n)}function zt(e){return jt(e,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),e}function Ht(e,t){return e?t?decodeURI(e.replace(/%25/g,"%2525")):decodeURIComponent(e):""}function Kt(e,t,n){return"string"===typeof e?(e=encodeURI(e).replace(t,Wt),n&&(e=e.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),e):null}function Wt(e){return e=e.charCodeAt(0),"%"+(e>>4&15).toString(16)+(15&e).toString(16)}qt.prototype.toString=function(){var e=[],t=this.j;t&&e.push(Kt(t,Zt,!0),":");var n=this.g;return(n||"file"==t)&&(e.push("//"),(t=this.s)&&e.push(Kt(t,Zt,!0),"@"),e.push(encodeURIComponent(String(n)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),n=this.m,null!=n&&e.push(":",String(n))),(n=this.l)&&(this.g&&"/"!=n.charAt(0)&&e.push("/"),e.push(Kt(n,"/"==n.charAt(0)?Jt:Gt,!0))),(n=this.i.toString())&&e.push("?",n),(n=this.o)&&e.push("#",Kt(n,Yt)),e.join("")};var Zt=/[#\/\?@]/g,Gt=/[#\?:]/g,Jt=/[#\?]/g,Qt=/[#\?@]/g,Yt=/#/g;function Xt(e,t){this.h=this.g=null,this.i=e||null,this.j=!!t}function en(e){e.g||(e.g=new Map,e.h=0,e.i&&Mt(e.i,(function(t,n){e.add(decodeURIComponent(t.replace(/\+/g," ")),n)})))}function tn(e,t){en(e),t=on(e,t),e.g.has(t)&&(e.i=null,e.h-=e.g.get(t).length,e.g.delete(t))}function nn(e,t){return en(e),t=on(e,t),e.g.has(t)}function rn(e,t,n){tn(e,t),0<n.length&&(e.i=null,e.g.set(on(e,t),T(n)),e.h+=n.length)}function on(e,t){return t=String(t),e.j&&(t=t.toLowerCase()),t}function sn(e,t){t&&!e.j&&(en(e),e.i=null,e.g.forEach((function(e,t){var n=t.toLowerCase();t!=n&&(tn(this,t),rn(this,n,e))}),e)),e.j=t}r=Xt.prototype,r.add=function(e,t){en(this),this.i=null,e=on(this,e);var n=this.g.get(e);return n||this.g.set(e,n=[]),n.push(t),this.h+=1,this},r.forEach=function(e,t){en(this),this.g.forEach((function(n,r){n.forEach((function(n){e.call(t,n,r,this)}),this)}),this)},r.ta=function(){en(this);const e=Array.from(this.g.values()),t=Array.from(this.g.keys()),n=[];for(let r=0;r<t.length;r++){const i=e[r];for(let e=0;e<i.length;e++)n.push(t[r])}return n},r.Z=function(e){en(this);let t=[];if("string"===typeof e)nn(this,e)&&(t=t.concat(this.g.get(on(this,e))));else{e=Array.from(this.g.values());for(let n=0;n<e.length;n++)t=t.concat(e[n])}return t},r.set=function(e,t){return en(this),this.i=null,e=on(this,e),nn(this,e)&&(this.h-=this.g.get(e).length),this.g.set(e,[t]),this.h+=1,this},r.get=function(e,t){return e?(e=this.Z(e),0<e.length?String(e[0]):t):t},r.toString=function(){if(this.i)return this.i;if(!this.g)return"";const e=[],t=Array.from(this.g.keys());for(var n=0;n<t.length;n++){var r=t[n];const o=encodeURIComponent(String(r)),s=this.Z(r);for(r=0;r<s.length;r++){var i=o;""!==s[r]&&(i+="="+encodeURIComponent(String(s[r]))),e.push(i)}}return this.i=e.join("&")};var an=class{constructor(e,t){this.g=e,this.map=t}};function ln(e){this.l=e||un,d.PerformanceNavigationTiming?(e=d.performance.getEntriesByType("navigation"),e=0<e.length&&("hq"==e[0].nextHopProtocol||"h2"==e[0].nextHopProtocol)):e=!!(d.g&&d.g.Ka&&d.g.Ka()&&d.g.Ka().ec),this.j=e?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}var un=10;function cn(e){return!!e.h||!!e.g&&e.g.size>=e.j}function dn(e){return e.h?1:e.g?e.g.size:0}function hn(e,t){return e.h?e.h==t:!!e.g&&e.g.has(t)}function fn(e,t){e.g?e.g.add(t):e.h=t}function pn(e,t){e.h&&e.h==t?e.h=null:e.g&&e.g.has(t)&&e.g.delete(t)}function gn(e){if(null!=e.h)return e.i.concat(e.h.F);if(null!=e.g&&0!==e.g.size){let t=e.i;for(const n of e.g.values())t=t.concat(n.F);return t}return T(e.i)}ln.prototype.cancel=function(){if(this.i=gn(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&0!==this.g.size){for(const e of this.g.values())e.cancel();this.g.clear()}};var mn=class{stringify(e){return d.JSON.stringify(e,void 0)}parse(e){return d.JSON.parse(e,void 0)}};function vn(){this.g=new mn}function yn(e,t,n){const r=n||"";try{Lt(e,(function(e,n){let i=e;f(e)&&(i=ke(e)),t.push(r+n+"="+encodeURIComponent(i))}))}catch(i){throw t.push(r+"type="+encodeURIComponent("_badmap")),i}}function bn(e,t){const n=new Ke;if(d.Image){const r=new Image;r.onload=w(wn,n,r,"TestLoadImage: loaded",!0,t),r.onerror=w(wn,n,r,"TestLoadImage: error",!1,t),r.onabort=w(wn,n,r,"TestLoadImage: abort",!1,t),r.ontimeout=w(wn,n,r,"TestLoadImage: timeout",!1,t),d.setTimeout((function(){r.ontimeout&&r.ontimeout()}),1e4),r.src=e}else t(!1)}function wn(e,t,n,r,i){try{t.onload=null,t.onerror=null,t.onabort=null,t.ontimeout=null,i(r)}catch(o){}}function _n(e){this.l=e.fc||null,this.j=e.ob||!1}function Sn(e,t){_e.call(this),this.F=e,this.u=t,this.m=void 0,this.readyState=En,this.status=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.v=new Headers,this.h=null,this.C="GET",this.B="",this.g=!1,this.A=this.j=this.l=null}_(_n,ut),_n.prototype.g=function(){return new Sn(this.l,this.j)},_n.prototype.i=function(e){return function(){return e}}({}),_(Sn,_e);var En=0;function kn(e){e.j.read().then(e.Xa.bind(e)).catch(e.ka.bind(e))}function Tn(e){e.readyState=4,e.l=null,e.j=null,e.A=null,Cn(e)}function Cn(e){e.onreadystatechange&&e.onreadystatechange.call(e)}r=Sn.prototype,r.open=function(e,t){if(this.readyState!=En)throw this.abort(),Error("Error reopening a connection");this.C=e,this.B=t,this.readyState=1,Cn(this)},r.send=function(e){if(1!=this.readyState)throw this.abort(),Error("need to call open() first. ");this.g=!0;const t={headers:this.v,method:this.C,credentials:this.m,cache:void 0};e&&(t.body=e),(this.F||d).fetch(new Request(this.B,t)).then(this.$a.bind(this),this.ka.bind(this))},r.abort=function(){this.response=this.responseText="",this.v=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch((()=>{})),1<=this.readyState&&this.g&&4!=this.readyState&&(this.g=!1,Tn(this)),this.readyState=En},r.$a=function(e){if(this.g&&(this.l=e,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=e.headers,this.readyState=2,Cn(this)),this.g&&(this.readyState=3,Cn(this),this.g)))if("arraybuffer"===this.responseType)e.arrayBuffer().then(this.Ya.bind(this),this.ka.bind(this));else if("undefined"!==typeof d.ReadableStream&&"body"in e){if(this.j=e.body.getReader(),this.u){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.A=new TextDecoder;kn(this)}else e.text().then(this.Za.bind(this),this.ka.bind(this))},r.Xa=function(e){if(this.g){if(this.u&&e.value)this.response.push(e.value);else if(!this.u){var t=e.value?e.value:new Uint8Array(0);(t=this.A.decode(t,{stream:!e.done}))&&(this.response=this.responseText+=t)}e.done?Tn(this):Cn(this),3==this.readyState&&kn(this)}},r.Za=function(e){this.g&&(this.response=this.responseText=e,Tn(this))},r.Ya=function(e){this.g&&(this.response=e,Tn(this))},r.ka=function(){this.g&&Tn(this)},r.setRequestHeader=function(e,t){this.v.append(e,t)},r.getResponseHeader=function(e){return this.h&&this.h.get(e.toLowerCase())||""},r.getAllResponseHeaders=function(){if(!this.h)return"";const e=[],t=this.h.entries();for(var n=t.next();!n.done;)n=n.value,e.push(n[0]+": "+n[1]),n=t.next();return e.join("\r\n")},Object.defineProperty(Sn.prototype,"withCredentials",{get:function(){return"include"===this.m},set:function(e){this.m=e?"include":"same-origin"}});var In=d.JSON.parse;function xn(e){_e.call(this),this.headers=new Map,this.u=e||null,this.h=!1,this.C=this.g=null,this.I="",this.m=0,this.j="",this.l=this.G=this.v=this.F=!1,this.B=0,this.A=null,this.K=An,this.L=this.M=!1}_(xn,_e);var An="",Rn=/^https?$/i,On=["POST","PUT"];function Nn(e){return M&&"number"===typeof e.timeout&&void 0!==e.ontimeout}function Pn(e,t){e.h=!1,e.g&&(e.l=!0,e.g.abort(),e.l=!1),e.j=t,e.m=5,Fn(e),Dn(e)}function Fn(e){e.F||(e.F=!0,Se(e,"complete"),Se(e,"error"))}function Ln(e){if(e.h&&"undefined"!=typeof c&&(!e.C[1]||4!=qn(e)||2!=e.da()))if(e.v&&4==qn(e))Ve(e.La,0,e);else if(Se(e,"readystatechange"),4==qn(e)){e.h=!1;try{const a=e.da();e:switch(a){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var t=!0;break e;default:t=!1}var n;if(!(n=t)){var r;if(r=0===a){var i=String(e.I).match(Dt)[1]||null;!i&&d.self&&d.self.location&&(i=d.self.location.protocol.slice(0,-1)),r=!Rn.test(i?i.toLowerCase():"")}n=r}if(n)Se(e,"complete"),Se(e,"success");else{e.m=6;try{var o=2<qn(e)?e.g.statusText:""}catch(s){o=""}e.j=o+" ["+e.da()+"]",Fn(e)}}finally{Dn(e)}}}function Dn(e,t){if(e.g){Mn(e);const r=e.g,i=e.C[0]?()=>{}:null;e.g=null,e.C=null,t||Se(e,"ready");try{r.onreadystatechange=i}catch(n){}}}function Mn(e){e.g&&e.L&&(e.g.ontimeout=null),e.A&&(d.clearTimeout(e.A),e.A=null)}function qn(e){return e.g?e.g.readyState:0}function Vn(e){try{if(!e.g)return null;if("response"in e.g)return e.g.response;switch(e.K){case An:case"text":return e.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in e.g)return e.g.mozResponseArrayBuffer}return null}catch(Zr){return null}}function Un(e){const t={};e=(e.g&&2<=qn(e)&&e.g.getAllResponseHeaders()||"").split("\r\n");for(let r=0;r<e.length;r++){if(A(e[r]))continue;var n=Re(e[r]);const i=n[0];if(n=n[1],"string"!==typeof n)continue;n=n.trim();const o=t[i]||[];t[i]=o,o.push(n)}te(t,(function(e){return e.join(", ")}))}function Bn(e){let t="";return ee(e,(function(e,n){t+=n,t+=":",t+=e,t+="\r\n"})),t}function $n(e,t,n){e:{for(r in n){var r=!1;break e}r=!0}r||(n=Bn(n),"string"===typeof e?null!=n&&encodeURIComponent(String(n)):jt(e,t,n))}function jn(e,t,n){return n&&n.internalChannelParams&&n.internalChannelParams[e]||t}function zn(e){this.Ga=0,this.j=[],this.l=new Ke,this.pa=this.wa=this.I=this.Y=this.g=this.Da=this.F=this.na=this.o=this.U=this.s=null,this.fb=this.W=0,this.cb=jn("failFast",!1,e),this.G=this.v=this.u=this.m=this.h=null,this.aa=!0,this.Fa=this.V=-1,this.ba=this.A=this.C=0,this.ab=jn("baseRetryDelayMs",5e3,e),this.hb=jn("retryDelaySeedMs",1e4,e),this.eb=jn("forwardChannelMaxRetries",2,e),this.xa=jn("forwardChannelRequestTimeoutMs",2e4,e),this.va=e&&e.xmlHttpFactory||void 0,this.Ha=e&&e.dc||!1,this.L=void 0,this.J=e&&e.supportsCrossDomainXhr||!1,this.K="",this.i=new ln(e&&e.concurrentRequestLimit),this.Ja=new vn,this.P=e&&e.fastHandshake||!1,this.O=e&&e.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.bb=e&&e.bc||!1,e&&e.Ea&&this.l.Ea(),e&&e.forceLongPolling&&(this.aa=!1),this.ca=!this.P&&this.aa&&e&&e.detectBufferingProxy||!1,this.qa=void 0,e&&e.longPollingTimeout&&0<e.longPollingTimeout&&(this.qa=e.longPollingTimeout),this.oa=void 0,this.S=0,this.M=!1,this.ma=this.B=null}function Hn(e){if(Wn(e),3==e.H){var t=e.W++,n=Vt(e.I);if(jt(n,"SID",e.K),jt(n,"RID",t),jt(n,"TYPE","terminate"),Qn(e,n),t=new vt(e,e.l,t),t.L=2,t.v=zt(Vt(n)),n=!1,d.navigator&&d.navigator.sendBeacon)try{n=d.navigator.sendBeacon(t.v.toString(),"")}catch(r){}!n&&d.Image&&((new Image).src=t.v,n=!0),n||(t.g=ur(t.l,null),t.g.ha(t.v)),t.G=Date.now(),It(t)}ar(e)}function Kn(e){e.g&&(tr(e),e.g.cancel(),e.g=null)}function Wn(e){Kn(e),e.u&&(d.clearTimeout(e.u),e.u=null),rr(e),e.i.cancel(),e.m&&("number"===typeof e.m&&d.clearTimeout(e.m),e.m=null)}function Zn(e){if(!cn(e.i)&&!e.m){e.m=!0;var t=e.Na;Ne||Le(),Pe||(Ne(),Pe=!0),Fe.add(t,e),e.C=0}}function Gn(e,t){return!(dn(e.i)>=e.i.j-(e.m?1:0))&&(e.m?(e.j=t.F.concat(e.j),!0):!(1==e.H||2==e.H||e.C>=(e.cb?0:e.eb))&&(e.m=st(b(e.Na,e,t),or(e,e.C)),e.C++,!0))}function Jn(e,t){var n;n=t?t.m:e.W++;const r=Vt(e.I);jt(r,"SID",e.K),jt(r,"RID",n),jt(r,"AID",e.V),Qn(e,r),e.o&&e.s&&$n(r,e.o,e.s),n=new vt(e,e.l,n,e.C+1),null===e.o&&(n.I=e.s),t&&(e.j=t.F.concat(e.j)),t=Yn(e,n,1e3),n.setTimeout(Math.round(.5*e.xa)+Math.round(.5*e.xa*Math.random())),fn(e.i,n),St(n,r,t)}function Qn(e,t){e.na&&ee(e.na,(function(e,n){jt(t,n,e)})),e.h&&Lt({},(function(e,n){jt(t,n,e)}))}function Yn(e,t,n){n=Math.min(e.j.length,n);var r=e.h?b(e.h.Va,e.h,e):null;e:{var i=e.j;let t=-1;for(;;){const e=["count="+n];-1==t?0<n?(t=i[0].g,e.push("ofs="+t)):t=0:e.push("ofs="+t);let o=!0;for(let s=0;s<n;s++){let n=i[s].g;const a=i[s].map;if(n-=t,0>n)t=Math.max(0,i[s].g-100),o=!1;else try{yn(a,e,"req"+n+"_")}catch(oi){r&&r(a)}}if(o){r=e.join("&");break e}}}return e=e.j.splice(0,n),t.F=e,r}function Xn(e){if(!e.g&&!e.u){e.ba=1;var t=e.Ma;Ne||Le(),Pe||(Ne(),Pe=!0),Fe.add(t,e),e.A=0}}function er(e){return!(e.g||e.u||3<=e.A)&&(e.ba++,e.u=st(b(e.Ma,e),or(e,e.A)),e.A++,!0)}function tr(e){null!=e.B&&(d.clearTimeout(e.B),e.B=null)}function nr(e){e.g=new vt(e,e.l,"rpc",e.ba),null===e.o&&(e.g.I=e.s),e.g.O=0;var t=Vt(e.wa);jt(t,"RID","rpc"),jt(t,"SID",e.K),jt(t,"AID",e.V),jt(t,"CI",e.G?"0":"1"),!e.G&&e.qa&&jt(t,"TO",e.qa),jt(t,"TYPE","xmlhttp"),Qn(e,t),e.o&&e.s&&$n(t,e.o,e.s),e.L&&e.g.setTimeout(e.L);var n=e.g;e=e.pa,n.L=1,n.v=zt(Vt(t)),n.s=null,n.S=!0,Et(n,e)}function rr(e){null!=e.v&&(d.clearTimeout(e.v),e.v=null)}function ir(e,t){var n=null;if(e.g==t){rr(e),tr(e),e.g=null;var r=2}else{if(!hn(e.i,t))return;n=t.F,pn(e.i,t),r=1}if(0!=e.H)if(t.i)if(1==r){n=t.s?t.s.length:0,t=Date.now()-t.G;var i=e.C;r=et(),Se(r,new ot(r,n)),Zn(e)}else Xn(e);else if(i=t.o,3==i||0==i&&0<t.ca||!(1==r&&Gn(e,t)||2==r&&er(e)))switch(n&&0<n.length&&(t=e.i,t.i=t.i.concat(n)),i){case 1:sr(e,5);break;case 4:sr(e,10);break;case 3:sr(e,6);break;default:sr(e,2)}}function or(e,t){let n=e.ab+Math.floor(Math.random()*e.hb);return e.isActive()||(n*=2),n*t}function sr(e,t){if(e.l.info("Error code "+t),2==t){var n=null;e.h&&(n=null);var r=b(e.pb,e);n||(n=new qt("//www.google.com/images/cleardot.gif"),d.location&&"http"==d.location.protocol||Ut(n,"https"),zt(n)),bn(n.toString(),r)}else it(2);e.H=0,e.h&&e.h.za(t),ar(e),Wn(e)}function ar(e){if(e.H=0,e.ma=[],e.h){const t=gn(e.i);0==t.length&&0==e.j.length||(C(e.ma,t),C(e.ma,e.j),e.i.i.length=0,T(e.j),e.j.length=0),e.h.ya()}}function lr(e,t,n){var r=n instanceof qt?Vt(n):new qt(n);if(""!=r.g)t&&(r.g=t+"."+r.g),Bt(r,r.m);else{var i=d.location;r=i.protocol,t=t?t+"."+i.hostname:i.hostname,i=+i.port;var o=new qt(null);r&&Ut(o,r),t&&(o.g=t),i&&Bt(o,i),n&&(o.l=n),r=o}return n=e.F,t=e.Da,n&&t&&jt(r,n,t),jt(r,"VER",e.ra),Qn(e,r),r}function ur(e,t,n){if(t&&!e.J)throw Error("Can't create secondary domain capable XhrIo object.");return t=n&&e.Ha&&!e.va?new xn(new _n({ob:!0})):new xn(e.va),t.Oa(e.J),t}function cr(){}function dr(){if(M&&!(10<=Number(W)))throw Error("Environmental error: no available transport.")}function hr(e,t){_e.call(this),this.g=new zn(t),this.l=e,this.h=t&&t.messageUrlParams||null,e=t&&t.messageHeaders||null,t&&t.clientProtocolHeaderRequired&&(e?e["X-Client-Protocol"]="webchannel":e={"X-Client-Protocol":"webchannel"}),this.g.s=e,e=t&&t.initMessageHeaders||null,t&&t.messageContentType&&(e?e["X-WebChannel-Content-Type"]=t.messageContentType:e={"X-WebChannel-Content-Type":t.messageContentType}),t&&t.Ca&&(e?e["X-WebChannel-Client-Profile"]=t.Ca:e={"X-WebChannel-Client-Profile":t.Ca}),this.g.U=e,(e=t&&t.cc)&&!A(e)&&(this.g.o=e),this.A=t&&t.supportsCrossDomainXhr||!1,this.v=t&&t.sendRawJson||!1,(t=t&&t.httpSessionIdParam)&&!A(t)&&(this.g.F=t,e=this.h,null!==e&&t in e&&(e=this.h,t in e&&delete e[t])),this.j=new gr(this)}function fr(e){pt.call(this),e.__headers__&&(this.headers=e.__headers__,this.statusCode=e.__status__,delete e.__headers__,delete e.__status__);var t=e.__sm__;if(t){e:{for(const n in t){e=n;break e}e=void 0}(this.i=e)&&(e=this.i,t=null!==t&&e in t?t[e]:void 0),this.data=t}else this.data=e}function pr(){gt.call(this),this.status=1}function gr(e){this.g=e}function mr(){this.blockSize=-1}function vr(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.m=Array(this.blockSize),this.i=this.h=0,this.reset()}function yr(e,t,n){n||(n=0);var r=Array(16);if("string"===typeof t)for(var i=0;16>i;++i)r[i]=t.charCodeAt(n++)|t.charCodeAt(n++)<<8|t.charCodeAt(n++)<<16|t.charCodeAt(n++)<<24;else for(i=0;16>i;++i)r[i]=t[n++]|t[n++]<<8|t[n++]<<16|t[n++]<<24;t=e.g[0],n=e.g[1],i=e.g[2];var o=e.g[3],s=t+(o^n&(i^o))+r[0]+3614090360&4294967295;t=n+(s<<7&4294967295|s>>>25),s=o+(i^t&(n^i))+r[1]+3905402710&4294967295,o=t+(s<<12&4294967295|s>>>20),s=i+(n^o&(t^n))+r[2]+606105819&4294967295,i=o+(s<<17&4294967295|s>>>15),s=n+(t^i&(o^t))+r[3]+3250441966&4294967295,n=i+(s<<22&4294967295|s>>>10),s=t+(o^n&(i^o))+r[4]+4118548399&4294967295,t=n+(s<<7&4294967295|s>>>25),s=o+(i^t&(n^i))+r[5]+1200080426&4294967295,o=t+(s<<12&4294967295|s>>>20),s=i+(n^o&(t^n))+r[6]+2821735955&4294967295,i=o+(s<<17&4294967295|s>>>15),s=n+(t^i&(o^t))+r[7]+4249261313&4294967295,n=i+(s<<22&4294967295|s>>>10),s=t+(o^n&(i^o))+r[8]+1770035416&4294967295,t=n+(s<<7&4294967295|s>>>25),s=o+(i^t&(n^i))+r[9]+2336552879&4294967295,o=t+(s<<12&4294967295|s>>>20),s=i+(n^o&(t^n))+r[10]+4294925233&4294967295,i=o+(s<<17&4294967295|s>>>15),s=n+(t^i&(o^t))+r[11]+2304563134&4294967295,n=i+(s<<22&4294967295|s>>>10),s=t+(o^n&(i^o))+r[12]+1804603682&4294967295,t=n+(s<<7&4294967295|s>>>25),s=o+(i^t&(n^i))+r[13]+4254626195&4294967295,o=t+(s<<12&4294967295|s>>>20),s=i+(n^o&(t^n))+r[14]+2792965006&4294967295,i=o+(s<<17&4294967295|s>>>15),s=n+(t^i&(o^t))+r[15]+1236535329&4294967295,n=i+(s<<22&4294967295|s>>>10),s=t+(i^o&(n^i))+r[1]+4129170786&4294967295,t=n+(s<<5&4294967295|s>>>27),s=o+(n^i&(t^n))+r[6]+3225465664&4294967295,o=t+(s<<9&4294967295|s>>>23),s=i+(t^n&(o^t))+r[11]+643717713&4294967295,i=o+(s<<14&4294967295|s>>>18),s=n+(o^t&(i^o))+r[0]+3921069994&4294967295,n=i+(s<<20&4294967295|s>>>12),s=t+(i^o&(n^i))+r[5]+3593408605&4294967295,t=n+(s<<5&4294967295|s>>>27),s=o+(n^i&(t^n))+r[10]+38016083&4294967295,o=t+(s<<9&4294967295|s>>>23),s=i+(t^n&(o^t))+r[15]+3634488961&4294967295,i=o+(s<<14&4294967295|s>>>18),s=n+(o^t&(i^o))+r[4]+3889429448&4294967295,n=i+(s<<20&4294967295|s>>>12),s=t+(i^o&(n^i))+r[9]+568446438&4294967295,t=n+(s<<5&4294967295|s>>>27),s=o+(n^i&(t^n))+r[14]+3275163606&4294967295,o=t+(s<<9&4294967295|s>>>23),s=i+(t^n&(o^t))+r[3]+4107603335&4294967295,i=o+(s<<14&4294967295|s>>>18),s=n+(o^t&(i^o))+r[8]+1163531501&4294967295,n=i+(s<<20&4294967295|s>>>12),s=t+(i^o&(n^i))+r[13]+2850285829&4294967295,t=n+(s<<5&4294967295|s>>>27),s=o+(n^i&(t^n))+r[2]+4243563512&4294967295,o=t+(s<<9&4294967295|s>>>23),s=i+(t^n&(o^t))+r[7]+1735328473&4294967295,i=o+(s<<14&4294967295|s>>>18),s=n+(o^t&(i^o))+r[12]+2368359562&4294967295,n=i+(s<<20&4294967295|s>>>12),s=t+(n^i^o)+r[5]+4294588738&4294967295,t=n+(s<<4&4294967295|s>>>28),s=o+(t^n^i)+r[8]+2272392833&4294967295,o=t+(s<<11&4294967295|s>>>21),s=i+(o^t^n)+r[11]+1839030562&4294967295,i=o+(s<<16&4294967295|s>>>16),s=n+(i^o^t)+r[14]+4259657740&4294967295,n=i+(s<<23&4294967295|s>>>9),s=t+(n^i^o)+r[1]+2763975236&4294967295,t=n+(s<<4&4294967295|s>>>28),s=o+(t^n^i)+r[4]+1272893353&4294967295,o=t+(s<<11&4294967295|s>>>21),s=i+(o^t^n)+r[7]+4139469664&4294967295,i=o+(s<<16&4294967295|s>>>16),s=n+(i^o^t)+r[10]+3200236656&4294967295,n=i+(s<<23&4294967295|s>>>9),s=t+(n^i^o)+r[13]+681279174&4294967295,t=n+(s<<4&4294967295|s>>>28),s=o+(t^n^i)+r[0]+3936430074&4294967295,o=t+(s<<11&4294967295|s>>>21),s=i+(o^t^n)+r[3]+3572445317&4294967295,i=o+(s<<16&4294967295|s>>>16),s=n+(i^o^t)+r[6]+76029189&4294967295,n=i+(s<<23&4294967295|s>>>9),s=t+(n^i^o)+r[9]+3654602809&4294967295,t=n+(s<<4&4294967295|s>>>28),s=o+(t^n^i)+r[12]+3873151461&4294967295,o=t+(s<<11&4294967295|s>>>21),s=i+(o^t^n)+r[15]+530742520&4294967295,i=o+(s<<16&4294967295|s>>>16),s=n+(i^o^t)+r[2]+3299628645&4294967295,n=i+(s<<23&4294967295|s>>>9),s=t+(i^(n|~o))+r[0]+4096336452&4294967295,t=n+(s<<6&4294967295|s>>>26),s=o+(n^(t|~i))+r[7]+1126891415&4294967295,o=t+(s<<10&4294967295|s>>>22),s=i+(t^(o|~n))+r[14]+2878612391&4294967295,i=o+(s<<15&4294967295|s>>>17),s=n+(o^(i|~t))+r[5]+4237533241&4294967295,n=i+(s<<21&4294967295|s>>>11),s=t+(i^(n|~o))+r[12]+1700485571&4294967295,t=n+(s<<6&4294967295|s>>>26),s=o+(n^(t|~i))+r[3]+2399980690&4294967295,o=t+(s<<10&4294967295|s>>>22),s=i+(t^(o|~n))+r[10]+4293915773&4294967295,i=o+(s<<15&4294967295|s>>>17),s=n+(o^(i|~t))+r[1]+2240044497&4294967295,n=i+(s<<21&4294967295|s>>>11),s=t+(i^(n|~o))+r[8]+1873313359&4294967295,t=n+(s<<6&4294967295|s>>>26),s=o+(n^(t|~i))+r[15]+4264355552&4294967295,o=t+(s<<10&4294967295|s>>>22),s=i+(t^(o|~n))+r[6]+2734768916&4294967295,i=o+(s<<15&4294967295|s>>>17),s=n+(o^(i|~t))+r[13]+1309151649&4294967295,n=i+(s<<21&4294967295|s>>>11),s=t+(i^(n|~o))+r[4]+4149444226&4294967295,t=n+(s<<6&4294967295|s>>>26),s=o+(n^(t|~i))+r[11]+3174756917&4294967295,o=t+(s<<10&4294967295|s>>>22),s=i+(t^(o|~n))+r[2]+718787259&4294967295,i=o+(s<<15&4294967295|s>>>17),s=n+(o^(i|~t))+r[9]+3951481745&4294967295,e.g[0]=e.g[0]+t&4294967295,e.g[1]=e.g[1]+(i+(s<<21&4294967295|s>>>11))&4294967295,e.g[2]=e.g[2]+i&4294967295,e.g[3]=e.g[3]+o&4294967295}function br(e,t){this.h=t;for(var n=[],r=!0,i=e.length-1;0<=i;i--){var o=0|e[i];r&&o==t||(n[i]=o,r=!1)}this.g=n}r=xn.prototype,r.Oa=function(e){this.M=e},r.ha=function(e,t,n,r){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.I+"; newUri="+e);t=t?t.toUpperCase():"GET",this.I=e,this.j="",this.m=0,this.F=!1,this.h=!0,this.g=this.u?this.u.g():ht.g(),this.C=this.u?ct(this.u):ct(ht),this.g.onreadystatechange=b(this.La,this);try{this.G=!0,this.g.open(t,String(e),!0),this.G=!1}catch(o){return void Pn(this,o)}if(e=n||"",n=new Map(this.headers),r)if(Object.getPrototypeOf(r)===Object.prototype)for(var i in r)n.set(i,r[i]);else{if("function"!==typeof r.keys||"function"!==typeof r.get)throw Error("Unknown input type for opt_headers: "+String(r));for(const e of r.keys())n.set(e,r.get(e))}r=Array.from(n.keys()).find((e=>"content-type"==e.toLowerCase())),i=d.FormData&&e instanceof d.FormData,!(0<=k(On,t))||r||i||n.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[s,a]of n)this.g.setRequestHeader(s,a);this.K&&(this.g.responseType=this.K),"withCredentials"in this.g&&this.g.withCredentials!==this.M&&(this.g.withCredentials=this.M);try{Mn(this),0<this.B&&((this.L=Nn(this.g))?(this.g.timeout=this.B,this.g.ontimeout=b(this.ua,this)):this.A=Ve(this.ua,this.B,this)),this.v=!0,this.g.send(e),this.v=!1}catch(o){Pn(this,o)}},r.ua=function(){"undefined"!=typeof c&&this.g&&(this.j="Timed out after "+this.B+"ms, aborting",this.m=8,Se(this,"timeout"),this.abort(8))},r.abort=function(e){this.g&&this.h&&(this.h=!1,this.l=!0,this.g.abort(),this.l=!1,this.m=e||7,Se(this,"complete"),Se(this,"abort"),Dn(this))},r.N=function(){this.g&&(this.h&&(this.h=!1,this.l=!0,this.g.abort(),this.l=!1),Dn(this,!0)),xn.$.N.call(this)},r.La=function(){this.s||(this.G||this.v||this.l?Ln(this):this.kb())},r.kb=function(){Ln(this)},r.isActive=function(){return!!this.g},r.da=function(){try{return 2<qn(this)?this.g.status:-1}catch(e){return-1}},r.ja=function(){try{return this.g?this.g.responseText:""}catch(e){return""}},r.Wa=function(e){if(this.g){var t=this.g.responseText;return e&&0==t.indexOf(e)&&(t=t.substring(e.length)),In(t)}},r.Ia=function(){return this.m},r.Sa=function(){return"string"===typeof this.j?this.j:String(this.j)},r=zn.prototype,r.ra=8,r.H=1,r.Na=function(e){if(this.m)if(this.m=null,1==this.H){if(!e){this.W=Math.floor(1e5*Math.random()),e=this.W++;const i=new vt(this,this.l,e);let o=this.s;if(this.U&&(o?(o=ne(o),ie(o,this.U)):o=this.U),null!==this.o||this.O||(i.I=o,o=null),this.P)e:{for(var t=0,n=0;n<this.j.length;n++){var r=this.j[n];if(r="__data__"in r.map&&(r=r.map.__data__,"string"===typeof r)?r.length:void 0,void 0===r)break;if(t+=r,4096<t){t=n;break e}if(4096===t||n===this.j.length-1){t=n+1;break e}}t=1e3}else t=1e3;t=Yn(this,i,t),n=Vt(this.I),jt(n,"RID",e),jt(n,"CVER",22),this.F&&jt(n,"X-HTTP-Session-Id",this.F),Qn(this,n),o&&(this.O?t="headers="+encodeURIComponent(String(Bn(o)))+"&"+t:this.o&&$n(n,this.o,o)),fn(this.i,i),this.bb&&jt(n,"TYPE","init"),this.P?(jt(n,"$req",t),jt(n,"SID","null"),i.aa=!0,St(i,n,null)):St(i,n,t),this.H=2}}else 3==this.H&&(e?Jn(this,e):0==this.j.length||cn(this.i)||Jn(this))},r.Ma=function(){if(this.u=null,nr(this),this.ca&&!(this.M||null==this.g||0>=this.S)){var e=2*this.S;this.l.info("BP detection timer enabled: "+e),this.B=st(b(this.jb,this),e)}},r.jb=function(){this.B&&(this.B=null,this.l.info("BP detection timeout reached."),this.l.info("Buffering proxy detected and switch to long-polling!"),this.G=!1,this.M=!0,it(10),Kn(this),nr(this))},r.ib=function(){null!=this.v&&(this.v=null,Kn(this),er(this),it(19))},r.pb=function(e){e?(this.l.info("Successfully pinged google.com"),it(2)):(this.l.info("Failed to ping google.com"),it(1))},r.isActive=function(){return!!this.h&&this.h.isActive(this)},r=cr.prototype,r.Ba=function(){},r.Aa=function(){},r.za=function(){},r.ya=function(){},r.isActive=function(){return!0},r.Va=function(){},dr.prototype.g=function(e,t){return new hr(e,t)},_(hr,_e),hr.prototype.m=function(){this.g.h=this.j,this.A&&(this.g.J=!0);var e=this.g,t=this.l,n=this.h||void 0;it(0),e.Y=t,e.na=n||{},e.G=e.aa,e.I=lr(e,null,e.Y),Zn(e)},hr.prototype.close=function(){Hn(this.g)},hr.prototype.u=function(e){var t=this.g;if("string"===typeof e){var n={};n.__data__=e,e=n}else this.v&&(n={},n.__data__=ke(e),e=n);t.j.push(new an(t.fb++,e)),3==t.H&&Zn(t)},hr.prototype.N=function(){this.g.h=null,delete this.j,Hn(this.g),delete this.g,hr.$.N.call(this)},_(fr,pt),_(pr,gt),_(gr,cr),gr.prototype.Ba=function(){Se(this.g,"a")},gr.prototype.Aa=function(e){Se(this.g,new fr(e))},gr.prototype.za=function(e){Se(this.g,new pr)},gr.prototype.ya=function(){Se(this.g,"b")},_(vr,mr),vr.prototype.reset=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.i=this.h=0},vr.prototype.j=function(e,t){void 0===t&&(t=e.length);for(var n=t-this.blockSize,r=this.m,i=this.h,o=0;o<t;){if(0==i)for(;o<=n;)yr(this,e,o),o+=this.blockSize;if("string"===typeof e){for(;o<t;)if(r[i++]=e.charCodeAt(o++),i==this.blockSize){yr(this,r),i=0;break}}else for(;o<t;)if(r[i++]=e[o++],i==this.blockSize){yr(this,r),i=0;break}}this.h=i,this.i+=t},vr.prototype.l=function(){var e=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);e[0]=128;for(var t=1;t<e.length-8;++t)e[t]=0;var n=8*this.i;for(t=e.length-8;t<e.length;++t)e[t]=255&n,n/=256;for(this.j(e),e=Array(16),t=n=0;4>t;++t)for(var r=0;32>r;r+=8)e[n++]=this.g[t]>>>r&255;return e};var wr={};function _r(e){return-128<=e&&128>e?P(e,(function(e){return new br([0|e],0>e?-1:0)})):new br([0|e],0>e?-1:0)}function Sr(e){if(isNaN(e)||!isFinite(e))return Tr;if(0>e)return Rr(Sr(-e));for(var t=[],n=1,r=0;e>=n;r++)t[r]=e/n|0,n*=kr;return new br(t,0)}function Er(e,t){if(0==e.length)throw Error("number format error: empty string");if(t=t||10,2>t||36<t)throw Error("radix out of range: "+t);if("-"==e.charAt(0))return Rr(Er(e.substring(1),t));if(0<=e.indexOf("-"))throw Error('number format error: interior "-" character');for(var n=Sr(Math.pow(t,8)),r=Tr,i=0;i<e.length;i+=8){var o=Math.min(8,e.length-i),s=parseInt(e.substring(i,i+o),t);8>o?(o=Sr(Math.pow(t,o)),r=r.R(o).add(Sr(s))):(r=r.R(n),r=r.add(Sr(s)))}return r}var kr=4294967296,Tr=_r(0),Cr=_r(1),Ir=_r(16777216);function xr(e){if(0!=e.h)return!1;for(var t=0;t<e.g.length;t++)if(0!=e.g[t])return!1;return!0}function Ar(e){return-1==e.h}function Rr(e){for(var t=e.g.length,n=[],r=0;r<t;r++)n[r]=~e.g[r];return new br(n,~e.h).add(Cr)}function Or(e,t){return e.add(Rr(t))}function Nr(e,t){for(;(65535&e[t])!=e[t];)e[t+1]+=e[t]>>>16,e[t]&=65535,t++}function Pr(e,t){this.g=e,this.h=t}function Fr(e,t){if(xr(t))throw Error("division by zero");if(xr(e))return new Pr(Tr,Tr);if(Ar(e))return t=Fr(Rr(e),t),new Pr(Rr(t.g),Rr(t.h));if(Ar(t))return t=Fr(e,Rr(t)),new Pr(Rr(t.g),t.h);if(30<e.g.length){if(Ar(e)||Ar(t))throw Error("slowDivide_ only works with positive integers.");for(var n=Cr,r=t;0>=r.X(e);)n=Lr(n),r=Lr(r);var i=Dr(n,1),o=Dr(r,1);for(r=Dr(r,2),n=Dr(n,2);!xr(r);){var s=o.add(r);0>=s.X(e)&&(i=i.add(n),o=s),r=Dr(r,1),n=Dr(n,1)}return t=Or(e,i.R(t)),new Pr(i,t)}for(i=Tr;0<=e.X(t);){for(n=Math.max(1,Math.floor(e.ea()/t.ea())),r=Math.ceil(Math.log(n)/Math.LN2),r=48>=r?1:Math.pow(2,r-48),o=Sr(n),s=o.R(t);Ar(s)||0<s.X(e);)n-=r,o=Sr(n),s=o.R(t);xr(o)&&(o=Cr),i=i.add(o),e=Or(e,s)}return new Pr(i,e)}function Lr(e){for(var t=e.g.length+1,n=[],r=0;r<t;r++)n[r]=e.D(r)<<1|e.D(r-1)>>>31;return new br(n,e.h)}function Dr(e,t){var n=t>>5;t%=32;for(var r=e.g.length-n,i=[],o=0;o<r;o++)i[o]=0<t?e.D(o+n)>>>t|e.D(o+n+1)<<32-t:e.D(o+n);return new br(i,e.h)}r=br.prototype,r.ea=function(){if(Ar(this))return-Rr(this).ea();for(var e=0,t=1,n=0;n<this.g.length;n++){var r=this.D(n);e+=(0<=r?r:kr+r)*t,t*=kr}return e},r.toString=function(e){if(e=e||10,2>e||36<e)throw Error("radix out of range: "+e);if(xr(this))return"0";if(Ar(this))return"-"+Rr(this).toString(e);for(var t=Sr(Math.pow(e,6)),n=this,r="";;){var i=Fr(n,t).g;n=Or(n,i.R(t));var o=((0<n.g.length?n.g[0]:n.h)>>>0).toString(e);if(n=i,xr(n))return o+r;for(;6>o.length;)o="0"+o;r=o+r}},r.D=function(e){return 0>e?0:e<this.g.length?this.g[e]:this.h},r.X=function(e){return e=Or(this,e),Ar(e)?-1:xr(e)?0:1},r.abs=function(){return Ar(this)?Rr(this):this},r.add=function(e){for(var t=Math.max(this.g.length,e.g.length),n=[],r=0,i=0;i<=t;i++){var o=r+(65535&this.D(i))+(65535&e.D(i)),s=(o>>>16)+(this.D(i)>>>16)+(e.D(i)>>>16);r=s>>>16,o&=65535,s&=65535,n[i]=s<<16|o}return new br(n,-2147483648&n[n.length-1]?-1:0)},r.R=function(e){if(xr(this)||xr(e))return Tr;if(Ar(this))return Ar(e)?Rr(this).R(Rr(e)):Rr(Rr(this).R(e));if(Ar(e))return Rr(this.R(Rr(e)));if(0>this.X(Ir)&&0>e.X(Ir))return Sr(this.ea()*e.ea());for(var t=this.g.length+e.g.length,n=[],r=0;r<2*t;r++)n[r]=0;for(r=0;r<this.g.length;r++)for(var i=0;i<e.g.length;i++){var o=this.D(r)>>>16,s=65535&this.D(r),a=e.D(i)>>>16,l=65535&e.D(i);n[2*r+2*i]+=s*l,Nr(n,2*r+2*i),n[2*r+2*i+1]+=o*l,Nr(n,2*r+2*i+1),n[2*r+2*i+1]+=s*a,Nr(n,2*r+2*i+1),n[2*r+2*i+2]+=o*a,Nr(n,2*r+2*i+2)}for(r=0;r<t;r++)n[r]=n[2*r+1]<<16|n[2*r];for(r=t;r<2*t;r++)n[r]=0;return new br(n,0)},r.gb=function(e){return Fr(this,e).h},r.and=function(e){for(var t=Math.max(this.g.length,e.g.length),n=[],r=0;r<t;r++)n[r]=this.D(r)&e.D(r);return new br(n,this.h&e.h)},r.or=function(e){for(var t=Math.max(this.g.length,e.g.length),n=[],r=0;r<t;r++)n[r]=this.D(r)|e.D(r);return new br(n,this.h|e.h)},r.xor=function(e){for(var t=Math.max(this.g.length,e.g.length),n=[],r=0;r<t;r++)n[r]=this.D(r)^e.D(r);return new br(n,this.h^e.h)},dr.prototype.createWebChannel=dr.prototype.g,hr.prototype.send=hr.prototype.u,hr.prototype.open=hr.prototype.m,hr.prototype.close=hr.prototype.close,at.NO_ERROR=0,at.TIMEOUT=8,at.HTTP_ERROR=6,lt.COMPLETE="complete",dt.EventType=ft,ft.OPEN="a",ft.CLOSE="b",ft.ERROR="c",ft.MESSAGE="d",_e.prototype.listen=_e.prototype.O,xn.prototype.listenOnce=xn.prototype.P,xn.prototype.getLastError=xn.prototype.Sa,xn.prototype.getLastErrorCode=xn.prototype.Ia,xn.prototype.getStatus=xn.prototype.da,xn.prototype.getResponseJson=xn.prototype.Wa,xn.prototype.getResponseText=xn.prototype.ja,xn.prototype.send=xn.prototype.ha,xn.prototype.setWithCredentials=xn.prototype.Oa,vr.prototype.digest=vr.prototype.l,vr.prototype.reset=vr.prototype.reset,vr.prototype.update=vr.prototype.j,br.prototype.add=br.prototype.add,br.prototype.multiply=br.prototype.R,br.prototype.modulo=br.prototype.gb,br.prototype.compare=br.prototype.X,br.prototype.toNumber=br.prototype.ea,br.prototype.toString=br.prototype.toString,br.prototype.getBits=br.prototype.D,br.fromNumber=Sr,br.fromString=Er;var Mr=u.createWebChannelTransport=function(){return new dr},qr=u.getStatEventTarget=function(){return et()},Vr=u.ErrorCode=at,Ur=u.EventType=lt,Br=u.Event=Ye,$r=u.Stat={xb:0,Ab:1,Bb:2,Ub:3,Zb:4,Wb:5,Xb:6,Vb:7,Tb:8,Yb:9,PROXY:10,NOPROXY:11,Rb:12,Nb:13,Ob:14,Mb:15,Pb:16,Qb:17,tb:18,sb:19,ub:20},jr=u.FetchXmlHttpFactory=_n,zr=u.WebChannel=dt,Hr=u.XhrIo=xn,Kr=u.Md5=vr,Wr=u.Integer=br;const Zr="@firebase/firestore";
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gr{constructor(e){this.uid=e}isAuthenticated(){return null!=this.uid}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}Gr.UNAUTHENTICATED=new Gr(null),Gr.GOOGLE_CREDENTIALS=new Gr("google-credentials-uid"),Gr.FIRST_PARTY=new Gr("first-party-uid"),Gr.MOCK_USER=new Gr("mock-user");
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jr="9.22.2";
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qr=new s.Yd("@firebase/firestore");function Yr(){return Qr.logLevel}function Xr(e,...t){if(Qr.logLevel<=s["in"].DEBUG){const n=t.map(ni);Qr.debug(`Firestore (${Jr}): ${e}`,...n)}}function ei(e,...t){if(Qr.logLevel<=s["in"].ERROR){const n=t.map(ni);Qr.error(`Firestore (${Jr}): ${e}`,...n)}}function ti(e,...t){if(Qr.logLevel<=s["in"].WARN){const n=t.map(ni);Qr.warn(`Firestore (${Jr}): ${e}`,...n)}}function ni(e){if("string"==typeof e)return e;try{return t=e,JSON.stringify(t)}catch(t){return e}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ri(e="Unexpected state"){const t=`FIRESTORE (${Jr}) INTERNAL ASSERTION FAILED: `+e;throw ei(t),new Error(t)}function ii(e,t){e||ri()}function oi(e,t){return e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const si={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class ai extends a.ZR{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class li{constructor(){this.promise=new Promise(((e,t)=>{this.resolve=e,this.reject=t}))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ui{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class ci{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable((()=>t(Gr.UNAUTHENTICATED)))}shutdown(){}}class di{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable((()=>t(this.token.user)))}shutdown(){this.changeListener=null}}class hi{constructor(e){this.t=e,this.currentUser=Gr.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){let n=this.i;const r=e=>this.i!==n?(n=this.i,t(e)):Promise.resolve();let i=new li;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new li,e.enqueueRetryable((()=>r(this.currentUser)))};const o=()=>{const t=i;e.enqueueRetryable((async()=>{await t.promise,await r(this.currentUser)}))},s=e=>{Xr("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=e,this.auth.addAuthTokenListener(this.o),o()};this.t.onInit((e=>s(e))),setTimeout((()=>{if(!this.auth){const e=this.t.getImmediate({optional:!0});e?s(e):(Xr("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new li)}}),0),o()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then((t=>this.i!==e?(Xr("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):t?(ii("string"==typeof t.accessToken),new ui(t.accessToken,this.currentUser)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){const e=this.auth&&this.auth.getUid();return ii(null===e||"string"==typeof e),new Gr(e)}}class fi{constructor(e,t,n){this.h=e,this.l=t,this.m=n,this.type="FirstParty",this.user=Gr.FIRST_PARTY,this.g=new Map}p(){return this.m?this.m():null}get headers(){this.g.set("X-Goog-AuthUser",this.h);const e=this.p();return e&&this.g.set("Authorization",e),this.l&&this.g.set("X-Goog-Iam-Authorization-Token",this.l),this.g}}class pi{constructor(e,t,n){this.h=e,this.l=t,this.m=n}getToken(){return Promise.resolve(new fi(this.h,this.l,this.m))}start(e,t){e.enqueueRetryable((()=>t(Gr.FIRST_PARTY)))}shutdown(){}invalidateToken(){}}class gi{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class mi{constructor(e){this.I=e,this.forceRefresh=!1,this.appCheck=null,this.T=null}start(e,t){const n=e=>{null!=e.error&&Xr("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${e.error.message}`);const n=e.token!==this.T;return this.T=e.token,Xr("FirebaseAppCheckTokenProvider",`Received ${n?"new":"existing"} token.`),n?t(e.token):Promise.resolve()};this.o=t=>{e.enqueueRetryable((()=>n(t)))};const r=e=>{Xr("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=e,this.appCheck.addTokenListener(this.o)};this.I.onInit((e=>r(e))),setTimeout((()=>{if(!this.appCheck){const e=this.I.getImmediate({optional:!0});e?r(e):Xr("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}}),0)}getToken(){const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then((e=>e?(ii("string"==typeof e.token),this.T=e.token,new gi(e.token)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function vi(e){const t="undefined"!=typeof self&&(self.crypto||self.msCrypto),n=new Uint8Array(e);if(t&&"function"==typeof t.getRandomValues)t.getRandomValues(n);else for(let r=0;r<e;r++)n[r]=Math.floor(256*Math.random());return n}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yi{static A(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=Math.floor(256/e.length)*e.length;let n="";for(;n.length<20;){const r=vi(40);for(let i=0;i<r.length;++i)n.length<20&&r[i]<t&&(n+=e.charAt(r[i]%e.length))}return n}}function bi(e,t){return e<t?-1:e>t?1:0}function wi(e,t,n){return e.length===t.length&&e.every(((e,r)=>n(e,t[r])))}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _i{constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new ai(si.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new ai(si.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<-62135596800)throw new ai(si.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new ai(si.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}static now(){return _i.fromMillis(Date.now())}static fromDate(e){return _i.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),n=Math.floor(1e6*(e-1e3*t));return new _i(t,n)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(e){return this.seconds===e.seconds?bi(this.nanoseconds,e.nanoseconds):bi(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const e=this.seconds- -62135596800;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Si{constructor(e){this.timestamp=e}static fromTimestamp(e){return new Si(e)}static min(){return new Si(new _i(0,0))}static max(){return new Si(new _i(253402300799,999999999))}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ei{constructor(e,t,n){void 0===t?t=0:t>e.length&&ri(),void 0===n?n=e.length-t:n>e.length-t&&ri(),this.segments=e,this.offset=t,this.len=n}get length(){return this.len}isEqual(e){return 0===Ei.comparator(this,e)}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Ei?e.forEach((e=>{t.push(e)})):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=void 0===e?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return 0===this.length}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,n=this.limit();t<n;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const n=Math.min(e.length,t.length);for(let r=0;r<n;r++){const n=e.get(r),i=t.get(r);if(n<i)return-1;if(n>i)return 1}return e.length<t.length?-1:e.length>t.length?1:0}}class ki extends Ei{construct(e,t,n){return new ki(e,t,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}static fromString(...e){const t=[];for(const n of e){if(n.indexOf("//")>=0)throw new ai(si.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);t.push(...n.split("/").filter((e=>e.length>0)))}return new ki(t)}static emptyPath(){return new ki([])}}const Ti=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class Ci extends Ei{construct(e,t,n){return new Ci(e,t,n)}static isValidIdentifier(e){return Ti.test(e)}canonicalString(){return this.toArray().map((e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Ci.isValidIdentifier(e)||(e="`"+e+"`"),e))).join(".")}toString(){return this.canonicalString()}isKeyField(){return 1===this.length&&"__name__"===this.get(0)}static keyField(){return new Ci(["__name__"])}static fromServerFormat(e){const t=[];let n="",r=0;const i=()=>{if(0===n.length)throw new ai(si.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(n),n=""};let o=!1;for(;r<e.length;){const t=e[r];if("\\"===t){if(r+1===e.length)throw new ai(si.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const t=e[r+1];if("\\"!==t&&"."!==t&&"`"!==t)throw new ai(si.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);n+=t,r+=2}else"`"===t?(o=!o,r++):"."!==t||o?(n+=t,r++):(i(),r++)}if(i(),o)throw new ai(si.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Ci(t)}static emptyPath(){return new Ci([])}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ii{constructor(e){this.path=e}static fromPath(e){return new Ii(ki.fromString(e))}static fromName(e){return new Ii(ki.fromString(e).popFirst(5))}static empty(){return new Ii(ki.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return null!==e&&0===ki.comparator(this.path,e.path)}toString(){return this.path.toString()}static comparator(e,t){return ki.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new Ii(new ki(e.slice()))}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xi{constructor(e,t,n,r){this.indexId=e,this.collectionGroup=t,this.fields=n,this.indexState=r}}xi.UNKNOWN_ID=-1;function Ai(e,t){const n=e.toTimestamp().seconds,r=e.toTimestamp().nanoseconds+1,i=Si.fromTimestamp(1e9===r?new _i(n+1,0):new _i(n,r));return new Oi(i,Ii.empty(),t)}function Ri(e){return new Oi(e.readTime,e.key,-1)}class Oi{constructor(e,t,n){this.readTime=e,this.documentKey=t,this.largestBatchId=n}static min(){return new Oi(Si.min(),Ii.empty(),-1)}static max(){return new Oi(Si.max(),Ii.empty(),-1)}}function Ni(e,t){let n=e.readTime.compareTo(t.readTime);return 0!==n?n:(n=Ii.comparator(e.documentKey,t.documentKey),0!==n?n:bi(e.largestBatchId,t.largestBatchId))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pi="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class Fi{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach((e=>e()))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Li(e){if(e.code!==si.FAILED_PRECONDITION||e.message!==Pi)throw e;Xr("LocalStore","Unexpectedly lost primary lease")}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Di{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e((e=>{this.isDone=!0,this.result=e,this.nextCallback&&this.nextCallback(e)}),(e=>{this.isDone=!0,this.error=e,this.catchCallback&&this.catchCallback(e)}))}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&ri(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new Di(((n,r)=>{this.nextCallback=t=>{this.wrapSuccess(e,t).next(n,r)},this.catchCallback=e=>{this.wrapFailure(t,e).next(n,r)}}))}toPromise(){return new Promise(((e,t)=>{this.next(e,t)}))}wrapUserFunction(e){try{const t=e();return t instanceof Di?t:Di.resolve(t)}catch(e){return Di.reject(e)}}wrapSuccess(e,t){return e?this.wrapUserFunction((()=>e(t))):Di.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction((()=>e(t))):Di.reject(t)}static resolve(e){return new Di(((t,n)=>{t(e)}))}static reject(e){return new Di(((t,n)=>{n(e)}))}static waitFor(e){return new Di(((t,n)=>{let r=0,i=0,o=!1;e.forEach((e=>{++r,e.next((()=>{++i,o&&i===r&&t()}),(e=>n(e)))})),o=!0,i===r&&t()}))}static or(e){let t=Di.resolve(!1);for(const n of e)t=t.next((e=>e?Di.resolve(e):n()));return t}static forEach(e,t){const n=[];return e.forEach(((e,r)=>{n.push(t.call(this,e,r))})),this.waitFor(n)}static mapArray(e,t){return new Di(((n,r)=>{const i=e.length,o=new Array(i);let s=0;for(let a=0;a<i;a++){const l=a;t(e[l]).next((e=>{o[l]=e,++s,s===i&&n(o)}),(e=>r(e)))}}))}static doWhile(e,t){return new Di(((n,r)=>{const i=()=>{!0===e()?t().next((()=>{i()}),r):n()};i()}))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mi(e){return"IndexedDbTransactionError"===e.name}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qi{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=e=>this.ot(e),this.ut=e=>t.writeSequenceNumber(e))}ot(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ut&&this.ut(e),e}}function Vi(e){return null==e}function Ui(e){return 0===e&&1/e==-1/0}function Bi(e){return"number"==typeof e&&Number.isInteger(e)&&!Ui(e)&&e<=Number.MAX_SAFE_INTEGER&&e>=Number.MIN_SAFE_INTEGER}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */qi.ct=-1;const $i=["mutationQueues","mutations","documentMutations","remoteDocuments","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries"],ji=["mutationQueues","mutations","documentMutations","remoteDocumentsV14","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries","documentOverlays"],zi=ji;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Hi(e){let t=0;for(const n in e)Object.prototype.hasOwnProperty.call(e,n)&&t++;return t}function Ki(e,t){for(const n in e)Object.prototype.hasOwnProperty.call(e,n)&&t(n,e[n])}function Wi(e){for(const t in e)if(Object.prototype.hasOwnProperty.call(e,t))return!1;return!0}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zi{constructor(e,t){this.comparator=e,this.root=t||Ji.EMPTY}insert(e,t){return new Zi(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,Ji.BLACK,null,null))}remove(e){return new Zi(this.comparator,this.root.remove(e,this.comparator).copy(null,null,Ji.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const n=this.comparator(e,t.key);if(0===n)return t.value;n<0?t=t.left:n>0&&(t=t.right)}return null}indexOf(e){let t=0,n=this.root;for(;!n.isEmpty();){const r=this.comparator(e,n.key);if(0===r)return t+n.left.size;r<0?n=n.left:(t+=n.left.size+1,n=n.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal(((t,n)=>(e(t,n),!1)))}toString(){const e=[];return this.inorderTraversal(((t,n)=>(e.push(`${t}:${n}`),!1))),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Gi(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Gi(this.root,e,this.comparator,!1)}getReverseIterator(){return new Gi(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Gi(this.root,e,this.comparator,!0)}}class Gi{constructor(e,t,n,r){this.isReverse=r,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?n(e.key,t):1,t&&r&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(0===i){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(0===this.nodeStack.length)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class Ji{constructor(e,t,n,r,i){this.key=e,this.value=t,this.color=null!=n?n:Ji.RED,this.left=null!=r?r:Ji.EMPTY,this.right=null!=i?i:Ji.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,n,r,i){return new Ji(null!=e?e:this.key,null!=t?t:this.value,null!=n?n:this.color,null!=r?r:this.left,null!=i?i:this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,n){let r=this;const i=n(e,r.key);return r=i<0?r.copy(null,null,null,r.left.insert(e,t,n),null):0===i?r.copy(null,t,null,null,null):r.copy(null,null,null,null,r.right.insert(e,t,n)),r.fixUp()}removeMin(){if(this.left.isEmpty())return Ji.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let n,r=this;if(t(e,r.key)<0)r.left.isEmpty()||r.left.isRed()||r.left.left.isRed()||(r=r.moveRedLeft()),r=r.copy(null,null,null,r.left.remove(e,t),null);else{if(r.left.isRed()&&(r=r.rotateRight()),r.right.isEmpty()||r.right.isRed()||r.right.left.isRed()||(r=r.moveRedRight()),0===t(e,r.key)){if(r.right.isEmpty())return Ji.EMPTY;n=r.right.min(),r=r.copy(n.key,n.value,null,null,r.right.removeMin())}r=r.copy(null,null,null,null,r.right.remove(e,t))}return r.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,Ji.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,Ji.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw ri();if(this.right.isRed())throw ri();const e=this.left.check();if(e!==this.right.check())throw ri();return e+(this.isRed()?0:1)}}Ji.EMPTY=null,Ji.RED=!0,Ji.BLACK=!1,Ji.EMPTY=new class{constructor(){this.size=0}get key(){throw ri()}get value(){throw ri()}get color(){throw ri()}get left(){throw ri()}get right(){throw ri()}copy(e,t,n,r,i){return this}insert(e,t,n){return new Ji(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(e){this.comparator=e,this.data=new Zi(this.comparator)}has(e){return null!==this.data.get(e)}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal(((t,n)=>(e(t),!1)))}forEachInRange(e,t){const n=this.data.getIteratorFrom(e[0]);for(;n.hasNext();){const r=n.getNext();if(this.comparator(r.key,e[1])>=0)return;t(r.key)}}forEachWhile(e,t){let n;for(n=void 0!==t?this.data.getIteratorFrom(t):this.data.getIterator();n.hasNext();)if(!e(n.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Yi(this.data.getIterator())}getIteratorFrom(e){return new Yi(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach((e=>{t=t.add(e)})),t}isEqual(e){if(!(e instanceof Qi))return!1;if(this.size!==e.size)return!1;const t=this.data.getIterator(),n=e.data.getIterator();for(;t.hasNext();){const e=t.getNext().key,r=n.getNext().key;if(0!==this.comparator(e,r))return!1}return!0}toArray(){const e=[];return this.forEach((t=>{e.push(t)})),e}toString(){const e=[];return this.forEach((t=>e.push(t))),"SortedSet("+e.toString()+")"}copy(e){const t=new Qi(this.comparator);return t.data=e,t}}class Yi{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(e){this.fields=e,e.sort(Ci.comparator)}static empty(){return new Xi([])}unionWith(e){let t=new Qi(Ci.comparator);for(const n of this.fields)t=t.add(n);for(const n of e)t=t.add(n);return new Xi(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return wi(this.fields,e.fields,((e,t)=>e.isEqual(t)))}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eo extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class to{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(e){try{return atob(e)}catch(e){throw"undefined"!=typeof DOMException&&e instanceof DOMException?new eo("Invalid base64 string: "+e):e}}(e);return new to(t)}static fromUint8Array(e){const t=function(e){let t="";for(let n=0;n<e.length;++n)t+=String.fromCharCode(e[n]);return t}(e);return new to(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return e=this.binaryString,btoa(e);var e}toUint8Array(){return function(e){const t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n);return t}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return bi(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}to.EMPTY_BYTE_STRING=new to("");const no=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function ro(e){if(ii(!!e),"string"==typeof e){let t=0;const n=no.exec(e);if(ii(!!n),n[1]){let e=n[1];e=(e+"000000000").substr(0,9),t=Number(e)}const r=new Date(e);return{seconds:Math.floor(r.getTime()/1e3),nanos:t}}return{seconds:io(e.seconds),nanos:io(e.nanos)}}function io(e){return"number"==typeof e?e:"string"==typeof e?Number(e):0}function oo(e){return"string"==typeof e?to.fromBase64String(e):to.fromUint8Array(e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function so(e){var t,n;return"server_timestamp"===(null===(n=((null===(t=null==e?void 0:e.mapValue)||void 0===t?void 0:t.fields)||{}).__type__)||void 0===n?void 0:n.stringValue)}function ao(e){const t=e.mapValue.fields.__previous_value__;return so(t)?ao(t):t}function lo(e){const t=ro(e.mapValue.fields.__local_write_time__.timestampValue);return new _i(t.seconds,t.nanos)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{constructor(e,t,n,r,i,o,s,a,l){this.databaseId=e,this.appId=t,this.persistenceKey=n,this.host=r,this.ssl=i,this.forceLongPolling=o,this.autoDetectLongPolling=s,this.longPollingOptions=a,this.useFetchStreams=l}}class co{constructor(e,t){this.projectId=e,this.database=t||"(default)"}static empty(){return new co("","")}get isDefaultDatabase(){return"(default)"===this.database}isEqual(e){return e instanceof co&&e.projectId===this.projectId&&e.database===this.database}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ho={mapValue:{fields:{__type__:{stringValue:"__max__"}}}};function fo(e){return"nullValue"in e?0:"booleanValue"in e?1:"integerValue"in e||"doubleValue"in e?2:"timestampValue"in e?3:"stringValue"in e?5:"bytesValue"in e?6:"referenceValue"in e?7:"geoPointValue"in e?8:"arrayValue"in e?9:"mapValue"in e?so(e)?4:Io(e)?9007199254740991:10:ri()}function po(e,t){if(e===t)return!0;const n=fo(e);if(n!==fo(t))return!1;switch(n){case 0:case 9007199254740991:return!0;case 1:return e.booleanValue===t.booleanValue;case 4:return lo(e).isEqual(lo(t));case 3:return function(e,t){if("string"==typeof e.timestampValue&&"string"==typeof t.timestampValue&&e.timestampValue.length===t.timestampValue.length)return e.timestampValue===t.timestampValue;const n=ro(e.timestampValue),r=ro(t.timestampValue);return n.seconds===r.seconds&&n.nanos===r.nanos}(e,t);case 5:return e.stringValue===t.stringValue;case 6:return function(e,t){return oo(e.bytesValue).isEqual(oo(t.bytesValue))}(e,t);case 7:return e.referenceValue===t.referenceValue;case 8:return function(e,t){return io(e.geoPointValue.latitude)===io(t.geoPointValue.latitude)&&io(e.geoPointValue.longitude)===io(t.geoPointValue.longitude)}(e,t);case 2:return function(e,t){if("integerValue"in e&&"integerValue"in t)return io(e.integerValue)===io(t.integerValue);if("doubleValue"in e&&"doubleValue"in t){const n=io(e.doubleValue),r=io(t.doubleValue);return n===r?Ui(n)===Ui(r):isNaN(n)&&isNaN(r)}return!1}(e,t);case 9:return wi(e.arrayValue.values||[],t.arrayValue.values||[],po);case 10:return function(e,t){const n=e.mapValue.fields||{},r=t.mapValue.fields||{};if(Hi(n)!==Hi(r))return!1;for(const i in n)if(n.hasOwnProperty(i)&&(void 0===r[i]||!po(n[i],r[i])))return!1;return!0}(e,t);default:return ri()}}function go(e,t){return void 0!==(e.values||[]).find((e=>po(e,t)))}function mo(e,t){if(e===t)return 0;const n=fo(e),r=fo(t);if(n!==r)return bi(n,r);switch(n){case 0:case 9007199254740991:return 0;case 1:return bi(e.booleanValue,t.booleanValue);case 2:return function(e,t){const n=io(e.integerValue||e.doubleValue),r=io(t.integerValue||t.doubleValue);return n<r?-1:n>r?1:n===r?0:isNaN(n)?isNaN(r)?0:-1:1}(e,t);case 3:return vo(e.timestampValue,t.timestampValue);case 4:return vo(lo(e),lo(t));case 5:return bi(e.stringValue,t.stringValue);case 6:return function(e,t){const n=oo(e),r=oo(t);return n.compareTo(r)}(e.bytesValue,t.bytesValue);case 7:return function(e,t){const n=e.split("/"),r=t.split("/");for(let i=0;i<n.length&&i<r.length;i++){const e=bi(n[i],r[i]);if(0!==e)return e}return bi(n.length,r.length)}(e.referenceValue,t.referenceValue);case 8:return function(e,t){const n=bi(io(e.latitude),io(t.latitude));return 0!==n?n:bi(io(e.longitude),io(t.longitude))}(e.geoPointValue,t.geoPointValue);case 9:return function(e,t){const n=e.values||[],r=t.values||[];for(let i=0;i<n.length&&i<r.length;++i){const e=mo(n[i],r[i]);if(e)return e}return bi(n.length,r.length)}(e.arrayValue,t.arrayValue);case 10:return function(e,t){if(e===ho.mapValue&&t===ho.mapValue)return 0;if(e===ho.mapValue)return 1;if(t===ho.mapValue)return-1;const n=e.fields||{},r=Object.keys(n),i=t.fields||{},o=Object.keys(i);r.sort(),o.sort();for(let s=0;s<r.length&&s<o.length;++s){const e=bi(r[s],o[s]);if(0!==e)return e;const t=mo(n[r[s]],i[o[s]]);if(0!==t)return t}return bi(r.length,o.length)}(e.mapValue,t.mapValue);default:throw ri()}}function vo(e,t){if("string"==typeof e&&"string"==typeof t&&e.length===t.length)return bi(e,t);const n=ro(e),r=ro(t),i=bi(n.seconds,r.seconds);return 0!==i?i:bi(n.nanos,r.nanos)}function yo(e){return bo(e)}function bo(e){return"nullValue"in e?"null":"booleanValue"in e?""+e.booleanValue:"integerValue"in e?""+e.integerValue:"doubleValue"in e?""+e.doubleValue:"timestampValue"in e?function(e){const t=ro(e);return`time(${t.seconds},${t.nanos})`}(e.timestampValue):"stringValue"in e?e.stringValue:"bytesValue"in e?oo(e.bytesValue).toBase64():"referenceValue"in e?(n=e.referenceValue,Ii.fromName(n).toString()):"geoPointValue"in e?`geo(${(t=e.geoPointValue).latitude},${t.longitude})`:"arrayValue"in e?function(e){let t="[",n=!0;for(const r of e.values||[])n?n=!1:t+=",",t+=bo(r);return t+"]"}(e.arrayValue):"mapValue"in e?function(e){const t=Object.keys(e.fields||{}).sort();let n="{",r=!0;for(const i of t)r?r=!1:n+=",",n+=`${i}:${bo(e.fields[i])}`;return n+"}"}(e.mapValue):ri();var t,n}function wo(e,t){return{referenceValue:`projects/${e.projectId}/databases/${e.database}/documents/${t.path.canonicalString()}`}}function _o(e){return!!e&&"integerValue"in e}function So(e){return!!e&&"arrayValue"in e}function Eo(e){return!!e&&"nullValue"in e}function ko(e){return!!e&&"doubleValue"in e&&isNaN(Number(e.doubleValue))}function To(e){return!!e&&"mapValue"in e}function Co(e){if(e.geoPointValue)return{geoPointValue:Object.assign({},e.geoPointValue)};if(e.timestampValue&&"object"==typeof e.timestampValue)return{timestampValue:Object.assign({},e.timestampValue)};if(e.mapValue){const t={mapValue:{fields:{}}};return Ki(e.mapValue.fields,((e,n)=>t.mapValue.fields[e]=Co(n))),t}if(e.arrayValue){const t={arrayValue:{values:[]}};for(let n=0;n<(e.arrayValue.values||[]).length;++n)t.arrayValue.values[n]=Co(e.arrayValue.values[n]);return t}return Object.assign({},e)}function Io(e){return"__max__"===(((e.mapValue||{}).fields||{}).__type__||{}).stringValue}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xo{constructor(e){this.value=e}static empty(){return new xo({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let n=0;n<e.length-1;++n)if(t=(t.mapValue.fields||{})[e.get(n)],!To(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=Co(t)}setAll(e){let t=Ci.emptyPath(),n={},r=[];e.forEach(((e,i)=>{if(!t.isImmediateParentOf(i)){const e=this.getFieldsMap(t);this.applyChanges(e,n,r),n={},r=[],t=i.popLast()}e?n[i.lastSegment()]=Co(e):r.push(i.lastSegment())}));const i=this.getFieldsMap(t);this.applyChanges(i,n,r)}delete(e){const t=this.field(e.popLast());To(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return po(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let n=0;n<e.length;++n){let r=t.mapValue.fields[e.get(n)];To(r)&&r.mapValue.fields||(r={mapValue:{fields:{}}},t.mapValue.fields[e.get(n)]=r),t=r}return t.mapValue.fields}applyChanges(e,t,n){Ki(t,((t,n)=>e[t]=n));for(const r of n)delete e[r]}clone(){return new xo(Co(this.value))}}function Ao(e){const t=[];return Ki(e.fields,((e,n)=>{const r=new Ci([e]);if(To(n)){const e=Ao(n.mapValue).fields;if(0===e.length)t.push(r);else for(const n of e)t.push(r.child(n))}else t.push(r)})),new Xi(t)
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class Ro{constructor(e,t,n,r,i,o,s){this.key=e,this.documentType=t,this.version=n,this.readTime=r,this.createTime=i,this.data=o,this.documentState=s}static newInvalidDocument(e){return new Ro(e,0,Si.min(),Si.min(),Si.min(),xo.empty(),0)}static newFoundDocument(e,t,n,r){return new Ro(e,1,t,Si.min(),n,r,0)}static newNoDocument(e,t){return new Ro(e,2,t,Si.min(),Si.min(),xo.empty(),0)}static newUnknownDocument(e,t){return new Ro(e,3,t,Si.min(),Si.min(),xo.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(Si.min())||2!==this.documentType&&0!==this.documentType||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=xo.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=xo.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=Si.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return 1===this.documentState}get hasCommittedMutations(){return 2===this.documentState}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return 0!==this.documentType}isFoundDocument(){return 1===this.documentType}isNoDocument(){return 2===this.documentType}isUnknownDocument(){return 3===this.documentType}isEqual(e){return e instanceof Ro&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Ro(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oo{constructor(e,t){this.position=e,this.inclusive=t}}function No(e,t,n){let r=0;for(let i=0;i<e.position.length;i++){const o=t[i],s=e.position[i];if(r=o.field.isKeyField()?Ii.comparator(Ii.fromName(s.referenceValue),n.key):mo(s,n.data.field(o.field)),"desc"===o.dir&&(r*=-1),0!==r)break}return r}function Po(e,t){if(null===e)return null===t;if(null===t)return!1;if(e.inclusive!==t.inclusive||e.position.length!==t.position.length)return!1;for(let n=0;n<e.position.length;n++)if(!po(e.position[n],t.position[n]))return!1;return!0}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fo{constructor(e,t="asc"){this.field=e,this.dir=t}}function Lo(e,t){return e.dir===t.dir&&e.field.isEqual(t.field)}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Do{}class Mo extends Do{constructor(e,t,n){super(),this.field=e,this.op=t,this.value=n}static create(e,t,n){return e.isKeyField()?"in"===t||"not-in"===t?this.createKeyFieldInFilter(e,t,n):new Ho(e,t,n):"array-contains"===t?new Go(e,n):"in"===t?new Jo(e,n):"not-in"===t?new Qo(e,n):"array-contains-any"===t?new Yo(e,n):new Mo(e,t,n)}static createKeyFieldInFilter(e,t,n){return"in"===t?new Ko(e,n):new Wo(e,n)}matches(e){const t=e.data.field(this.field);return"!="===this.op?null!==t&&this.matchesComparison(mo(t,this.value)):null!==t&&fo(this.value)===fo(t)&&this.matchesComparison(mo(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return 0===e;case"!=":return 0!==e;case">":return e>0;case">=":return e>=0;default:return ri()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}getFirstInequalityField(){return this.isInequality()?this.field:null}}class qo extends Do{constructor(e,t){super(),this.filters=e,this.op=t,this.lt=null}static create(e,t){return new qo(e,t)}matches(e){return Vo(this)?void 0===this.filters.find((t=>!t.matches(e))):void 0!==this.filters.find((t=>t.matches(e)))}getFlattenedFilters(){return null!==this.lt||(this.lt=this.filters.reduce(((e,t)=>e.concat(t.getFlattenedFilters())),[])),this.lt}getFilters(){return Object.assign([],this.filters)}getFirstInequalityField(){const e=this.ft((e=>e.isInequality()));return null!==e?e.field:null}ft(e){for(const t of this.getFlattenedFilters())if(e(t))return t;return null}}function Vo(e){return"and"===e.op}function Uo(e){return Bo(e)&&Vo(e)}function Bo(e){for(const t of e.filters)if(t instanceof qo)return!1;return!0}function $o(e){if(e instanceof Mo)return e.field.canonicalString()+e.op.toString()+yo(e.value);if(Uo(e))return e.filters.map((e=>$o(e))).join(",");{const t=e.filters.map((e=>$o(e))).join(",");return`${e.op}(${t})`}}function jo(e,t){return e instanceof Mo?function(e,t){return t instanceof Mo&&e.op===t.op&&e.field.isEqual(t.field)&&po(e.value,t.value)}(e,t):e instanceof qo?function(e,t){return t instanceof qo&&e.op===t.op&&e.filters.length===t.filters.length&&e.filters.reduce(((e,n,r)=>e&&jo(n,t.filters[r])),!0)}(e,t):void ri()}function zo(e){return e instanceof Mo?function(e){return`${e.field.canonicalString()} ${e.op} ${yo(e.value)}`}(e):e instanceof qo?function(e){return e.op.toString()+" {"+e.getFilters().map(zo).join(" ,")+"}"}(e):"Filter"}class Ho extends Mo{constructor(e,t,n){super(e,t,n),this.key=Ii.fromName(n.referenceValue)}matches(e){const t=Ii.comparator(e.key,this.key);return this.matchesComparison(t)}}class Ko extends Mo{constructor(e,t){super(e,"in",t),this.keys=Zo("in",t)}matches(e){return this.keys.some((t=>t.isEqual(e.key)))}}class Wo extends Mo{constructor(e,t){super(e,"not-in",t),this.keys=Zo("not-in",t)}matches(e){return!this.keys.some((t=>t.isEqual(e.key)))}}function Zo(e,t){var n;return((null===(n=t.arrayValue)||void 0===n?void 0:n.values)||[]).map((e=>Ii.fromName(e.referenceValue)))}class Go extends Mo{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return So(t)&&go(t.arrayValue,this.value)}}class Jo extends Mo{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return null!==t&&go(this.value.arrayValue,t)}}class Qo extends Mo{constructor(e,t){super(e,"not-in",t)}matches(e){if(go(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return null!==t&&!go(this.value.arrayValue,t)}}class Yo extends Mo{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!So(t)||!t.arrayValue.values)&&t.arrayValue.values.some((e=>go(this.value.arrayValue,e)))}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xo{constructor(e,t=null,n=[],r=[],i=null,o=null,s=null){this.path=e,this.collectionGroup=t,this.orderBy=n,this.filters=r,this.limit=i,this.startAt=o,this.endAt=s,this.dt=null}}function es(e,t=null,n=[],r=[],i=null,o=null,s=null){return new Xo(e,t,n,r,i,o,s)}function ts(e){const t=oi(e);if(null===t.dt){let e=t.path.canonicalString();null!==t.collectionGroup&&(e+="|cg:"+t.collectionGroup),e+="|f:",e+=t.filters.map((e=>$o(e))).join(","),e+="|ob:",e+=t.orderBy.map((e=>function(e){return e.field.canonicalString()+e.dir}(e))).join(","),Vi(t.limit)||(e+="|l:",e+=t.limit),t.startAt&&(e+="|lb:",e+=t.startAt.inclusive?"b:":"a:",e+=t.startAt.position.map((e=>yo(e))).join(",")),t.endAt&&(e+="|ub:",e+=t.endAt.inclusive?"a:":"b:",e+=t.endAt.position.map((e=>yo(e))).join(",")),t.dt=e}return t.dt}function ns(e,t){if(e.limit!==t.limit)return!1;if(e.orderBy.length!==t.orderBy.length)return!1;for(let n=0;n<e.orderBy.length;n++)if(!Lo(e.orderBy[n],t.orderBy[n]))return!1;if(e.filters.length!==t.filters.length)return!1;for(let n=0;n<e.filters.length;n++)if(!jo(e.filters[n],t.filters[n]))return!1;return e.collectionGroup===t.collectionGroup&&!!e.path.isEqual(t.path)&&!!Po(e.startAt,t.startAt)&&Po(e.endAt,t.endAt)}function rs(e){return Ii.isDocumentKey(e.path)&&null===e.collectionGroup&&0===e.filters.length}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class is{constructor(e,t=null,n=[],r=[],i=null,o="F",s=null,a=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=n,this.filters=r,this.limit=i,this.limitType=o,this.startAt=s,this.endAt=a,this.wt=null,this._t=null,this.startAt,this.endAt}}function os(e,t,n,r,i,o,s,a){return new is(e,t,n,r,i,o,s,a)}function ss(e){return new is(e)}function as(e){return 0===e.filters.length&&null===e.limit&&null==e.startAt&&null==e.endAt&&(0===e.explicitOrderBy.length||1===e.explicitOrderBy.length&&e.explicitOrderBy[0].field.isKeyField())}function ls(e){return e.explicitOrderBy.length>0?e.explicitOrderBy[0].field:null}function us(e){for(const t of e.filters){const e=t.getFirstInequalityField();if(null!==e)return e}return null}function cs(e){return null!==e.collectionGroup}function ds(e){const t=oi(e);if(null===t.wt){t.wt=[];const e=us(t),n=ls(t);if(null!==e&&null===n)e.isKeyField()||t.wt.push(new Fo(e)),t.wt.push(new Fo(Ci.keyField(),"asc"));else{let e=!1;for(const n of t.explicitOrderBy)t.wt.push(n),n.field.isKeyField()&&(e=!0);if(!e){const e=t.explicitOrderBy.length>0?t.explicitOrderBy[t.explicitOrderBy.length-1].dir:"asc";t.wt.push(new Fo(Ci.keyField(),e))}}}return t.wt}function hs(e){const t=oi(e);if(!t._t)if("F"===t.limitType)t._t=es(t.path,t.collectionGroup,ds(t),t.filters,t.limit,t.startAt,t.endAt);else{const e=[];for(const i of ds(t)){const t="desc"===i.dir?"asc":"desc";e.push(new Fo(i.field,t))}const n=t.endAt?new Oo(t.endAt.position,t.endAt.inclusive):null,r=t.startAt?new Oo(t.startAt.position,t.startAt.inclusive):null;t._t=es(t.path,t.collectionGroup,e,t.filters,t.limit,n,r)}return t._t}function fs(e,t){t.getFirstInequalityField(),us(e);const n=e.filters.concat([t]);return new is(e.path,e.collectionGroup,e.explicitOrderBy.slice(),n,e.limit,e.limitType,e.startAt,e.endAt)}function ps(e,t,n){return new is(e.path,e.collectionGroup,e.explicitOrderBy.slice(),e.filters.slice(),t,n,e.startAt,e.endAt)}function gs(e,t){return ns(hs(e),hs(t))&&e.limitType===t.limitType}function ms(e){return`${ts(hs(e))}|lt:${e.limitType}`}function vs(e){return`Query(target=${function(e){let t=e.path.canonicalString();return null!==e.collectionGroup&&(t+=" collectionGroup="+e.collectionGroup),e.filters.length>0&&(t+=`, filters: [${e.filters.map((e=>zo(e))).join(", ")}]`),Vi(e.limit)||(t+=", limit: "+e.limit),e.orderBy.length>0&&(t+=`, orderBy: [${e.orderBy.map((e=>function(e){return`${e.field.canonicalString()} (${e.dir})`}(e))).join(", ")}]`),e.startAt&&(t+=", startAt: ",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map((e=>yo(e))).join(",")),e.endAt&&(t+=", endAt: ",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map((e=>yo(e))).join(",")),`Target(${t})`}(hs(e))}; limitType=${e.limitType})`}function ys(e,t){return t.isFoundDocument()&&function(e,t){const n=t.key.path;return null!==e.collectionGroup?t.key.hasCollectionId(e.collectionGroup)&&e.path.isPrefixOf(n):Ii.isDocumentKey(e.path)?e.path.isEqual(n):e.path.isImmediateParentOf(n)}(e,t)&&function(e,t){for(const n of ds(e))if(!n.field.isKeyField()&&null===t.data.field(n.field))return!1;return!0}(e,t)&&function(e,t){for(const n of e.filters)if(!n.matches(t))return!1;return!0}(e,t)&&function(e,t){return!(e.startAt&&!function(e,t,n){const r=No(e,t,n);return e.inclusive?r<=0:r<0}(e.startAt,ds(e),t))&&!(e.endAt&&!function(e,t,n){const r=No(e,t,n);return e.inclusive?r>=0:r>0}(e.endAt,ds(e),t))}(e,t)}function bs(e){return e.collectionGroup||(e.path.length%2==1?e.path.lastSegment():e.path.get(e.path.length-2))}function ws(e){return(t,n)=>{let r=!1;for(const i of ds(e)){const e=_s(i,t,n);if(0!==e)return e;r=r||i.field.isKeyField()}return 0}}function _s(e,t,n){const r=e.field.isKeyField()?Ii.comparator(t.key,n.key):function(e,t,n){const r=t.data.field(e),i=n.data.field(e);return null!==r&&null!==i?mo(r,i):ri()}(e.field,t,n);switch(e.dir){case"asc":return r;case"desc":return-1*r;default:return ri()}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ss{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),n=this.inner[t];if(void 0!==n)for(const[r,i]of n)if(this.equalsFn(r,e))return i}has(e){return void 0!==this.get(e)}set(e,t){const n=this.mapKeyFn(e),r=this.inner[n];if(void 0===r)return this.inner[n]=[[e,t]],void this.innerSize++;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return void(r[i]=[e,t]);r.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),n=this.inner[t];if(void 0===n)return!1;for(let r=0;r<n.length;r++)if(this.equalsFn(n[r][0],e))return 1===n.length?delete this.inner[t]:n.splice(r,1),this.innerSize--,!0;return!1}forEach(e){Ki(this.inner,((t,n)=>{for(const[r,i]of n)e(r,i)}))}isEmpty(){return Wi(this.inner)}size(){return this.innerSize}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Es=new Zi(Ii.comparator);function ks(){return Es}const Ts=new Zi(Ii.comparator);function Cs(...e){let t=Ts;for(const n of e)t=t.insert(n.key,n);return t}function Is(e){let t=Ts;return e.forEach(((e,n)=>t=t.insert(e,n.overlayedDocument))),t}function xs(){return Rs()}function As(){return Rs()}function Rs(){return new Ss((e=>e.toString()),((e,t)=>e.isEqual(t)))}const Os=new Zi(Ii.comparator),Ns=new Qi(Ii.comparator);function Ps(...e){let t=Ns;for(const n of e)t=t.add(n);return t}const Fs=new Qi(bi);function Ls(){return Fs}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ds(e,t){if(e.useProto3Json){if(isNaN(t))return{doubleValue:"NaN"};if(t===1/0)return{doubleValue:"Infinity"};if(t===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Ui(t)?"-0":t}}function Ms(e){return{integerValue:""+e}}function qs(e,t){return Bi(t)?Ms(t):Ds(e,t)}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vs{constructor(){this._=void 0}}function Us(e,t,n){return e instanceof js?function(e,t){const n={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:e.seconds,nanos:e.nanoseconds}}}};return t&&so(t)&&(t=ao(t)),t&&(n.fields.__previous_value__=t),{mapValue:n}}(n,t):e instanceof zs?Hs(e,t):e instanceof Ks?Ws(e,t):function(e,t){const n=$s(e,t),r=Gs(n)+Gs(e.gt);return _o(n)&&_o(e.gt)?Ms(r):Ds(e.serializer,r)}(e,t)}function Bs(e,t,n){return e instanceof zs?Hs(e,t):e instanceof Ks?Ws(e,t):n}function $s(e,t){return e instanceof Zs?_o(n=t)||function(e){return!!e&&"doubleValue"in e}(n)?t:{integerValue:0}:null;var n}class js extends Vs{}class zs extends Vs{constructor(e){super(),this.elements=e}}function Hs(e,t){const n=Js(t);for(const r of e.elements)n.some((e=>po(e,r)))||n.push(r);return{arrayValue:{values:n}}}class Ks extends Vs{constructor(e){super(),this.elements=e}}function Ws(e,t){let n=Js(t);for(const r of e.elements)n=n.filter((e=>!po(e,r)));return{arrayValue:{values:n}}}class Zs extends Vs{constructor(e,t){super(),this.serializer=e,this.gt=t}}function Gs(e){return io(e.integerValue||e.doubleValue)}function Js(e){return So(e)&&e.arrayValue.values?e.arrayValue.values.slice():[]}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qs(e,t){return e.field.isEqual(t.field)&&function(e,t){return e instanceof zs&&t instanceof zs||e instanceof Ks&&t instanceof Ks?wi(e.elements,t.elements,po):e instanceof Zs&&t instanceof Zs?po(e.gt,t.gt):e instanceof js&&t instanceof js}(e.transform,t.transform)}class Ys{constructor(e,t){this.version=e,this.transformResults=t}}class Xs{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new Xs}static exists(e){return new Xs(void 0,e)}static updateTime(e){return new Xs(e)}get isNone(){return void 0===this.updateTime&&void 0===this.exists}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function ea(e,t){return void 0!==e.updateTime?t.isFoundDocument()&&t.version.isEqual(e.updateTime):void 0===e.exists||e.exists===t.isFoundDocument()}class ta{}function na(e,t){if(!e.hasLocalMutations||t&&0===t.fields.length)return null;if(null===t)return e.isNoDocument()?new ha(e.key,Xs.none()):new aa(e.key,e.data,Xs.none());{const n=e.data,r=xo.empty();let i=new Qi(Ci.comparator);for(let e of t.fields)if(!i.has(e)){let t=n.field(e);null===t&&e.length>1&&(e=e.popLast(),t=n.field(e)),null===t?r.delete(e):r.set(e,t),i=i.add(e)}return new la(e.key,r,new Xi(i.toArray()),Xs.none())}}function ra(e,t,n){e instanceof aa?function(e,t,n){const r=e.value.clone(),i=ca(e.fieldTransforms,t,n.transformResults);r.setAll(i),t.convertToFoundDocument(n.version,r).setHasCommittedMutations()}(e,t,n):e instanceof la?function(e,t,n){if(!ea(e.precondition,t))return void t.convertToUnknownDocument(n.version);const r=ca(e.fieldTransforms,t,n.transformResults),i=t.data;i.setAll(ua(e)),i.setAll(r),t.convertToFoundDocument(n.version,i).setHasCommittedMutations()}(e,t,n):function(e,t,n){t.convertToNoDocument(n.version).setHasCommittedMutations()}(0,t,n)}function ia(e,t,n,r){return e instanceof aa?function(e,t,n,r){if(!ea(e.precondition,t))return n;const i=e.value.clone(),o=da(e.fieldTransforms,r,t);return i.setAll(o),t.convertToFoundDocument(t.version,i).setHasLocalMutations(),null}(e,t,n,r):e instanceof la?function(e,t,n,r){if(!ea(e.precondition,t))return n;const i=da(e.fieldTransforms,r,t),o=t.data;return o.setAll(ua(e)),o.setAll(i),t.convertToFoundDocument(t.version,o).setHasLocalMutations(),null===n?null:n.unionWith(e.fieldMask.fields).unionWith(e.fieldTransforms.map((e=>e.field)))}(e,t,n,r):function(e,t,n){return ea(e.precondition,t)?(t.convertToNoDocument(t.version).setHasLocalMutations(),null):n}(e,t,n)}function oa(e,t){let n=null;for(const r of e.fieldTransforms){const e=t.data.field(r.field),i=$s(r.transform,e||null);null!=i&&(null===n&&(n=xo.empty()),n.set(r.field,i))}return n||null}function sa(e,t){return e.type===t.type&&!!e.key.isEqual(t.key)&&!!e.precondition.isEqual(t.precondition)&&!!function(e,t){return void 0===e&&void 0===t||!(!e||!t)&&wi(e,t,((e,t)=>Qs(e,t)))}(e.fieldTransforms,t.fieldTransforms)&&(0===e.type?e.value.isEqual(t.value):1!==e.type||e.data.isEqual(t.data)&&e.fieldMask.isEqual(t.fieldMask))}class aa extends ta{constructor(e,t,n,r=[]){super(),this.key=e,this.value=t,this.precondition=n,this.fieldTransforms=r,this.type=0}getFieldMask(){return null}}class la extends ta{constructor(e,t,n,r,i=[]){super(),this.key=e,this.data=t,this.fieldMask=n,this.precondition=r,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function ua(e){const t=new Map;return e.fieldMask.fields.forEach((n=>{if(!n.isEmpty()){const r=e.data.field(n);t.set(n,r)}})),t}function ca(e,t,n){const r=new Map;ii(e.length===n.length);for(let i=0;i<n.length;i++){const o=e[i],s=o.transform,a=t.data.field(o.field);r.set(o.field,Bs(s,a,n[i]))}return r}function da(e,t,n){const r=new Map;for(const i of e){const e=i.transform,o=n.data.field(i.field);r.set(i.field,Us(e,o,t))}return r}class ha extends ta{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class fa extends ta{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pa{constructor(e,t,n,r){this.batchId=e,this.localWriteTime=t,this.baseMutations=n,this.mutations=r}applyToRemoteDocument(e,t){const n=t.mutationResults;for(let r=0;r<this.mutations.length;r++){const t=this.mutations[r];t.key.isEqual(e.key)&&ra(t,e,n[r])}}applyToLocalView(e,t){for(const n of this.baseMutations)n.key.isEqual(e.key)&&(t=ia(n,e,t,this.localWriteTime));for(const n of this.mutations)n.key.isEqual(e.key)&&(t=ia(n,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const n=As();return this.mutations.forEach((r=>{const i=e.get(r.key),o=i.overlayedDocument;let s=this.applyToLocalView(o,i.mutatedFields);s=t.has(r.key)?null:s;const a=na(o,s);null!==a&&n.set(r.key,a),o.isValidDocument()||o.convertToNoDocument(Si.min())})),n}keys(){return this.mutations.reduce(((e,t)=>e.add(t.key)),Ps())}isEqual(e){return this.batchId===e.batchId&&wi(this.mutations,e.mutations,((e,t)=>sa(e,t)))&&wi(this.baseMutations,e.baseMutations,((e,t)=>sa(e,t)))}}class ga{constructor(e,t,n,r){this.batch=e,this.commitVersion=t,this.mutationResults=n,this.docVersions=r}static from(e,t,n){ii(e.mutations.length===n.length);let r=Os;const i=e.mutations;for(let o=0;o<i.length;o++)r=r.insert(i[o].key,n[o].version);return new ga(e,t,n,r)}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ma{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return null!==e&&this.mutation===e.mutation}toString(){return`Overlay{\n      largestBatchId: ${this.largestBatchId},\n      mutation: ${this.mutation.toString()}\n    }`}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{constructor(e,t){this.count=e,this.unchangedNames=t}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ya,ba;function wa(e){switch(e){default:return ri();case si.CANCELLED:case si.UNKNOWN:case si.DEADLINE_EXCEEDED:case si.RESOURCE_EXHAUSTED:case si.INTERNAL:case si.UNAVAILABLE:case si.UNAUTHENTICATED:return!1;case si.INVALID_ARGUMENT:case si.NOT_FOUND:case si.ALREADY_EXISTS:case si.PERMISSION_DENIED:case si.FAILED_PRECONDITION:case si.ABORTED:case si.OUT_OF_RANGE:case si.UNIMPLEMENTED:case si.DATA_LOSS:return!0}}function _a(e){if(void 0===e)return ei("GRPC error has no .code"),si.UNKNOWN;switch(e){case ya.OK:return si.OK;case ya.CANCELLED:return si.CANCELLED;case ya.UNKNOWN:return si.UNKNOWN;case ya.DEADLINE_EXCEEDED:return si.DEADLINE_EXCEEDED;case ya.RESOURCE_EXHAUSTED:return si.RESOURCE_EXHAUSTED;case ya.INTERNAL:return si.INTERNAL;case ya.UNAVAILABLE:return si.UNAVAILABLE;case ya.UNAUTHENTICATED:return si.UNAUTHENTICATED;case ya.INVALID_ARGUMENT:return si.INVALID_ARGUMENT;case ya.NOT_FOUND:return si.NOT_FOUND;case ya.ALREADY_EXISTS:return si.ALREADY_EXISTS;case ya.PERMISSION_DENIED:return si.PERMISSION_DENIED;case ya.FAILED_PRECONDITION:return si.FAILED_PRECONDITION;case ya.ABORTED:return si.ABORTED;case ya.OUT_OF_RANGE:return si.OUT_OF_RANGE;case ya.UNIMPLEMENTED:return si.UNIMPLEMENTED;case ya.DATA_LOSS:return si.DATA_LOSS;default:return ri()}}(ba=ya||(ya={}))[ba.OK=0]="OK",ba[ba.CANCELLED=1]="CANCELLED",ba[ba.UNKNOWN=2]="UNKNOWN",ba[ba.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",ba[ba.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",ba[ba.NOT_FOUND=5]="NOT_FOUND",ba[ba.ALREADY_EXISTS=6]="ALREADY_EXISTS",ba[ba.PERMISSION_DENIED=7]="PERMISSION_DENIED",ba[ba.UNAUTHENTICATED=16]="UNAUTHENTICATED",ba[ba.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",ba[ba.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",ba[ba.ABORTED=10]="ABORTED",ba[ba.OUT_OF_RANGE=11]="OUT_OF_RANGE",ba[ba.UNIMPLEMENTED=12]="UNIMPLEMENTED",ba[ba.INTERNAL=13]="INTERNAL",ba[ba.UNAVAILABLE=14]="UNAVAILABLE",ba[ba.DATA_LOSS=15]="DATA_LOSS";
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sa{constructor(){this.onExistenceFilterMismatchCallbacks=new Map}static get instance(){return Ea}static getOrCreateInstance(){return null===Ea&&(Ea=new Sa),Ea}onExistenceFilterMismatch(e){const t=Symbol();return this.onExistenceFilterMismatchCallbacks.set(t,e),()=>this.onExistenceFilterMismatchCallbacks.delete(t)}notifyOnExistenceFilterMismatch(e){this.onExistenceFilterMismatchCallbacks.forEach((t=>t(e)))}}let Ea=null;
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ka(){return new TextEncoder}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ta=new Wr([4294967295,4294967295],0);function Ca(e){const t=ka().encode(e),n=new Kr;return n.update(t),new Uint8Array(n.digest())}function Ia(e){const t=new DataView(e.buffer),n=t.getUint32(0,!0),r=t.getUint32(4,!0),i=t.getUint32(8,!0),o=t.getUint32(12,!0);return[new Wr([n,r],0),new Wr([i,o],0)]}class xa{constructor(e,t,n){if(this.bitmap=e,this.padding=t,this.hashCount=n,t<0||t>=8)throw new Aa(`Invalid padding: ${t}`);if(n<0)throw new Aa(`Invalid hash count: ${n}`);if(e.length>0&&0===this.hashCount)throw new Aa(`Invalid hash count: ${n}`);if(0===e.length&&0!==t)throw new Aa(`Invalid padding when bitmap length is 0: ${t}`);this.It=8*e.length-t,this.Tt=Wr.fromNumber(this.It)}Et(e,t,n){let r=e.add(t.multiply(Wr.fromNumber(n)));return 1===r.compare(Ta)&&(r=new Wr([r.getBits(0),r.getBits(1)],0)),r.modulo(this.Tt).toNumber()}At(e){return 0!=(this.bitmap[Math.floor(e/8)]&1<<e%8)}vt(e){if(0===this.It)return!1;const t=Ca(e),[n,r]=Ia(t);for(let i=0;i<this.hashCount;i++){const e=this.Et(n,r,i);if(!this.At(e))return!1}return!0}static create(e,t,n){const r=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),o=new xa(i,r,t);return n.forEach((e=>o.insert(e))),o}insert(e){if(0===this.It)return;const t=Ca(e),[n,r]=Ia(t);for(let i=0;i<this.hashCount;i++){const e=this.Et(n,r,i);this.Rt(e)}}Rt(e){const t=Math.floor(e/8),n=e%8;this.bitmap[t]|=1<<n}}class Aa extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ra{constructor(e,t,n,r,i){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=n,this.documentUpdates=r,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(e,t,n){const r=new Map;return r.set(e,Oa.createSynthesizedTargetChangeForCurrentChange(e,t,n)),new Ra(Si.min(),r,new Zi(bi),ks(),Ps())}}class Oa{constructor(e,t,n,r,i){this.resumeToken=e,this.current=t,this.addedDocuments=n,this.modifiedDocuments=r,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,n){return new Oa(n,t,Ps(),Ps(),Ps())}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Na{constructor(e,t,n,r){this.Pt=e,this.removedTargetIds=t,this.key=n,this.bt=r}}class Pa{constructor(e,t){this.targetId=e,this.Vt=t}}class Fa{constructor(e,t,n=to.EMPTY_BYTE_STRING,r=null){this.state=e,this.targetIds=t,this.resumeToken=n,this.cause=r}}class La{constructor(){this.St=0,this.Dt=qa(),this.Ct=to.EMPTY_BYTE_STRING,this.xt=!1,this.Nt=!0}get current(){return this.xt}get resumeToken(){return this.Ct}get kt(){return 0!==this.St}get Mt(){return this.Nt}$t(e){e.approximateByteSize()>0&&(this.Nt=!0,this.Ct=e)}Ot(){let e=Ps(),t=Ps(),n=Ps();return this.Dt.forEach(((r,i)=>{switch(i){case 0:e=e.add(r);break;case 2:t=t.add(r);break;case 1:n=n.add(r);break;default:ri()}})),new Oa(this.Ct,this.xt,e,t,n)}Ft(){this.Nt=!1,this.Dt=qa()}Bt(e,t){this.Nt=!0,this.Dt=this.Dt.insert(e,t)}Lt(e){this.Nt=!0,this.Dt=this.Dt.remove(e)}qt(){this.St+=1}Ut(){this.St-=1}Kt(){this.Nt=!0,this.xt=!0}}class Da{constructor(e){this.Gt=e,this.Qt=new Map,this.jt=ks(),this.zt=Ma(),this.Wt=new Zi(bi)}Ht(e){for(const t of e.Pt)e.bt&&e.bt.isFoundDocument()?this.Jt(t,e.bt):this.Yt(t,e.key,e.bt);for(const t of e.removedTargetIds)this.Yt(t,e.key,e.bt)}Xt(e){this.forEachTarget(e,(t=>{const n=this.Zt(t);switch(e.state){case 0:this.te(t)&&n.$t(e.resumeToken);break;case 1:n.Ut(),n.kt||n.Ft(),n.$t(e.resumeToken);break;case 2:n.Ut(),n.kt||this.removeTarget(t);break;case 3:this.te(t)&&(n.Kt(),n.$t(e.resumeToken));break;case 4:this.te(t)&&(this.ee(t),n.$t(e.resumeToken));break;default:ri()}}))}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.Qt.forEach(((e,n)=>{this.te(n)&&t(n)}))}ne(e){var t;const n=e.targetId,r=e.Vt.count,i=this.se(n);if(i){const o=i.target;if(rs(o))if(0===r){const e=new Ii(o.path);this.Yt(n,e,Ro.newNoDocument(e,Si.min()))}else ii(1===r);else{const i=this.ie(n);if(i!==r){const r=this.re(e,i);if(0!==r){this.ee(n);const e=2===r?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Wt=this.Wt.insert(n,e)}null===(t=Sa.instance)||void 0===t||t.notifyOnExistenceFilterMismatch(function(e,t,n){var r,i,o,s,a,l;const u={localCacheCount:t,existenceFilterCount:n.count},c=n.unchangedNames;return c&&(u.bloomFilter={applied:0===e,hashCount:null!==(r=null==c?void 0:c.hashCount)&&void 0!==r?r:0,bitmapLength:null!==(s=null===(o=null===(i=null==c?void 0:c.bits)||void 0===i?void 0:i.bitmap)||void 0===o?void 0:o.length)&&void 0!==s?s:0,padding:null!==(l=null===(a=null==c?void 0:c.bits)||void 0===a?void 0:a.padding)&&void 0!==l?l:0}),u}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(r,i,e.Vt))}}}}re(e,t){const{unchangedNames:n,count:r}=e.Vt;if(!n||!n.bits)return 1;const{bits:{bitmap:i="",padding:o=0},hashCount:s=0}=n;let a,l;try{a=oo(i).toUint8Array()}catch(e){if(e instanceof eo)return ti("Decoding the base64 bloom filter in existence filter failed ("+e.message+"); ignoring the bloom filter and falling back to full re-query."),1;throw e}try{l=new xa(a,o,s)}catch(e){return ti(e instanceof Aa?"BloomFilter error: ":"Applying bloom filter failed: ",e),1}return 0===l.It?1:r!==t-this.oe(e.targetId,l)?2:0}oe(e,t){const n=this.Gt.getRemoteKeysForTarget(e);let r=0;return n.forEach((n=>{const i=this.Gt.ue(),o=`projects/${i.projectId}/databases/${i.database}/documents/${n.path.canonicalString()}`;t.vt(o)||(this.Yt(e,n,null),r++)})),r}ce(e){const t=new Map;this.Qt.forEach(((n,r)=>{const i=this.se(r);if(i){if(n.current&&rs(i.target)){const t=new Ii(i.target.path);null!==this.jt.get(t)||this.ae(r,t)||this.Yt(r,t,Ro.newNoDocument(t,e))}n.Mt&&(t.set(r,n.Ot()),n.Ft())}}));let n=Ps();this.zt.forEach(((e,t)=>{let r=!0;t.forEachWhile((e=>{const t=this.se(e);return!t||"TargetPurposeLimboResolution"===t.purpose||(r=!1,!1)})),r&&(n=n.add(e))})),this.jt.forEach(((t,n)=>n.setReadTime(e)));const r=new Ra(e,t,this.Wt,this.jt,n);return this.jt=ks(),this.zt=Ma(),this.Wt=new Zi(bi),r}Jt(e,t){if(!this.te(e))return;const n=this.ae(e,t.key)?2:0;this.Zt(e).Bt(t.key,n),this.jt=this.jt.insert(t.key,t),this.zt=this.zt.insert(t.key,this.he(t.key).add(e))}Yt(e,t,n){if(!this.te(e))return;const r=this.Zt(e);this.ae(e,t)?r.Bt(t,1):r.Lt(t),this.zt=this.zt.insert(t,this.he(t).delete(e)),n&&(this.jt=this.jt.insert(t,n))}removeTarget(e){this.Qt.delete(e)}ie(e){const t=this.Zt(e).Ot();return this.Gt.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}qt(e){this.Zt(e).qt()}Zt(e){let t=this.Qt.get(e);return t||(t=new La,this.Qt.set(e,t)),t}he(e){let t=this.zt.get(e);return t||(t=new Qi(bi),this.zt=this.zt.insert(e,t)),t}te(e){const t=null!==this.se(e);return t||Xr("WatchChangeAggregator","Detected inactive target",e),t}se(e){const t=this.Qt.get(e);return t&&t.kt?null:this.Gt.le(e)}ee(e){this.Qt.set(e,new La),this.Gt.getRemoteKeysForTarget(e).forEach((t=>{this.Yt(e,t,null)}))}ae(e,t){return this.Gt.getRemoteKeysForTarget(e).has(t)}}function Ma(){return new Zi(Ii.comparator)}function qa(){return new Zi(Ii.comparator)}const Va=(()=>{const e={asc:"ASCENDING",desc:"DESCENDING"};return e})(),Ua=(()=>{const e={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"};return e})(),Ba=(()=>{const e={and:"AND",or:"OR"};return e})();class $a{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function ja(e,t){return e.useProto3Json||Vi(t)?t:{value:t}}function za(e,t){return e.useProto3Json?`${new Date(1e3*t.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+t.nanoseconds).slice(-9)}Z`:{seconds:""+t.seconds,nanos:t.nanoseconds}}function Ha(e,t){return e.useProto3Json?t.toBase64():t.toUint8Array()}function Ka(e,t){return za(e,t.toTimestamp())}function Wa(e){return ii(!!e),Si.fromTimestamp(function(e){const t=ro(e);return new _i(t.seconds,t.nanos)}(e))}function Za(e,t){return function(e){return new ki(["projects",e.projectId,"databases",e.database])}(e).child("documents").child(t).canonicalString()}function Ga(e){const t=ki.fromString(e);return ii(yl(t)),t}function Ja(e,t){return Za(e.databaseId,t.path)}function Qa(e,t){const n=Ga(t);if(n.get(1)!==e.databaseId.projectId)throw new ai(si.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+n.get(1)+" vs "+e.databaseId.projectId);if(n.get(3)!==e.databaseId.database)throw new ai(si.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+n.get(3)+" vs "+e.databaseId.database);return new Ii(tl(n))}function Ya(e,t){return Za(e.databaseId,t)}function Xa(e){const t=Ga(e);return 4===t.length?ki.emptyPath():tl(t)}function el(e){return new ki(["projects",e.databaseId.projectId,"databases",e.databaseId.database]).canonicalString()}function tl(e){return ii(e.length>4&&"documents"===e.get(4)),e.popFirst(5)}function nl(e,t,n){return{name:Ja(e,t),fields:n.value.mapValue.fields}}function rl(e,t){let n;if("targetChange"in t){t.targetChange;const r=function(e){return"NO_CHANGE"===e?0:"ADD"===e?1:"REMOVE"===e?2:"CURRENT"===e?3:"RESET"===e?4:ri()}(t.targetChange.targetChangeType||"NO_CHANGE"),i=t.targetChange.targetIds||[],o=function(e,t){return e.useProto3Json?(ii(void 0===t||"string"==typeof t),to.fromBase64String(t||"")):(ii(void 0===t||t instanceof Uint8Array),to.fromUint8Array(t||new Uint8Array))}(e,t.targetChange.resumeToken),s=t.targetChange.cause,a=s&&function(e){const t=void 0===e.code?si.UNKNOWN:_a(e.code);return new ai(t,e.message||"")}(s);n=new Fa(r,i,o,a||null)}else if("documentChange"in t){t.documentChange;const r=t.documentChange;r.document,r.document.name,r.document.updateTime;const i=Qa(e,r.document.name),o=Wa(r.document.updateTime),s=r.document.createTime?Wa(r.document.createTime):Si.min(),a=new xo({mapValue:{fields:r.document.fields}}),l=Ro.newFoundDocument(i,o,s,a),u=r.targetIds||[],c=r.removedTargetIds||[];n=new Na(u,c,l.key,l)}else if("documentDelete"in t){t.documentDelete;const r=t.documentDelete;r.document;const i=Qa(e,r.document),o=r.readTime?Wa(r.readTime):Si.min(),s=Ro.newNoDocument(i,o),a=r.removedTargetIds||[];n=new Na([],a,s.key,s)}else if("documentRemove"in t){t.documentRemove;const r=t.documentRemove;r.document;const i=Qa(e,r.document),o=r.removedTargetIds||[];n=new Na([],o,i,null)}else{if(!("filter"in t))return ri();{t.filter;const e=t.filter;e.targetId;const{count:r=0,unchangedNames:i}=e,o=new va(r,i),s=e.targetId;n=new Pa(s,o)}}return n}function il(e,t){let n;if(t instanceof aa)n={update:nl(e,t.key,t.value)};else if(t instanceof ha)n={delete:Ja(e,t.key)};else if(t instanceof la)n={update:nl(e,t.key,t.data),updateMask:vl(t.fieldMask)};else{if(!(t instanceof fa))return ri();n={verify:Ja(e,t.key)}}return t.fieldTransforms.length>0&&(n.updateTransforms=t.fieldTransforms.map((e=>function(e,t){const n=t.transform;if(n instanceof js)return{fieldPath:t.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(n instanceof zs)return{fieldPath:t.field.canonicalString(),appendMissingElements:{values:n.elements}};if(n instanceof Ks)return{fieldPath:t.field.canonicalString(),removeAllFromArray:{values:n.elements}};if(n instanceof Zs)return{fieldPath:t.field.canonicalString(),increment:n.gt};throw ri()}(0,e)))),t.precondition.isNone||(n.currentDocument=function(e,t){return void 0!==t.updateTime?{updateTime:Ka(e,t.updateTime)}:void 0!==t.exists?{exists:t.exists}:ri()}(e,t.precondition)),n}function ol(e,t){return e&&e.length>0?(ii(void 0!==t),e.map((e=>function(e,t){let n=e.updateTime?Wa(e.updateTime):Wa(t);return n.isEqual(Si.min())&&(n=Wa(t)),new Ys(n,e.transformResults||[])}(e,t)))):[]}function sl(e,t){return{documents:[Ya(e,t.path)]}}function al(e,t){const n={structuredQuery:{}},r=t.path;null!==t.collectionGroup?(n.parent=Ya(e,r),n.structuredQuery.from=[{collectionId:t.collectionGroup,allDescendants:!0}]):(n.parent=Ya(e,r.popLast()),n.structuredQuery.from=[{collectionId:r.lastSegment()}]);const i=function(e){if(0!==e.length)return ml(qo.create(e,"and"))}(t.filters);i&&(n.structuredQuery.where=i);const o=function(e){if(0!==e.length)return e.map((e=>function(e){return{field:pl(e.field),direction:dl(e.dir)}}(e)))}(t.orderBy);o&&(n.structuredQuery.orderBy=o);const s=ja(e,t.limit);var a;return null!==s&&(n.structuredQuery.limit=s),t.startAt&&(n.structuredQuery.startAt={before:(a=t.startAt).inclusive,values:a.position}),t.endAt&&(n.structuredQuery.endAt=function(e){return{before:!e.inclusive,values:e.position}}(t.endAt)),n}function ll(e){let t=Xa(e.parent);const n=e.structuredQuery,r=n.from?n.from.length:0;let i=null;if(r>0){ii(1===r);const e=n.from[0];e.allDescendants?i=e.collectionId:t=t.child(e.collectionId)}let o=[];n.where&&(o=function(e){const t=cl(e);return t instanceof qo&&Uo(t)?t.getFilters():[t]}(n.where));let s=[];n.orderBy&&(s=n.orderBy.map((e=>function(e){return new Fo(gl(e.field),function(e){switch(e){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(e.direction))}(e))));let a=null;n.limit&&(a=function(e){let t;return t="object"==typeof e?e.value:e,Vi(t)?null:t}(n.limit));let l=null;n.startAt&&(l=function(e){const t=!!e.before,n=e.values||[];return new Oo(n,t)}(n.startAt));let u=null;return n.endAt&&(u=function(e){const t=!e.before,n=e.values||[];return new Oo(n,t)}(n.endAt)),os(t,i,s,o,a,"F",l,u)}function ul(e,t){const n=function(e){switch(e){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return ri()}}(t.purpose);return null==n?null:{"goog-listen-tags":n}}function cl(e){return void 0!==e.unaryFilter?function(e){switch(e.unaryFilter.op){case"IS_NAN":const t=gl(e.unaryFilter.field);return Mo.create(t,"==",{doubleValue:NaN});case"IS_NULL":const n=gl(e.unaryFilter.field);return Mo.create(n,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const r=gl(e.unaryFilter.field);return Mo.create(r,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const i=gl(e.unaryFilter.field);return Mo.create(i,"!=",{nullValue:"NULL_VALUE"});default:return ri()}}(e):void 0!==e.fieldFilter?function(e){return Mo.create(gl(e.fieldFilter.field),function(e){switch(e){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return ri()}}(e.fieldFilter.op),e.fieldFilter.value)}(e):void 0!==e.compositeFilter?function(e){return qo.create(e.compositeFilter.filters.map((e=>cl(e))),function(e){switch(e){case"AND":return"and";case"OR":return"or";default:return ri()}}(e.compositeFilter.op))}(e):ri()}function dl(e){return Va[e]}function hl(e){return Ua[e]}function fl(e){return Ba[e]}function pl(e){return{fieldPath:e.canonicalString()}}function gl(e){return Ci.fromServerFormat(e.fieldPath)}function ml(e){return e instanceof Mo?function(e){if("=="===e.op){if(ko(e.value))return{unaryFilter:{field:pl(e.field),op:"IS_NAN"}};if(Eo(e.value))return{unaryFilter:{field:pl(e.field),op:"IS_NULL"}}}else if("!="===e.op){if(ko(e.value))return{unaryFilter:{field:pl(e.field),op:"IS_NOT_NAN"}};if(Eo(e.value))return{unaryFilter:{field:pl(e.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:pl(e.field),op:hl(e.op),value:e.value}}}(e):e instanceof qo?function(e){const t=e.getFilters().map((e=>ml(e)));return 1===t.length?t[0]:{compositeFilter:{op:fl(e.op),filters:t}}}(e):ri()}function vl(e){const t=[];return e.fields.forEach((e=>t.push(e.canonicalString()))),{fieldPaths:t}}function yl(e){return e.length>=4&&"projects"===e.get(0)&&"databases"===e.get(2)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bl{constructor(e,t,n,r,i=Si.min(),o=Si.min(),s=to.EMPTY_BYTE_STRING,a=null){this.target=e,this.targetId=t,this.purpose=n,this.sequenceNumber=r,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=s,this.expectedCount=a}withSequenceNumber(e){return new bl(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new bl(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new bl(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new bl(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wl{constructor(e){this.fe=e}}function _l(e){const t=ll({parent:e.parent,structuredQuery:e.structuredQuery});return"LAST"===e.limitType?ps(t,t.limit,"L"):t}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sl{constructor(){}_e(e,t){this.me(e,t),t.ge()}me(e,t){if("nullValue"in e)this.ye(t,5);else if("booleanValue"in e)this.ye(t,10),t.pe(e.booleanValue?1:0);else if("integerValue"in e)this.ye(t,15),t.pe(io(e.integerValue));else if("doubleValue"in e){const n=io(e.doubleValue);isNaN(n)?this.ye(t,13):(this.ye(t,15),Ui(n)?t.pe(0):t.pe(n))}else if("timestampValue"in e){const n=e.timestampValue;this.ye(t,20),"string"==typeof n?t.Ie(n):(t.Ie(`${n.seconds||""}`),t.pe(n.nanos||0))}else if("stringValue"in e)this.Te(e.stringValue,t),this.Ee(t);else if("bytesValue"in e)this.ye(t,30),t.Ae(oo(e.bytesValue)),this.Ee(t);else if("referenceValue"in e)this.ve(e.referenceValue,t);else if("geoPointValue"in e){const n=e.geoPointValue;this.ye(t,45),t.pe(n.latitude||0),t.pe(n.longitude||0)}else"mapValue"in e?Io(e)?this.ye(t,Number.MAX_SAFE_INTEGER):(this.Re(e.mapValue,t),this.Ee(t)):"arrayValue"in e?(this.Pe(e.arrayValue,t),this.Ee(t)):ri()}Te(e,t){this.ye(t,25),this.be(e,t)}be(e,t){t.Ie(e)}Re(e,t){const n=e.fields||{};this.ye(t,55);for(const r of Object.keys(n))this.Te(r,t),this.me(n[r],t)}Pe(e,t){const n=e.values||[];this.ye(t,50);for(const r of n)this.me(r,t)}ve(e,t){this.ye(t,37),Ii.fromName(e).path.forEach((e=>{this.ye(t,60),this.be(e,t)}))}ye(e,t){e.pe(t)}Ee(e){e.pe(2)}}Sl.Ve=new Sl;
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class El{constructor(){this.rn=new kl}addToCollectionParentIndex(e,t){return this.rn.add(t),Di.resolve()}getCollectionParents(e,t){return Di.resolve(this.rn.getEntries(t))}addFieldIndex(e,t){return Di.resolve()}deleteFieldIndex(e,t){return Di.resolve()}getDocumentsMatchingTarget(e,t){return Di.resolve(null)}getIndexType(e,t){return Di.resolve(0)}getFieldIndexes(e,t){return Di.resolve([])}getNextCollectionGroupToUpdate(e){return Di.resolve(null)}getMinOffset(e,t){return Di.resolve(Oi.min())}getMinOffsetFromCollectionGroup(e,t){return Di.resolve(Oi.min())}updateCollectionGroup(e,t,n){return Di.resolve()}updateIndexEntries(e,t){return Di.resolve()}}class kl{constructor(){this.index={}}add(e){const t=e.lastSegment(),n=e.popLast(),r=this.index[t]||new Qi(ki.comparator),i=!r.has(n);return this.index[t]=r.add(n),i}has(e){const t=e.lastSegment(),n=e.popLast(),r=this.index[t];return r&&r.has(n)}getEntries(e){return(this.index[e]||new Qi(ki.comparator)).toArray()}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */new Uint8Array(0);class Tl{constructor(e,t,n){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=n}static withCacheSize(e){return new Tl(e,Tl.DEFAULT_COLLECTION_PERCENTILE,Tl.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Tl.DEFAULT_COLLECTION_PERCENTILE=10,Tl.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,Tl.DEFAULT=new Tl(41943040,Tl.DEFAULT_COLLECTION_PERCENTILE,Tl.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),Tl.DISABLED=new Tl(-1,0,0);
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cl{constructor(e){this.Nn=e}next(){return this.Nn+=2,this.Nn}static kn(){return new Cl(0)}static Mn(){return new Cl(-1)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(){this.changes=new Ss((e=>e.toString()),((e,t)=>e.isEqual(t))),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Ro.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const n=this.changes.get(t);return void 0!==n?Di.resolve(n):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Al{constructor(e,t,n,r){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=n,this.indexManager=r}getDocument(e,t){let n=null;return this.documentOverlayCache.getOverlay(e,t).next((r=>(n=r,this.remoteDocumentCache.getEntry(e,t)))).next((e=>(null!==n&&ia(n.mutation,e,Xi.empty(),_i.now()),e)))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next((t=>this.getLocalViewOfDocuments(e,t,Ps()).next((()=>t))))}getLocalViewOfDocuments(e,t,n=Ps()){const r=xs();return this.populateOverlays(e,r,t).next((()=>this.computeViews(e,t,r,n).next((e=>{let t=Cs();return e.forEach(((e,n)=>{t=t.insert(e,n.overlayedDocument)})),t}))))}getOverlayedDocuments(e,t){const n=xs();return this.populateOverlays(e,n,t).next((()=>this.computeViews(e,t,n,Ps())))}populateOverlays(e,t,n){const r=[];return n.forEach((e=>{t.has(e)||r.push(e)})),this.documentOverlayCache.getOverlays(e,r).next((e=>{e.forEach(((e,n)=>{t.set(e,n)}))}))}computeViews(e,t,n,r){let i=ks();const o=Rs(),s=Rs();return t.forEach(((e,t)=>{const s=n.get(t.key);r.has(t.key)&&(void 0===s||s.mutation instanceof la)?i=i.insert(t.key,t):void 0!==s?(o.set(t.key,s.mutation.getFieldMask()),ia(s.mutation,t,s.mutation.getFieldMask(),_i.now())):o.set(t.key,Xi.empty())})),this.recalculateAndSaveOverlays(e,i).next((e=>(e.forEach(((e,t)=>o.set(e,t))),t.forEach(((e,t)=>{var n;return s.set(e,new xl(t,null!==(n=o.get(e))&&void 0!==n?n:null))})),s)))}recalculateAndSaveOverlays(e,t){const n=Rs();let r=new Zi(((e,t)=>e-t)),i=Ps();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next((e=>{for(const i of e)i.keys().forEach((e=>{const o=t.get(e);if(null===o)return;let s=n.get(e)||Xi.empty();s=i.applyToLocalView(o,s),n.set(e,s);const a=(r.get(i.batchId)||Ps()).add(e);r=r.insert(i.batchId,a)}))})).next((()=>{const o=[],s=r.getReverseIterator();for(;s.hasNext();){const r=s.getNext(),a=r.key,l=r.value,u=As();l.forEach((e=>{if(!i.has(e)){const r=na(t.get(e),n.get(e));null!==r&&u.set(e,r),i=i.add(e)}})),o.push(this.documentOverlayCache.saveOverlays(e,a,u))}return Di.waitFor(o)})).next((()=>n))}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next((t=>this.recalculateAndSaveOverlays(e,t)))}getDocumentsMatchingQuery(e,t,n){return function(e){return Ii.isDocumentKey(e.path)&&null===e.collectionGroup&&0===e.filters.length}(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):cs(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,n):this.getDocumentsMatchingCollectionQuery(e,t,n)}getNextDocuments(e,t,n,r){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,n,r).next((i=>{const o=r-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,n.largestBatchId,r-i.size):Di.resolve(xs());let s=-1,a=i;return o.next((t=>Di.forEach(t,((t,n)=>(s<n.largestBatchId&&(s=n.largestBatchId),i.get(t)?Di.resolve():this.remoteDocumentCache.getEntry(e,t).next((e=>{a=a.insert(t,e)}))))).next((()=>this.populateOverlays(e,t,i))).next((()=>this.computeViews(e,a,t,Ps()))).next((e=>({batchId:s,changes:Is(e)})))))}))}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new Ii(t)).next((e=>{let t=Cs();return e.isFoundDocument()&&(t=t.insert(e.key,e)),t}))}getDocumentsMatchingCollectionGroupQuery(e,t,n){const r=t.collectionGroup;let i=Cs();return this.indexManager.getCollectionParents(e,r).next((o=>Di.forEach(o,(o=>{const s=function(e,t){return new is(t,null,e.explicitOrderBy.slice(),e.filters.slice(),e.limit,e.limitType,e.startAt,e.endAt)}(t,o.child(r));return this.getDocumentsMatchingCollectionQuery(e,s,n).next((e=>{e.forEach(((e,t)=>{i=i.insert(e,t)}))}))})).next((()=>i))))}getDocumentsMatchingCollectionQuery(e,t,n){let r;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,n.largestBatchId).next((i=>(r=i,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,r)))).next((e=>{r.forEach(((t,n)=>{const r=n.getKey();null===e.get(r)&&(e=e.insert(r,Ro.newInvalidDocument(r)))}));let n=Cs();return e.forEach(((e,i)=>{const o=r.get(e);void 0!==o&&ia(o.mutation,i,Xi.empty(),_i.now()),ys(t,i)&&(n=n.insert(e,i))})),n}))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rl{constructor(e){this.serializer=e,this.cs=new Map,this.hs=new Map}getBundleMetadata(e,t){return Di.resolve(this.cs.get(t))}saveBundleMetadata(e,t){var n;return this.cs.set(t.id,{id:(n=t).id,version:n.version,createTime:Wa(n.createTime)}),Di.resolve()}getNamedQuery(e,t){return Di.resolve(this.hs.get(t))}saveNamedQuery(e,t){return this.hs.set(t.name,function(e){return{name:e.name,query:_l(e.bundledQuery),readTime:Wa(e.readTime)}}(t)),Di.resolve()}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ol{constructor(){this.overlays=new Zi(Ii.comparator),this.ls=new Map}getOverlay(e,t){return Di.resolve(this.overlays.get(t))}getOverlays(e,t){const n=xs();return Di.forEach(t,(t=>this.getOverlay(e,t).next((e=>{null!==e&&n.set(t,e)})))).next((()=>n))}saveOverlays(e,t,n){return n.forEach(((n,r)=>{this.we(e,t,r)})),Di.resolve()}removeOverlaysForBatchId(e,t,n){const r=this.ls.get(n);return void 0!==r&&(r.forEach((e=>this.overlays=this.overlays.remove(e))),this.ls.delete(n)),Di.resolve()}getOverlaysForCollection(e,t,n){const r=xs(),i=t.length+1,o=new Ii(t.child("")),s=this.overlays.getIteratorFrom(o);for(;s.hasNext();){const e=s.getNext().value,o=e.getKey();if(!t.isPrefixOf(o.path))break;o.path.length===i&&e.largestBatchId>n&&r.set(e.getKey(),e)}return Di.resolve(r)}getOverlaysForCollectionGroup(e,t,n,r){let i=new Zi(((e,t)=>e-t));const o=this.overlays.getIterator();for(;o.hasNext();){const e=o.getNext().value;if(e.getKey().getCollectionGroup()===t&&e.largestBatchId>n){let t=i.get(e.largestBatchId);null===t&&(t=xs(),i=i.insert(e.largestBatchId,t)),t.set(e.getKey(),e)}}const s=xs(),a=i.getIterator();for(;a.hasNext();)if(a.getNext().value.forEach(((e,t)=>s.set(e,t))),s.size()>=r)break;return Di.resolve(s)}we(e,t,n){const r=this.overlays.get(n.key);if(null!==r){const e=this.ls.get(r.largestBatchId).delete(n.key);this.ls.set(r.largestBatchId,e)}this.overlays=this.overlays.insert(n.key,new ma(t,n));let i=this.ls.get(t);void 0===i&&(i=Ps(),this.ls.set(t,i)),this.ls.set(t,i.add(n.key))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nl{constructor(){this.fs=new Qi(Pl.ds),this.ws=new Qi(Pl._s)}isEmpty(){return this.fs.isEmpty()}addReference(e,t){const n=new Pl(e,t);this.fs=this.fs.add(n),this.ws=this.ws.add(n)}gs(e,t){e.forEach((e=>this.addReference(e,t)))}removeReference(e,t){this.ys(new Pl(e,t))}ps(e,t){e.forEach((e=>this.removeReference(e,t)))}Is(e){const t=new Ii(new ki([])),n=new Pl(t,e),r=new Pl(t,e+1),i=[];return this.ws.forEachInRange([n,r],(e=>{this.ys(e),i.push(e.key)})),i}Ts(){this.fs.forEach((e=>this.ys(e)))}ys(e){this.fs=this.fs.delete(e),this.ws=this.ws.delete(e)}Es(e){const t=new Ii(new ki([])),n=new Pl(t,e),r=new Pl(t,e+1);let i=Ps();return this.ws.forEachInRange([n,r],(e=>{i=i.add(e.key)})),i}containsKey(e){const t=new Pl(e,0),n=this.fs.firstAfterOrEqual(t);return null!==n&&e.isEqual(n.key)}}class Pl{constructor(e,t){this.key=e,this.As=t}static ds(e,t){return Ii.comparator(e.key,t.key)||bi(e.As,t.As)}static _s(e,t){return bi(e.As,t.As)||Ii.comparator(e.key,t.key)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fl{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.vs=1,this.Rs=new Qi(Pl.ds)}checkEmpty(e){return Di.resolve(0===this.mutationQueue.length)}addMutationBatch(e,t,n,r){const i=this.vs;this.vs++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new pa(i,t,n,r);this.mutationQueue.push(o);for(const s of r)this.Rs=this.Rs.add(new Pl(s.key,i)),this.indexManager.addToCollectionParentIndex(e,s.key.path.popLast());return Di.resolve(o)}lookupMutationBatch(e,t){return Di.resolve(this.Ps(t))}getNextMutationBatchAfterBatchId(e,t){const n=t+1,r=this.bs(n),i=r<0?0:r;return Di.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return Di.resolve(0===this.mutationQueue.length?-1:this.vs-1)}getAllMutationBatches(e){return Di.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const n=new Pl(t,0),r=new Pl(t,Number.POSITIVE_INFINITY),i=[];return this.Rs.forEachInRange([n,r],(e=>{const t=this.Ps(e.As);i.push(t)})),Di.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let n=new Qi(bi);return t.forEach((e=>{const t=new Pl(e,0),r=new Pl(e,Number.POSITIVE_INFINITY);this.Rs.forEachInRange([t,r],(e=>{n=n.add(e.As)}))})),Di.resolve(this.Vs(n))}getAllMutationBatchesAffectingQuery(e,t){const n=t.path,r=n.length+1;let i=n;Ii.isDocumentKey(i)||(i=i.child(""));const o=new Pl(new Ii(i),0);let s=new Qi(bi);return this.Rs.forEachWhile((e=>{const t=e.key.path;return!!n.isPrefixOf(t)&&(t.length===r&&(s=s.add(e.As)),!0)}),o),Di.resolve(this.Vs(s))}Vs(e){const t=[];return e.forEach((e=>{const n=this.Ps(e);null!==n&&t.push(n)})),t}removeMutationBatch(e,t){ii(0===this.Ss(t.batchId,"removed")),this.mutationQueue.shift();let n=this.Rs;return Di.forEach(t.mutations,(r=>{const i=new Pl(r.key,t.batchId);return n=n.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,r.key)})).next((()=>{this.Rs=n}))}Cn(e){}containsKey(e,t){const n=new Pl(t,0),r=this.Rs.firstAfterOrEqual(n);return Di.resolve(t.isEqual(r&&r.key))}performConsistencyCheck(e){return this.mutationQueue.length,Di.resolve()}Ss(e,t){return this.bs(e)}bs(e){return 0===this.mutationQueue.length?0:e-this.mutationQueue[0].batchId}Ps(e){const t=this.bs(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ll{constructor(e){this.Ds=e,this.docs=new Zi(Ii.comparator),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const n=t.key,r=this.docs.get(n),i=r?r.size:0,o=this.Ds(t);return this.docs=this.docs.insert(n,{document:t.mutableCopy(),size:o}),this.size+=o-i,this.indexManager.addToCollectionParentIndex(e,n.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const n=this.docs.get(t);return Di.resolve(n?n.document.mutableCopy():Ro.newInvalidDocument(t))}getEntries(e,t){let n=ks();return t.forEach((e=>{const t=this.docs.get(e);n=n.insert(e,t?t.document.mutableCopy():Ro.newInvalidDocument(e))})),Di.resolve(n)}getDocumentsMatchingQuery(e,t,n,r){let i=ks();const o=t.path,s=new Ii(o.child("")),a=this.docs.getIteratorFrom(s);for(;a.hasNext();){const{key:e,value:{document:s}}=a.getNext();if(!o.isPrefixOf(e.path))break;e.path.length>o.length+1||Ni(Ri(s),n)<=0||(r.has(s.key)||ys(t,s))&&(i=i.insert(s.key,s.mutableCopy()))}return Di.resolve(i)}getAllFromCollectionGroup(e,t,n,r){ri()}Cs(e,t){return Di.forEach(this.docs,(e=>t(e)))}newChangeBuffer(e){return new Dl(this)}getSize(e){return Di.resolve(this.size)}}class Dl extends Il{constructor(e){super(),this.os=e}applyChanges(e){const t=[];return this.changes.forEach(((n,r)=>{r.isValidDocument()?t.push(this.os.addEntry(e,r)):this.os.removeEntry(n)})),Di.waitFor(t)}getFromCache(e,t){return this.os.getEntry(e,t)}getAllFromCache(e,t){return this.os.getEntries(e,t)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ml{constructor(e){this.persistence=e,this.xs=new Ss((e=>ts(e)),ns),this.lastRemoteSnapshotVersion=Si.min(),this.highestTargetId=0,this.Ns=0,this.ks=new Nl,this.targetCount=0,this.Ms=Cl.kn()}forEachTarget(e,t){return this.xs.forEach(((e,n)=>t(n))),Di.resolve()}getLastRemoteSnapshotVersion(e){return Di.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return Di.resolve(this.Ns)}allocateTargetId(e){return this.highestTargetId=this.Ms.next(),Di.resolve(this.highestTargetId)}setTargetsMetadata(e,t,n){return n&&(this.lastRemoteSnapshotVersion=n),t>this.Ns&&(this.Ns=t),Di.resolve()}Fn(e){this.xs.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.Ms=new Cl(t),this.highestTargetId=t),e.sequenceNumber>this.Ns&&(this.Ns=e.sequenceNumber)}addTargetData(e,t){return this.Fn(t),this.targetCount+=1,Di.resolve()}updateTargetData(e,t){return this.Fn(t),Di.resolve()}removeTargetData(e,t){return this.xs.delete(t.target),this.ks.Is(t.targetId),this.targetCount-=1,Di.resolve()}removeTargets(e,t,n){let r=0;const i=[];return this.xs.forEach(((o,s)=>{s.sequenceNumber<=t&&null===n.get(s.targetId)&&(this.xs.delete(o),i.push(this.removeMatchingKeysForTargetId(e,s.targetId)),r++)})),Di.waitFor(i).next((()=>r))}getTargetCount(e){return Di.resolve(this.targetCount)}getTargetData(e,t){const n=this.xs.get(t)||null;return Di.resolve(n)}addMatchingKeys(e,t,n){return this.ks.gs(t,n),Di.resolve()}removeMatchingKeys(e,t,n){this.ks.ps(t,n);const r=this.persistence.referenceDelegate,i=[];return r&&t.forEach((t=>{i.push(r.markPotentiallyOrphaned(e,t))})),Di.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.ks.Is(t),Di.resolve()}getMatchingKeysForTargetId(e,t){const n=this.ks.Es(t);return Di.resolve(n)}containsKey(e,t){return Di.resolve(this.ks.containsKey(t))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ql{constructor(e,t){this.$s={},this.overlays={},this.Os=new qi(0),this.Fs=!1,this.Fs=!0,this.referenceDelegate=e(this),this.Bs=new Ml(this),this.indexManager=new El,this.remoteDocumentCache=function(e){return new Ll(e)}((e=>this.referenceDelegate.Ls(e))),this.serializer=new wl(t),this.qs=new Rl(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.Fs=!1,Promise.resolve()}get started(){return this.Fs}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new Ol,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let n=this.$s[e.toKey()];return n||(n=new Fl(t,this.referenceDelegate),this.$s[e.toKey()]=n),n}getTargetCache(){return this.Bs}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.qs}runTransaction(e,t,n){Xr("MemoryPersistence","Starting transaction:",e);const r=new Vl(this.Os.next());return this.referenceDelegate.Us(),n(r).next((e=>this.referenceDelegate.Ks(r).next((()=>e)))).toPromise().then((e=>(r.raiseOnCommittedEvent(),e)))}Gs(e,t){return Di.or(Object.values(this.$s).map((n=>()=>n.containsKey(e,t))))}}class Vl extends Fi{constructor(e){super(),this.currentSequenceNumber=e}}class Ul{constructor(e){this.persistence=e,this.Qs=new Nl,this.js=null}static zs(e){return new Ul(e)}get Ws(){if(this.js)return this.js;throw ri()}addReference(e,t,n){return this.Qs.addReference(n,t),this.Ws.delete(n.toString()),Di.resolve()}removeReference(e,t,n){return this.Qs.removeReference(n,t),this.Ws.add(n.toString()),Di.resolve()}markPotentiallyOrphaned(e,t){return this.Ws.add(t.toString()),Di.resolve()}removeTarget(e,t){this.Qs.Is(t.targetId).forEach((e=>this.Ws.add(e.toString())));const n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(e,t.targetId).next((e=>{e.forEach((e=>this.Ws.add(e.toString())))})).next((()=>n.removeTargetData(e,t)))}Us(){this.js=new Set}Ks(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return Di.forEach(this.Ws,(n=>{const r=Ii.fromPath(n);return this.Hs(e,r).next((e=>{e||t.removeEntry(r,Si.min())}))})).next((()=>(this.js=null,t.apply(e))))}updateLimboDocument(e,t){return this.Hs(e,t).next((e=>{e?this.Ws.delete(t.toString()):this.Ws.add(t.toString())}))}Ls(e){return 0}Hs(e,t){return Di.or([()=>Di.resolve(this.Qs.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Gs(e,t)])}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(e,t,n,r){this.targetId=e,this.fromCache=t,this.Fi=n,this.Bi=r}static Li(e,t){let n=Ps(),r=Ps();for(const i of t.docChanges)switch(i.type){case 0:n=n.add(i.doc.key);break;case 1:r=r.add(i.doc.key)}return new Bl(e,t.fromCache,n,r)}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $l{constructor(){this.qi=!1}initialize(e,t){this.Ui=e,this.indexManager=t,this.qi=!0}getDocumentsMatchingQuery(e,t,n,r){return this.Ki(e,t).next((i=>i||this.Gi(e,t,r,n))).next((n=>n||this.Qi(e,t)))}Ki(e,t){if(as(t))return Di.resolve(null);let n=hs(t);return this.indexManager.getIndexType(e,n).next((r=>0===r?null:(null!==t.limit&&1===r&&(t=ps(t,null,"F"),n=hs(t)),this.indexManager.getDocumentsMatchingTarget(e,n).next((r=>{const i=Ps(...r);return this.Ui.getDocuments(e,i).next((r=>this.indexManager.getMinOffset(e,n).next((n=>{const o=this.ji(t,r);return this.zi(t,o,i,n.readTime)?this.Ki(e,ps(t,null,"F")):this.Wi(e,o,t,n)}))))})))))}Gi(e,t,n,r){return as(t)||r.isEqual(Si.min())?this.Qi(e,t):this.Ui.getDocuments(e,n).next((i=>{const o=this.ji(t,i);return this.zi(t,o,n,r)?this.Qi(e,t):(Yr()<=s["in"].DEBUG&&Xr("QueryEngine","Re-using previous result from %s to execute query: %s",r.toString(),vs(t)),this.Wi(e,o,t,Ai(r,-1)))}))}ji(e,t){let n=new Qi(ws(e));return t.forEach(((t,r)=>{ys(e,r)&&(n=n.add(r))})),n}zi(e,t,n,r){if(null===e.limit)return!1;if(n.size!==t.size)return!0;const i="F"===e.limitType?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(r)>0)}Qi(e,t){return Yr()<=s["in"].DEBUG&&Xr("QueryEngine","Using full collection scan to execute query:",vs(t)),this.Ui.getDocumentsMatchingQuery(e,t,Oi.min())}Wi(e,t,n,r){return this.Ui.getDocumentsMatchingQuery(e,n,r).next((e=>(t.forEach((t=>{e=e.insert(t.key,t)})),e)))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jl{constructor(e,t,n,r){this.persistence=e,this.Hi=t,this.serializer=r,this.Ji=new Zi(bi),this.Yi=new Ss((e=>ts(e)),ns),this.Xi=new Map,this.Zi=e.getRemoteDocumentCache(),this.Bs=e.getTargetCache(),this.qs=e.getBundleCache(),this.tr(n)}tr(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new Al(this.Zi,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.Zi.setIndexManager(this.indexManager),this.Hi.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",(t=>e.collect(t,this.Ji)))}}function zl(e,t,n,r){return new jl(e,t,n,r)}async function Hl(e,t){const n=oi(e);return await n.persistence.runTransaction("Handle user change","readonly",(e=>{let r;return n.mutationQueue.getAllMutationBatches(e).next((i=>(r=i,n.tr(t),n.mutationQueue.getAllMutationBatches(e)))).next((t=>{const i=[],o=[];let s=Ps();for(const e of r){i.push(e.batchId);for(const t of e.mutations)s=s.add(t.key)}for(const e of t){o.push(e.batchId);for(const t of e.mutations)s=s.add(t.key)}return n.localDocuments.getDocuments(e,s).next((e=>({er:e,removedBatchIds:i,addedBatchIds:o})))}))}))}function Kl(e,t){const n=oi(e);return n.persistence.runTransaction("Acknowledge batch","readwrite-primary",(e=>{const r=t.batch.keys(),i=n.Zi.newChangeBuffer({trackRemovals:!0});return function(e,t,n,r){const i=n.batch,o=i.keys();let s=Di.resolve();return o.forEach((e=>{s=s.next((()=>r.getEntry(t,e))).next((t=>{const o=n.docVersions.get(e);ii(null!==o),t.version.compareTo(o)<0&&(i.applyToRemoteDocument(t,n),t.isValidDocument()&&(t.setReadTime(n.commitVersion),r.addEntry(t)))}))})),s.next((()=>e.mutationQueue.removeMutationBatch(t,i)))}(n,e,t,i).next((()=>i.apply(e))).next((()=>n.mutationQueue.performConsistencyCheck(e))).next((()=>n.documentOverlayCache.removeOverlaysForBatchId(e,r,t.batch.batchId))).next((()=>n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(e,function(e){let t=Ps();for(let n=0;n<e.mutationResults.length;++n)e.mutationResults[n].transformResults.length>0&&(t=t.add(e.batch.mutations[n].key));return t}(t)))).next((()=>n.localDocuments.getDocuments(e,r)))}))}function Wl(e){const t=oi(e);return t.persistence.runTransaction("Get last remote snapshot version","readonly",(e=>t.Bs.getLastRemoteSnapshotVersion(e)))}function Zl(e,t){const n=oi(e),r=t.snapshotVersion;let i=n.Ji;return n.persistence.runTransaction("Apply remote event","readwrite-primary",(e=>{const o=n.Zi.newChangeBuffer({trackRemovals:!0});i=n.Ji;const s=[];t.targetChanges.forEach(((o,a)=>{const l=i.get(a);if(!l)return;s.push(n.Bs.removeMatchingKeys(e,o.removedDocuments,a).next((()=>n.Bs.addMatchingKeys(e,o.addedDocuments,a))));let u=l.withSequenceNumber(e.currentSequenceNumber);null!==t.targetMismatches.get(a)?u=u.withResumeToken(to.EMPTY_BYTE_STRING,Si.min()).withLastLimboFreeSnapshotVersion(Si.min()):o.resumeToken.approximateByteSize()>0&&(u=u.withResumeToken(o.resumeToken,r)),i=i.insert(a,u),function(e,t,n){return 0===e.resumeToken.approximateByteSize()||(t.snapshotVersion.toMicroseconds()-e.snapshotVersion.toMicroseconds()>=3e8||n.addedDocuments.size+n.modifiedDocuments.size+n.removedDocuments.size>0)}(l,u,o)&&s.push(n.Bs.updateTargetData(e,u))}));let a=ks(),l=Ps();if(t.documentUpdates.forEach((r=>{t.resolvedLimboDocuments.has(r)&&s.push(n.persistence.referenceDelegate.updateLimboDocument(e,r))})),s.push(Gl(e,o,t.documentUpdates).next((e=>{a=e.nr,l=e.sr}))),!r.isEqual(Si.min())){const t=n.Bs.getLastRemoteSnapshotVersion(e).next((t=>n.Bs.setTargetsMetadata(e,e.currentSequenceNumber,r)));s.push(t)}return Di.waitFor(s).next((()=>o.apply(e))).next((()=>n.localDocuments.getLocalViewOfDocuments(e,a,l))).next((()=>a))})).then((e=>(n.Ji=i,e)))}function Gl(e,t,n){let r=Ps(),i=Ps();return n.forEach((e=>r=r.add(e))),t.getEntries(e,r).next((e=>{let r=ks();return n.forEach(((n,o)=>{const s=e.get(n);o.isFoundDocument()!==s.isFoundDocument()&&(i=i.add(n)),o.isNoDocument()&&o.version.isEqual(Si.min())?(t.removeEntry(n,o.readTime),r=r.insert(n,o)):!s.isValidDocument()||o.version.compareTo(s.version)>0||0===o.version.compareTo(s.version)&&s.hasPendingWrites?(t.addEntry(o),r=r.insert(n,o)):Xr("LocalStore","Ignoring outdated watch update for ",n,". Current version:",s.version," Watch version:",o.version)})),{nr:r,sr:i}}))}function Jl(e,t){const n=oi(e);return n.persistence.runTransaction("Get next mutation batch","readonly",(e=>(void 0===t&&(t=-1),n.mutationQueue.getNextMutationBatchAfterBatchId(e,t))))}function Ql(e,t){const n=oi(e);return n.persistence.runTransaction("Allocate target","readwrite",(e=>{let r;return n.Bs.getTargetData(e,t).next((i=>i?(r=i,Di.resolve(r)):n.Bs.allocateTargetId(e).next((i=>(r=new bl(t,i,"TargetPurposeListen",e.currentSequenceNumber),n.Bs.addTargetData(e,r).next((()=>r)))))))})).then((e=>{const r=n.Ji.get(e.targetId);return(null===r||e.snapshotVersion.compareTo(r.snapshotVersion)>0)&&(n.Ji=n.Ji.insert(e.targetId,e),n.Yi.set(t,e.targetId)),e}))}async function Yl(e,t,n){const r=oi(e),i=r.Ji.get(t),o=n?"readwrite":"readwrite-primary";try{n||await r.persistence.runTransaction("Release target",o,(e=>r.persistence.referenceDelegate.removeTarget(e,i)))}catch(e){if(!Mi(e))throw e;Xr("LocalStore",`Failed to update sequence numbers for target ${t}: ${e}`)}r.Ji=r.Ji.remove(t),r.Yi.delete(i.target)}function Xl(e,t,n){const r=oi(e);let i=Si.min(),o=Ps();return r.persistence.runTransaction("Execute query","readonly",(e=>function(e,t,n){const r=oi(e),i=r.Yi.get(n);return void 0!==i?Di.resolve(r.Ji.get(i)):r.Bs.getTargetData(t,n)}(r,e,hs(t)).next((t=>{if(t)return i=t.lastLimboFreeSnapshotVersion,r.Bs.getMatchingKeysForTargetId(e,t.targetId).next((e=>{o=e}))})).next((()=>r.Hi.getDocumentsMatchingQuery(e,t,n?i:Si.min(),n?o:Ps()))).next((e=>(eu(r,bs(t),e),{documents:e,ir:o})))))}function eu(e,t,n){let r=e.Xi.get(t)||Si.min();n.forEach(((e,t)=>{t.readTime.compareTo(r)>0&&(r=t.readTime)})),e.Xi.set(t,r)}class tu{constructor(){this.activeTargetIds=Ls()}lr(e){this.activeTargetIds=this.activeTargetIds.add(e)}dr(e){this.activeTargetIds=this.activeTargetIds.delete(e)}hr(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class nu{constructor(){this.Hr=new tu,this.Jr={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,n){}addLocalQueryTarget(e){return this.Hr.lr(e),this.Jr[e]||"not-current"}updateQueryState(e,t,n){this.Jr[e]=t}removeLocalQueryTarget(e){this.Hr.dr(e)}isLocalQueryTarget(e){return this.Hr.activeTargetIds.has(e)}clearQueryState(e){delete this.Jr[e]}getAllActiveQueryTargets(){return this.Hr.activeTargetIds}isActiveQueryTarget(e){return this.Hr.activeTargetIds.has(e)}start(){return this.Hr=new tu,Promise.resolve()}handleUserChange(e,t,n){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ru{Yr(e){}shutdown(){}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iu{constructor(){this.Xr=()=>this.Zr(),this.eo=()=>this.no(),this.so=[],this.io()}Yr(e){this.so.push(e)}shutdown(){window.removeEventListener("online",this.Xr),window.removeEventListener("offline",this.eo)}io(){window.addEventListener("online",this.Xr),window.addEventListener("offline",this.eo)}Zr(){Xr("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(const e of this.so)e(0)}no(){Xr("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(const e of this.so)e(1)}static D(){return"undefined"!=typeof window&&void 0!==window.addEventListener&&void 0!==window.removeEventListener}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ou=null;function su(){return null===ou?ou=268435456+Math.round(2147483648*Math.random()):ou++,"0x"+ou.toString(16)
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}const au={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lu{constructor(e){this.ro=e.ro,this.oo=e.oo}uo(e){this.co=e}ao(e){this.ho=e}onMessage(e){this.lo=e}close(){this.oo()}send(e){this.ro(e)}fo(){this.co()}wo(e){this.ho(e)}_o(e){this.lo(e)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uu="WebChannelConnection";class cu extends class{constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http";this.mo=t+"://"+e.host,this.yo="projects/"+this.databaseId.projectId+"/databases/"+this.databaseId.database+"/documents"}get po(){return!1}Io(e,t,n,r,i){const o=su(),s=this.To(e,t);Xr("RestConnection",`Sending RPC '${e}' ${o}:`,s,n);const a={};return this.Eo(a,r,i),this.Ao(e,s,a,n).then((t=>(Xr("RestConnection",`Received RPC '${e}' ${o}: `,t),t)),(t=>{throw ti("RestConnection",`RPC '${e}' ${o} failed with error: `,t,"url: ",s,"request:",n),t}))}vo(e,t,n,r,i,o){return this.Io(e,t,n,r,i)}Eo(e,t,n){e["X-Goog-Api-Client"]="gl-js/ fire/"+Jr,e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach(((t,n)=>e[n]=t)),n&&n.headers.forEach(((t,n)=>e[n]=t))}To(e,t){const n=au[e];return`${this.mo}/v1/${t}:${n}`}}{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}Ao(e,t,n,r){const i=su();return new Promise(((o,s)=>{const a=new Hr;a.setWithCredentials(!0),a.listenOnce(Ur.COMPLETE,(()=>{try{switch(a.getLastErrorCode()){case Vr.NO_ERROR:const t=a.getResponseJson();Xr(uu,`XHR for RPC '${e}' ${i} received:`,JSON.stringify(t)),o(t);break;case Vr.TIMEOUT:Xr(uu,`RPC '${e}' ${i} timed out`),s(new ai(si.DEADLINE_EXCEEDED,"Request time out"));break;case Vr.HTTP_ERROR:const n=a.getStatus();if(Xr(uu,`RPC '${e}' ${i} failed with status:`,n,"response text:",a.getResponseText()),n>0){let e=a.getResponseJson();Array.isArray(e)&&(e=e[0]);const t=null==e?void 0:e.error;if(t&&t.status&&t.message){const e=function(e){const t=e.toLowerCase().replace(/_/g,"-");return Object.values(si).indexOf(t)>=0?t:si.UNKNOWN}(t.status);s(new ai(e,t.message))}else s(new ai(si.UNKNOWN,"Server responded with status "+a.getStatus()))}else s(new ai(si.UNAVAILABLE,"Connection failed."));break;default:ri()}}finally{Xr(uu,`RPC '${e}' ${i} completed.`)}}));const l=JSON.stringify(r);Xr(uu,`RPC '${e}' ${i} sending request:`,r),a.send(t,"POST",l,n,15)}))}Ro(e,t,n){const r=su(),i=[this.mo,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=Mr(),s=qr(),a={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},l=this.longPollingOptions.timeoutSeconds;void 0!==l&&(a.longPollingTimeout=Math.round(1e3*l)),this.useFetchStreams&&(a.xmlHttpFactory=new jr({})),this.Eo(a.initMessageHeaders,t,n),a.encodeInitMessageHeaders=!0;const u=i.join("");Xr(uu,`Creating RPC '${e}' stream ${r}: ${u}`,a);const c=o.createWebChannel(u,a);let d=!1,h=!1;const f=new lu({ro:t=>{h?Xr(uu,`Not sending because RPC '${e}' stream ${r} is closed:`,t):(d||(Xr(uu,`Opening RPC '${e}' stream ${r} transport.`),c.open(),d=!0),Xr(uu,`RPC '${e}' stream ${r} sending:`,t),c.send(t))},oo:()=>c.close()}),p=(e,t,n)=>{e.listen(t,(e=>{try{n(e)}catch(e){setTimeout((()=>{throw e}),0)}}))};return p(c,zr.EventType.OPEN,(()=>{h||Xr(uu,`RPC '${e}' stream ${r} transport opened.`)})),p(c,zr.EventType.CLOSE,(()=>{h||(h=!0,Xr(uu,`RPC '${e}' stream ${r} transport closed`),f.wo())})),p(c,zr.EventType.ERROR,(t=>{h||(h=!0,ti(uu,`RPC '${e}' stream ${r} transport errored:`,t),f.wo(new ai(si.UNAVAILABLE,"The operation could not be completed")))})),p(c,zr.EventType.MESSAGE,(t=>{var n;if(!h){const i=t.data[0];ii(!!i);const o=i,s=o.error||(null===(n=o[0])||void 0===n?void 0:n.error);if(s){Xr(uu,`RPC '${e}' stream ${r} received error:`,s);const t=s.status;let n=function(e){const t=ya[e];if(void 0!==t)return _a(t)}(t),i=s.message;void 0===n&&(n=si.INTERNAL,i="Unknown error status: "+t+" with message "+s.message),h=!0,f.wo(new ai(n,i)),c.close()}else Xr(uu,`RPC '${e}' stream ${r} received:`,i),f._o(i)}})),p(s,Br.STAT_EVENT,(t=>{t.stat===$r.PROXY?Xr(uu,`RPC '${e}' stream ${r} detected buffering proxy`):t.stat===$r.NOPROXY&&Xr(uu,`RPC '${e}' stream ${r} detected no buffering proxy`)})),setTimeout((()=>{f.fo()}),0),f}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function du(){return"undefined"!=typeof document?document:null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hu(e){return new $a(e,!0)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fu{constructor(e,t,n=1e3,r=1.5,i=6e4){this.ii=e,this.timerId=t,this.Po=n,this.bo=r,this.Vo=i,this.So=0,this.Do=null,this.Co=Date.now(),this.reset()}reset(){this.So=0}xo(){this.So=this.Vo}No(e){this.cancel();const t=Math.floor(this.So+this.ko()),n=Math.max(0,Date.now()-this.Co),r=Math.max(0,t-n);r>0&&Xr("ExponentialBackoff",`Backing off for ${r} ms (base delay: ${this.So} ms, delay with jitter: ${t} ms, last attempt: ${n} ms ago)`),this.Do=this.ii.enqueueAfterDelay(this.timerId,r,(()=>(this.Co=Date.now(),e()))),this.So*=this.bo,this.So<this.Po&&(this.So=this.Po),this.So>this.Vo&&(this.So=this.Vo)}Mo(){null!==this.Do&&(this.Do.skipDelay(),this.Do=null)}cancel(){null!==this.Do&&(this.Do.cancel(),this.Do=null)}ko(){return(Math.random()-.5)*this.So}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pu{constructor(e,t,n,r,i,o,s,a){this.ii=e,this.$o=n,this.Oo=r,this.connection=i,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=s,this.listener=a,this.state=0,this.Fo=0,this.Bo=null,this.Lo=null,this.stream=null,this.qo=new fu(e,t)}Uo(){return 1===this.state||5===this.state||this.Ko()}Ko(){return 2===this.state||3===this.state}start(){4!==this.state?this.auth():this.Go()}async stop(){this.Uo()&&await this.close(0)}Qo(){this.state=0,this.qo.reset()}jo(){this.Ko()&&null===this.Bo&&(this.Bo=this.ii.enqueueAfterDelay(this.$o,6e4,(()=>this.zo())))}Wo(e){this.Ho(),this.stream.send(e)}async zo(){if(this.Ko())return this.close(0)}Ho(){this.Bo&&(this.Bo.cancel(),this.Bo=null)}Jo(){this.Lo&&(this.Lo.cancel(),this.Lo=null)}async close(e,t){this.Ho(),this.Jo(),this.qo.cancel(),this.Fo++,4!==e?this.qo.reset():t&&t.code===si.RESOURCE_EXHAUSTED?(ei(t.toString()),ei("Using maximum backoff delay to prevent overloading the backend."),this.qo.xo()):t&&t.code===si.UNAUTHENTICATED&&3!==this.state&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),null!==this.stream&&(this.Yo(),this.stream.close(),this.stream=null),this.state=e,await this.listener.ao(t)}Yo(){}auth(){this.state=1;const e=this.Xo(this.Fo),t=this.Fo;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then((([e,n])=>{this.Fo===t&&this.Zo(e,n)}),(t=>{e((()=>{const e=new ai(si.UNKNOWN,"Fetching auth token failed: "+t.message);return this.tu(e)}))}))}Zo(e,t){const n=this.Xo(this.Fo);this.stream=this.eu(e,t),this.stream.uo((()=>{n((()=>(this.state=2,this.Lo=this.ii.enqueueAfterDelay(this.Oo,1e4,(()=>(this.Ko()&&(this.state=3),Promise.resolve()))),this.listener.uo())))})),this.stream.ao((e=>{n((()=>this.tu(e)))})),this.stream.onMessage((e=>{n((()=>this.onMessage(e)))}))}Go(){this.state=5,this.qo.No((async()=>{this.state=0,this.start()}))}tu(e){return Xr("PersistentStream",`close with error: ${e}`),this.stream=null,this.close(4,e)}Xo(e){return t=>{this.ii.enqueueAndForget((()=>this.Fo===e?t():(Xr("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve())))}}}class gu extends pu{constructor(e,t,n,r,i,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,n,r,o),this.serializer=i}eu(e,t){return this.connection.Ro("Listen",e,t)}onMessage(e){this.qo.reset();const t=rl(this.serializer,e),n=function(e){if(!("targetChange"in e))return Si.min();const t=e.targetChange;return t.targetIds&&t.targetIds.length?Si.min():t.readTime?Wa(t.readTime):Si.min()}(e);return this.listener.nu(t,n)}su(e){const t={};t.database=el(this.serializer),t.addTarget=function(e,t){let n;const r=t.target;if(n=rs(r)?{documents:sl(e,r)}:{query:al(e,r)},n.targetId=t.targetId,t.resumeToken.approximateByteSize()>0){n.resumeToken=Ha(e,t.resumeToken);const r=ja(e,t.expectedCount);null!==r&&(n.expectedCount=r)}else if(t.snapshotVersion.compareTo(Si.min())>0){n.readTime=za(e,t.snapshotVersion.toTimestamp());const r=ja(e,t.expectedCount);null!==r&&(n.expectedCount=r)}return n}(this.serializer,e);const n=ul(this.serializer,e);n&&(t.labels=n),this.Wo(t)}iu(e){const t={};t.database=el(this.serializer),t.removeTarget=e,this.Wo(t)}}class mu extends pu{constructor(e,t,n,r,i,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,n,r,o),this.serializer=i,this.ru=!1}get ou(){return this.ru}start(){this.ru=!1,this.lastStreamToken=void 0,super.start()}Yo(){this.ru&&this.uu([])}eu(e,t){return this.connection.Ro("Write",e,t)}onMessage(e){if(ii(!!e.streamToken),this.lastStreamToken=e.streamToken,this.ru){this.qo.reset();const t=ol(e.writeResults,e.commitTime),n=Wa(e.commitTime);return this.listener.cu(n,t)}return ii(!e.writeResults||0===e.writeResults.length),this.ru=!0,this.listener.au()}hu(){const e={};e.database=el(this.serializer),this.Wo(e)}uu(e){const t={streamToken:this.lastStreamToken,writes:e.map((e=>il(this.serializer,e)))};this.Wo(t)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vu extends class{}{constructor(e,t,n,r){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=n,this.serializer=r,this.lu=!1}fu(){if(this.lu)throw new ai(si.FAILED_PRECONDITION,"The client has already been terminated.")}Io(e,t,n){return this.fu(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([r,i])=>this.connection.Io(e,t,n,r,i))).catch((e=>{throw"FirebaseError"===e.name?(e.code===si.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),e):new ai(si.UNKNOWN,e.toString())}))}vo(e,t,n,r){return this.fu(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([i,o])=>this.connection.vo(e,t,n,i,o,r))).catch((e=>{throw"FirebaseError"===e.name?(e.code===si.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),e):new ai(si.UNKNOWN,e.toString())}))}terminate(){this.lu=!0}}class yu{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.wu=0,this._u=null,this.mu=!0}gu(){0===this.wu&&(this.yu("Unknown"),this._u=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,(()=>(this._u=null,this.pu("Backend didn't respond within 10 seconds."),this.yu("Offline"),Promise.resolve()))))}Iu(e){"Online"===this.state?this.yu("Unknown"):(this.wu++,this.wu>=1&&(this.Tu(),this.pu(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.yu("Offline")))}set(e){this.Tu(),this.wu=0,"Online"===e&&(this.mu=!1),this.yu(e)}yu(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}pu(e){const t=`Could not reach Cloud Firestore backend. ${e}\nThis typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.mu?(ei(t),this.mu=!1):Xr("OnlineStateTracker",t)}Tu(){null!==this._u&&(this._u.cancel(),this._u=null)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bu{constructor(e,t,n,r,i){this.localStore=e,this.datastore=t,this.asyncQueue=n,this.remoteSyncer={},this.Eu=[],this.Au=new Map,this.vu=new Set,this.Ru=[],this.Pu=i,this.Pu.Yr((e=>{n.enqueueAndForget((async()=>{xu(this)&&(Xr("RemoteStore","Restarting streams for network reachability change."),await async function(e){const t=oi(e);t.vu.add(4),await _u(t),t.bu.set("Unknown"),t.vu.delete(4),await wu(t)}(this))}))})),this.bu=new yu(n,r)}}async function wu(e){if(xu(e))for(const t of e.Ru)await t(!0)}async function _u(e){for(const t of e.Ru)await t(!1)}function Su(e,t){const n=oi(e);n.Au.has(t.targetId)||(n.Au.set(t.targetId,t),Iu(n)?Cu(n):Ku(n).Ko()&&ku(n,t))}function Eu(e,t){const n=oi(e),r=Ku(n);n.Au.delete(t),r.Ko()&&Tu(n,t),0===n.Au.size&&(r.Ko()?r.jo():xu(n)&&n.bu.set("Unknown"))}function ku(e,t){if(e.Vu.qt(t.targetId),t.resumeToken.approximateByteSize()>0||t.snapshotVersion.compareTo(Si.min())>0){const n=e.remoteSyncer.getRemoteKeysForTarget(t.targetId).size;t=t.withExpectedCount(n)}Ku(e).su(t)}function Tu(e,t){e.Vu.qt(t),Ku(e).iu(t)}function Cu(e){e.Vu=new Da({getRemoteKeysForTarget:t=>e.remoteSyncer.getRemoteKeysForTarget(t),le:t=>e.Au.get(t)||null,ue:()=>e.datastore.serializer.databaseId}),Ku(e).start(),e.bu.gu()}function Iu(e){return xu(e)&&!Ku(e).Uo()&&e.Au.size>0}function xu(e){return 0===oi(e).vu.size}function Au(e){e.Vu=void 0}async function Ru(e){e.Au.forEach(((t,n)=>{ku(e,t)}))}async function Ou(e,t){Au(e),Iu(e)?(e.bu.Iu(t),Cu(e)):e.bu.set("Unknown")}async function Nu(e,t,n){if(e.bu.set("Online"),t instanceof Fa&&2===t.state&&t.cause)try{await async function(e,t){const n=t.cause;for(const r of t.targetIds)e.Au.has(r)&&(await e.remoteSyncer.rejectListen(r,n),e.Au.delete(r),e.Vu.removeTarget(r))}(e,t)}catch(n){Xr("RemoteStore","Failed to remove targets %s: %s ",t.targetIds.join(","),n),await Pu(e,n)}else if(t instanceof Na?e.Vu.Ht(t):t instanceof Pa?e.Vu.ne(t):e.Vu.Xt(t),!n.isEqual(Si.min()))try{const t=await Wl(e.localStore);n.compareTo(t)>=0&&await function(e,t){const n=e.Vu.ce(t);return n.targetChanges.forEach(((n,r)=>{if(n.resumeToken.approximateByteSize()>0){const i=e.Au.get(r);i&&e.Au.set(r,i.withResumeToken(n.resumeToken,t))}})),n.targetMismatches.forEach(((t,n)=>{const r=e.Au.get(t);if(!r)return;e.Au.set(t,r.withResumeToken(to.EMPTY_BYTE_STRING,r.snapshotVersion)),Tu(e,t);const i=new bl(r.target,t,n,r.sequenceNumber);ku(e,i)})),e.remoteSyncer.applyRemoteEvent(n)}(e,n)}catch(t){Xr("RemoteStore","Failed to raise snapshot:",t),await Pu(e,t)}}async function Pu(e,t,n){if(!Mi(t))throw t;e.vu.add(1),await _u(e),e.bu.set("Offline"),n||(n=()=>Wl(e.localStore)),e.asyncQueue.enqueueRetryable((async()=>{Xr("RemoteStore","Retrying IndexedDB access"),await n(),e.vu.delete(1),await wu(e)}))}function Fu(e,t){return t().catch((n=>Pu(e,n,t)))}async function Lu(e){const t=oi(e),n=Wu(t);let r=t.Eu.length>0?t.Eu[t.Eu.length-1].batchId:-1;for(;Du(t);)try{const e=await Jl(t.localStore,r);if(null===e){0===t.Eu.length&&n.jo();break}r=e.batchId,Mu(t,e)}catch(e){await Pu(t,e)}qu(t)&&Vu(t)}function Du(e){return xu(e)&&e.Eu.length<10}function Mu(e,t){e.Eu.push(t);const n=Wu(e);n.Ko()&&n.ou&&n.uu(t.mutations)}function qu(e){return xu(e)&&!Wu(e).Uo()&&e.Eu.length>0}function Vu(e){Wu(e).start()}async function Uu(e){Wu(e).hu()}async function Bu(e){const t=Wu(e);for(const n of e.Eu)t.uu(n.mutations)}async function $u(e,t,n){const r=e.Eu.shift(),i=ga.from(r,t,n);await Fu(e,(()=>e.remoteSyncer.applySuccessfulWrite(i))),await Lu(e)}async function ju(e,t){t&&Wu(e).ou&&await async function(e,t){if(n=t.code,wa(n)&&n!==si.ABORTED){const n=e.Eu.shift();Wu(e).Qo(),await Fu(e,(()=>e.remoteSyncer.rejectFailedWrite(n.batchId,t))),await Lu(e)}var n}(e,t),qu(e)&&Vu(e)}async function zu(e,t){const n=oi(e);n.asyncQueue.verifyOperationInProgress(),Xr("RemoteStore","RemoteStore received new credentials");const r=xu(n);n.vu.add(3),await _u(n),r&&n.bu.set("Unknown"),await n.remoteSyncer.handleCredentialChange(t),n.vu.delete(3),await wu(n)}async function Hu(e,t){const n=oi(e);t?(n.vu.delete(2),await wu(n)):t||(n.vu.add(2),await _u(n),n.bu.set("Unknown"))}function Ku(e){return e.Su||(e.Su=function(e,t,n){const r=oi(e);return r.fu(),new gu(t,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,n)
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}(e.datastore,e.asyncQueue,{uo:Ru.bind(null,e),ao:Ou.bind(null,e),nu:Nu.bind(null,e)}),e.Ru.push((async t=>{t?(e.Su.Qo(),Iu(e)?Cu(e):e.bu.set("Unknown")):(await e.Su.stop(),Au(e))}))),e.Su}function Wu(e){return e.Du||(e.Du=function(e,t,n){const r=oi(e);return r.fu(),new mu(t,r.connection,r.authCredentials,r.appCheckCredentials,r.serializer,n)}(e.datastore,e.asyncQueue,{uo:Uu.bind(null,e),ao:ju.bind(null,e),au:Bu.bind(null,e),cu:$u.bind(null,e)}),e.Ru.push((async t=>{t?(e.Du.Qo(),await Lu(e)):(await e.Du.stop(),e.Eu.length>0&&(Xr("RemoteStore",`Stopping write stream with ${e.Eu.length} pending writes`),e.Eu=[]))}))),e.Du
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class Zu{constructor(e,t,n,r,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=n,this.op=r,this.removalCallback=i,this.deferred=new li,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch((e=>{}))}static createAndSchedule(e,t,n,r,i){const o=Date.now()+n,s=new Zu(e,t,o,r,i);return s.start(n),s}start(e){this.timerHandle=setTimeout((()=>this.handleDelayElapsed()),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){null!==this.timerHandle&&(this.clearTimeout(),this.deferred.reject(new ai(si.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget((()=>null!==this.timerHandle?(this.clearTimeout(),this.op().then((e=>this.deferred.resolve(e)))):Promise.resolve()))}clearTimeout(){null!==this.timerHandle&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Gu(e,t){if(ei("AsyncQueue",`${t}: ${e}`),Mi(e))return new ai(si.UNAVAILABLE,`${t}: ${e}`);throw e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ju{constructor(e){this.comparator=e?(t,n)=>e(t,n)||Ii.comparator(t.key,n.key):(e,t)=>Ii.comparator(e.key,t.key),this.keyedMap=Cs(),this.sortedSet=new Zi(this.comparator)}static emptySet(e){return new Ju(e.comparator)}has(e){return null!=this.keyedMap.get(e)}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal(((t,n)=>(e(t),!1)))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof Ju))return!1;if(this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),n=e.sortedSet.getIterator();for(;t.hasNext();){const e=t.getNext().key,r=n.getNext().key;if(!e.isEqual(r))return!1}return!0}toString(){const e=[];return this.forEach((t=>{e.push(t.toString())})),0===e.length?"DocumentSet ()":"DocumentSet (\n  "+e.join("  \n")+"\n)"}copy(e,t){const n=new Ju;return n.comparator=this.comparator,n.keyedMap=e,n.sortedSet=t,n}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qu{constructor(){this.Cu=new Zi(Ii.comparator)}track(e){const t=e.doc.key,n=this.Cu.get(t);n?0!==e.type&&3===n.type?this.Cu=this.Cu.insert(t,e):3===e.type&&1!==n.type?this.Cu=this.Cu.insert(t,{type:n.type,doc:e.doc}):2===e.type&&2===n.type?this.Cu=this.Cu.insert(t,{type:2,doc:e.doc}):2===e.type&&0===n.type?this.Cu=this.Cu.insert(t,{type:0,doc:e.doc}):1===e.type&&0===n.type?this.Cu=this.Cu.remove(t):1===e.type&&2===n.type?this.Cu=this.Cu.insert(t,{type:1,doc:n.doc}):0===e.type&&1===n.type?this.Cu=this.Cu.insert(t,{type:2,doc:e.doc}):ri():this.Cu=this.Cu.insert(t,e)}xu(){const e=[];return this.Cu.inorderTraversal(((t,n)=>{e.push(n)})),e}}class Yu{constructor(e,t,n,r,i,o,s,a,l){this.query=e,this.docs=t,this.oldDocs=n,this.docChanges=r,this.mutatedKeys=i,this.fromCache=o,this.syncStateChanged=s,this.excludesMetadataChanges=a,this.hasCachedResults=l}static fromInitialDocuments(e,t,n,r,i){const o=[];return t.forEach((e=>{o.push({type:0,doc:e})})),new Yu(e,t,Ju.emptySet(t),o,n,r,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&gs(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,n=e.docChanges;if(t.length!==n.length)return!1;for(let r=0;r<t.length;r++)if(t[r].type!==n[r].type||!t[r].doc.isEqual(n[r].doc))return!1;return!0}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xu{constructor(){this.Nu=void 0,this.listeners=[]}}class ec{constructor(){this.queries=new Ss((e=>ms(e)),gs),this.onlineState="Unknown",this.ku=new Set}}async function tc(e,t){const n=oi(e),r=t.query;let i=!1,o=n.queries.get(r);if(o||(i=!0,o=new Xu),i)try{o.Nu=await n.onListen(r)}catch(e){const n=Gu(e,`Initialization of query '${vs(t.query)}' failed`);return void t.onError(n)}n.queries.set(r,o),o.listeners.push(t),t.Mu(n.onlineState),o.Nu&&t.$u(o.Nu)&&oc(n)}async function nc(e,t){const n=oi(e),r=t.query;let i=!1;const o=n.queries.get(r);if(o){const e=o.listeners.indexOf(t);e>=0&&(o.listeners.splice(e,1),i=0===o.listeners.length)}if(i)return n.queries.delete(r),n.onUnlisten(r)}function rc(e,t){const n=oi(e);let r=!1;for(const i of t){const e=i.query,t=n.queries.get(e);if(t){for(const e of t.listeners)e.$u(i)&&(r=!0);t.Nu=i}}r&&oc(n)}function ic(e,t,n){const r=oi(e),i=r.queries.get(t);if(i)for(const o of i.listeners)o.onError(n);r.queries.delete(t)}function oc(e){e.ku.forEach((e=>{e.next()}))}class sc{constructor(e,t,n){this.query=e,this.Ou=t,this.Fu=!1,this.Bu=null,this.onlineState="Unknown",this.options=n||{}}$u(e){if(!this.options.includeMetadataChanges){const t=[];for(const n of e.docChanges)3!==n.type&&t.push(n);e=new Yu(e.query,e.docs,e.oldDocs,t,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Fu?this.Lu(e)&&(this.Ou.next(e),t=!0):this.qu(e,this.onlineState)&&(this.Uu(e),t=!0),this.Bu=e,t}onError(e){this.Ou.error(e)}Mu(e){this.onlineState=e;let t=!1;return this.Bu&&!this.Fu&&this.qu(this.Bu,e)&&(this.Uu(this.Bu),t=!0),t}qu(e,t){if(!e.fromCache)return!0;const n="Offline"!==t;return(!this.options.Ku||!n)&&(!e.docs.isEmpty()||e.hasCachedResults||"Offline"===t)}Lu(e){if(e.docChanges.length>0)return!0;const t=this.Bu&&this.Bu.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&!0===this.options.includeMetadataChanges}Uu(e){e=Yu.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Fu=!0,this.Ou.next(e)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ac{constructor(e){this.key=e}}class lc{constructor(e){this.key=e}}class uc{constructor(e,t){this.query=e,this.Yu=t,this.Xu=null,this.hasCachedResults=!1,this.current=!1,this.Zu=Ps(),this.mutatedKeys=Ps(),this.tc=ws(e),this.ec=new Ju(this.tc)}get nc(){return this.Yu}sc(e,t){const n=t?t.ic:new Qu,r=t?t.ec:this.ec;let i=t?t.mutatedKeys:this.mutatedKeys,o=r,s=!1;const a="F"===this.query.limitType&&r.size===this.query.limit?r.last():null,l="L"===this.query.limitType&&r.size===this.query.limit?r.first():null;if(e.inorderTraversal(((e,t)=>{const u=r.get(e),c=ys(this.query,t)?t:null,d=!!u&&this.mutatedKeys.has(u.key),h=!!c&&(c.hasLocalMutations||this.mutatedKeys.has(c.key)&&c.hasCommittedMutations);let f=!1;u&&c?u.data.isEqual(c.data)?d!==h&&(n.track({type:3,doc:c}),f=!0):this.rc(u,c)||(n.track({type:2,doc:c}),f=!0,(a&&this.tc(c,a)>0||l&&this.tc(c,l)<0)&&(s=!0)):!u&&c?(n.track({type:0,doc:c}),f=!0):u&&!c&&(n.track({type:1,doc:u}),f=!0,(a||l)&&(s=!0)),f&&(c?(o=o.add(c),i=h?i.add(e):i.delete(e)):(o=o.delete(e),i=i.delete(e)))})),null!==this.query.limit)for(;o.size>this.query.limit;){const e="F"===this.query.limitType?o.last():o.first();o=o.delete(e.key),i=i.delete(e.key),n.track({type:1,doc:e})}return{ec:o,ic:n,zi:s,mutatedKeys:i}}rc(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,n){const r=this.ec;this.ec=e.ec,this.mutatedKeys=e.mutatedKeys;const i=e.ic.xu();i.sort(((e,t)=>function(e,t){const n=e=>{switch(e){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return ri()}};return n(e)-n(t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(e.type,t.type)||this.tc(e.doc,t.doc))),this.oc(n);const o=t?this.uc():[],s=0===this.Zu.size&&this.current?1:0,a=s!==this.Xu;return this.Xu=s,0!==i.length||a?{snapshot:new Yu(this.query,e.ec,r,i,e.mutatedKeys,0===s,a,!1,!!n&&n.resumeToken.approximateByteSize()>0),cc:o}:{cc:o}}Mu(e){return this.current&&"Offline"===e?(this.current=!1,this.applyChanges({ec:this.ec,ic:new Qu,mutatedKeys:this.mutatedKeys,zi:!1},!1)):{cc:[]}}ac(e){return!this.Yu.has(e)&&!!this.ec.has(e)&&!this.ec.get(e).hasLocalMutations}oc(e){e&&(e.addedDocuments.forEach((e=>this.Yu=this.Yu.add(e))),e.modifiedDocuments.forEach((e=>{})),e.removedDocuments.forEach((e=>this.Yu=this.Yu.delete(e))),this.current=e.current)}uc(){if(!this.current)return[];const e=this.Zu;this.Zu=Ps(),this.ec.forEach((e=>{this.ac(e.key)&&(this.Zu=this.Zu.add(e.key))}));const t=[];return e.forEach((e=>{this.Zu.has(e)||t.push(new lc(e))})),this.Zu.forEach((n=>{e.has(n)||t.push(new ac(n))})),t}hc(e){this.Yu=e.ir,this.Zu=Ps();const t=this.sc(e.documents);return this.applyChanges(t,!0)}lc(){return Yu.fromInitialDocuments(this.query,this.ec,this.mutatedKeys,0===this.Xu,this.hasCachedResults)}}class cc{constructor(e,t,n){this.query=e,this.targetId=t,this.view=n}}class dc{constructor(e){this.key=e,this.fc=!1}}class hc{constructor(e,t,n,r,i,o){this.localStore=e,this.remoteStore=t,this.eventManager=n,this.sharedClientState=r,this.currentUser=i,this.maxConcurrentLimboResolutions=o,this.dc={},this.wc=new Ss((e=>ms(e)),gs),this._c=new Map,this.mc=new Set,this.gc=new Zi(Ii.comparator),this.yc=new Map,this.Ic=new Nl,this.Tc={},this.Ec=new Map,this.Ac=Cl.Mn(),this.onlineState="Unknown",this.vc=void 0}get isPrimaryClient(){return!0===this.vc}}async function fc(e,t){const n=Nc(e);let r,i;const o=n.wc.get(t);if(o)r=o.targetId,n.sharedClientState.addLocalQueryTarget(r),i=o.view.lc();else{const e=await Ql(n.localStore,hs(t)),o=n.sharedClientState.addLocalQueryTarget(e.targetId);r=e.targetId,i=await pc(n,t,r,"current"===o,e.resumeToken),n.isPrimaryClient&&Su(n.remoteStore,e)}return i}async function pc(e,t,n,r,i){e.Rc=(t,n,r)=>async function(e,t,n,r){let i=t.view.sc(n);i.zi&&(i=await Xl(e.localStore,t.query,!1).then((({documents:e})=>t.view.sc(e,i))));const o=r&&r.targetChanges.get(t.targetId),s=t.view.applyChanges(i,e.isPrimaryClient,o);return Cc(e,t.targetId,s.cc),s.snapshot}(e,t,n,r);const o=await Xl(e.localStore,t,!0),s=new uc(t,o.ir),a=s.sc(o.documents),l=Oa.createSynthesizedTargetChangeForCurrentChange(n,r&&"Offline"!==e.onlineState,i),u=s.applyChanges(a,e.isPrimaryClient,l);Cc(e,n,u.cc);const c=new cc(t,n,s);return e.wc.set(t,c),e._c.has(n)?e._c.get(n).push(t):e._c.set(n,[t]),u.snapshot}async function gc(e,t){const n=oi(e),r=n.wc.get(t),i=n._c.get(r.targetId);if(i.length>1)return n._c.set(r.targetId,i.filter((e=>!gs(e,t)))),void n.wc.delete(t);n.isPrimaryClient?(n.sharedClientState.removeLocalQueryTarget(r.targetId),n.sharedClientState.isActiveQueryTarget(r.targetId)||await Yl(n.localStore,r.targetId,!1).then((()=>{n.sharedClientState.clearQueryState(r.targetId),Eu(n.remoteStore,r.targetId),kc(n,r.targetId)})).catch(Li)):(kc(n,r.targetId),await Yl(n.localStore,r.targetId,!0))}async function mc(e,t,n){const r=Pc(e);try{const e=await function(e,t){const n=oi(e),r=_i.now(),i=t.reduce(((e,t)=>e.add(t.key)),Ps());let o,s;return n.persistence.runTransaction("Locally write mutations","readwrite",(e=>{let a=ks(),l=Ps();return n.Zi.getEntries(e,i).next((e=>{a=e,a.forEach(((e,t)=>{t.isValidDocument()||(l=l.add(e))}))})).next((()=>n.localDocuments.getOverlayedDocuments(e,a))).next((i=>{o=i;const s=[];for(const e of t){const t=oa(e,o.get(e.key).overlayedDocument);null!=t&&s.push(new la(e.key,t,Ao(t.value.mapValue),Xs.exists(!0)))}return n.mutationQueue.addMutationBatch(e,r,s,t)})).next((t=>{s=t;const r=t.applyToLocalDocumentSet(o,l);return n.documentOverlayCache.saveOverlays(e,t.batchId,r)}))})).then((()=>({batchId:s.batchId,changes:Is(o)})))}(r.localStore,t);r.sharedClientState.addPendingMutation(e.batchId),function(e,t,n){let r=e.Tc[e.currentUser.toKey()];r||(r=new Zi(bi)),r=r.insert(t,n),e.Tc[e.currentUser.toKey()]=r}(r,e.batchId,n),await Ac(r,e.changes),await Lu(r.remoteStore)}catch(e){const t=Gu(e,"Failed to persist write");n.reject(t)}}async function vc(e,t){const n=oi(e);try{const e=await Zl(n.localStore,t);t.targetChanges.forEach(((e,t)=>{const r=n.yc.get(t);r&&(ii(e.addedDocuments.size+e.modifiedDocuments.size+e.removedDocuments.size<=1),e.addedDocuments.size>0?r.fc=!0:e.modifiedDocuments.size>0?ii(r.fc):e.removedDocuments.size>0&&(ii(r.fc),r.fc=!1))})),await Ac(n,e,t)}catch(e){await Li(e)}}function yc(e,t,n){const r=oi(e);if(r.isPrimaryClient&&0===n||!r.isPrimaryClient&&1===n){const e=[];r.wc.forEach(((n,r)=>{const i=r.view.Mu(t);i.snapshot&&e.push(i.snapshot)})),function(e,t){const n=oi(e);n.onlineState=t;let r=!1;n.queries.forEach(((e,n)=>{for(const i of n.listeners)i.Mu(t)&&(r=!0)})),r&&oc(n)}(r.eventManager,t),e.length&&r.dc.nu(e),r.onlineState=t,r.isPrimaryClient&&r.sharedClientState.setOnlineState(t)}}async function bc(e,t,n){const r=oi(e);r.sharedClientState.updateQueryState(t,"rejected",n);const i=r.yc.get(t),o=i&&i.key;if(o){let e=new Zi(Ii.comparator);e=e.insert(o,Ro.newNoDocument(o,Si.min()));const n=Ps().add(o),i=new Ra(Si.min(),new Map,new Zi(bi),e,n);await vc(r,i),r.gc=r.gc.remove(o),r.yc.delete(t),xc(r)}else await Yl(r.localStore,t,!1).then((()=>kc(r,t,n))).catch(Li)}async function wc(e,t){const n=oi(e),r=t.batch.batchId;try{const e=await Kl(n.localStore,t);Ec(n,r,null),Sc(n,r),n.sharedClientState.updateMutationState(r,"acknowledged"),await Ac(n,e)}catch(e){await Li(e)}}async function _c(e,t,n){const r=oi(e);try{const e=await function(e,t){const n=oi(e);return n.persistence.runTransaction("Reject batch","readwrite-primary",(e=>{let r;return n.mutationQueue.lookupMutationBatch(e,t).next((t=>(ii(null!==t),r=t.keys(),n.mutationQueue.removeMutationBatch(e,t)))).next((()=>n.mutationQueue.performConsistencyCheck(e))).next((()=>n.documentOverlayCache.removeOverlaysForBatchId(e,r,t))).next((()=>n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(e,r))).next((()=>n.localDocuments.getDocuments(e,r)))}))}(r.localStore,t);Ec(r,t,n),Sc(r,t),r.sharedClientState.updateMutationState(t,"rejected",n),await Ac(r,e)}catch(n){await Li(n)}}function Sc(e,t){(e.Ec.get(t)||[]).forEach((e=>{e.resolve()})),e.Ec.delete(t)}function Ec(e,t,n){const r=oi(e);let i=r.Tc[r.currentUser.toKey()];if(i){const e=i.get(t);e&&(n?e.reject(n):e.resolve(),i=i.remove(t)),r.Tc[r.currentUser.toKey()]=i}}function kc(e,t,n=null){e.sharedClientState.removeLocalQueryTarget(t);for(const r of e._c.get(t))e.wc.delete(r),n&&e.dc.Pc(r,n);e._c.delete(t),e.isPrimaryClient&&e.Ic.Is(t).forEach((t=>{e.Ic.containsKey(t)||Tc(e,t)}))}function Tc(e,t){e.mc.delete(t.path.canonicalString());const n=e.gc.get(t);null!==n&&(Eu(e.remoteStore,n),e.gc=e.gc.remove(t),e.yc.delete(n),xc(e))}function Cc(e,t,n){for(const r of n)r instanceof ac?(e.Ic.addReference(r.key,t),Ic(e,r)):r instanceof lc?(Xr("SyncEngine","Document no longer in limbo: "+r.key),e.Ic.removeReference(r.key,t),e.Ic.containsKey(r.key)||Tc(e,r.key)):ri()}function Ic(e,t){const n=t.key,r=n.path.canonicalString();e.gc.get(n)||e.mc.has(r)||(Xr("SyncEngine","New document in limbo: "+n),e.mc.add(r),xc(e))}function xc(e){for(;e.mc.size>0&&e.gc.size<e.maxConcurrentLimboResolutions;){const t=e.mc.values().next().value;e.mc.delete(t);const n=new Ii(ki.fromString(t)),r=e.Ac.next();e.yc.set(r,new dc(n)),e.gc=e.gc.insert(n,r),Su(e.remoteStore,new bl(hs(ss(n.path)),r,"TargetPurposeLimboResolution",qi.ct))}}async function Ac(e,t,n){const r=oi(e),i=[],o=[],s=[];r.wc.isEmpty()||(r.wc.forEach(((e,a)=>{s.push(r.Rc(a,t,n).then((e=>{if((e||n)&&r.isPrimaryClient&&r.sharedClientState.updateQueryState(a.targetId,(null==e?void 0:e.fromCache)?"not-current":"current"),e){i.push(e);const t=Bl.Li(a.targetId,e);o.push(t)}})))})),await Promise.all(s),r.dc.nu(i),await async function(e,t){const n=oi(e);try{await n.persistence.runTransaction("notifyLocalViewChanges","readwrite",(e=>Di.forEach(t,(t=>Di.forEach(t.Fi,(r=>n.persistence.referenceDelegate.addReference(e,t.targetId,r))).next((()=>Di.forEach(t.Bi,(r=>n.persistence.referenceDelegate.removeReference(e,t.targetId,r)))))))))}catch(e){if(!Mi(e))throw e;Xr("LocalStore","Failed to update sequence numbers: "+e)}for(const r of t){const e=r.targetId;if(!r.fromCache){const t=n.Ji.get(e),r=t.snapshotVersion,i=t.withLastLimboFreeSnapshotVersion(r);n.Ji=n.Ji.insert(e,i)}}}(r.localStore,o))}async function Rc(e,t){const n=oi(e);if(!n.currentUser.isEqual(t)){Xr("SyncEngine","User change. New user:",t.toKey());const e=await Hl(n.localStore,t);n.currentUser=t,function(e,t){e.Ec.forEach((e=>{e.forEach((e=>{e.reject(new ai(si.CANCELLED,t))}))})),e.Ec.clear()}(n,"'waitForPendingWrites' promise is rejected due to a user change."),n.sharedClientState.handleUserChange(t,e.removedBatchIds,e.addedBatchIds),await Ac(n,e.er)}}function Oc(e,t){const n=oi(e),r=n.yc.get(t);if(r&&r.fc)return Ps().add(r.key);{let e=Ps();const r=n._c.get(t);if(!r)return e;for(const t of r){const r=n.wc.get(t);e=e.unionWith(r.view.nc)}return e}}function Nc(e){const t=oi(e);return t.remoteStore.remoteSyncer.applyRemoteEvent=vc.bind(null,t),t.remoteStore.remoteSyncer.getRemoteKeysForTarget=Oc.bind(null,t),t.remoteStore.remoteSyncer.rejectListen=bc.bind(null,t),t.dc.nu=rc.bind(null,t.eventManager),t.dc.Pc=ic.bind(null,t.eventManager),t}function Pc(e){const t=oi(e);return t.remoteStore.remoteSyncer.applySuccessfulWrite=wc.bind(null,t),t.remoteStore.remoteSyncer.rejectFailedWrite=_c.bind(null,t),t}class Fc{constructor(){this.synchronizeTabs=!1}async initialize(e){this.serializer=hu(e.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(e),this.persistence=this.createPersistence(e),await this.persistence.start(),this.localStore=this.createLocalStore(e),this.gcScheduler=this.createGarbageCollectionScheduler(e,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(e,this.localStore)}createGarbageCollectionScheduler(e,t){return null}createIndexBackfillerScheduler(e,t){return null}createLocalStore(e){return zl(this.persistence,new $l,e.initialUser,this.serializer)}createPersistence(e){return new ql(Ul.zs,this.serializer)}createSharedClientState(e){return new nu}async terminate(){this.gcScheduler&&this.gcScheduler.stop(),await this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class Lc{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=e=>yc(this.syncEngine,e,1),this.remoteStore.remoteSyncer.handleCredentialChange=Rc.bind(null,this.syncEngine),await Hu(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return new ec}createDatastore(e){const t=hu(e.databaseInfo.databaseId),n=(r=e.databaseInfo,new cu(r));var r;return function(e,t,n,r){return new vu(e,t,n,r)}(e.authCredentials,e.appCheckCredentials,n,t)}createRemoteStore(e){return t=this.localStore,n=this.datastore,r=e.asyncQueue,i=e=>yc(this.syncEngine,e,0),o=iu.D()?new iu:new ru,new bu(t,n,r,i,o);var t,n,r,i,o}createSyncEngine(e,t){return function(e,t,n,r,i,o,s){const a=new hc(e,t,n,r,i,o);return s&&(a.vc=!0),a}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}terminate(){return async function(e){const t=oi(e);Xr("RemoteStore","RemoteStore shutting down."),t.vu.add(5),await _u(t),t.Pu.shutdown(),t.bu.set("Unknown")}(this.remoteStore)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dc{constructor(e){this.observer=e,this.muted=!1}next(e){this.observer.next&&this.Sc(this.observer.next,e)}error(e){this.observer.error?this.Sc(this.observer.error,e):ei("Uncaught Error in snapshot listener:",e.toString())}Dc(){this.muted=!0}Sc(e,t){this.muted||setTimeout((()=>{this.muted||e(t)}),0)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mc{constructor(e,t,n,r){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=n,this.databaseInfo=r,this.user=Gr.UNAUTHENTICATED,this.clientId=yi.A(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(n,(async e=>{Xr("FirestoreClient","Received user=",e.uid),await this.authCredentialListener(e),this.user=e})),this.appCheckCredentials.start(n,(e=>(Xr("FirestoreClient","Received new app check token=",e),this.appCheckCredentialListener(e,this.user))))}async getConfiguration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new ai(si.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();const e=new li;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted((async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const n=Gu(t,"Failed to shutdown persistence");e.reject(n)}})),e.promise}}async function qc(e,t){e.asyncQueue.verifyOperationInProgress(),Xr("FirestoreClient","Initializing OfflineComponentProvider");const n=await e.getConfiguration();await t.initialize(n);let r=n.initialUser;e.setCredentialChangeListener((async e=>{r.isEqual(e)||(await Hl(t.localStore,e),r=e)})),t.persistence.setDatabaseDeletedListener((()=>e.terminate())),e._offlineComponents=t}async function Vc(e,t){e.asyncQueue.verifyOperationInProgress();const n=await Bc(e);Xr("FirestoreClient","Initializing OnlineComponentProvider");const r=await e.getConfiguration();await t.initialize(n,r),e.setCredentialChangeListener((e=>zu(t.remoteStore,e))),e.setAppCheckTokenChangeListener(((e,n)=>zu(t.remoteStore,n))),e._onlineComponents=t}function Uc(e){return"FirebaseError"===e.name?e.code===si.FAILED_PRECONDITION||e.code===si.UNIMPLEMENTED:!("undefined"!=typeof DOMException&&e instanceof DOMException)||22===e.code||20===e.code||11===e.code}async function Bc(e){if(!e._offlineComponents)if(e._uninitializedComponentsProvider){Xr("FirestoreClient","Using user provided OfflineComponentProvider");try{await qc(e,e._uninitializedComponentsProvider._offline)}catch(t){const n=t;if(!Uc(n))throw n;ti("Error using user provided cache. Falling back to memory cache: "+n),await qc(e,new Fc)}}else Xr("FirestoreClient","Using default OfflineComponentProvider"),await qc(e,new Fc);return e._offlineComponents}async function $c(e){return e._onlineComponents||(e._uninitializedComponentsProvider?(Xr("FirestoreClient","Using user provided OnlineComponentProvider"),await Vc(e,e._uninitializedComponentsProvider._online)):(Xr("FirestoreClient","Using default OnlineComponentProvider"),await Vc(e,new Lc))),e._onlineComponents}function jc(e){return $c(e).then((e=>e.syncEngine))}async function zc(e){const t=await $c(e),n=t.eventManager;return n.onListen=fc.bind(null,t.syncEngine),n.onUnlisten=gc.bind(null,t.syncEngine),n}function Hc(e,t,n={}){const r=new li;return e.asyncQueue.enqueueAndForget((async()=>function(e,t,n,r,i){const o=new Dc({next:n=>{t.enqueueAndForget((()=>nc(e,s))),n.fromCache&&"server"===r.source?i.reject(new ai(si.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):i.resolve(n)},error:e=>i.reject(e)}),s=new sc(n,o,{includeMetadataChanges:!0,Ku:!0});return tc(e,s)}(await zc(e),e.asyncQueue,t,n,r))),r.promise}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kc(e){const t={};return void 0!==e.timeoutSeconds&&(t.timeoutSeconds=e.timeoutSeconds),t
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}const Wc=new Map;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zc(e,t,n){if(!n)throw new ai(si.INVALID_ARGUMENT,`Function ${e}() cannot be called with an empty ${t}.`)}function Gc(e,t,n,r){if(!0===t&&!0===r)throw new ai(si.INVALID_ARGUMENT,`${e} and ${n} cannot be used together.`)}function Jc(e){if(!Ii.isDocumentKey(e))throw new ai(si.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${e} has ${e.length}.`)}function Qc(e){if(Ii.isDocumentKey(e))throw new ai(si.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${e} has ${e.length}.`)}function Yc(e){if(void 0===e)return"undefined";if(null===e)return"null";if("string"==typeof e)return e.length>20&&(e=`${e.substring(0,20)}...`),JSON.stringify(e);if("number"==typeof e||"boolean"==typeof e)return""+e;if("object"==typeof e){if(e instanceof Array)return"an array";{const t=function(e){return e.constructor?e.constructor.name:null}(e);return t?`a custom ${t} object`:"an object"}}return"function"==typeof e?"a function":ri()}function Xc(e,t){if("_delegate"in e&&(e=e._delegate),!(e instanceof t)){if(t.name===e.constructor.name)throw new ai(si.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const n=Yc(e);throw new ai(si.INVALID_ARGUMENT,`Expected type '${t.name}', but it was: ${n}`)}}return e}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ed{constructor(e){var t,n;if(void 0===e.host){if(void 0!==e.ssl)throw new ai(si.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=null===(t=e.ssl)||void 0===t||t;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.cache=e.localCache,void 0===e.cacheSizeBytes)this.cacheSizeBytes=41943040;else{if(-1!==e.cacheSizeBytes&&e.cacheSizeBytes<1048576)throw new ai(si.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}Gc("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:void 0===e.experimentalAutoDetectLongPolling?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Kc(null!==(n=e.experimentalLongPollingOptions)&&void 0!==n?n:{}),function(e){if(void 0!==e.timeoutSeconds){if(isNaN(e.timeoutSeconds))throw new ai(si.INVALID_ARGUMENT,`invalid long polling timeout: ${e.timeoutSeconds} (must not be NaN)`);if(e.timeoutSeconds<5)throw new ai(si.INVALID_ARGUMENT,`invalid long polling timeout: ${e.timeoutSeconds} (minimum allowed value is 5)`);if(e.timeoutSeconds>30)throw new ai(si.INVALID_ARGUMENT,`invalid long polling timeout: ${e.timeoutSeconds} (maximum allowed value is 30)`)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&(t=this.experimentalLongPollingOptions,n=e.experimentalLongPollingOptions,t.timeoutSeconds===n.timeoutSeconds)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams;var t,n}}class td{constructor(e,t,n,r){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=n,this._app=r,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new ed({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new ai(si.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return void 0!==this._terminateTask}_setSettings(e){if(this._settingsFrozen)throw new ai(si.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new ed(e),void 0!==e.credentials&&(this._authCredentials=function(e){if(!e)return new ci;switch(e.type){case"firstParty":return new pi(e.sessionIndex||"0",e.iamToken||null,e.authTokenFactory||null);case"provider":return e.client;default:throw new ai(si.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(e){const t=Wc.get(e);t&&(Xr("ComponentProvider","Removing Datastore"),Wc.delete(e),t.terminate())}(this),Promise.resolve()}}function nd(e,t,n,r={}){var i;const o=(e=Xc(e,td))._getSettings(),s=`${t}:${n}`;if("firestore.googleapis.com"!==o.host&&o.host!==s&&ti("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used."),e._setSettings(Object.assign(Object.assign({},o),{host:s,ssl:!1})),r.mockUserToken){let t,n;if("string"==typeof r.mockUserToken)t=r.mockUserToken,n=Gr.MOCK_USER;else{t=(0,a.Sg)(r.mockUserToken,null===(i=e._app)||void 0===i?void 0:i.options.projectId);const o=r.mockUserToken.sub||r.mockUserToken.user_id;if(!o)throw new ai(si.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");n=new Gr(o)}e._authCredentials=new di(new ui(t,n))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rd{constructor(e,t,n){this.converter=t,this._key=n,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new od(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new rd(this.firestore,e,this._key)}}class id{constructor(e,t,n){this.converter=t,this._query=n,this.type="query",this.firestore=e}withConverter(e){return new id(this.firestore,e,this._query)}}class od extends id{constructor(e,t,n){super(e,t,ss(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new rd(this.firestore,null,new Ii(e))}withConverter(e){return new od(this.firestore,e,this._path)}}function sd(e,t,...n){if(e=(0,a.m9)(e),Zc("collection","path",t),e instanceof td){const r=ki.fromString(t,...n);return Qc(r),new od(e,null,r)}{if(!(e instanceof rd||e instanceof od))throw new ai(si.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=e._path.child(ki.fromString(t,...n));return Qc(r),new od(e.firestore,null,r)}}function ad(e,t,...n){if(e=(0,a.m9)(e),1===arguments.length&&(t=yi.A()),Zc("doc","path",t),e instanceof td){const r=ki.fromString(t,...n);return Jc(r),new rd(e,null,new Ii(r))}{if(!(e instanceof rd||e instanceof od))throw new ai(si.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=e._path.child(ki.fromString(t,...n));return Jc(r),new rd(e.firestore,e instanceof od?e.converter:null,new Ii(r))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ld{constructor(){this.Gc=Promise.resolve(),this.Qc=[],this.jc=!1,this.zc=[],this.Wc=null,this.Hc=!1,this.Jc=!1,this.Yc=[],this.qo=new fu(this,"async_queue_retry"),this.Xc=()=>{const e=du();e&&Xr("AsyncQueue","Visibility state changed to "+e.visibilityState),this.qo.Mo()};const e=du();e&&"function"==typeof e.addEventListener&&e.addEventListener("visibilitychange",this.Xc)}get isShuttingDown(){return this.jc}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Zc(),this.ta(e)}enterRestrictedMode(e){if(!this.jc){this.jc=!0,this.Jc=e||!1;const t=du();t&&"function"==typeof t.removeEventListener&&t.removeEventListener("visibilitychange",this.Xc)}}enqueue(e){if(this.Zc(),this.jc)return new Promise((()=>{}));const t=new li;return this.ta((()=>this.jc&&this.Jc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise))).then((()=>t.promise))}enqueueRetryable(e){this.enqueueAndForget((()=>(this.Qc.push(e),this.ea())))}async ea(){if(0!==this.Qc.length){try{await this.Qc[0](),this.Qc.shift(),this.qo.reset()}catch(e){if(!Mi(e))throw e;Xr("AsyncQueue","Operation failed with retryable error: "+e)}this.Qc.length>0&&this.qo.No((()=>this.ea()))}}ta(e){const t=this.Gc.then((()=>(this.Hc=!0,e().catch((e=>{this.Wc=e,this.Hc=!1;const t=function(e){let t=e.message||"";return e.stack&&(t=e.stack.includes(e.message)?e.stack:e.message+"\n"+e.stack),t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(e);throw ei("INTERNAL UNHANDLED ERROR: ",t),e})).then((e=>(this.Hc=!1,e))))));return this.Gc=t,t}enqueueAfterDelay(e,t,n){this.Zc(),this.Yc.indexOf(e)>-1&&(t=0);const r=Zu.createAndSchedule(this,e,t,n,(e=>this.na(e)));return this.zc.push(r),r}Zc(){this.Wc&&ri()}verifyOperationInProgress(){}async sa(){let e;do{e=this.Gc,await e}while(e!==this.Gc)}ia(e){for(const t of this.zc)if(t.timerId===e)return!0;return!1}ra(e){return this.sa().then((()=>{this.zc.sort(((e,t)=>e.targetTimeMs-t.targetTimeMs));for(const t of this.zc)if(t.skipDelay(),"all"!==e&&t.timerId===e)break;return this.sa()}))}oa(e){this.Yc.push(e)}na(e){const t=this.zc.indexOf(e);this.zc.splice(t,1)}}class ud extends td{constructor(e,t,n,r){super(e,t,n,r),this.type="firestore",this._queue=new ld,this._persistenceKey=(null==r?void 0:r.name)||"[DEFAULT]"}_terminate(){return this._firestoreClient||hd(this),this._firestoreClient.terminate()}}function cd(e,t){const n="object"==typeof e?e:(0,i.Mq)(),r="string"==typeof e?e:t||"(default)",o=(0,i.qX)(n,"firestore").getImmediate({identifier:r});if(!o._initialized){const e=(0,a.P0)("firestore");e&&nd(o,...e)}return o}function dd(e){return e._firestoreClient||hd(e),e._firestoreClient.verifyNotTerminated(),e._firestoreClient}function hd(e){var t,n,r;const i=e._freezeSettings(),o=function(e,t,n,r){return new uo(e,t,n,r.host,r.ssl,r.experimentalForceLongPolling,r.experimentalAutoDetectLongPolling,Kc(r.experimentalLongPollingOptions),r.useFetchStreams)}(e._databaseId,(null===(t=e._app)||void 0===t?void 0:t.options.appId)||"",e._persistenceKey,i);e._firestoreClient=new Mc(e._authCredentials,e._appCheckCredentials,e._queue,o),(null===(n=i.cache)||void 0===n?void 0:n._offlineComponentProvider)&&(null===(r=i.cache)||void 0===r?void 0:r._onlineComponentProvider)&&(e._firestoreClient._uninitializedComponentsProvider={_offlineKind:i.cache.kind,_offline:i.cache._offlineComponentProvider,_online:i.cache._onlineComponentProvider})}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(e){this._byteString=e}static fromBase64String(e){try{return new fd(to.fromBase64String(e))}catch(e){throw new ai(si.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+e)}}static fromUint8Array(e){return new fd(to.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pd{constructor(...e){for(let t=0;t<e.length;++t)if(0===e[t].length)throw new ai(si.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Ci(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(e){this._methodName=e}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class md{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new ai(si.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new ai(si.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return bi(this._lat,e._lat)||bi(this._long,e._long)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vd=/^__.*__$/;class yd{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return null!==this.fieldMask?new la(e,this.data,this.fieldMask,t,this.fieldTransforms):new aa(e,this.data,t,this.fieldTransforms)}}class bd{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return new la(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function wd(e){switch(e){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw ri()}}class _d{constructor(e,t,n,r,i,o){this.settings=e,this.databaseId=t,this.serializer=n,this.ignoreUndefinedProperties=r,void 0===i&&this.ua(),this.fieldTransforms=i||[],this.fieldMask=o||[]}get path(){return this.settings.path}get ca(){return this.settings.ca}aa(e){return new _d(Object.assign(Object.assign({},this.settings),e),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}ha(e){var t;const n=null===(t=this.path)||void 0===t?void 0:t.child(e),r=this.aa({path:n,la:!1});return r.fa(e),r}da(e){var t;const n=null===(t=this.path)||void 0===t?void 0:t.child(e),r=this.aa({path:n,la:!1});return r.ua(),r}wa(e){return this.aa({path:void 0,la:!0})}_a(e){return Dd(e,this.settings.methodName,this.settings.ma||!1,this.path,this.settings.ga)}contains(e){return void 0!==this.fieldMask.find((t=>e.isPrefixOf(t)))||void 0!==this.fieldTransforms.find((t=>e.isPrefixOf(t.field)))}ua(){if(this.path)for(let e=0;e<this.path.length;e++)this.fa(this.path.get(e))}fa(e){if(0===e.length)throw this._a("Document fields must not be empty");if(wd(this.ca)&&vd.test(e))throw this._a('Document fields cannot begin and end with "__"')}}class Sd{constructor(e,t,n){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=n||hu(e)}ya(e,t,n,r=!1){return new _d({ca:e,methodName:t,ga:n,path:Ci.emptyPath(),la:!1,ma:r},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Ed(e){const t=e._freezeSettings(),n=hu(e._databaseId);return new Sd(e._databaseId,!!t.ignoreUndefinedProperties,n)}function kd(e,t,n,r,i,o={}){const s=e.ya(o.merge||o.mergeFields?2:0,t,n,i);Nd("Data must be an object, but it was:",s,r);const a=Rd(r,s);let l,u;if(o.merge)l=new Xi(s.fieldMask),u=s.fieldTransforms;else if(o.mergeFields){const e=[];for(const r of o.mergeFields){const i=Pd(t,r,n);if(!s.contains(i))throw new ai(si.INVALID_ARGUMENT,`Field '${i}' is specified in your field mask but missing from your input data.`);Md(e,i)||e.push(i)}l=new Xi(e),u=s.fieldTransforms.filter((e=>l.covers(e.field)))}else l=null,u=s.fieldTransforms;return new yd(new xo(a),l,u)}class Td extends gd{_toFieldTransform(e){if(2!==e.ca)throw 1===e.ca?e._a(`${this._methodName}() can only appear at the top level of your update data`):e._a(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof Td}}function Cd(e,t,n,r){const i=e.ya(1,t,n);Nd("Data must be an object, but it was:",i,r);const o=[],s=xo.empty();Ki(r,((e,r)=>{const l=Ld(t,e,n);r=(0,a.m9)(r);const u=i.da(l);if(r instanceof Td)o.push(l);else{const e=Ad(r,u);null!=e&&(o.push(l),s.set(l,e))}}));const l=new Xi(o);return new bd(s,l,i.fieldTransforms)}function Id(e,t,n,r,i,o){const s=e.ya(1,t,n),l=[Pd(t,r,n)],u=[i];if(o.length%2!=0)throw new ai(si.INVALID_ARGUMENT,`Function ${t}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let a=0;a<o.length;a+=2)l.push(Pd(t,o[a])),u.push(o[a+1]);const c=[],d=xo.empty();for(let f=l.length-1;f>=0;--f)if(!Md(c,l[f])){const e=l[f];let t=u[f];t=(0,a.m9)(t);const n=s.da(e);if(t instanceof Td)c.push(e);else{const r=Ad(t,n);null!=r&&(c.push(e),d.set(e,r))}}const h=new Xi(c);return new bd(d,h,s.fieldTransforms)}function xd(e,t,n,r=!1){return Ad(n,e.ya(r?4:3,t))}function Ad(e,t){if(Od(e=(0,a.m9)(e)))return Nd("Unsupported field value:",t,e),Rd(e,t);if(e instanceof gd)return function(e,t){if(!wd(t.ca))throw t._a(`${e._methodName}() can only be used with update() and set()`);if(!t.path)throw t._a(`${e._methodName}() is not currently supported inside arrays`);const n=e._toFieldTransform(t);n&&t.fieldTransforms.push(n)}(e,t),null;if(void 0===e&&t.ignoreUndefinedProperties)return null;if(t.path&&t.fieldMask.push(t.path),e instanceof Array){if(t.settings.la&&4!==t.ca)throw t._a("Nested arrays are not supported");return function(e,t){const n=[];let r=0;for(const i of e){let e=Ad(i,t.wa(r));null==e&&(e={nullValue:"NULL_VALUE"}),n.push(e),r++}return{arrayValue:{values:n}}}(e,t)}return function(e,t){if(null===(e=(0,a.m9)(e)))return{nullValue:"NULL_VALUE"};if("number"==typeof e)return qs(t.serializer,e);if("boolean"==typeof e)return{booleanValue:e};if("string"==typeof e)return{stringValue:e};if(e instanceof Date){const n=_i.fromDate(e);return{timestampValue:za(t.serializer,n)}}if(e instanceof _i){const n=new _i(e.seconds,1e3*Math.floor(e.nanoseconds/1e3));return{timestampValue:za(t.serializer,n)}}if(e instanceof md)return{geoPointValue:{latitude:e.latitude,longitude:e.longitude}};if(e instanceof fd)return{bytesValue:Ha(t.serializer,e._byteString)};if(e instanceof rd){const n=t.databaseId,r=e.firestore._databaseId;if(!r.isEqual(n))throw t._a(`Document reference is for database ${r.projectId}/${r.database} but should be for database ${n.projectId}/${n.database}`);return{referenceValue:Za(e.firestore._databaseId||t.databaseId,e._key.path)}}throw t._a(`Unsupported field value: ${Yc(e)}`)}(e,t)}function Rd(e,t){const n={};return Wi(e)?t.path&&t.path.length>0&&t.fieldMask.push(t.path):Ki(e,((e,r)=>{const i=Ad(r,t.ha(e));null!=i&&(n[e]=i)})),{mapValue:{fields:n}}}function Od(e){return!("object"!=typeof e||null===e||e instanceof Array||e instanceof Date||e instanceof _i||e instanceof md||e instanceof fd||e instanceof rd||e instanceof gd)}function Nd(e,t,n){if(!Od(n)||!function(e){return"object"==typeof e&&null!==e&&(Object.getPrototypeOf(e)===Object.prototype||null===Object.getPrototypeOf(e))}(n)){const r=Yc(n);throw"an object"===r?t._a(e+" a custom object"):t._a(e+" "+r)}}function Pd(e,t,n){if((t=(0,a.m9)(t))instanceof pd)return t._internalPath;if("string"==typeof t)return Ld(e,t);throw Dd("Field path arguments must be of type string or ",e,!1,void 0,n)}const Fd=new RegExp("[~\\*/\\[\\]]");function Ld(e,t,n){if(t.search(Fd)>=0)throw Dd(`Invalid field path (${t}). Paths must not contain '~', '*', '/', '[', or ']'`,e,!1,void 0,n);try{return new pd(...t.split("."))._internalPath}catch(r){throw Dd(`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,e,!1,void 0,n)}}function Dd(e,t,n,r,i){const o=r&&!r.isEmpty(),s=void 0!==i;let a=`Function ${t}() called with invalid data`;n&&(a+=" (via `toFirestore()`)"),a+=". ";let l="";return(o||s)&&(l+=" (found",o&&(l+=` in field ${r}`),s&&(l+=` in document ${i}`),l+=")"),new ai(si.INVALID_ARGUMENT,a+e+l)}function Md(e,t){return e.some((e=>e.isEqual(t)))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qd{constructor(e,t,n,r,i){this._firestore=e,this._userDataWriter=t,this._key=n,this._document=r,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new rd(this._firestore,this._converter,this._key)}exists(){return null!==this._document}data(){if(this._document){if(this._converter){const e=new Vd(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){const t=this._document.data.field(Ud("DocumentSnapshot.get",e));if(null!==t)return this._userDataWriter.convertValue(t)}}}class Vd extends qd{data(){return super.data()}}function Ud(e,t){return"string"==typeof t?Ld(e,t):t instanceof pd?t._internalPath:t._delegate._internalPath}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bd(e){if("L"===e.limitType&&0===e.explicitOrderBy.length)throw new ai(si.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class $d{}class jd extends $d{}function zd(e,t,...n){let r=[];t instanceof $d&&r.push(t),r=r.concat(n),function(e){const t=e.filter((e=>e instanceof Wd)).length,n=e.filter((e=>e instanceof Hd)).length;if(t>1||t>0&&n>0)throw new ai(si.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(r);for(const i of r)e=i._apply(e);return e}class Hd extends jd{constructor(e,t,n){super(),this._field=e,this._op=t,this._value=n,this.type="where"}static _create(e,t,n){return new Hd(e,t,n)}_apply(e){const t=this._parse(e);return Jd(e._query,t),new id(e.firestore,e.converter,fs(e._query,t))}_parse(e){const t=Ed(e.firestore),n=function(e,t,n,r,i,o,s){let a;if(i.isKeyField()){if("array-contains"===o||"array-contains-any"===o)throw new ai(si.INVALID_ARGUMENT,`Invalid Query. You can't perform '${o}' queries on documentId().`);if("in"===o||"not-in"===o){Gd(s,o);const t=[];for(const n of s)t.push(Zd(r,e,n));a={arrayValue:{values:t}}}else a=Zd(r,e,s)}else"in"!==o&&"not-in"!==o&&"array-contains-any"!==o||Gd(s,o),a=xd(n,t,s,"in"===o||"not-in"===o);return Mo.create(i,o,a)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value);return n}}function Kd(e,t,n){const r=t,i=Ud("where",e);return Hd._create(i,r,n)}class Wd extends $d{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Wd(e,t)}_parse(e){const t=this._queryConstraints.map((t=>t._parse(e))).filter((e=>e.getFilters().length>0));return 1===t.length?t[0]:qo.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return 0===t.getFilters().length?e:(function(e,t){let n=e;const r=t.getFlattenedFilters();for(const i of r)Jd(n,i),n=fs(n,i)}(e._query,t),new id(e.firestore,e.converter,fs(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return"and"===this.type?"and":"or"}}function Zd(e,t,n){if("string"==typeof(n=(0,a.m9)(n))){if(""===n)throw new ai(si.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!cs(t)&&-1!==n.indexOf("/"))throw new ai(si.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${n}' contains a '/' character.`);const r=t.path.child(ki.fromString(n));if(!Ii.isDocumentKey(r))throw new ai(si.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);return wo(e,new Ii(r))}if(n instanceof rd)return wo(e,n._key);throw new ai(si.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${Yc(n)}.`)}function Gd(e,t){if(!Array.isArray(e)||0===e.length)throw new ai(si.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${t.toString()}' filters.`)}function Jd(e,t){if(t.isInequality()){const n=us(e),r=t.field;if(null!==n&&!n.isEqual(r))throw new ai(si.INVALID_ARGUMENT,`Invalid query. All where filters with an inequality (<, <=, !=, not-in, >, or >=) must be on the same field. But you have inequality filters on '${n.toString()}' and '${r.toString()}'`);const i=ls(e);null!==i&&Qd(e,r,i)}const n=function(e,t){for(const n of e)for(const e of n.getFlattenedFilters())if(t.indexOf(e.op)>=0)return e.op;return null}(e.filters,function(e){switch(e){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(t.op));if(null!==n)throw n===t.op?new ai(si.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${t.op.toString()}' filter.`):new ai(si.INVALID_ARGUMENT,`Invalid query. You cannot use '${t.op.toString()}' filters with '${n.toString()}' filters.`)}function Qd(e,t,n){if(!n.isEqual(t))throw new ai(si.INVALID_ARGUMENT,`Invalid query. You have a where filter with an inequality (<, <=, !=, not-in, >, or >=) on field '${t.toString()}' and so you must also use '${t.toString()}' as your first argument to orderBy(), but your first orderBy() is on field '${n.toString()}' instead.`)}class Yd{convertValue(e,t="none"){switch(fo(e)){case 0:return null;case 1:return e.booleanValue;case 2:return io(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(oo(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 10:return this.convertObject(e.mapValue,t);default:throw ri()}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const n={};return Ki(e,((e,r)=>{n[e]=this.convertValue(r,t)})),n}convertGeoPoint(e){return new md(io(e.latitude),io(e.longitude))}convertArray(e,t){return(e.values||[]).map((e=>this.convertValue(e,t)))}convertServerTimestamp(e,t){switch(t){case"previous":const n=ao(e);return null==n?null:this.convertValue(n,t);case"estimate":return this.convertTimestamp(lo(e));default:return null}}convertTimestamp(e){const t=ro(e);return new _i(t.seconds,t.nanos)}convertDocumentKey(e,t){const n=ki.fromString(e);ii(yl(n));const r=new co(n.get(1),n.get(3)),i=new Ii(n.popFirst(5));return r.isEqual(t)||ei(`Document ${i} contains a document reference within a different database (${r.projectId}/${r.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xd(e,t,n){let r;return r=e?n&&(n.merge||n.mergeFields)?e.toFirestore(t,n):e.toFirestore(t):t,r}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class th extends qd{constructor(e,t,n,r,i,o){super(e,t,n,r,o),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new nh(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const n=this._document.data.field(Ud("DocumentSnapshot.get",e));if(null!==n)return this._userDataWriter.convertValue(n,t.serverTimestamps)}}}class nh extends th{data(e={}){return super.data(e)}}class rh{constructor(e,t,n,r){this._firestore=e,this._userDataWriter=t,this._snapshot=r,this.metadata=new eh(r.hasPendingWrites,r.fromCache),this.query=n}get docs(){const e=[];return this.forEach((t=>e.push(t))),e}get size(){return this._snapshot.docs.size}get empty(){return 0===this.size}forEach(e,t){this._snapshot.docs.forEach((n=>{e.call(t,new nh(this._firestore,this._userDataWriter,n.key,n,new eh(this._snapshot.mutatedKeys.has(n.key),this._snapshot.fromCache),this.query.converter))}))}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new ai(si.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(e,t){if(e._snapshot.oldDocs.isEmpty()){let t=0;return e._snapshot.docChanges.map((n=>{const r=new nh(e._firestore,e._userDataWriter,n.doc.key,n.doc,new eh(e._snapshot.mutatedKeys.has(n.doc.key),e._snapshot.fromCache),e.query.converter);return n.doc,{type:"added",doc:r,oldIndex:-1,newIndex:t++}}))}{let n=e._snapshot.oldDocs;return e._snapshot.docChanges.filter((e=>t||3!==e.type)).map((t=>{const r=new nh(e._firestore,e._userDataWriter,t.doc.key,t.doc,new eh(e._snapshot.mutatedKeys.has(t.doc.key),e._snapshot.fromCache),e.query.converter);let i=-1,o=-1;return 0!==t.type&&(i=n.indexOf(t.doc.key),n=n.delete(t.doc.key)),1!==t.type&&(n=n.add(t.doc),o=n.indexOf(t.doc.key)),{type:ih(t.type),doc:r,oldIndex:i,newIndex:o}}))}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}}function ih(e){switch(e){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return ri()}}class oh extends Yd{constructor(e){super(),this.firestore=e}convertBytes(e){return new fd(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new rd(this.firestore,null,t)}}function sh(e){e=Xc(e,id);const t=Xc(e.firestore,ud),n=dd(t),r=new oh(t);return Bd(e._query),Hc(n,e._query).then((n=>new rh(t,r,e,n)))}function ah(e,t,n,...r){e=Xc(e,rd);const i=Xc(e.firestore,ud),o=Ed(i);let s;return s="string"==typeof(t=(0,a.m9)(t))||t instanceof pd?Id(o,"updateDoc",e._key,t,n,r):Cd(o,"updateDoc",e._key,t),uh(i,[s.toMutation(e._key,Xs.exists(!0))])}function lh(e,t){const n=Xc(e.firestore,ud),r=ad(e),i=Xd(e.converter,t);return uh(n,[kd(Ed(e.firestore),"addDoc",r._key,i,null!==e.converter,{}).toMutation(r._key,Xs.exists(!1))]).then((()=>r))}function uh(e,t){return function(e,t){const n=new li;return e.asyncQueue.enqueueAndForget((async()=>mc(await jc(e),t,n))),n.promise}(dd(e),t)}!function(e,t=!0){!function(e){Jr=e}(i.Jn),(0,i.Xd)(new o.wA("firestore",((e,{instanceIdentifier:n,options:r})=>{const i=e.getProvider("app").getImmediate(),o=new ud(new hi(e.getProvider("auth-internal")),new mi(e.getProvider("app-check-internal")),function(e,t){if(!Object.prototype.hasOwnProperty.apply(e.options,["projectId"]))throw new ai(si.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new co(e.options.projectId,t)}(i,n),i);return r=Object.assign({useFetchStreams:t},r),o._setSettings(r),o}),"PUBLIC").setMultipleInstances(!0)),(0,i.KN)(Zr,"3.12.2",e),(0,i.KN)(Zr,"3.12.2","esm2017")}()},147:(e,t,n)=>{"use strict";n.d(t,{Jt:()=>rt,cF:()=>ot,iH:()=>it,KV:()=>nt});var r=n(8897),i=n(5505),o=n(3513);
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const s="firebasestorage.googleapis.com",a="storageBucket",l=12e4,u=6e5;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class c extends i.ZR{constructor(e,t,n=0){super(f(e),`Firebase Storage: ${t} (${f(e)})`),this.status_=n,this.customData={serverResponse:null},this._baseMessage=this.message,Object.setPrototypeOf(this,c.prototype)}get status(){return this.status_}set status(e){this.status_=e}_codeEquals(e){return f(e)===this.code}get serverResponse(){return this.customData.serverResponse}set serverResponse(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=`${this._baseMessage}\n${this.customData.serverResponse}`:this.message=this._baseMessage}}var d,h;function f(e){return"storage/"+e}function p(){const e="An unknown error occurred, please check the error payload for server response.";return new c(d.UNKNOWN,e)}function g(e){return new c(d.OBJECT_NOT_FOUND,"Object '"+e+"' does not exist.")}function m(e){return new c(d.QUOTA_EXCEEDED,"Quota for bucket '"+e+"' exceeded, please view quota on https://firebase.google.com/pricing/.")}function v(){const e="User is not authenticated, please authenticate using Firebase Authentication and try again.";return new c(d.UNAUTHENTICATED,e)}function y(){return new c(d.UNAUTHORIZED_APP,"This app does not have permission to access Firebase Storage on this project.")}function b(e){return new c(d.UNAUTHORIZED,"User does not have permission to access '"+e+"'.")}function w(){return new c(d.RETRY_LIMIT_EXCEEDED,"Max retry time for operation exceeded, please try again.")}function _(){return new c(d.CANCELED,"User canceled the upload/download.")}function S(e){return new c(d.INVALID_URL,"Invalid URL '"+e+"'.")}function E(e){return new c(d.INVALID_DEFAULT_BUCKET,"Invalid default bucket '"+e+"'.")}function k(){return new c(d.NO_DEFAULT_BUCKET,"No default bucket found. Did you set the '"+a+"' property when initializing the app?")}function T(){return new c(d.CANNOT_SLICE_BLOB,"Cannot slice blob for upload. Please retry the upload.")}function C(){return new c(d.NO_DOWNLOAD_URL,"The given file does not have any download URLs.")}function I(e){return new c(d.UNSUPPORTED_ENVIRONMENT,`${e} is missing. Make sure to install the required polyfills. See https://firebase.google.com/docs/web/environments-js-sdk#polyfills for more information.`)}function x(e){return new c(d.INVALID_ARGUMENT,e)}function A(){return new c(d.APP_DELETED,"The Firebase app was deleted.")}function R(e){return new c(d.INVALID_ROOT_OPERATION,"The operation '"+e+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}function O(e,t){return new c(d.INVALID_FORMAT,"String does not match format '"+e+"': "+t)}function N(e){throw new c(d.INTERNAL_ERROR,"Internal error: "+e)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(function(e){e["UNKNOWN"]="unknown",e["OBJECT_NOT_FOUND"]="object-not-found",e["BUCKET_NOT_FOUND"]="bucket-not-found",e["PROJECT_NOT_FOUND"]="project-not-found",e["QUOTA_EXCEEDED"]="quota-exceeded",e["UNAUTHENTICATED"]="unauthenticated",e["UNAUTHORIZED"]="unauthorized",e["UNAUTHORIZED_APP"]="unauthorized-app",e["RETRY_LIMIT_EXCEEDED"]="retry-limit-exceeded",e["INVALID_CHECKSUM"]="invalid-checksum",e["CANCELED"]="canceled",e["INVALID_EVENT_NAME"]="invalid-event-name",e["INVALID_URL"]="invalid-url",e["INVALID_DEFAULT_BUCKET"]="invalid-default-bucket",e["NO_DEFAULT_BUCKET"]="no-default-bucket",e["CANNOT_SLICE_BLOB"]="cannot-slice-blob",e["SERVER_FILE_WRONG_SIZE"]="server-file-wrong-size",e["NO_DOWNLOAD_URL"]="no-download-url",e["INVALID_ARGUMENT"]="invalid-argument",e["INVALID_ARGUMENT_COUNT"]="invalid-argument-count",e["APP_DELETED"]="app-deleted",e["INVALID_ROOT_OPERATION"]="invalid-root-operation",e["INVALID_FORMAT"]="invalid-format",e["INTERNAL_ERROR"]="internal-error",e["UNSUPPORTED_ENVIRONMENT"]="unsupported-environment"})(d||(d={}));class P{constructor(e,t){this.bucket=e,this.path_=t}get path(){return this.path_}get isRoot(){return 0===this.path.length}fullServerUrl(){const e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)}bucketOnlyServerUrl(){const e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o"}static makeFromBucketSpec(e,t){let n;try{n=P.makeFromUrl(e,t)}catch(r){return new P(e,"")}if(""===n.path)return n;throw E(e)}static makeFromUrl(e,t){let n=null;const r="([A-Za-z0-9.\\-_]+)";function i(e){"/"===e.path.charAt(e.path.length-1)&&(e.path_=e.path_.slice(0,-1))}const o="(/(.*))?$",a=new RegExp("^gs://"+r+o,"i"),l={bucket:1,path:3};function u(e){e.path_=decodeURIComponent(e.path)}const c="v[A-Za-z0-9_]+",d=t.replace(/[.]/g,"\\."),h="(/([^?#]*).*)?$",f=new RegExp(`^https?://${d}/${c}/b/${r}/o${h}`,"i"),p={bucket:1,path:3},g=t===s?"(?:storage.googleapis.com|storage.cloud.google.com)":t,m="([^?#]*)",v=new RegExp(`^https?://${g}/${r}/${m}`,"i"),y={bucket:1,path:2},b=[{regex:a,indices:l,postModify:i},{regex:f,indices:p,postModify:u},{regex:v,indices:y,postModify:u}];for(let s=0;s<b.length;s++){const t=b[s],r=t.regex.exec(e);if(r){const e=r[t.indices.bucket];let i=r[t.indices.path];i||(i=""),n=new P(e,i),t.postModify(n);break}}if(null==n)throw S(e);return n}}class F{constructor(e){this.promise_=Promise.reject(e)}getPromise(){return this.promise_}cancel(e=!1){}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function L(e,t,n){let r=1,i=null,o=null,s=!1,a=0;function l(){return 2===a}let u=!1;function c(...e){u||(u=!0,t.apply(null,e))}function d(t){i=setTimeout((()=>{i=null,e(f,l())}),t)}function h(){o&&clearTimeout(o)}function f(e,...t){if(u)return void h();if(e)return h(),void c.call(null,e,...t);const n=l()||s;if(n)return h(),void c.call(null,e,...t);let i;r<64&&(r*=2),1===a?(a=2,i=0):i=1e3*(r+Math.random()),d(i)}let p=!1;function g(e){p||(p=!0,h(),u||(null!==i?(e||(a=2),clearTimeout(i),d(0)):e||(a=1)))}return d(0),o=setTimeout((()=>{s=!0,g(!0)}),n),g}function D(e){e(!1)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function M(e){return void 0!==e}function q(e){return"object"===typeof e&&!Array.isArray(e)}function V(e){return"string"===typeof e||e instanceof String}function U(e){return B()&&e instanceof Blob}function B(){return"undefined"!==typeof Blob&&!(0,i.UG)()}function $(e,t,n,r){if(r<t)throw x(`Invalid value for '${e}'. Expected ${t} or greater.`);if(r>n)throw x(`Invalid value for '${e}'. Expected ${n} or less.`)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function j(e,t,n){let r=t;return null==n&&(r=`https://${t}`),`${n}://${r}/v0${e}`}function z(e){const t=encodeURIComponent;let n="?";for(const r in e)if(e.hasOwnProperty(r)){const i=t(r)+"="+t(e[r]);n=n+i+"&"}return n=n.slice(0,-1),n}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function H(e,t){const n=e>=500&&e<600,r=[408,429],i=-1!==r.indexOf(e),o=-1!==t.indexOf(e);return n||i||o}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(function(e){e[e["NO_ERROR"]=0]="NO_ERROR",e[e["NETWORK_ERROR"]=1]="NETWORK_ERROR",e[e["ABORT"]=2]="ABORT"})(h||(h={}));class K{constructor(e,t,n,r,i,o,s,a,l,u,c,d=!0){this.url_=e,this.method_=t,this.headers_=n,this.body_=r,this.successCodes_=i,this.additionalRetryCodes_=o,this.callback_=s,this.errorCallback_=a,this.timeout_=l,this.progressCallback_=u,this.connectionFactory_=c,this.retry=d,this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.promise_=new Promise(((e,t)=>{this.resolve_=e,this.reject_=t,this.start_()}))}start_(){const e=(e,t)=>{if(t)return void e(!1,new W(!1,null,!0));const n=this.connectionFactory_();this.pendingConnection_=n;const r=e=>{const t=e.loaded,n=e.lengthComputable?e.total:-1;null!==this.progressCallback_&&this.progressCallback_(t,n)};null!==this.progressCallback_&&n.addUploadProgressListener(r),n.send(this.url_,this.method_,this.body_,this.headers_).then((()=>{null!==this.progressCallback_&&n.removeUploadProgressListener(r),this.pendingConnection_=null;const t=n.getErrorCode()===h.NO_ERROR,i=n.getStatus();if(!t||H(i,this.additionalRetryCodes_)&&this.retry){const t=n.getErrorCode()===h.ABORT;return void e(!1,new W(!1,null,t))}const o=-1!==this.successCodes_.indexOf(i);e(!0,new W(o,n))}))},t=(e,t)=>{const n=this.resolve_,r=this.reject_,i=t.connection;if(t.wasSuccessCode)try{const e=this.callback_(i,i.getResponse());M(e)?n(e):n()}catch(o){r(o)}else if(null!==i){const e=p();e.serverResponse=i.getErrorText(),this.errorCallback_?r(this.errorCallback_(i,e)):r(e)}else if(t.canceled){const e=this.appDelete_?A():_();r(e)}else{const e=w();r(e)}};this.canceled_?t(!1,new W(!1,null,!0)):this.backoffId_=L(e,t,this.timeout_)}getPromise(){return this.promise_}cancel(e){this.canceled_=!0,this.appDelete_=e||!1,null!==this.backoffId_&&D(this.backoffId_),null!==this.pendingConnection_&&this.pendingConnection_.abort()}}class W{constructor(e,t,n){this.wasSuccessCode=e,this.connection=t,this.canceled=!!n}}function Z(e,t){null!==t&&t.length>0&&(e["Authorization"]="Firebase "+t)}function G(e,t){e["X-Firebase-Storage-Version"]="webjs/"+(null!==t&&void 0!==t?t:"AppManager")}function J(e,t){t&&(e["X-Firebase-GMPID"]=t)}function Q(e,t){null!==t&&(e["X-Firebase-AppCheck"]=t)}function Y(e,t,n,r,i,o,s=!0){const a=z(e.urlParams),l=e.url+a,u=Object.assign({},e.headers);return J(u,t),Z(u,n),G(u,o),Q(u,r),new K(l,e.method,u,e.body,e.successCodes,e.additionalRetryCodes,e.handler,e.errorHandler,e.timeout,e.progressCallback,i,s)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function X(){return"undefined"!==typeof BlobBuilder?BlobBuilder:"undefined"!==typeof WebKitBlobBuilder?WebKitBlobBuilder:void 0}function ee(...e){const t=X();if(void 0!==t){const n=new t;for(let t=0;t<e.length;t++)n.append(e[t]);return n.getBlob()}if(B())return new Blob(e);throw new c(d.UNSUPPORTED_ENVIRONMENT,"This browser doesn't seem to support creating Blobs")}function te(e,t,n){return e.webkitSlice?e.webkitSlice(t,n):e.mozSlice?e.mozSlice(t,n):e.slice?e.slice(t,n):null}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ne(e){if("undefined"===typeof atob)throw I("base-64");return atob(e)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const re={RAW:"raw",BASE64:"base64",BASE64URL:"base64url",DATA_URL:"data_url"};class ie{constructor(e,t){this.data=e,this.contentType=t||null}}function oe(e,t){switch(e){case re.RAW:return new ie(se(t));case re.BASE64:case re.BASE64URL:return new ie(le(e,t));case re.DATA_URL:return new ie(ce(t),de(t))}throw p()}function se(e){const t=[];for(let n=0;n<e.length;n++){let r=e.charCodeAt(n);if(r<=127)t.push(r);else if(r<=2047)t.push(192|r>>6,128|63&r);else if(55296===(64512&r)){const i=n<e.length-1&&56320===(64512&e.charCodeAt(n+1));if(i){const i=r,o=e.charCodeAt(++n);r=65536|(1023&i)<<10|1023&o,t.push(240|r>>18,128|r>>12&63,128|r>>6&63,128|63&r)}else t.push(239,191,189)}else 56320===(64512&r)?t.push(239,191,189):t.push(224|r>>12,128|r>>6&63,128|63&r)}return new Uint8Array(t)}function ae(e){let t;try{t=decodeURIComponent(e)}catch(n){throw O(re.DATA_URL,"Malformed data URL.")}return se(t)}function le(e,t){switch(e){case re.BASE64:{const n=-1!==t.indexOf("-"),r=-1!==t.indexOf("_");if(n||r){const t=n?"-":"_";throw O(e,"Invalid character '"+t+"' found: is it base64url encoded?")}break}case re.BASE64URL:{const n=-1!==t.indexOf("+"),r=-1!==t.indexOf("/");if(n||r){const t=n?"+":"/";throw O(e,"Invalid character '"+t+"' found: is it base64 encoded?")}t=t.replace(/-/g,"+").replace(/_/g,"/");break}}let n;try{n=ne(t)}catch(i){if(i.message.includes("polyfill"))throw i;throw O(e,"Invalid character found")}const r=new Uint8Array(n.length);for(let o=0;o<n.length;o++)r[o]=n.charCodeAt(o);return r}class ue{constructor(e){this.base64=!1,this.contentType=null;const t=e.match(/^data:([^,]+)?,/);if(null===t)throw O(re.DATA_URL,"Must be formatted 'data:[<mediatype>][;base64],<data>");const n=t[1]||null;null!=n&&(this.base64=he(n,";base64"),this.contentType=this.base64?n.substring(0,n.length-7):n),this.rest=e.substring(e.indexOf(",")+1)}}function ce(e){const t=new ue(e);return t.base64?le(re.BASE64,t.rest):ae(t.rest)}function de(e){const t=new ue(e);return t.contentType}function he(e,t){const n=e.length>=t.length;return!!n&&e.substring(e.length-t.length)===t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fe{constructor(e,t){let n=0,r="";U(e)?(this.data_=e,n=e.size,r=e.type):e instanceof ArrayBuffer?(t?this.data_=new Uint8Array(e):(this.data_=new Uint8Array(e.byteLength),this.data_.set(new Uint8Array(e))),n=this.data_.length):e instanceof Uint8Array&&(t?this.data_=e:(this.data_=new Uint8Array(e.length),this.data_.set(e)),n=e.length),this.size_=n,this.type_=r}size(){return this.size_}type(){return this.type_}slice(e,t){if(U(this.data_)){const n=this.data_,r=te(n,e,t);return null===r?null:new fe(r)}{const n=new Uint8Array(this.data_.buffer,e,t-e);return new fe(n,!0)}}static getBlob(...e){if(B()){const t=e.map((e=>e instanceof fe?e.data_:e));return new fe(ee.apply(null,t))}{const t=e.map((e=>V(e)?oe(re.RAW,e).data:e.data_));let n=0;t.forEach((e=>{n+=e.byteLength}));const r=new Uint8Array(n);let i=0;return t.forEach((e=>{for(let t=0;t<e.length;t++)r[i++]=e[t]})),new fe(r,!0)}}uploadData(){return this.data_}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pe(e){let t;try{t=JSON.parse(e)}catch(n){return null}return q(t)?t:null}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ge(e){if(0===e.length)return null;const t=e.lastIndexOf("/");if(-1===t)return"";const n=e.slice(0,t);return n}function me(e,t){const n=t.split("/").filter((e=>e.length>0)).join("/");return 0===e.length?n:e+"/"+n}function ve(e){const t=e.lastIndexOf("/",e.length-2);return-1===t?e:e.slice(t+1)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ye(e,t){return t}class be{constructor(e,t,n,r){this.server=e,this.local=t||e,this.writable=!!n,this.xform=r||ye}}let we=null;function _e(e){return!V(e)||e.length<2?e:ve(e)}function Se(){if(we)return we;const e=[];function t(e,t){return _e(t)}e.push(new be("bucket")),e.push(new be("generation")),e.push(new be("metageneration")),e.push(new be("name","fullPath",!0));const n=new be("name");function r(e,t){return void 0!==t?Number(t):t}n.xform=t,e.push(n);const i=new be("size");return i.xform=r,e.push(i),e.push(new be("timeCreated")),e.push(new be("updated")),e.push(new be("md5Hash",null,!0)),e.push(new be("cacheControl",null,!0)),e.push(new be("contentDisposition",null,!0)),e.push(new be("contentEncoding",null,!0)),e.push(new be("contentLanguage",null,!0)),e.push(new be("contentType",null,!0)),e.push(new be("metadata","customMetadata",!0)),we=e,we}function Ee(e,t){function n(){const n=e["bucket"],r=e["fullPath"],i=new P(n,r);return t._makeStorageReference(i)}Object.defineProperty(e,"ref",{get:n})}function ke(e,t,n){const r={type:"file"},i=n.length;for(let o=0;o<i;o++){const e=n[o];r[e.local]=e.xform(r,t[e.server])}return Ee(r,e),r}function Te(e,t,n){const r=pe(t);if(null===r)return null;const i=r;return ke(e,i,n)}function Ce(e,t,n,r){const i=pe(t);if(null===i)return null;if(!V(i["downloadTokens"]))return null;const o=i["downloadTokens"];if(0===o.length)return null;const s=encodeURIComponent,a=o.split(","),l=a.map((t=>{const i=e["bucket"],o=e["fullPath"],a="/b/"+s(i)+"/o/"+s(o),l=j(a,n,r),u=z({alt:"media",token:t});return l+u}));return l[0]}function Ie(e,t){const n={},r=t.length;for(let i=0;i<r;i++){const r=t[i];r.writable&&(n[r.server]=e[r.local])}return JSON.stringify(n)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xe{constructor(e,t,n,r){this.url=e,this.method=t,this.handler=n,this.timeout=r,this.urlParams={},this.headers={},this.body=null,this.errorHandler=null,this.progressCallback=null,this.successCodes=[200],this.additionalRetryCodes=[]}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ae(e){if(!e)throw p()}function Re(e,t){function n(n,r){const i=Te(e,r,t);return Ae(null!==i),i}return n}function Oe(e,t){function n(n,r){const i=Te(e,r,t);return Ae(null!==i),Ce(i,r,e.host,e._protocol)}return n}function Ne(e){function t(t,n){let r;return r=401===t.getStatus()?t.getErrorText().includes("Firebase App Check token is invalid")?y():v():402===t.getStatus()?m(e.bucket):403===t.getStatus()?b(e.path):n,r.status=t.getStatus(),r.serverResponse=n.serverResponse,r}return t}function Pe(e){const t=Ne(e);function n(n,r){let i=t(n,r);return 404===n.getStatus()&&(i=g(e.path)),i.serverResponse=r.serverResponse,i}return n}function Fe(e,t,n){const r=t.fullServerUrl(),i=j(r,e.host,e._protocol),o="GET",s=e.maxOperationRetryTime,a=new xe(i,o,Oe(e,n),s);return a.errorHandler=Pe(t),a}function Le(e,t){return e&&e["contentType"]||t&&t.type()||"application/octet-stream"}function De(e,t,n){const r=Object.assign({},n);return r["fullPath"]=e.path,r["size"]=t.size(),r["contentType"]||(r["contentType"]=Le(null,t)),r}function Me(e,t,n,r,i){const o=t.bucketOnlyServerUrl(),s={"X-Goog-Upload-Protocol":"multipart"};function a(){let e="";for(let t=0;t<2;t++)e+=Math.random().toString().slice(2);return e}const l=a();s["Content-Type"]="multipart/related; boundary="+l;const u=De(t,r,i),c=Ie(u,n),d="--"+l+"\r\nContent-Type: application/json; charset=utf-8\r\n\r\n"+c+"\r\n--"+l+"\r\nContent-Type: "+u["contentType"]+"\r\n\r\n",h="\r\n--"+l+"--",f=fe.getBlob(d,r,h);if(null===f)throw T();const p={name:u["fullPath"]},g=j(o,e.host,e._protocol),m="POST",v=e.maxUploadRetryTime,y=new xe(g,m,Re(e,n),v);return y.urlParams=p,y.headers=s,y.body=f.uploadData(),y.errorHandler=Ne(t),y}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let qe=null;class Ve{constructor(){this.sent_=!1,this.xhr_=new XMLHttpRequest,this.initXhr(),this.errorCode_=h.NO_ERROR,this.sendPromise_=new Promise((e=>{this.xhr_.addEventListener("abort",(()=>{this.errorCode_=h.ABORT,e()})),this.xhr_.addEventListener("error",(()=>{this.errorCode_=h.NETWORK_ERROR,e()})),this.xhr_.addEventListener("load",(()=>{e()}))}))}send(e,t,n,r){if(this.sent_)throw N("cannot .send() more than once");if(this.sent_=!0,this.xhr_.open(t,e,!0),void 0!==r)for(const i in r)r.hasOwnProperty(i)&&this.xhr_.setRequestHeader(i,r[i].toString());return void 0!==n?this.xhr_.send(n):this.xhr_.send(),this.sendPromise_}getErrorCode(){if(!this.sent_)throw N("cannot .getErrorCode() before sending");return this.errorCode_}getStatus(){if(!this.sent_)throw N("cannot .getStatus() before sending");try{return this.xhr_.status}catch(e){return-1}}getResponse(){if(!this.sent_)throw N("cannot .getResponse() before sending");return this.xhr_.response}getErrorText(){if(!this.sent_)throw N("cannot .getErrorText() before sending");return this.xhr_.statusText}abort(){this.xhr_.abort()}getResponseHeader(e){return this.xhr_.getResponseHeader(e)}addUploadProgressListener(e){null!=this.xhr_.upload&&this.xhr_.upload.addEventListener("progress",e)}removeUploadProgressListener(e){null!=this.xhr_.upload&&this.xhr_.upload.removeEventListener("progress",e)}}class Ue extends Ve{initXhr(){this.xhr_.responseType="text"}}function Be(){return qe?qe():new Ue}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(e,t){this._service=e,this._location=t instanceof P?t:P.makeFromUrl(t,e.host)}toString(){return"gs://"+this._location.bucket+"/"+this._location.path}_newRef(e,t){return new $e(e,t)}get root(){const e=new P(this._location.bucket,"");return this._newRef(this._service,e)}get bucket(){return this._location.bucket}get fullPath(){return this._location.path}get name(){return ve(this._location.path)}get storage(){return this._service}get parent(){const e=ge(this._location.path);if(null===e)return null;const t=new P(this._location.bucket,e);return new $e(this._service,t)}_throwIfRoot(e){if(""===this._location.path)throw R(e)}}function je(e,t,n){e._throwIfRoot("uploadBytes");const r=Me(e.storage,e._location,Se(),new fe(t,!0),n);return e.storage.makeRequestWithTokens(r,Be).then((t=>({metadata:t,ref:e})))}function ze(e){e._throwIfRoot("getDownloadURL");const t=Fe(e.storage,e._location,Se());return e.storage.makeRequestWithTokens(t,Be).then((e=>{if(null===e)throw C();return e}))}function He(e,t){const n=me(e._location.path,t),r=new P(e._location.bucket,n);return new $e(e.storage,r)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ke(e){return/^[A-Za-z]+:\/\//.test(e)}function We(e,t){return new $e(e,t)}function Ze(e,t){if(e instanceof Ye){const n=e;if(null==n._bucket)throw k();const r=new $e(n,n._bucket);return null!=t?Ze(r,t):r}return void 0!==t?He(e,t):e}function Ge(e,t){if(t&&Ke(t)){if(e instanceof Ye)return We(e,t);throw x("To use ref(service, url), the first argument must be a Storage instance.")}return Ze(e,t)}function Je(e,t){const n=null===t||void 0===t?void 0:t[a];return null==n?null:P.makeFromBucketSpec(n,e)}function Qe(e,t,n,r={}){e.host=`${t}:${n}`,e._protocol="http";const{mockUserToken:o}=r;o&&(e._overrideAuthToken="string"===typeof o?o:(0,i.Sg)(o,e.app.options.projectId))}class Ye{constructor(e,t,n,r,i){this.app=e,this._authProvider=t,this._appCheckProvider=n,this._url=r,this._firebaseVersion=i,this._bucket=null,this._host=s,this._protocol="https",this._appId=null,this._deleted=!1,this._maxOperationRetryTime=l,this._maxUploadRetryTime=u,this._requests=new Set,this._bucket=null!=r?P.makeFromBucketSpec(r,this._host):Je(this._host,this.app.options)}get host(){return this._host}set host(e){this._host=e,null!=this._url?this._bucket=P.makeFromBucketSpec(this._url,e):this._bucket=Je(e,this.app.options)}get maxUploadRetryTime(){return this._maxUploadRetryTime}set maxUploadRetryTime(e){$("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e}get maxOperationRetryTime(){return this._maxOperationRetryTime}set maxOperationRetryTime(e){$("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e}async _getAuthToken(){if(this._overrideAuthToken)return this._overrideAuthToken;const e=this._authProvider.getImmediate({optional:!0});if(e){const t=await e.getToken();if(null!==t)return t.accessToken}return null}async _getAppCheckToken(){const e=this._appCheckProvider.getImmediate({optional:!0});if(e){const t=await e.getToken();return t.token}return null}_delete(){return this._deleted||(this._deleted=!0,this._requests.forEach((e=>e.cancel())),this._requests.clear()),Promise.resolve()}_makeStorageReference(e){return new $e(this,e)}_makeRequest(e,t,n,r,i=!0){if(this._deleted)return new F(A());{const o=Y(e,this._appId,n,r,t,this._firebaseVersion,i);return this._requests.add(o),o.getPromise().then((()=>this._requests.delete(o)),(()=>this._requests.delete(o))),o}}async makeRequestWithTokens(e,t){const[n,r]=await Promise.all([this._getAuthToken(),this._getAppCheckToken()]);return this._makeRequest(e,t,n,r).getPromise()}}const Xe="@firebase/storage",et="0.11.2",tt="storage";function nt(e,t,n){return e=(0,i.m9)(e),je(e,t,n)}function rt(e){return e=(0,i.m9)(e),ze(e)}function it(e,t){return e=(0,i.m9)(e),Ge(e,t)}function ot(e=(0,r.Mq)(),t){e=(0,i.m9)(e);const n=(0,r.qX)(e,tt),o=n.getImmediate({identifier:t}),s=(0,i.P0)("storage");return s&&st(o,...s),o}function st(e,t,n,r={}){Qe(e,t,n,r)}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function at(e,{instanceIdentifier:t}){const n=e.getProvider("app").getImmediate(),i=e.getProvider("auth-internal"),o=e.getProvider("app-check-internal");return new Ye(n,i,o,t,r.Jn)}function lt(){(0,r.Xd)(new o.wA(tt,at,"PUBLIC").setMultipleInstances(!0)),(0,r.KN)(Xe,et,""),(0,r.KN)(Xe,et,"esm2017")}lt()}}]);